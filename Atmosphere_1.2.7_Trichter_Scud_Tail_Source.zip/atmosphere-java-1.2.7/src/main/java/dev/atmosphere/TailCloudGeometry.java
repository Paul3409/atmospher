package dev.atmosphere;

/** Continuous storm-relative tail; broad root is buried in the wall cloud. */
public final class TailCloudGeometry {
 private TailCloudGeometry(){}
 private static double[] pos(long seed,double s,double a,double r,double base,double growth,double tick){
  double length=r*(1.05+.35*WeatherCells.hash(seed,0,1811));
  double width=r*(.18*Math.pow(1-s,1.4)+.012*Math.sin(Math.PI*s));
  double flow=CloudNoise.billow(s*5+tick*.006,Math.cos(a),Math.sin(a),seed);
  width*=1+.28*flow;
  double along=.05*r-.28*length*s+.06*r*Math.sin(s*Math.PI);
  double across=-.35*r+length*s;
  double y=base-SupercellGeometry.lowering(growth)+19-18*s+7*Math.sin(s*Math.PI);
  return new double[]{along+Math.cos(a)*width/Math.sqrt(1.0784),y+Math.sin(a)*width*.38,
    across+Math.cos(a)*width*.28/Math.sqrt(1.0784)};
 }
 public static CloudGeometry.Point point(long seed,double s,double a,double r,double base,double growth,double tick){
  var p=pos(seed,s,a,r,base,growth,tick);var q=pos(seed,Math.min(1,s+.0001),a,r,base,growth,tick);
  var t=pos(seed,s,a+.0001,r,base,growth,tick);
  double x=t[0]-p[0],y=t[1]-p[1],z=t[2]-p[2],u=q[0]-p[0],v=q[1]-p[1],w=q[2]-p[2];
  double nx=y*w-z*v,ny=z*u-x*w,nz=x*v-y*u,n=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));
  return new CloudGeometry.Point(p[0],p[1],p[2],nx/n,ny/n,nz/n);
 }
}
