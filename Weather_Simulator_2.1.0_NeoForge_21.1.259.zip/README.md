# Weather Simulator 2.1.0

Sauberer Neubau für Minecraft 1.21.1, NeoForge 21.1.259 und Java 21. Die Mod besitzt keine eigenen Wolken, kein Radar, keine Wetterzellen und keine Klassen oder Konfigurationen aus Atmosphere Companion. Minecraft rendert seine Standardwolken unverändert.

## Bedienung

- `M`: Hauptmenü
- `R`: Zonenkarte
- Globales Wetter gilt außerhalb aller Zonen.
- Der Status unten im Menü nennt immer die tatsächlich wirksame Quelle, Oberflächenhöhe, Temperatur und Niederschlagsart.
- Neue Zonen werden auf der Karte gemalt. Linksklick malt, Radieren entfernt Flächen, Rechtsziehen verschiebt die Karte und das Mausrad zoomt.
- Neuere Zonen haben Vorrang. Eine kleine Zone mit `AUS` kann deshalb ein Haus aus einer größeren Schneezone aussparen.

## Niederschlagsmodelle

- `REGEN`, `SCHNEEREGEN`, `SCHNEE`: feste manuelle Art
- `NACH_SCHNEEFALLGRENZE`: Regen unterhalb, Schneeregen im frei einstellbaren Übergangsband und Schnee oberhalb
- `NACH_TEMPERATUR`: standardmäßig Schnee unter 0 °C, Schneeregen von 0 bis unter 1 °C und Regen ab 1 °C; beide Grenzen sind einstellbar

Temperatur bei Y 64 und Abkühlung pro 100 Höhenblöcke sind separat einstellbar. Alle Fallbahnen sind in Weltkoordinaten verankert und benutzen eine feste Höhe über dem jeweiligen Boden. Kamera- und Spielerhöhe verändern die Bahnen nicht.

## Schneedecke

Die optische Schneedecke sammelt sich bei Schneefall unter 0 °C an. Zwischen 0 und 1 °C taut sie langsam, oberhalb 1 °C schneller. Aufbau sowie beide Schmelzraten besitzen eigene Regler. Der Zustand wird getrennt pro Spielstand und Dimension gespeichert. Die Darstellung verändert keine Weltblöcke.

## Speicherung

Zonen und Schneedecke werden unter `config/weather-simulator/worlds/` getrennt für jeden Einzelspieler-Spielstand beziehungsweise Multiplayer-Server und jede Dimension gespeichert.

## Installation

`weather-simulator-neoforge-2.1.0.jar` in den Mods-Ordner einer Minecraft-1.21.1-Installation mit NeoForge 21.1.259 legen. Java 21 wird benötigt.
