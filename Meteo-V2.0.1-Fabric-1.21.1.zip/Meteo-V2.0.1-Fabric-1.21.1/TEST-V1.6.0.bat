@echo off
setlocal
cd /d "%~dp0"
echo Meteo V1.6.0 - kompletter Fabric Build
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
if errorlevel 1 (
  echo.
  echo FEHLER: Bitte die komplette CMD-Ausgabe an ChatGPT schicken.
) else (
  echo.
  echo BUILD SUCCESSFUL - Haupt-JAR liegt in build\libs
)
pause
