@echo off
setlocal
if not exist build\v151-tests mkdir build\v151-tests
javac -encoding UTF-8 -d build\v151-tests src\main\java\de\meteo\RegionalPhysics.java src\main\java\de\meteo\WeatherDynamics.java src\main\java\de\meteo\StationReading.java src\main\java\de\meteo\StationArchive.java src\main\java\de\meteo\StationWeather.java tests\de\meteo\V151StationTest.java
if errorlevel 1 exit /b 1
java -cp build\v151-tests de.meteo.V151StationTest
if errorlevel 1 exit /b 1
if not exist build\v151-packets mkdir build\v151-packets
javac -encoding UTF-8 -d build\v151-packets tests\v141-stubs\net\minecraft\util\Identifier.java tests\v141-stubs\net\minecraft\network\RegistryByteBuf.java tests\v141-stubs\net\minecraft\network\codec\PacketCodec.java tests\v141-stubs\net\minecraft\network\packet\CustomPayload.java src\main\java\de\meteo\RegionalPhysics.java src\main\java\de\meteo\WeatherDynamics.java src\main\java\de\meteo\StationReading.java src\main\java\de\meteo\StationArchive.java src\main\java\de\meteo\StationPagePayload.java src\main\java\de\meteo\StationRequestPayload.java tests\de\meteo\V151PacketTest.java
if errorlevel 1 exit /b 1
java -cp build\v151-packets de.meteo.V151PacketTest
if errorlevel 1 exit /b 1
python tests\V151SourceCheck.py
if errorlevel 1 exit /b 1
call TEST-V1.5.0.bat
