# Meteo V1.8.1 – Grafik-Bugfix

V1.8.1 korrigiert die übergroßen geometrischen Wolkendecken aus V1.8.0.

- Wolkenfelder werden nur noch moderat vergrößert.
- Front- und Regenwolken besitzen unregelmäßigere Ränder und Lücken.
- Große Wolkendecken halten mehr Abstand zum Gelände.
- Wolkenschatten variieren stärker über der Unterseite.
- Regen ist bei normaler Einstellung dichter.
- Der helle blau-graue Niederschlagsschleier wurde reduziert.

Das Welt- und Wolkenspeicherformat bleibt kompatibel.
