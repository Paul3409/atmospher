@echo off
setlocal
cd /d "%~dp0"
echo METEO V1.7.3 - Fabric 1.21.1 - Java 21
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
if errorlevel 1 (
 echo BUILD FEHLGESCHLAGEN - bitte die ERSTE Fehlermeldung senden.
) else (
 echo BUILD SUCCESSFUL - die Mod-JAR liegt in build\libs.
 echo Die -sources.jar NICHT in den mods-Ordner kopieren.
)
pause
