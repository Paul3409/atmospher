# METEO V1.7.1 – Wolkenoptimierung und bleibender Schnee

Minecraft Java 1.21.1, Fabric, Java 21. Vollständiges Projekt. Baut mit Gradle 8.14.6.

**Neu:** Die Wolkengruppierung nutzt in Ausgewogen/Stark eine räumliche Nachbarschaftssuche statt alle Wolkenpaarungen bei jedem Tick zu prüfen. Gruppen werden im Abstand von sechs bzw. zwölf Ticks ermittelt; Positionen, Wachstum und Ein-/Ausblenden bleiben pro Tick. Entfernte Wolken werden konservativ ausgeschlossen, wenn sie weit hinter der Kamera liegen. Formgebung und Wetterphysik sind unverändert. Einstellbar unter O -> Wolken.

**Schneedecke:** Meteo erzeugt echte Minecraft-Schneeschichten (bis acht Layer) an offenen Oberflächen innerhalb 50/75/100/150 Blöcken um jeden Spieler. Nur bereits geladene Chunks werden verändert. Je stärker Schnee fällt, desto häufiger wachsen die Schichten; Schneeregen lagert wenig ab. Unter 0 °C erfolgt kein temperaturbedingtes Abschmelzen; um 0 °C langsam, ab über +1 °C zunehmend. Unter O -> Schnee sind Radius, Ansammlung und Schmelze einstellbar und werden pro Welt gespeichert. Schneeblöcke selbst speichert Minecraft im Weltstand.

**Wichtig:** Der Bereich wird in kleinen zufällig ausgewählten 4×4-Patches nach und nach aktualisiert; keine sofortige flächendeckende Änderung auf jedem Block. Bis alle Flächen erfasst sind, kann es besonders bei 150 Blöcken eine Weile dauern. Bei nicht geladenen Chunks wird die Schneebildung erst fortgesetzt, wenn ein Spieler sie lädt; keine Chunk-Zwangsladung. Die Temperatur wird aus der örtlichen Atmosphäre des Spielers und einem Höhengradienten angenähert.

Keine Sounddateien. Die Wolken-Geometrie und die Regen-/Schneeflocken-Partikel bleiben erhalten.

**Prüfstatus:** Eigenständige Java-Tests für Schnee und Optimierungsregeln möglich; vollständiger Gradle-/Minecraft-Build muss lokal durchgeführt werden. Siehe `V1.7.1-TESTPLAN.md`.
