package de.meteo;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Server-owned persisted preferences; not client-only cosmetic settings. */
public final class WeatherSettingsStore {
    private WeatherSettingsStore(){}
    private static Path path(){return FabricLoader.getInstance().getConfigDir().resolve("meteo-weather.properties");}
    public static WeatherDynamics.Settings load(){
        try {
            if(!Files.isRegularFile(path()))return WeatherDynamics.DEFAULT;
            Properties p=new Properties();try(var in=Files.newInputStream(path())){p.load(in);}
            return new WeatherDynamics.Settings(Integer.parseInt(p.getProperty("pace","2")),
                Integer.parseInt(p.getProperty("windMode","0")),Integer.parseInt(p.getProperty("variability","65")),
                Integer.parseInt(p.getProperty("fixedFrom","270")),
                Integer.parseInt(p.getProperty("meanWindKmh","15")),Integer.parseInt(p.getProperty("maxGustKmh","50")));
        }catch(Exception e){MeteoMod.LOGGER.warn("Cannot read weather settings; using defaults",e);return WeatherDynamics.DEFAULT;}
    }
    public static void save(WeatherDynamics.Settings s){
        try {
            Properties p=new Properties();p.setProperty("pace",Integer.toString(s.pace()));
            p.setProperty("windMode",Integer.toString(s.windMode()));p.setProperty("variability",Integer.toString(s.variability()));
            p.setProperty("fixedFrom",Integer.toString(s.fixedFrom()));
            p.setProperty("meanWindKmh",Integer.toString(s.meanWindKmh()));
            p.setProperty("maxGustKmh",Integer.toString(s.maxGustKmh()));
            Files.createDirectories(path().getParent());try(var out=Files.newOutputStream(path())){p.store(out,"Meteo weather dynamics (server)");}
        }catch(Exception e){MeteoMod.LOGGER.warn("Cannot save weather settings",e);}
    }
}
