package de.meteo;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Versioned per-world station archive. Full history stays on disk; the GUI requests bounded pages. */
public final class StationArchive {
    public static final int PAGE_SIZE = 100;
    private static final int MAGIC = 0x4d535431, VERSION = 2;
    public static final class Station {
        public final UUID id;
        public final String dimension;
        public final long pos;
        public final List<StationReading> history = new ArrayList<>();
        public boolean active = true;
        public long lastTick = Long.MIN_VALUE;
        public Station(UUID id, String dimension, long pos) {
            this.id=id;this.dimension=dimension;this.pos=pos;
        }
        public StationReading latest() {return history.isEmpty()?null:history.get(history.size()-1);}
        public int pages() {return Math.max(1,(history.size()+PAGE_SIZE-1)/PAGE_SIZE);}
        public List<StationReading> page(int page) {
            int n=history.size(), start=Math.max(0,n-(page+1)*PAGE_SIZE), end=Math.max(0,n-page*PAGE_SIZE);
            if(page<0 || page>=pages())return List.of();
            return List.copyOf(history.subList(start,end));
        }
    }
    private final Map<UUID,Station> stations=new LinkedHashMap<>();
    public Collection<Station> all(){return Collections.unmodifiableCollection(stations.values());}
    public Station byId(UUID id){return stations.get(id);}
    public Station activeAt(String dimension,long pos){
        for(Station s:stations.values())if(s.active && s.pos==pos && s.dimension.equals(dimension))return s;
        return null;
    }
    public Station place(String dimension,long pos){
        Station existing=activeAt(dimension,pos);
        if(existing!=null)return existing;
        Station s=new Station(UUID.randomUUID(),dimension,pos);stations.put(s.id,s);return s;
    }
    public void remove(String dimension,long pos){
        Station s=activeAt(dimension,pos);if(s!=null)s.active=false; // Keep its entire historical archive.
    }
    public static StationArchive load(Path path) throws IOException {
        StationArchive a=new StationArchive();
        if(!Files.isRegularFile(path))return a;
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(path)))){
            if(in.readInt()!=MAGIC)throw new IOException("Invalid Meteo station archive");
            int version=in.readInt();if(version!=1&&version!=VERSION)throw new IOException("Unknown Meteo station archive version");
            int count=in.readInt();if(count<0 || count>100000)throw new IOException("Invalid station count");
            for(int i=0;i<count;i++){
                UUID id=new UUID(in.readLong(),in.readLong());String dimension=in.readUTF();long pos=in.readLong();
                Station s=new Station(id,dimension,pos);s.active=in.readBoolean();s.lastTick=in.readLong();
                int n=in.readInt();if(n<0 || n>10000000)throw new IOException("Invalid history size");
                for(int j=0;j<n;j++){
                    long tick=in.readLong();double temp=in.readDouble(),dew=in.readDouble(),press=in.readDouble();
                    double rain=in.readDouble(),total=in.readDouble(),wind=in.readDouble(),gust=in.readDouble();
                    double from=in.readDouble(),cover=in.readDouble();boolean estimated=in.readBoolean();
                    double snow=version>=2?in.readDouble():0,accSnow=version>=2?in.readDouble():0;
                    s.history.add(new StationReading(tick,temp,dew,press,rain,total,wind,gust,from,cover,estimated,snow,accSnow));
                }
                a.stations.put(id,s);
            }
        }
        return a;
    }
    public void save(Path path) throws IOException {
        Files.createDirectories(path.getParent());
        Path temp=path.resolveSibling(path.getFileName()+".tmp");
        try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)))){
            out.writeInt(MAGIC);out.writeInt(VERSION);out.writeInt(stations.size());
            for(Station s:stations.values()){
                out.writeLong(s.id.getMostSignificantBits());out.writeLong(s.id.getLeastSignificantBits());
                out.writeUTF(s.dimension);out.writeLong(s.pos);out.writeBoolean(s.active);out.writeLong(s.lastTick);
                out.writeInt(s.history.size());
                for(StationReading r:s.history){
                    out.writeLong(r.tick());out.writeDouble(r.temperature());out.writeDouble(r.dewPoint());
                    out.writeDouble(r.pressure());out.writeDouble(r.rainRate());out.writeDouble(r.rainTotal());
                    out.writeDouble(r.windSpeed());out.writeDouble(r.gustSpeed());out.writeDouble(r.windFrom());
                    out.writeDouble(r.cloudCover());out.writeBoolean(r.estimated());
                    out.writeDouble(r.snowRate());out.writeDouble(r.snowTotal());
                }
            }
        }
        try{Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
        catch(AtomicMoveNotSupportedException e){Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING);}
    }
}
