package de.meteo;

/** Deterministic, spatially anchored synoptic systems. All map and local effects use this source.
 * This is a simplified mesoscale model, not a forecast of the real atmosphere.
 */
public final class SynopticWeather {
    private SynopticWeather() {}
    /** 0..200 pressure strength, 0..3 duration, 0..200 front strength, warning and HUD toggles. */
    public record Settings(int highStrength,int lowStrength,int duration,int frontStrength,
                           int thunderFrequency,int stormStrength,boolean fronts,boolean hud,
                           boolean warnings,boolean isobars,boolean precip,boolean cloudFronts) {
        public Settings {
            highStrength=clamp(highStrength,0,200);lowStrength=clamp(lowStrength,0,200);
            duration=clamp(duration,0,3);frontStrength=clamp(frontStrength,0,200);
            thunderFrequency=clamp(thunderFrequency,0,200);stormStrength=clamp(stormStrength,0,200);
        }
    }
    public static final Settings DEFAULT=new Settings(100,100,1,100,100,100,true,true,true,true,true,true);
    public record State(double pressureHpa,double pressureOffset,double frontIntensity,byte frontType,
                        double humidityFactor,double temperatureOffset,double windU,double windV) {}
    private static int clamp(int value,int lo,int hi){return Math.max(lo,Math.min(hi,value));}
    private static double clamp(double value,double lo,double hi){return Math.max(lo,Math.min(hi,value));}
    private static double gauss(double x){return Math.exp(-x*x);}
    private static double wrapAngle(double a){return Math.atan2(Math.sin(a),Math.cos(a));}
    /** Front arms join at a common occluded head, rather than three crossing spirals. */
    private static double armAngle(double d,double rotation,byte type){
        double s=(d-400)/1700.0;
        return rotation+.25+(type==2?.58*s:type==1?-.43*s:.22*s);
    }
    private static double frontBand(double d,double angle,double rotation,byte type){
        double lo=type==3?210:410,hi=type==3?590:2350;
        if(d<lo||d>hi)return 0;
        double distance=Math.abs(wrapAngle(angle-armAngle(d,rotation,type)))*Math.max(250,d);
        double width=type==1?260:type==2?210:185;
        double endFade=Math.min(1,Math.min((d-lo)/180.0,(hi-d)/180.0));
        return gauss(distance/width)*clamp(endFade,0,1);
    }
    public record FrontPoint(float x,float z,byte type) {}
    /** Continuous radar polylines sampled from the exact world-space front geometry. */
    public static java.util.List<java.util.List<FrontPoint>> paths(double seconds,double minX,double minZ,
                    double maxX,double maxZ,Settings config){
        java.util.List<java.util.List<FrontPoint>> paths=new java.util.ArrayList<>();
        if(!config.fronts()||config.frontStrength()==0)return paths;
        double rate=new double[]{1.6,1.0,.66,.40}[config.duration()];
        double t=seconds*rate,shiftX=t*.010,shiftZ=t*.007;
        int minCx=(int)Math.floor((minX-2600-shiftX)/3200)-1;
        int maxCx=(int)Math.floor((maxX+2600-shiftX)/3200)+1;
        int minCz=(int)Math.floor((minZ-2600-shiftZ)/3200)-1;
        int maxCz=(int)Math.floor((maxZ+2600-shiftZ)/3200)+1;
        for(int cx=minCx;cx<=maxCx;cx++)for(int cz=minCz;cz<=maxCz;cz++){
            if(Math.floorMod(cx+cz,2)!=0)continue;
            double sx=(cx+.5)*3200+shiftX+Math.sin(cx*1.7+cz*.8)*380;
            double sz=(cz+.5)*3200+shiftZ+Math.cos(cx*.8-cz*2.1)*410;
            appendPaths(paths,sx,sz,t/42000+cx*.33-cz*.27,minX,minZ,maxX,maxZ);
        }
        for(var manual:SynopticRuntime.centres())if(manual.low()){
            double sx=manual.x()+(seconds-manual.createdAt())*.002;
            double sz=manual.z()+(seconds-manual.createdAt())*.001;
            appendPaths(paths,sx,sz,(seconds-manual.createdAt())/42000+.30,minX,minZ,maxX,maxZ);
        }
        return paths;
    }
    private static void appendPaths(java.util.List<java.util.List<FrontPoint>> paths,double sx,double sz,
                       double rotation,double x0,double z0,double x1,double z1){
        for(byte type=1;type<=3;type++){
            int lo=type==3?210:410,hi=type==3?590:2350;
            java.util.ArrayList<FrontPoint> current=new java.util.ArrayList<>();
            for(int d=lo;d<=hi;d+=40){
                double a=armAngle(d,rotation,type);
                double x=sx+Math.cos(a)*d,z=sz+Math.sin(a)*d;
                boolean inside=x>=x0&&x<=x1&&z>=z0&&z<=z1;
                if(inside)current.add(new FrontPoint((float)x,(float)z,type));
                else if(!current.isEmpty()){
                    if(current.size()>1)paths.add(java.util.List.copyOf(current));
                    current.clear();
                }
            }
            if(current.size()>1)paths.add(java.util.List.copyOf(current));
        }
    }
    /** Advance zone extends beyond the actual front and does not require seeded cloud cells. */
    public static double frontalVeil(double seconds,double x,double z,Settings config){
        if(!config.fronts()||!config.cloudFronts())return 0;
        double front=at(seconds,x,z,config).frontIntensity();
        double near=front;
        // A cheap footprint of the advancing band (roughly 400-700 blocks ahead).
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
            if(dx==0&&dz==0)continue;
            near=Math.max(near,at(seconds,x+dx*350,z+dz*350,config).frontIntensity()*.68);
        }
        return clamp(Math.max(front,near),0,1);
    }
    /** World X east, Z south; evolving patterns are world-anchored and independent of player location. */
    public static State at(double seconds,double x,double z,Settings config){
        double rate=new double[]{1.6,1.0,.66,.40}[config.duration()];
        double t=seconds*rate;
        var air=AirMassPhysics.at(t,x,z);
        double pressure=0,storm=0,temperature=0,humidity=1,windU=0,windV=0;
        byte frontType=0;
        // 4.8-kiloblock cells: persistent, slowly travelling alternating pressure centres.
        double shiftX=t*.010,shiftZ=t*.007;
        int ix=(int)Math.floor((x-shiftX)/3200),iz=(int)Math.floor((z-shiftZ)/3200);
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
            int cx=ix+dx,cz=iz+dz;
            double wiggle=Math.sin(cx*14.3+cz*27.1);
            double sx=(cx+.5)*3200+shiftX+Math.sin(cx*1.7+cz*.8)*380;
            double sz=(cz+.5)*3200+shiftZ+Math.cos(cx*.8-cz*2.1)*410;
            double xx=x-sx,zz=z-sz,d=Math.hypot(xx,zz);
            boolean low=Math.floorMod(cx+cz,2)==0;
            double strength=(low?config.lowStrength():config.highStrength())/100.0;
            double radius=1720+wiggle*180;
            // Synoptic isobars follow slowly rotating, asymmetric pressure
            // lobes instead of perfect mathematical circles. Every radar and
            // local barometer samples this SAME pressure function.
            double azimuth=Math.atan2(zz,xx);
            double warp=1+.095*Math.sin(3*azimuth+cx*.67-cz*.31+t/38000.0)
                +.045*Math.sin(5*azimuth-cx*.19+cz*.24-t/53000.0);
            double weight=gauss(d*warp/radius);
            pressure+=(low?-10.5:9.5)*strength*weight;
            // Around lows: cyclonic circulation, around highs: anticyclonic circulation.
            double influence=4.5*weight*strength/Math.max(240,d);
            windU+=(low?-zz:zz)*influence;
            windV+=(low?xx:-xx)*influence;
            if(!low||!config.fronts())continue;
            // One common, connected three-arm geometry. The same geometric
            // centre lines are transmitted to the radar as continuous paths.
            double a=Math.atan2(zz,xx);
            double rotation=t/42000+cx*.33-cz*.27;
            double fc=frontBand(d,a,rotation,(byte)2);
            double fw=frontBand(d,a,rotation,(byte)1);
            double fo=frontBand(d,a,rotation,(byte)3);
            double band=Math.max(fc,Math.max(fw,fo));
            byte kind=fc>=fw&&fc>=fo?(byte)2:fw>=fo?(byte)1:(byte)3;
            if(band>storm){storm=band;frontType=kind;}
            temperature+=weight*(low?-1.2:1.5)*strength;
        }
        // Operator-created centres are world-local, capped and saved. They are real forcing,
        // not merely labels drawn on the radar.
        for(var manual:SynopticRuntime.centres()){
            double xx=x-manual.x()-(seconds-manual.createdAt())*.002;
            double zz=z-manual.z()-(seconds-manual.createdAt())*.001;
            double d=Math.hypot(xx,zz),weight=gauss(d/1600.0);
            double strength=(manual.low()?config.lowStrength():config.highStrength())/100.0;
            pressure+=(manual.low()?-13:12)*strength*weight;
            double swirl=4.0*weight*strength/Math.max(240,d);
            windU+=(manual.low()?-zz:zz)*swirl;
            windV+=(manual.low()?xx:-xx)*swirl;
            if(manual.low()&&config.fronts()){
                double angle=Math.atan2(zz,xx);
                double rotation=(seconds-manual.createdAt())/42000+.30;
                double fc=frontBand(d,angle,rotation,(byte)2);
                double fw=frontBand(d,angle,rotation,(byte)1);
                double fo=frontBand(d,angle,rotation,(byte)3);
                double f=Math.max(fc,Math.max(fw,fo));
                if(f>storm){storm=f;frontType=fc>=fw&&fc>=fo?(byte)2:fw>=fo?(byte)1:(byte)3;}
            }
        }
        // Slowly varying synoptic troughs superimposed on the main pressure
        // centres produce bent, unevenly spaced isobars. This correction is
        // physical model data shared by radar and local barometers, not UI noise.
        pressure+=1.7*Math.sin(x/2100.0+t/83000.0)*Math.cos(z/1900.0-t/99000.0)
            +.9*Math.sin((x+z)/3500.0-t/116000.0);
        double convectiveSupport=clamp(.72+(1-air.stability())*.45,.60,1.15);
        storm=clamp(storm*config.frontStrength()/100.0*convectiveSupport,0,1);
        humidity=clamp((1+storm*.33)*air.humidity(),.65,1.42);
        temperature+=storm*(frontType==2?-2.1:frontType==1?1.2:-.4);
        // Fronts move with the same timebase used by the regional atmosphere.
        return new State(1013.25+pressure,pressure,storm,frontType,humidity,temperature,
                clamp(windU,-5,5),clamp(windV,-5,5));
    }
}
