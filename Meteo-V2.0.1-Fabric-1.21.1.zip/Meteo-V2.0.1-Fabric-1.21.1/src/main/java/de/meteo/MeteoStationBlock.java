package de.meteo;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Simple sensor block. The player can build the surrounding weather-station structure. */
public final class MeteoStationBlock extends Block {
    public MeteoStationBlock(Settings settings){super(settings);}
    @Override public void onPlaced(World world,BlockPos pos,BlockState state,LivingEntity placer,ItemStack stack){
        super.onPlaced(world,pos,state,placer,stack);
        if(!world.isClient && world instanceof net.minecraft.server.world.ServerWorld server)
            StationManager.place(server,pos);
    }
    @Override protected void onStateReplaced(BlockState state,World world,BlockPos pos,BlockState newState,boolean moved){
        if(!world.isClient && !state.isOf(newState.getBlock()) && world instanceof net.minecraft.server.world.ServerWorld server)
            StationManager.remove(server,pos);
        super.onStateReplaced(state,world,pos,newState,moved);
    }
}
