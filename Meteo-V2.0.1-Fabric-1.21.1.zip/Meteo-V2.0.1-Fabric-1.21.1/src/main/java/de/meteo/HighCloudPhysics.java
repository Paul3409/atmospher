package de.meteo;
/** Diagnostic high ice-cloud potential and bounded Minecraft-altitude layering. */
public final class HighCloudPhysics {
    private HighCloudPhysics() {}
    public static double iceContent(double upperRh,double tempC){
        if(!Double.isFinite(upperRh)||!Double.isFinite(tempC))return 0;
        double moist=Math.max(0,Math.min(1,(upperRh-.42)/.48));
        // This layer is high relative to the terrain; always thin compared to
        // convective condensate. Cold air allows longer-lasting ice filaments.
        double cold=Math.max(.45,Math.min(1,(-tempC+12)/37.0));
        return moist<=0?0:.18*moist+.62*moist*cold;
    }
    public static double cover(double ice){return Math.max(0,Math.min(.75,ice*.95));}
    public static double baseY(int worldTop,int ground,double humidity){
        // Avoid crossing the Minecraft height limit; stay above low decks.
        double high=Math.max(ground+82,232+humidity*30);
        return Math.max(ground+36,Math.min(worldTop-27,high));
    }
}
