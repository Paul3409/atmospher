package de.meteo;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
/** A bounded server-side synoptic forecast request. */
public record RadarForecastRequestPayload(int hours) implements CustomPayload {
    public static final Id<RadarForecastRequestPayload> ID=new Id<>(Identifier.of("meteo","forecast_request"));
    public static final PacketCodec<RegistryByteBuf,RadarForecastRequestPayload> CODEC=CustomPayload.codecOf(RadarForecastRequestPayload::write,RadarForecastRequestPayload::read);
    private void write(RegistryByteBuf b){b.writeVarInt(hours);}
    private static RadarForecastRequestPayload read(RegistryByteBuf b){return new RadarForecastRequestPayload(b.readVarInt());}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
