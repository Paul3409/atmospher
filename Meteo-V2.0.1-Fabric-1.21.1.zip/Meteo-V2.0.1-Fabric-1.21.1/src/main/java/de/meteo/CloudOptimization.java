package de.meteo;
/** Client-only cloud budget helpers. No weather or geometry physics changes. */
public final class CloudOptimization {
    private CloudOptimization(){}
    /** 0=off (legacy), 1=balanced, 2=strong. */
    public static int groupingInterval(int mode){return mode<=0?1:mode==1?6:12;}
    /** Cull only clouds far behind the camera, never nearby formations. */
    public static boolean hiddenBehind(double distance,double dot,int mode){
        return mode>0 && distance>400 && dot < -distance*(mode>=2?.32:.65);
    }
    /** Strong mode reduces detail only beyond the detailed near field. */
    public static int detail(int quality,double distance,int mode){
        int high=Math.max(0,quality);
        if(mode==2)return distance>420?0:distance>220?Math.min(high,1):high;
        return distance>480?0:distance>240?Math.min(high,1):high;
    }
    public static long bucket(double x,double z){
        long gx=(long)Math.floor(x/160),gz=(long)Math.floor(z/160);
        return (gx<<32)^(gz&0xffffffffL);
    }
}
