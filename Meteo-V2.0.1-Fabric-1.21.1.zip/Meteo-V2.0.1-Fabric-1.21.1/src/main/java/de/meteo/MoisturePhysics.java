package de.meteo;
/** Conservative transfer of a normalized water reservoir (vapor + cloud liquid).
 * All rates are illustrative and bounded, not a full atmospheric fluid model.
 */
public final class MoisturePhysics {
    private MoisturePhysics() {}
    public record Parcel(double vapor, double liquid) {
        public Parcel { if (!Double.isFinite(vapor)||!Double.isFinite(liquid)||vapor<0||liquid<0) throw new IllegalArgumentException("invalid water"); }
        public double total(){return vapor+liquid;}
    }
    public record Phase(Parcel parcel,double condensation,double evaporation,double precipitation) {}
    public static Parcel exchange(Parcel donor,Parcel receiver,double fraction){
        double f=Math.max(0,Math.min(1,fraction));
        return new Parcel(receiver.vapor()+donor.vapor()*f,receiver.liquid()+donor.liquid()*f);
    }
    public static Parcel retain(Parcel donor,double fraction){
        double f=Math.max(0,Math.min(1,fraction));
        return new Parcel(donor.vapor()*(1-f),donor.liquid()*(1-f));
    }
    public static Phase phase(Parcel old,double saturation,double lift,double seconds){
        double dt=Math.max(0,Math.min(120,seconds));
        double sat=Math.max(0.02,Math.min(1.5,saturation));
        double cond=Math.min(old.vapor(),Math.max(0,old.vapor()-sat)*Math.min(1,dt/120.0));
        double evap=Math.min(old.liquid(),Math.max(0,sat-(old.vapor()-cond))*Math.min(1,dt/210.0));
        double liquid=old.liquid()+cond-evap;
        double vapor=old.vapor()-cond+evap;
        // Precipitation is a documented water sink, unlike phase changes.
        // Small shower cores form under saturated, rising clouds. Subsidence
        // suppresses new precipitation; condensate remains conserved except for this sink.
        double strength=Math.min(1,Math.max(0,(lift-0.10)/0.65));
        double rain=lift>0.10&&liquid>0.29
            ? Math.min(liquid, (liquid-0.29)*strength*dt/2400.0) : 0;
        return new Phase(new Parcel(vapor,liquid-rain),cond,evap,rain);
    }
}
