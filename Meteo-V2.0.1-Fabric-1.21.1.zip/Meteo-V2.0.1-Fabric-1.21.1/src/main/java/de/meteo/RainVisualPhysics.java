package de.meteo;
/** Deterministic raindrop parameter ranges shared by P5.2 tests. */
public final class RainVisualPhysics {
    private RainVisualPhysics() {}
    /** 0 drizzle; 1 showers; 2 heavy rainfall (mm/h). */
    public static int stage(double mmHour){return mmHour<1.5?0:mmHour<7?1:2;}
    public static double fallSpeed(int stage,double r){
        return (.38+.24*Math.max(0,Math.min(2,stage)))+.20*Math.max(0,Math.min(1,r));
    }
    public static double width(int stage,int size,double r){
        return (.026+.021*Math.max(0,Math.min(2,size))+.012*Math.max(0,Math.min(2,stage)))*(.75+.5*r);
    }
    public static double length(int stage,int size,double r){
        return (.6+.32*Math.max(0,Math.min(2,size))+.40*Math.max(0,Math.min(2,stage)))*(.68+.64*r);
    }
}
