package de.meteo;

/** Projection for unloaded station chunks: keeps sampling without forcing chunk loads.
 * Marked as estimated in the archive; actual observations resume when the chunk loads.
 */
public final class StationWeather {
    private StationWeather(){}
    public static StationReading estimate(StationReading previous,long tick,int x,int z,WeatherDynamics.Settings settings){
        var now=WeatherDynamics.at(tick*3.6,x,z,settings);
        var before=WeatherDynamics.at(previous.tick()*3.6,x,z,settings);
        double dt=Math.max(0,tick-previous.tick());
        double seasonal=SeasonSystem.offsetC(tick)-SeasonSystem.offsetC(previous.tick());
        double temp=previous.temperature()+Math.max(-2.5,Math.min(2.5,now.temperatureOffset()-before.temperatureOffset()+seasonal));
        double dew=previous.dewPoint()+Math.max(-.7,Math.min(.7,(now.humidityFactor()-before.humidityFactor())*2));
        double pressure=previous.pressure()+Math.max(-1.5,Math.min(1.5,now.pressure()-before.pressure()));
        double u=now.targetU(),v=now.targetV(),wind=Math.hypot(u,v);
        double from=(Math.toDegrees(Math.atan2(-u,v))+360)%360;
        // Do not invent new remote showers. Last observed rain decays until local cloud data returns.
        double rain=previous.rainRate()*Math.exp(-dt/1800.0);
        double total=previous.rainTotal()+rain*dt/72000.0;
        double snow=previous.snowRate()*Math.exp(-dt/1800.0);
        double snowTotal=previous.snowTotal()+snow*dt/72000.0; // ticks -> hours: 72000 ticks/h
        double cover=previous.cloudCover()*Math.exp(-dt/12000.0);
        return new StationReading(tick,temp,dew,pressure,rain,total,wind,wind*1.25,from,cover,true,snow,snowTotal);
    }
}
