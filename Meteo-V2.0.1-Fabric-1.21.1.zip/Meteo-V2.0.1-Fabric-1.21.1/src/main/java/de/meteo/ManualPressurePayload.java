package de.meteo;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
/** Create a local high/low or clear user-created systems. Requires server OP or world owner. */
public record ManualPressurePayload(int action) implements CustomPayload {
    public static final Id<ManualPressurePayload> ID=new Id<>(Identifier.of("meteo","manual_pressure"));
    public static final PacketCodec<RegistryByteBuf,ManualPressurePayload> CODEC=CustomPayload.codecOf(ManualPressurePayload::write,ManualPressurePayload::read);
    private void write(RegistryByteBuf b){b.writeByte(action);}
    private static ManualPressurePayload read(RegistryByteBuf b){return new ManualPressurePayload(b.readByte());}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
