package de.meteo;

/** Conservative movement of *visible* low-cloud parcels across sampled terrain.
 * Mountains do not act as solid walls to air: parcels either lift modestly,
 * steer around a ridge, or remain on the windward side as fresh condensate forms.
 * Only previously loaded terrain columns may be supplied by the server.
 */
public final class TerrainCloudFlow {
    private TerrainCloudFlow(){}
    public record Route(double x,double z,double minimumBase,boolean obstructed,boolean stalled){}
    public static final double CLEARANCE=14;
    public static Route steer(double x,double z,double targetX,double targetZ,double base,
                              int ahead,int left,int right,double lift){
        double dx=targetX-x,dz=targetZ-z,step=Math.hypot(dx,dz);
        if(!Double.isFinite(base)||!Double.isFinite(step)||step<1e-6)
            return new Route(x,z,base,false,false);
        double needed=ahead+CLEARANCE;
        if(needed<=base)return new Route(targetX,targetZ,base,false,false);
        double rise=needed-base;
        // Gentle orographic ascent over a manageable ridge is physically valid.
        if(lift>.12&&rise<=20)return new Route(targetX,targetZ,needed,true,false);
        // Prefer the lower of two contours beside the wind direction. A small
        // lateral step looks like flowing around the hill, not teleporting.
        double crossX=-dz/step,crossZ=dx/step;
        double sideways=Math.min(2.5,step*.95);
        if(left+CLEARANCE<=base&&left+3<ahead)
            return new Route(x+dx*.18+crossX*sideways,z+dz*.18+crossZ*sideways,base,true,false);
        if(right+CLEARANCE<=base&&right+3<ahead)
            return new Route(x+dx*.18-crossX*sideways,z+dz*.18-crossZ*sideways,base,true,false);
        // Stationary upslope condensation: the cloud can continue precipitating
        // and evolving although its centroid does not penetrate the mountain.
        return new Route(x,z,base,true,true);
    }
    public static double clearBase(double base,int terrainHeight){
        return Math.max(base,terrainHeight+CLEARANCE);
    }
}
