package de.meteo;

/** Slow synoptic forcing shared by the atmosphere regions. Pure Java: testable without Minecraft. */
public final class WeatherDynamics {
    private WeatherDynamics() {}
    /** Weather pace: 0 quiet, 1 normal, 2 lively, 3 turbulent. Wind: 0 dynamic, 1 variable, 2 fixed. */
    public record Settings(int pace,int windMode,int variability,int fixedFrom,int meanWindKmh,int maxGustKmh) {
        /** Compatibility with existing weather settings and previous physics tests. */
        public Settings(int pace,int windMode,int variability,int fixedFrom){
            this(pace,windMode,variability,fixedFrom,15,50);
        }
        public Settings {
            pace=Math.max(0,Math.min(3,pace));
            windMode=Math.max(0,Math.min(2,windMode));
            variability=Math.max(0,Math.min(100,variability));
            fixedFrom=Math.floorMod((int)Math.round(fixedFrom/45.0)*45,360);
            meanWindKmh=Math.max(0,Math.min(100,meanWindKmh));
            maxGustKmh=Math.max(0,Math.min(160,maxGustKmh));
        }
    }
    public static final Settings DEFAULT=new Settings(2,0,65,270);
    public record State(double targetU,double targetV,double pressure,double humidityFactor,double temperatureOffset) {}
    public static State at(double simulatedSeconds,double x,double z,Settings settings){
        // 1 real second = 72 simulated seconds in the existing Meteo clock.
        // Synoptic periods thus last many real minutes, not a few ticks.
        double pace=new double[]{0.50,0.78,1.0,1.42}[settings.pace()];
        double t=simulatedSeconds*pace;
        double phase=t/34000.0+x/21000.0-z/27000.0;
        double front=t/17500.0-x/12000.0-z/16000.0;
        double slow=t/78000.0+x/46000.0;
        double swing=Math.sin(phase)*0.85+Math.sin(front)*0.36+Math.cos(slow)*0.32;
        // Rotating large-scale wind: never snap to a random compass direction.
        double turn=settings.variability()/100.0*(settings.windMode()==1?2.3:1.55);
        double angle=-0.85+turn*swing;
        double speed=(3.6+1.15*Math.sin(front-0.6)+0.8*Math.sin(slow))*(settings.meanWindKmh()/15.0);
        if(settings.windMode()==2){
            // Meteorological 'from' bearing: X east, Z south; wind travels opposite.
            angle=Math.toRadians(settings.fixedFrom()+90.0);
        }
        double u=speed*Math.cos(angle),v=speed*Math.sin(angle);
        double pressure=2.4*Math.cos(front)+1.2*Math.sin(slow+0.4);
        // Moist/dry air masses travel with fronts; bounded to avoid instant storms.
        var air=AirMassPhysics.at(t,x,z);
        double humidity=RegionalPhysics.clamp(air.humidity(),0.64,1.40);
        double temp=air.temperatureC()+0.9*Math.cos(slow);
        var syn=SynopticWeather.at(simulatedSeconds,x,z,SynopticRuntime.current());
        // An explicitly fixed compass bearing must never be rotated by pressure systems.
        if(settings.windMode()!=2){
            u=RegionalPhysics.clamp(u+syn.windU()*.38,-18,18);
            v=RegionalPhysics.clamp(v+syn.windV()*.38,-18,18);
        }
        pressure+=syn.pressureOffset()*.42+air.pressureTrend();
        humidity=RegionalPhysics.clamp(humidity*syn.humidityFactor(),.64,1.48);
        temp+=syn.temperatureOffset()*.45;
        return new State(u,v,pressure,humidity,temp);
    }
}
