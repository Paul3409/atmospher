package de.meteo;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import java.util.*;

/** Regional, terrain-aware diagnostic atmosphere; three displayed vertical levels. */
public final class AtmosphereEngine {
    public record Layer(String name,double temperatureC,double pressureHpa,double relativeHumidity,
                        double windU,double windV,double verticalWind,double dewPointC,
                        double specificHumidityGkg,double potentialTemperatureK) {}
    public record Sample(int terrainHeight,List<Layer> layers,long steps,double simulatedSeconds) {}
    private static final int CELL=256,N=RegionalPhysics.N;
    private static final int[] HEIGHTS={2,500,2000};
    private static final String[] NAMES={"Surface","Boundary","Free air"};
    private static final int MAX_REGIONS=24;
    // Access-order LRU: only the least recently sampled region is discarded.
    private final Map<String,Region> regions=new LinkedHashMap<>(32,.75f,true);
    private ServerWorld activeWorld;
    private WeatherDynamics.Settings dynamics=WeatherDynamics.DEFAULT;
    private double elapsedSeconds;
    private boolean storageWritable=true;
    public void setDynamics(WeatherDynamics.Settings settings){dynamics=settings;}
    private final Map<String,Clock> clocks=new HashMap<>();
    private static final class Clock {
        long world;
        Clock(long w){world=w;}
    }
    private static final class Region {
        final RegionalPhysics.Grid grid=new RegionalPhysics.Grid();
        final int[][] terrain=new int[N][N];
    }
    /** No atmosphere state may survive an integrated-server world change. */
    public void reset(){regions.clear();clocks.clear();activeWorld=null;elapsedSeconds=0;storageWritable=true;}
    private void ensureWorld(ServerWorld world){
        if(activeWorld!=world){reset();activeWorld=world;}
    }
    public void tick(ServerWorld world){
        ensureWorld(world);
        String dim=world.getRegistryKey().getValue().toString();
        long worldTime=world.getTime();
        Clock c=clocks.get(dim);
        if(c==null){clocks.put(dim,new Clock(worldTime));return;}
        long wd=worldTime-c.world;
        c.world=worldTime;
        // /time set changes the sky clock, not the elapsed server-tick clock.
        // Large jumps (e.g. server restore) are intentionally not simulated at once.
        if(wd<=0||wd>200)return;
        double remaining=wd*3.6;
        while(remaining>1e-7){
            double dt=Math.min(RegionalPhysics.DT_MAX,remaining);
            for(var e:regions.entrySet())if(e.getKey().startsWith(dim+":"))RegionalPhysics.step(e.getValue().grid,dt,dynamics);
            elapsedSeconds+=dt;
            remaining-=dt;
        }
    }
    public Sample sample(ServerWorld world,BlockPos pos){
        ensureWorld(world);
        int gx=Math.floorDiv(pos.getX(),CELL),gz=Math.floorDiv(pos.getZ(),CELL);
        int rx=Math.floorDiv(gx,N),rz=Math.floorDiv(gz,N);
        String key=world.getRegistryKey().getValue()+":"+rx+":"+rz;
        Region r=regions.get(key);
        if(r==null){
            // Build before eviction, so an unsuccessful terrain lookup leaves the cache intact.
            r=create(world,rx*N,rz*N);
            if(regions.size()>=MAX_REGIONS){
                var iterator=regions.keySet().iterator();
                iterator.next();iterator.remove();
            }
            regions.put(key,r);
        }
        int x=Math.floorMod(gx,N),z=Math.floorMod(gz,N);
        var g=r.grid;
        // The station, HUD, cloud physics and synoptic radar now reference the
        // same world-anchored pressure system (the radar displays sea-level
        // pressure, while local barometers retain their terrain correction).
        var synoptic=SynopticRuntime.fieldAt(elapsedSeconds,pos.getX(),pos.getZ());
        int ground=terrain(world,pos.getX(),pos.getZ());
        double sx=(terrain(world,pos.getX()+16,pos.getZ())-terrain(world,pos.getX()-16,pos.getZ()))/32.0;
        double sz=(terrain(world,pos.getX(),pos.getZ()+16)-terrain(world,pos.getX(),pos.getZ()-16))/32.0;
        double w=RegionalPhysics.clamp(g.u[x][z]*sx+g.v[x][z]*sz,-2,2);
        List<Layer> layers=new ArrayList<>();
        for(int i=0;i<3;i++){
            double altitude=ground+HEIGHTS[i];
            double pressure=1013.25*Math.pow(Math.max(.1,1-2.25577e-5*altitude),5.25588)
                +(g.p[x][z]+synoptic.pressureOffset())*Math.exp(-HEIGHTS[i]/8000.0);
            double temp=g.t[x][z]-(ground-r.terrain[x][z])*.0065-HEIGHTS[i]*.0065
                +SeasonSystem.offsetC(world.getTimeOfDay())+synoptic.temperatureOffset();
            double factor=1+i*.35;
            // Store humidity as specific humidity, not RH. Heights use a fixed, documented profile.
            // Frontal moisture convergence belongs to the very same synoptic
            // system that feeds the radar, not an unrelated decorative factor.
            // This changes environmental vapor content, not cloud condensate.
            double q=g.q[x][z]*synoptic.humidityFactor()*Math.exp(-HEIGHTS[i]/2800.0);
            double e=Thermodynamics.vaporPressureFromSpecificHumidityHpa(q,pressure);
            double rh=RegionalPhysics.clamp(e/Thermodynamics.saturationVaporPressureHpa(temp),0,1);
            layers.add(new Layer(NAMES[i],temp,pressure,rh,(g.u[x][z]+synoptic.windU())*factor,(g.v[x][z]+synoptic.windV())*factor,
                w*Math.exp(-i*1.2),Thermodynamics.dewPointC(e),1000*q,
                Thermodynamics.potentialTemperatureK(temp,pressure)));
        }
        return new Sample(ground,List.copyOf(layers),g.steps,g.seconds);
    }
    private Region create(ServerWorld world,int ox,int oz){
        Region r=new Region();var g=r.grid;
        g.originX=(double)ox*CELL;g.originZ=(double)oz*CELL;g.seconds=elapsedSeconds;
        var initial=WeatherDynamics.at(elapsedSeconds,g.originX+N*CELL/2.0,g.originZ+N*CELL/2.0,dynamics);
        for(int x=0;x<N;x++)for(int z=0;z<N;z++){
            int wx=(ox+x)*CELL+CELL/2,wz=(oz+z)*CELL+CELL/2;
            int h=terrain(world,wx,wz);r.terrain[x][z]=h;
            double biome=world.getBiome(new BlockPos(wx,h,wz)).value().getTemperature();
            double t=15+(biome-.8)*17-(h-64)*.0065;
            double rh=RegionalPhysics.clamp(.65-(biome-.8)*.18,.15,.95);
            double pressure=1013.25*Math.pow(Math.max(.1,1-2.25577e-5*(h+2)),5.25588);
            double e=rh*Thermodynamics.saturationVaporPressureHpa(t);
            double phase=wx/5000.0+wz/7000.0;
            g.t[x][z]=t;g.baseline[x][z]=t;
            g.q[x][z]=Thermodynamics.specificHumidityKgKg(e,pressure);g.baselineQ[x][z]=g.q[x][z];
            g.p[x][z]=2*Math.sin(phase);
            g.u[x][z]=initial.targetU();g.v[x][z]=initial.targetV();
        }
        return r;
    }
    /** Accumulated simulation time drives the same moving synoptic fields after a restart. */
    public double simulatedSeconds(){return elapsedSeconds;}
    /** Store all region grids and model time in the world folder; never touch the old save on read errors. */
    public void save(java.nio.file.Path file){
        if(!storageWritable)return;
        try{
            java.nio.file.Files.createDirectories(file.getParent());
            java.nio.file.Path temp=file.resolveSibling(file.getFileName()+".tmp");
            try(var o=new java.io.DataOutputStream(new java.util.zip.GZIPOutputStream(java.nio.file.Files.newOutputStream(temp)))){
                o.writeInt(0x4d54454f);o.writeInt(1);o.writeDouble(elapsedSeconds);o.writeInt(regions.size());
                for(var e:regions.entrySet()){
                    o.writeUTF(e.getKey());Region r=e.getValue();var g=r.grid;
                    o.writeDouble(g.originX);o.writeDouble(g.originZ);o.writeDouble(g.seconds);o.writeLong(g.steps);
                    for(int x=0;x<N;x++)for(int z=0;z<N;z++){
                        o.writeInt(r.terrain[x][z]);o.writeDouble(g.t[x][z]);o.writeDouble(g.q[x][z]);
                        o.writeDouble(g.p[x][z]);o.writeDouble(g.u[x][z]);o.writeDouble(g.v[x][z]);
                        o.writeDouble(g.baseline[x][z]);o.writeDouble(g.baselineQ[x][z]);
                    }
                }
            }
            try{java.nio.file.Files.move(temp,file,java.nio.file.StandardCopyOption.REPLACE_EXISTING,java.nio.file.StandardCopyOption.ATOMIC_MOVE);}
            catch(java.nio.file.AtomicMoveNotSupportedException e){java.nio.file.Files.move(temp,file,java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
        }catch(java.io.IOException e){MeteoMod.LOGGER.error("Cannot save Meteo atmosphere",e);}
    }
    public void load(ServerWorld world,java.nio.file.Path file){
        reset();activeWorld=world;
        clocks.put(world.getRegistryKey().getValue().toString(),new Clock(world.getTime()));
        if(!java.nio.file.Files.isRegularFile(file))return;
        try(var in=new java.io.DataInputStream(new java.util.zip.GZIPInputStream(java.nio.file.Files.newInputStream(file)))){
            if(in.readInt()!=0x4d54454f||in.readInt()!=1)throw new java.io.IOException("Unknown atmosphere save format");
            double seconds=in.readDouble();int count=in.readInt();
            if(!Double.isFinite(seconds)||seconds<0||count<0||count>MAX_REGIONS)throw new java.io.IOException("Invalid atmosphere save header");
            Map<String,Region> restored=new LinkedHashMap<>();
            for(int i=0;i<count;i++){
                String key=in.readUTF();if(key.length()>150||!key.startsWith("minecraft:overworld:"))throw new java.io.IOException("Invalid region key");
                Region r=new Region();var g=r.grid;
                g.originX=in.readDouble();g.originZ=in.readDouble();g.seconds=in.readDouble();g.steps=in.readLong();
                for(int x=0;x<N;x++)for(int z=0;z<N;z++){
                    r.terrain[x][z]=in.readInt();g.t[x][z]=in.readDouble();g.q[x][z]=in.readDouble();
                    g.p[x][z]=in.readDouble();g.u[x][z]=in.readDouble();g.v[x][z]=in.readDouble();
                    g.baseline[x][z]=in.readDouble();g.baselineQ[x][z]=in.readDouble();
                    if(!Double.isFinite(g.t[x][z])||!Double.isFinite(g.q[x][z])||!Double.isFinite(g.p[x][z])||
                        !Double.isFinite(g.u[x][z])||!Double.isFinite(g.v[x][z]))throw new java.io.IOException("Invalid region data");
                }
                restored.put(key,r);
            }
            elapsedSeconds=seconds;regions.clear();regions.putAll(restored);
            MeteoMod.LOGGER.info("Restored {} atmosphere regions",regions.size());
        }catch(Exception e){MeteoMod.LOGGER.error("Could not load Meteo atmosphere; preserving the original save",e);reset();activeWorld=world;
            clocks.put(world.getRegistryKey().getValue().toString(),new Clock(world.getTime()));storageWritable=false;}
    }
    private static int terrain(ServerWorld world,int x,int z){
        return world.getTopY(Heightmap.Type.WORLD_SURFACE,x,z);
    }
}
