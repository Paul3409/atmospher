package de.meteo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server-owned cloud formations and local precipitation, proximity-filtered moving-cloud window.
 * World positions are explicitly transmitted; no position depends on the viewer. */
public record CloudSnapshotPayload(long serverTick,List<CloudCell> cells) implements CustomPayload {
    public static final CustomPayload.Id<CloudSnapshotPayload> ID=new CustomPayload.Id<>(Identifier.of("meteo", "cloud_volume"));
    public static final PacketCodec<RegistryByteBuf,CloudSnapshotPayload> CODEC=
        CustomPayload.codecOf(CloudSnapshotPayload::write,CloudSnapshotPayload::read);

    /** (cx,cz) is the stable seed/identity, x/z is the advected world position. */
    public record CloudCell(int cx,int cz,float x,float z,float baseY,float cover,float liquid,float lift,
                            float windU,float windV,byte type,float rainMmHour,float temperatureC,
                            float humidity,float terrainLift) {}

    private void write(RegistryByteBuf buf){
        if(cells.size()>416)throw new IllegalArgumentException("At most 416 Meteo cloud formations");
        buf.writeLong(serverTick);
        buf.writeVarInt(cells.size());
        for(CloudCell c:cells){
            buf.writeInt(c.cx());buf.writeInt(c.cz());buf.writeFloat(c.x());buf.writeFloat(c.z());
            buf.writeFloat(c.baseY());buf.writeFloat(c.cover());buf.writeFloat(c.liquid());
            buf.writeFloat(c.lift());buf.writeFloat(c.windU());buf.writeFloat(c.windV());
            buf.writeByte(c.type());buf.writeFloat(c.rainMmHour());buf.writeFloat(c.temperatureC());
            buf.writeFloat(c.humidity());buf.writeFloat(c.terrainLift());
        }
    }
    private static CloudSnapshotPayload read(RegistryByteBuf buf){
        long tick=buf.readLong();
        int count=buf.readVarInt();
        if(count<0||count>416)throw new IllegalArgumentException("Invalid Meteo cell count: "+count);
        List<CloudCell> cs=new ArrayList<>(count);
        for(int i=0;i<count;i++)cs.add(new CloudCell(buf.readInt(),buf.readInt(),buf.readFloat(),
            buf.readFloat(),buf.readFloat(),buf.readFloat(),buf.readFloat(),buf.readFloat(),
            buf.readFloat(),buf.readFloat(),buf.readByte(),buf.readFloat(),buf.readFloat(),
            buf.readFloat(),buf.readFloat()));
        return new CloudSnapshotPayload(tick,List.copyOf(cs));
    }
    @Override public CustomPayload.Id<? extends CustomPayload> getId(){return ID;}
}
