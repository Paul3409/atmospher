package de.meteo;

/** World-space positions in Minecraft blocks. Wind is m/s; one block represents
 * approximately ten metres vertically in Meteo's current scaling. Visual
 * advection uses a 480:1 scaling from simulated seconds so wind does not
 * appear to rush past at the 72x accelerated meteorological clock, so clouds
 * remain observable while still tracking wind direction. No client/player
 * coordinates are used to place a cloud. The seed cell identifies the formation. */
public final class CloudMotion {
    private CloudMotion() {}
    public record Position(double x,double z) {}
    public static Position advance(Position old,double windU,double windV,double simulationSeconds){
        if(!Double.isFinite(windU)||!Double.isFinite(windV)||!Double.isFinite(simulationSeconds))return old;
        double dt=Math.max(0,Math.min(720,simulationSeconds));
        double speed=Math.hypot(windU,windV);
        double scale=speed>35?35/speed:1;
        return new Position(old.x()+windU*scale*dt/480.0,old.z()+windV*scale*dt/480.0);
    }
    /** Distances are measured to a cloud's extent, not its originating cell. */
    public static boolean intersects(double x,double z,double eyeX,double eyeZ,double radius,double viewDistance){
        double dx=x-eyeX,dz=z-eyeZ;
        double d=Math.max(0,Math.hypot(dx,dz)-Math.max(0,radius));
        return d<=viewDistance;
    }
}
