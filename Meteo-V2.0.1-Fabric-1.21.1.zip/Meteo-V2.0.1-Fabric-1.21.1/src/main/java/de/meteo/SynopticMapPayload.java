package de.meteo;
import java.util.*;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
/** Complete server-authored map grid; 33x25 sample points cover +-1536 blocks. */
public record SynopticMapPayload(long tick,int originX,int originZ, List<MapPoint> grid,List<FrontLine> frontLines) implements CustomPayload {
    public static final int COLS=33,ROWS=25,STEP=96,MAX=COLS*ROWS;
    public static final Id<SynopticMapPayload> ID=new Id<>(Identifier.of("meteo","synoptic_map"));
    public static final PacketCodec<RegistryByteBuf,SynopticMapPayload> CODEC=CustomPayload.codecOf(SynopticMapPayload::write,SynopticMapPayload::read);
    public record MapPoint(float pressure,float front,byte type,float rainPotential){}
    public record FrontLine(byte type,List<SynopticWeather.FrontPoint> points) {}
    public SynopticMapPayload {if(grid==null||grid.size()!=MAX)throw new IllegalArgumentException("Invalid synoptic map grid");grid=List.copyOf(grid);frontLines=List.copyOf(frontLines);}
    private void write(RegistryByteBuf b){b.writeLong(tick);b.writeInt(originX);b.writeInt(originZ);b.writeVarInt(grid.size());
        for(var c:grid){b.writeFloat(c.pressure());b.writeFloat(c.front());b.writeByte(c.type());b.writeFloat(c.rainPotential());}
        b.writeVarInt(frontLines.size());for(var line:frontLines){b.writeByte(line.type());b.writeVarInt(line.points().size());
            for(var pt:line.points()){b.writeFloat(pt.x());b.writeFloat(pt.z());}}
    }
    private static SynopticMapPayload read(RegistryByteBuf b){long t=b.readLong();int x=b.readInt(),z=b.readInt(),n=b.readVarInt();
        if(n!=MAX)throw new IllegalArgumentException("Invalid grid size "+n);
        List<MapPoint> data=new ArrayList<>(n);for(int i=0;i<n;i++)data.add(new MapPoint(b.readFloat(),b.readFloat(),b.readByte(),b.readFloat()));
        int lines=b.readVarInt();if(lines<0||lines>90)throw new IllegalArgumentException("Invalid front paths");
        List<FrontLine> fronts=new ArrayList<>();
        for(int j=0;j<lines;j++){byte type=b.readByte();int points=b.readVarInt();if(points<2||points>90)throw new IllegalArgumentException("Invalid path");
            List<SynopticWeather.FrontPoint> ps=new ArrayList<>();
            for(int k=0;k<points;k++)ps.add(new SynopticWeather.FrontPoint(b.readFloat(),b.readFloat(),type));
            fronts.add(new FrontLine(type,List.copyOf(ps)));
        }
        return new SynopticMapPayload(t,x,z,data,fronts);}
    public static SynopticMapPayload around(long tick,int x,int z,double seconds,SynopticWeather.Settings settings){
        int ox=Math.floorDiv(x,STEP)*STEP,oz=Math.floorDiv(z,STEP)*STEP;
        List<MapPoint> cells=new ArrayList<>(MAX);
        for(int row=0;row<ROWS;row++)for(int col=0;col<COLS;col++){
            var w=SynopticWeather.at(seconds,ox+(col-COLS/2)*STEP,oz+(row-ROWS/2)*STEP,settings);
            cells.add(new MapPoint((float)w.pressureHpa(),(float)w.frontIntensity(),w.frontType(),(float)FrontalCloudPhysics.precipitationPotential(w)));
        }
        double minX=ox-(COLS/2)*STEP,minZ=oz-(ROWS/2)*STEP;
        List<FrontLine> lines=new ArrayList<>();
        for(var path:SynopticWeather.paths(seconds,minX,minZ,minX+(COLS-1)*STEP,minZ+(ROWS-1)*STEP,settings))
            lines.add(new FrontLine(path.get(0).type(),path));
        return new SynopticMapPayload(tick,ox,oz,cells,lines);
    }
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
