package de.meteo;
/** Diagnostic moist-air quantities; temperatures in Celsius unless marked K. */
public final class Thermodynamics {
    private Thermodynamics() {}
    public static double saturationVaporPressureHpa(double temperatureC) {
        // Bolton/Magnus approximation over liquid water (best near -30..+50 C).
        return 6.112 * Math.exp(17.67 * temperatureC / (temperatureC + 243.5));
    }
    public static double dewPointC(double vaporPressureHpa) {
        double e = Math.max(0.001, vaporPressureHpa);
        double x = Math.log(e / 6.112);
        return 243.5 * x / (17.67 - x);
    }
    public static double specificHumidityKgKg(double vaporPressureHpa, double pressureHpa) {
        double e = Math.max(0.0, Math.min(vaporPressureHpa, pressureHpa * 0.99));
        return 0.622 * e / (pressureHpa - 0.378 * e);
    }
    public static double vaporPressureFromSpecificHumidityHpa(double q,double pressureHpa) {
        return pressureHpa*q/(0.622+0.378*q);
    }
    public static double potentialTemperatureK(double temperatureC, double pressureHpa) {
        return (temperatureC + 273.15) * Math.pow(1000.0 / pressureHpa, 0.2854);
    }
}
