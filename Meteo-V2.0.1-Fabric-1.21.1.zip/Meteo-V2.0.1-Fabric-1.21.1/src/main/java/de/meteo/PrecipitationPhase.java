package de.meteo;
/** Data-only rain/snow phase diagnosis using local air temperature in Celsius. */
public final class PrecipitationPhase {
    private PrecipitationPhase(){}
    public static double snowFraction(double c){return Math.max(0,Math.min(1,(2.0-c)/3.0));}
    public static double snowRate(double total,double c){return Math.max(0,total)*snowFraction(c);}
    public static double rainRate(double total,double c){return Math.max(0,total)*(1-snowFraction(c));}
}
