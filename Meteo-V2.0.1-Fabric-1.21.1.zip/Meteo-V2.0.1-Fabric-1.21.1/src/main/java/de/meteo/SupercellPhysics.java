package de.meteo;
public final class SupercellPhysics {
    private SupercellPhysics() {}
    public enum Stage { NONE, BUILDING, MATURE, DISSIPATING }
    public record State(boolean supercell,Stage stage,double potential,double mesocyclone,double updraft,double hailPotential) {}
    public static State diagnose(double stormStrength,double lift,double humidity,double windShear,double stormAgeSeconds,double frontCore){
        double instability=RegionalPhysics.clamp((lift-.28)/.55,0,1)*RegionalPhysics.clamp((humidity-.74)/.22,0,1);
        double shear=RegionalPhysics.clamp((windShear-5)/12,0,1), organisation=RegionalPhysics.clamp((stormStrength-.48)/.52,0,1);
        double mature=RegionalPhysics.clamp((stormAgeSeconds-900)/1800,0,1);
        double potential=RegionalPhysics.clamp(instability*.34+shear*.34+organisation*.20+frontCore*.07+mature*.05,0,1);
        boolean active=potential>.68&&stormStrength>.58&&stormAgeSeconds>=900;
        Stage stage=Stage.NONE;
        if(active)stage=stormAgeSeconds<1500?Stage.BUILDING:stormAgeSeconds<3600?Stage.MATURE:Stage.DISSIPATING;
        double strength=stage==Stage.DISSIPATING?potential*.72:potential;
        return new State(active,stage,strength,active?strength*.82:0,active?Math.min(1,stormStrength*.9+strength*.18):stormStrength*.62,active?RegionalPhysics.clamp((strength-.68)*2.8,0,1):0);
    }
}
