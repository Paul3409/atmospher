package de.meteo;

/** Pure probabilities for sparse, bounded snow-surface updates.
 * The server samples surface patches instead of scanning every column every tick.
 * Only weather-model precipitation and air temperature drive the probabilities.
 */
public final class SnowCoverPhysics {
    private SnowCoverPhysics() {}
    private static double clamp(double v) {return Double.isFinite(v)?Math.max(0,Math.min(1,v)):0;}
    public static double depositChance(double totalRate,double temperature,int accumulation) {
        double snowPart=PrecipitationPhase.snowFraction(temperature);
        if(snowPart<=.05||totalRate<=.05||accumulation<=0)return 0;
        // Sleet produces much less durable snow than fully frozen precipitation.
        double sleetFactor=snowPart<.7 ? .25+.65*snowPart : 1;
        double chance=Math.max(0,totalRate)*snowPart*sleetFactor*.065;
        return clamp(chance*new double[]{0,.55,1,1.7}[Math.max(0,Math.min(3,accumulation))]);
    }
    public static double meltChance(double temperature,int melt) {
        if(melt<=0||temperature<-.05)return 0;
        // At the freezing point only minor thaw, sustained positive temperatures melt.
        double thaw=temperature<=1?.012+.045*Math.max(0,temperature):.08+.105*(temperature-1);
        return clamp(thaw*new double[]{0,.55,1,1.65}[Math.max(0,Math.min(3,melt))]);
    }
    public static int nextLayers(int current,boolean snowing,double depositDraw,double meltDraw,
                                 double precipitation,double temperature,int accumulation,int melt) {
        current=Math.max(0,Math.min(8,current));
        if(current>0&&meltDraw<meltChance(temperature,melt))return current-1;
        if(snowing&&current<8&&depositDraw<depositChance(precipitation,temperature,accumulation))return current+1;
        return current;
    }
}
