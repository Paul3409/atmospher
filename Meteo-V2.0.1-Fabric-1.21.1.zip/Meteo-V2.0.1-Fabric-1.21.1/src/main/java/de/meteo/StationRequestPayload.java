package de.meteo;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client requests an older history page while physically near the station. */
public record StationRequestPayload(long position,int page) implements CustomPayload {
    public static final Id<StationRequestPayload> ID=new Id<>(Identifier.of("meteo","station_request"));
    public static final PacketCodec<RegistryByteBuf,StationRequestPayload> CODEC=CustomPayload.codecOf(StationRequestPayload::write,StationRequestPayload::read);
    private void write(RegistryByteBuf b){b.writeLong(position);b.writeVarInt(page);}
    private static StationRequestPayload read(RegistryByteBuf b){return new StationRequestPayload(b.readLong(),b.readVarInt());}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
