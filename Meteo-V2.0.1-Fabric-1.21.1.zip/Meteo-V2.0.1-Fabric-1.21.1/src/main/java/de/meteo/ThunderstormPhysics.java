package de.meteo;
public final class ThunderstormPhysics {
    private ThunderstormPhysics() {}
    public enum Stage { NONE, BUILDING, MATURE, DISSIPATING }
    public record State(Stage stage,double strength,double updraft,double downdraft) {}
    public static State diagnose(double cover,double water,double lift,double humidity,double solar,double ageSeconds){
        double fuel=RegionalPhysics.clamp((humidity-.68)/.28,0,1)*RegionalPhysics.clamp((solar+.15)/1.15,0,1);
        double trigger=RegionalPhysics.clamp((lift-.18)/.48,0,1), moisture=RegionalPhysics.clamp((water-.22)/.58,0,1);
        double strength=RegionalPhysics.clamp(fuel*.35+trigger*.35+moisture*.30,0,1)*RegionalPhysics.clamp(cover*1.45,0,1);
        Stage stage=Stage.NONE;
        if(strength>.18) stage=ageSeconds<900?Stage.BUILDING:strength>.62?Stage.MATURE:Stage.DISSIPATING;
        return new State(stage,strength,stage==Stage.MATURE?strength*.95:strength*.62,
            stage==Stage.MATURE?strength*.55:stage==Stage.DISSIPATING?strength*.75:0);
    }
}
