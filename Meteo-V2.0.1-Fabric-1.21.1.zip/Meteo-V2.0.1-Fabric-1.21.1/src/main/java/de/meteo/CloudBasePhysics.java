package de.meteo;
/** Consistent, bounded LCL mapping into Minecraft's limited vertical domain.
 * LCL is ~125 meters per degree of temperature/dewpoint spread. A 0.13
 * world scale compresses this height; saturation lowers the base, but
 * non-fog cumulus cannot routinely sit at roof height.
 */
public final class CloudBasePhysics {
    private CloudBasePhysics(){}
    public static double baseAboveGround(double temperatureC,double dewPointC){
        if(!Double.isFinite(temperatureC)||!Double.isFinite(dewPointC))return 85;
        double depression=Math.max(0,temperatureC-dewPointC);
        return RegionalPhysics.clamp(125.0*depression*.13,38,160);
    }
    public static double relax(double current,double target,double seconds){
        if(!Double.isFinite(target))return current;
        if(!Double.isFinite(current))return target;
        double dt=RegionalPhysics.clamp(seconds,0,120);
        return current+(target-current)*(1-Math.exp(-dt/540));
    }
    public static double terrainLiftEffect(double terrainLift,double humidity){
        double moist=RegionalPhysics.clamp((humidity-.48)/.40,0,1);
        return RegionalPhysics.clamp(terrainLift*moist,-1.6,1.6);
    }
    public static double adjustedSaturation(double terrainLift,double lift,double humidity,double solar){
        double oro=terrainLiftEffect(terrainLift,humidity);
        return RegionalPhysics.clamp(.77-Math.max(0,lift)*.18-Math.max(0,oro)*.12
            +Math.max(0,-oro)*.19 +Math.max(0,-lift)*.12-solar*.03,.35,1.12);
    }
}
