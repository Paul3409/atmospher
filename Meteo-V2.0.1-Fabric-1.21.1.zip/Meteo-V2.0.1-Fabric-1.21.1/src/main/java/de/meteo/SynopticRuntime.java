package de.meteo;

import java.io.*;
import java.nio.file.*;
import java.util.*;
/** Server-owned synoptic parameters and optional operator-created pressure centres. */
public final class SynopticRuntime {
    private SynopticRuntime(){}
    public record ManualCentre(double x,double z,double createdAt,boolean low){}
    private static SynopticWeather.Settings value=SynopticWeather.DEFAULT;
    private static List<ManualCentre> centres=List.of();
    // The server queries overlapping cloud, station and HUD columns many times
    // per tick. Cache a coarse synoptic field, but never cache actual cloud water,
    // terrain lift or rain; those remain locally simulated at full resolution.
    private record FieldKey(long interval,int bx,int bz){}
    private static final java.util.LinkedHashMap<FieldKey,SynopticWeather.State> fieldCache=
        new java.util.LinkedHashMap<>(4096,.75f,true);
    private static void invalidate(){fieldCache.clear();}
    public static SynopticWeather.State fieldAt(double seconds,double x,double z){
        long t=(long)Math.floor(seconds/120.0);
        int bx=(int)Math.floor(x/32.0),bz=(int)Math.floor(z/32.0);
        var key=new FieldKey(t,bx,bz);
        var state=fieldCache.get(key);
        if(state!=null)return state;
        state=SynopticWeather.at(t*120+60,bx*32.0+16,bz*32.0+16,value);
        if(fieldCache.size()>=4096){var iter=fieldCache.keySet().iterator();iter.next();iter.remove();}
        fieldCache.put(key,state);
        return state;
    }
    public static SynopticWeather.Settings current(){return value;}
    public static void set(SynopticWeather.Settings settings){value=settings;invalidate();}
    public static List<ManualCentre> centres(){return centres;}
    public static void create(double x,double z,double seconds,boolean low){
        List<ManualCentre> next=new ArrayList<>(centres);if(next.size()>=12)next.remove(0);
        next.add(new ManualCentre(x,z,seconds,low));centres=List.copyOf(next);invalidate();
    }
    public static void clear(){centres=List.of();invalidate();}
    public static void load(Path root){
        centres=List.of();invalidate();Path file=root.resolve("data/meteo-manual-pressure.bin");if(!Files.isRegularFile(file))return;
        try(var in=new DataInputStream(new BufferedInputStream(Files.newInputStream(file)))){
            if(in.readInt()!=0x4d504353||in.readInt()!=1)throw new IOException("Invalid pressure archive");
            int count=in.readInt();if(count<0||count>12)throw new IOException("Invalid pressure centre count");
            List<ManualCentre> read=new ArrayList<>();
            for(int i=0;i<count;i++){
                double x=in.readDouble(),z=in.readDouble(),seconds=in.readDouble();boolean low=in.readBoolean();
                if(!Double.isFinite(x)||!Double.isFinite(z)||!Double.isFinite(seconds))throw new IOException("Invalid pressure values");
                read.add(new ManualCentre(x,z,seconds,low));
            }
            centres=List.copyOf(read);invalidate();
        }catch(Exception e){java.util.logging.Logger.getLogger("Meteo").warning("Could not load manual pressure archive: "+e);centres=List.of();}
    }
    public static void save(Path root){
        Path file=root.resolve("data/meteo-manual-pressure.bin");
        try{
            Files.createDirectories(file.getParent());Path temp=file.resolveSibling(file.getFileName()+".tmp");
            try(var out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)))){
                out.writeInt(0x4d504353);out.writeInt(1);out.writeInt(centres.size());
                for(var c:centres){out.writeDouble(c.x());out.writeDouble(c.z());out.writeDouble(c.createdAt());out.writeBoolean(c.low());}
            }
            try{Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
        }catch(IOException e){java.util.logging.Logger.getLogger("Meteo").warning("Cannot save manual pressure centres: "+e);}
    }
}
