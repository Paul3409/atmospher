package de.meteo;

import java.util.*;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client bounded history page; all historical readings remain on the server. */
public record StationPagePayload(long position, String name, int page, int pages, int total,
    List<StationReading> readings) implements CustomPayload {
    public static final Id<StationPagePayload> ID=new Id<>(Identifier.of("meteo","station_page"));
    public static final PacketCodec<RegistryByteBuf,StationPagePayload> CODEC=CustomPayload.codecOf(StationPagePayload::write,StationPagePayload::read);
    public StationPagePayload {
        if(readings==null||readings.size()>StationArchive.PAGE_SIZE)throw new IllegalArgumentException("Station page too large");
        readings=List.copyOf(readings);
    }
    private void write(RegistryByteBuf b){
        b.writeLong(position);b.writeString(name,80);b.writeVarInt(page);b.writeVarInt(pages);b.writeVarInt(total);
        b.writeVarInt(readings.size());
        for(var r:readings){
            b.writeLong(r.tick());b.writeDouble(r.temperature());b.writeDouble(r.dewPoint());b.writeDouble(r.pressure());
            b.writeDouble(r.rainRate());b.writeDouble(r.rainTotal());b.writeDouble(r.windSpeed());
            b.writeDouble(r.gustSpeed());b.writeDouble(r.windFrom());b.writeDouble(r.cloudCover());b.writeBoolean(r.estimated());
            b.writeDouble(r.snowRate());b.writeDouble(r.snowTotal());
        }
    }
    private static StationPagePayload read(RegistryByteBuf b){
        long pos=b.readLong();String name=b.readString(80);int page=b.readVarInt(),pages=b.readVarInt(),total=b.readVarInt();
        int n=b.readVarInt();if(n<0||n>StationArchive.PAGE_SIZE||pages<1||pages>10000000||page<0||page>=pages)
            throw new IllegalArgumentException("Invalid station history packet");
        List<StationReading> history=new ArrayList<>(n);
        for(int i=0;i<n;i++){
            long tick=b.readLong();double temperature=b.readDouble(),dew=b.readDouble(),pressure=b.readDouble();
            double rain=b.readDouble(),rainTotal=b.readDouble(),wind=b.readDouble(),gust=b.readDouble();
            double from=b.readDouble(),cloud=b.readDouble();boolean estimated=b.readBoolean();
            history.add(new StationReading(tick,temperature,dew,pressure,rain,rainTotal,wind,gust,from,cloud,estimated,b.readDouble(),b.readDouble()));
        }
        return new StationPagePayload(pos,name,page,pages,total,history);
    }
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
