package de.meteo;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import java.util.Random;

/** Bounded world-block snow accumulation. Uses vanilla SNOW layers, which Minecraft
 * saves with the world; no extra per-column persistence or forced chunk loading.
 * Samples surface patches around players only; does not recolor biomes/grass/trees.
 */
public final class SnowCoverEngine {
    private SnowCoverEngine() {}
    private static final int PATCHES_PER_SECOND=12;
    private static final int PATCH_EDGE=4;
    private static final int MAX_CHANGES_PER_PLAYER=36;

    public static void tick(AtmosphereEngine atmosphere,ServerWorld world){
        if(world.getRegistryKey()!=World.OVERWORLD || world.getTime()%20!=0)return;
        var cfg=SnowCoverSettings.current();
        if(!cfg.enabled() || (cfg.accumulation()==0 && cfg.melt()==0))return;
        for(var player:world.getPlayers()){
            long seed=world.getTime()*0x9e3779b97f4a7c15L ^ player.getUuid().getMostSignificantBits();
            Random random=new Random(seed);
            int changed=0;
            var playerSample=atmosphere.sample(world,player.getBlockPos());
            double playerTemp=playerSample.layers().get(0).temperatureC();
            int playerGround=playerSample.terrainHeight();
            for(int patch=0;patch<PATCHES_PER_SECOND && changed<MAX_CHANGES_PER_PLAYER;patch++){
                // Uniform square sampling with circular rejection; no chunk tickets.
                int dx=random.nextInt(cfg.radius()*2+1)-cfg.radius();
                int dz=random.nextInt(cfg.radius()*2+1)-cfg.radius();
                if(dx*dx+dz*dz>cfg.radius()*cfg.radius())continue;
                int ox=player.getBlockX()+dx,oz=player.getBlockZ()+dz;
                if(!world.getChunkManager().isChunkLoaded(ox>>4,oz>>4))continue;
                // Wet cells come from the same moving clouds used by the radar and stations.
                // No new cloud seed is created solely to put down snow.
                double precipitation=CloudEffects.precipitationAt(world,ox,oz);
                for(int ix=0;ix<PATCH_EDGE && changed<MAX_CHANGES_PER_PLAYER;ix++)for(int iz=0;iz<PATCH_EDGE && changed<MAX_CHANGES_PER_PLAYER;iz++){
                    int x=ox+ix-1,z=oz+iz-1;
                    int localX=x-player.getBlockX(),localZ=z-player.getBlockZ();
                    if(localX*localX+localZ*localZ>cfg.radius()*cfg.radius())continue;
                    if(!world.getChunkManager().isChunkLoaded(x>>4,z>>4))continue;
                    int top=world.getTopY(Heightmap.Type.WORLD_SURFACE,x,z);
                    if(top<world.getBottomY()+1||top>=world.getTopY()-1)continue;
                    BlockPos surface=new BlockPos(x,top-1,z);
                    BlockState existing=world.getBlockState(surface);
                    boolean snowy=existing.isOf(Blocks.SNOW);
                    BlockPos at=snowy?surface:new BlockPos(x,top,z);
                    // Snow never appears indoors, in caves or underneath overhangs.
                    if(!world.isSkyVisible(at))continue;
                    BlockState state=snowy?existing:world.getBlockState(at);
                    if(!snowy && !state.isAir())continue;
                    double localTemp=playerTemp-(top-playerGround)*.0065;
                    int current=snowy?state.get(SnowBlock.LAYERS):0;
                    int next=SnowCoverPhysics.nextLayers(current,precipitation>.05,random.nextDouble(),random.nextDouble(),
                        precipitation,localTemp,cfg.accumulation(),cfg.melt());
                    if(current==next)continue;
                    if(next==0){world.setBlockState(at,Blocks.AIR.getDefaultState(),3);changed++;}
                    else{
                        BlockState snow=Blocks.SNOW.getDefaultState().with(SnowBlock.LAYERS,next);
                        if(snow.canPlaceAt(world,at)){
                            world.setBlockState(at,snow,3);changed++;
                        }
                    }
                }
            }
        }
    }
}
