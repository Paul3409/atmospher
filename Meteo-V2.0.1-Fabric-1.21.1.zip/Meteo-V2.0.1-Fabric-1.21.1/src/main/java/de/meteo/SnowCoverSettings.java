package de.meteo;

import java.io.IOException;
import java.nio.file.*;
import java.util.Properties;

/** World-specific, server-controlled snow accumulation preferences. */
public final class SnowCoverSettings {
    private SnowCoverSettings(){}
    public record Settings(boolean enabled,int radius,int accumulation,int melt) {
        public Settings {
            radius=radius<=50?50:radius<=75?75:radius<=100?100:150;
            accumulation=Math.max(0,Math.min(3,accumulation));
            melt=Math.max(0,Math.min(3,melt));
        }
    }
    public static final Settings DEFAULT=new Settings(true,100,2,2);
    private static Settings value=DEFAULT;
    private static Path file;
    public static Settings current(){return value;}
    public static void start(Path root){
        file=root.resolve("data/meteo-snow-cover.properties");value=DEFAULT;
        if(!Files.isRegularFile(file))return;
        try(var in=Files.newInputStream(file)){
            Properties p=new Properties();p.load(in);
            value=new Settings(Boolean.parseBoolean(p.getProperty("enabled","true")),
                Integer.parseInt(p.getProperty("radius","100")),
                Integer.parseInt(p.getProperty("accumulation","2")),Integer.parseInt(p.getProperty("melt","2")));
        }catch(Exception e){MeteoMod.LOGGER.warn("Could not read snow cover settings",e);}
    }
    public static void change(Settings next){value=next;save();}
    public static void stop(){file=null;value=DEFAULT;}
    public static void save(){
        if(file==null)return;
        try{
            Files.createDirectories(file.getParent());Properties p=new Properties();
            p.setProperty("enabled",Boolean.toString(value.enabled()));p.setProperty("radius",Integer.toString(value.radius()));
            p.setProperty("accumulation",Integer.toString(value.accumulation()));p.setProperty("melt",Integer.toString(value.melt()));
            Path temp=file.resolveSibling(file.getFileName()+".tmp");
            try(var out=Files.newOutputStream(temp)){p.store(out,"Meteo world snow cover preferences");}
            Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);
        }catch(IOException e){MeteoMod.LOGGER.warn("Could not save snow cover settings",e);}
    }
}
