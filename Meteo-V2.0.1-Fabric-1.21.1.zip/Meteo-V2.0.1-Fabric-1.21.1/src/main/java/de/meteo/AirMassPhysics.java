package de.meteo;
public final class AirMassPhysics {
    private AirMassPhysics() {}
    public record State(double temperatureC,double dewPointC,double humidity,double stability,double pressureTrend) {}
    public static State at(double seconds,double x,double z){
        double boundary=Math.sin(seconds/17500.0-x/12000.0-z/16000.0);
        double maritime=Math.sin(seconds/42000.0+x/28000.0-z/31000.0);
        return new State(2.4*boundary+.8*maritime,1.7*boundary+1.5*maritime,
            RegionalPhysics.clamp(1+.18*maritime+.10*boundary,.70,1.30),
            RegionalPhysics.clamp(.52-.18*boundary+.08*maritime,.12,.88),
            -.22*boundary-.08*maritime);
    }
}
