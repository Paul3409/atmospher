package de.meteo;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server-owned synoptic settings (also sent to a joining client). */
public record SynopticControlPayload(int high,int low,int duration,int frontsStrength,int thunder,int storm,
    boolean fronts,boolean hud,boolean warnings,boolean isobars,boolean precip,boolean cloudFronts) implements CustomPayload {
    public static final Id<SynopticControlPayload> ID=new Id<>(Identifier.of("meteo","synoptic_controls"));
    public static final PacketCodec<RegistryByteBuf,SynopticControlPayload> CODEC=CustomPayload.codecOf(SynopticControlPayload::write,SynopticControlPayload::read);
    private void write(RegistryByteBuf b){b.writeVarInt(high);b.writeVarInt(low);b.writeVarInt(duration);b.writeVarInt(frontsStrength);
        b.writeVarInt(thunder);b.writeVarInt(storm);b.writeBoolean(fronts);b.writeBoolean(hud);b.writeBoolean(warnings);
        b.writeBoolean(isobars);b.writeBoolean(precip);b.writeBoolean(cloudFronts);}
    private static SynopticControlPayload read(RegistryByteBuf b){return new SynopticControlPayload(b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarInt(),
        b.readVarInt(),b.readVarInt(),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.readBoolean());}
    public SynopticWeather.Settings settings(){return new SynopticWeather.Settings(high,low,duration,frontsStrength,thunder,storm,fronts,hud,warnings,isobars,precip,cloudFronts);}
    public static SynopticControlPayload of(SynopticWeather.Settings s){return new SynopticControlPayload(s.highStrength(),s.lowStrength(),s.duration(),s.frontStrength(),
        s.thunderFrequency(),s.stormStrength(),s.fronts(),s.hud(),s.warnings(),s.isobars(),s.precip(),s.cloudFronts());}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
