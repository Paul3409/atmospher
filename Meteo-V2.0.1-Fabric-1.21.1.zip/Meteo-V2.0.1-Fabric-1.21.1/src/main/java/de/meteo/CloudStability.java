package de.meteo;
/** Real game-tick easing: independent of frame rate and of weather-speed multipliers. */
public final class CloudStability {
    private CloudStability() {}
    public static double approach(double current,double target,double ticks,double duration){
        if(!Double.isFinite(current)||!Double.isFinite(target)||!Double.isFinite(duration)||duration<=0)return current;
        double alpha=1-Math.exp(-Math.max(0,Math.min(200,ticks))/duration);
        return current+(target-current)*alpha;
    }
}
