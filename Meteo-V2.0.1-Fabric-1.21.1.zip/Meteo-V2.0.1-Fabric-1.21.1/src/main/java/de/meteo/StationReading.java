package de.meteo;

/** One station measurement; immutable and independent of the player position. */
public record StationReading(long tick, double temperature, double dewPoint, double pressure,
    double rainRate, double rainTotal, double windSpeed, double gustSpeed,
    double windFrom, double cloudCover, boolean estimated,
    double snowRate, double snowTotal) {
    /** Compatibility with V1.5/V1.6 readings and existing physics tests. */
    public StationReading(long tick,double temperature,double dewPoint,double pressure,double rainRate,double rainTotal,
        double windSpeed,double gustSpeed,double windFrom,double cloudCover,boolean estimated){
        this(tick,temperature,dewPoint,pressure,rainRate,rainTotal,windSpeed,gustSpeed,windFrom,cloudCover,estimated,0,0);
    }
    public StationReading {
        if (!Double.isFinite(temperature) || !Double.isFinite(dewPoint) || !Double.isFinite(pressure)
            || !Double.isFinite(rainRate) || !Double.isFinite(rainTotal) || !Double.isFinite(windSpeed)
            || !Double.isFinite(gustSpeed) || !Double.isFinite(windFrom) || !Double.isFinite(cloudCover)
            || !Double.isFinite(snowRate) || !Double.isFinite(snowTotal))
            throw new IllegalArgumentException("Invalid station reading");
        rainRate = Math.max(0, Math.min(100, rainRate));
        rainTotal = Math.max(0, rainTotal);
        snowRate=Math.max(0,Math.min(100,snowRate));snowTotal=Math.max(0,snowTotal);
        windSpeed = Math.max(0, windSpeed);
        gustSpeed = Math.max(windSpeed, gustSpeed);
        windFrom = ((windFrom % 360) + 360) % 360;
        cloudCover = Math.max(0, Math.min(1, cloudCover));
    }
}
