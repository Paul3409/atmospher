package de.meteo;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server-measured, player-local atmospheric diagnostic snapshot. */
public record CloudDiagnosticPayload(long serverTick,double temperatureC,double dewPointC,
    double humidity,double windU,double windV,double lift,double orographicLift,
    float baseAboveGround,float baseWorldY,float cover,float cloudWater,
    float rainMmHour,int activeFormations,int wetFormations,int terrainY) implements CustomPayload {
    public static final Id<CloudDiagnosticPayload> ID=new Id<>(Identifier.of("meteo","diagnostics"));
    public static final PacketCodec<RegistryByteBuf,CloudDiagnosticPayload> CODEC=
        CustomPayload.codecOf(CloudDiagnosticPayload::write,CloudDiagnosticPayload::read);
    private void write(RegistryByteBuf b){
        b.writeLong(serverTick);b.writeDouble(temperatureC);b.writeDouble(dewPointC);
        b.writeDouble(humidity);b.writeDouble(windU);b.writeDouble(windV);
        b.writeDouble(lift);b.writeDouble(orographicLift);
        b.writeFloat(baseAboveGround);b.writeFloat(baseWorldY);b.writeFloat(cover);
        b.writeFloat(cloudWater);b.writeFloat(rainMmHour);
        b.writeVarInt(activeFormations);b.writeVarInt(wetFormations);b.writeVarInt(terrainY);
    }
    private static CloudDiagnosticPayload read(RegistryByteBuf b){
        return new CloudDiagnosticPayload(b.readLong(),b.readDouble(),b.readDouble(),b.readDouble(),
            b.readDouble(),b.readDouble(),b.readDouble(),b.readDouble(),b.readFloat(),
            b.readFloat(),b.readFloat(),b.readFloat(),b.readFloat(),b.readVarInt(),b.readVarInt(),b.readVarInt());
    }
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
