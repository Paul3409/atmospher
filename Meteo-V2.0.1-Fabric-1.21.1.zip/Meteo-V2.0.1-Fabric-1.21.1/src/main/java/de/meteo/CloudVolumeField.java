package de.meteo;

import java.util.ArrayList;
import java.util.List;

/** 3D scalar cloud-density volume sampled on a bounded grid.
 * Seeded 3D value noise roughens the meteorologically chosen envelope; it never
 * creates clouds without simulated liquid water and cover. No Minecraft dependency.
 */
public final class CloudVolumeField {
    private CloudVolumeField(){}
    public record Voxel(float x,float y,float z,float radius,float opacity,float shade){}
    public static double clamp(double value,double min,double max){return Math.max(min,Math.min(max,value));}
    private static double smooth(double f){return f*f*(3-2*f);}
    private static double hash(int x,int y,int z,int seed){
        long h=seed*0x9E3779B97F4A7C15L;
        h^=(long)x*0xBF58476D1CE4E5B9L;
        h^=(long)y*0x94D049BB133111EBL;
        h^=(long)z*0xD6E8FEB86659FD93L;
        h^=h>>>30;h*=0xBF58476D1CE4E5B9L;h^=h>>>27;
        return ((h>>>15)&0xffff)/65535.0;
    }
    /** Continuous trilinear low-frequency detail noise. */
    public static double noise(double x,double y,double z,int seed){
        int ix=(int)Math.floor(x),iy=(int)Math.floor(y),iz=(int)Math.floor(z);
        double fx=smooth(x-ix),fy=smooth(y-iy),fz=smooth(z-iz);
        double sum=0;
        for(int a=0;a<2;a++)for(int b=0;b<2;b++)for(int c=0;c<2;c++){
            double w=(a==0?1-fx:fx)*(b==0?1-fy:fy)*(c==0?1-fz:fz);
            sum+=w*hash(ix+a,iy+b,iz+c,seed);
        }
        return sum;
    }
    /** A family of three-dimensional, coherent condensation envelopes.
     * Inspired by the general multi-scale-noise approach used in cloud renderers
     * (including Simple Clouds), independently implemented without external shaders.
     * Normalized X,Z in [-1,1]; Y is the altitude above the local cloud base [0,1].
     * Weather still controls cloud presence, moisture, height and category.
     */
    private static double puff(double x,double y,double z,
                               double px,double py,double pz,
                               double rx,double ry,double rz){
        double dx=(x-px)/rx,dy=(y-py)/ry,dz=(z-pz)/rz;
        return 1.0-Math.sqrt(dx*dx+dy*dy+dz*dz);
    }
    private static double fbm(double x,double y,double z,int seed){
        return .59*noise(x,y,z,seed)+.29*noise(x*2.17+7,y*2.13+11,z*2.11-5,seed+61)
              +.12*noise(x*4.38-9,y*4.19+6,z*4.25+17,seed+157);
    }
    /** Weather types: 0 mountain, 1 cumulus, 2 congestus, 3 stratus, 4 Sc, 5 cirrus, 6 front, 7 Cb, 8 Ns, 9 Ac. */
    public static double density(double nx,double ny,double nz,int type,int seed){
        if(!Double.isFinite(nx)||!Double.isFinite(ny)||!Double.isFinite(nz)
          ||Math.abs(nx)>=1||Math.abs(nz)>=1||ny<=0||ny>=1)return 0;
        // Broad displacements preserve recognizable cloud lobes; smaller turbulence
        // breaks up artificial smooth ellipsoid edges without spawning new clouds.
        double wx=(fbm(nx*2.5+5,ny*2.9+11,nz*2.5-8,seed)-.5)*.16;
        double wz=(fbm(nx*2.5-3,ny*2.7+7,nz*2.5+9,seed+19)-.5)*.16;
        double x=nx+wx,z=nz+wz;
        double s1=(noise(seed*.00002,3.6,5.9,seed+71)-.5)*.19;
        double s2=(noise(7.2,seed*.00003,1.3,seed+113)-.5)*.19;
        double body;
        if(type==7){
            // Cumulonimbus: broad dark base, stepped buoyant tower and a spread-out anvil.
            // Growth is still controlled by existing cloud water, lift and the renderer life cycle.
            body=Math.max(puff(x,ny,z,0,.15,0,.95,.19,.92),
                puff(x,ny,z,-.11,.45,.05,.52,.41,.55));
            body=Math.max(body,puff(x,ny,z,.12,.71,-.08,.38,.25,.42));
            body=Math.max(body,puff(x,ny,z,.12,.87,-.07,.95,.115,.82));
        }else if(type==8||type==6){
            // Nimbostratus remains layered, while an active front has embedded
            // raised billows.  Offset lobes leave natural breaks at the margins.
            body=Math.max(puff(x,ny,z,-.31,.29,-.18,.74,.18,.81),
                puff(x,ny,z,.31,.31,.27,.78,.17,.78));
            body=Math.max(body,puff(x,ny,z,.02,.17,.04,.92,.12,.90));
            if(type==6){
                body=Math.max(body,puff(x,ny,z,-.24,.53,.18,.48,.25,.52));
                body=Math.max(body,puff(x,ny,z,.35,.48,-.23,.43,.21,.48));
            }
        }else if(type==9){
            // Mid-layer patches: altocumulus, distinct grouped lumps with blue gaps.
            body=Math.max(puff(x,ny,z,-.55,.42,-.41,.34,.20,.32),
                puff(x,ny,z,.45,.51,-.27,.31,.20,.33));
            body=Math.max(body,puff(x,ny,z,-.12,.49,.48,.38,.18,.28));
            body=Math.max(body,puff(x,ny,z,.48,.46,.44,.29,.20,.28));
        }else if(type==5){
            // Elongated broken strands, thin in Y, with seed-dependent streaks.
            // Keep discrete Minecraft-like voxel edges; no smooth-ball impostors.
            double bend=.09*Math.sin((x+z)*4+seed*.0001);
            double ribbon1=puff(x,ny,z,-.20,.50+bend,-.14,.94,.095,.22);
            double ribbon2=puff(x,ny,z,.26,.55-bend,.24,.83,.065,.19);
            double veil=puff(x,ny,z,-.12,.52,.04,.88,.055,.64)*.70;
            body=Math.max(Math.max(ribbon1,ribbon2),veil);
        }else if(type==3||type==4||type==0){
            // Low and stratiform clouds stretch over several regional cells.
            double vertical=type==3?.16:type==4?.26:.30;
            body=Math.max(
                puff(x,ny,z,-.16+s1,.22,.04+s2,.92,vertical,.89),
                puff(x,ny,z,.38+s2,.25,-.26+s1,.69,vertical*.90,.76));
            if(type==4){ // More distinct soft rolls in stratocumulus.
                body=Math.max(body,puff(x,ny,z,-.39+s2,.39,-.25,.51,.24,.50));
            }
        }else{
            // A wide, fairly flat convective base and overlapping buoyant heads.
            // Unlike the former tall single ovals, the shared base joins lobes
            // and the cloud broadens substantially before growing upward.
            body=Math.max(
                puff(x,ny,z,-.32+s1,.17,.05,.72,.23,.72),
                puff(x,ny,z,.27+s2,.19,-.10,.72,.25,.74));
            body=Math.max(body,puff(x,ny,z,-.08,.22,.32+s1,.67,.23,.58));
            body=Math.max(body,puff(x,ny,z,-.39+s1,.40,-.13,.48,.30,.49));
            body=Math.max(body,puff(x,ny,z,.29+s2,.46,.15,.46,.32,.51));
            body=Math.max(body,puff(x,ny,z,.02,.52,-.27+s1,.39,.26,.39));
            if(type==2){
                // A distinct congestus turret, still rooted in its wide base.
                body=Math.max(body,puff(x,ny,z,-.26+s1,.64,-.08,.39,.28,.43));
                body=Math.max(body,puff(x,ny,z,-.13+s1,.82,-.02,.31,.18,.34));
                body=Math.max(body,puff(x,ny,z,.18+s2,.68,.12,.32,.22,.38));
            }else{
                body=Math.max(body,puff(x,ny,z,.16+s2,.64,.13,.35,.19,.36));
            }
        }
        if(body<-.35)return 0;
        double edge=(fbm(nx*5.0+17,ny*5.8+29,nz*5.0-13,seed+237)-.5)*.27;
        // Fine break-up is local to the edge; the interior stays solid.
        double fine=(noise(nx*13.0+4,ny*12.0+18,nz*13.0+1,seed+509)-.5)*.065;
        // Large precipitation decks need broad holes and irregular margins;
        // fine voxel noise alone only produced a perfectly continuous slab.
        double breakup=(type==6||type==8)
            ?(fbm(nx*2.1-4,ny*1.7+2,nz*2.1+8,seed+811)-.5)*.34:0;
        return clamp(body*.99+.21+edge+fine+breakup,0,1);
    }
    /** Stable world-space voxel sample locations; weather controls radius, thickness and opacity.
     * One volume per 64x64 weather cell, max 11x7x11 density probes.
     */
    public static List<Voxel> build(int cx,int cz,float cloudBase,int type,float coverage,float water){
        double strength=clamp(Math.min(coverage*1.3,water*1.5),0,1);
        if(strength<.07)return List.of();
        int seed=cx*73428767^cz*912931^0x4d455445;
        boolean layer=type==0||type==3||type==4;
        float width=layer?58:44;
        float height=type==2?66:type==1?38:layer?18:30;
        // Strong convection yields deeper cloud; cloudBase always comes from meteorology.
        height*=type==2?(0.75+0.5*strength):(0.85+0.22*strength);
        float stepX=width/13,stepY=height/9,stepZ=width/13;
        float centerX=cx*64+32+(float)((hash(cx,2,cz,seed)-.5)*11);
        float centerZ=cz*64+32+(float)((hash(cx,5,cz,seed)-.5)*11);
        List<Voxel> voxels=new ArrayList<>();
        for(int iy=0;iy<9;iy++)for(int ix=0;ix<13;ix++)for(int iz=0;iz<13;iz++){
            double nx=(ix-6)/6.0,ny=(iy+.5)/9.0,nz=(iz-6)/6.0;
            double d=density(nx,ny,nz,type,seed);
            if(d<.27)continue;
            // Opacity and brightness are the integrated contribution of this density probe.
            float opacity=(float)clamp((d-.24)*strength*.11,.005,.095);
            float shade=(float)clamp(.48+ny*.38+(noise(nx*4,ny*4,nz*4,seed+29)-.5)*.13,.36,.98);
            voxels.add(new Voxel(centerX+(ix-6)*stepX,
                cloudBase+(iy+.5f)*stepY,centerZ+(iz-6)*stepZ,
                Math.max(stepX,stepZ)*1.12f,opacity,shade));
        }
        return List.copyOf(voxels);
    }
}
