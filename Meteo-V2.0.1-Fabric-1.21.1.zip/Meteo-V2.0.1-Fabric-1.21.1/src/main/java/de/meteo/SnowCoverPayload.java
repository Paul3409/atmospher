package de.meteo;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record SnowCoverPayload(SnowCoverSettings.Settings settings) implements CustomPayload {
    public static final Id<SnowCoverPayload> ID=new Id<>(Identifier.of("meteo","snow_cover_settings"));
    public static final PacketCodec<RegistryByteBuf,SnowCoverPayload> CODEC=CustomPayload.codecOf(SnowCoverPayload::write,SnowCoverPayload::read);
    private void write(RegistryByteBuf b){b.writeBoolean(settings.enabled());b.writeVarInt(settings.radius());
        b.writeVarInt(settings.accumulation());b.writeVarInt(settings.melt());}
    private static SnowCoverPayload read(RegistryByteBuf b){return new SnowCoverPayload(new SnowCoverSettings.Settings(
        b.readBoolean(),b.readVarInt(),b.readVarInt(),b.readVarInt()));}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
