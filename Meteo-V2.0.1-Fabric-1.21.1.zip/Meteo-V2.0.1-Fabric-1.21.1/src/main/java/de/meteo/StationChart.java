package de.meteo;

import java.util.List;

/** Deterministic chart geometry. Pure Java so chart rendering can be tested without Minecraft. */
public final class StationChart {
    private StationChart() {}
    public record Point(int x, int y) {}
    public record Series(List<Point> points, double minimum, double maximum) {}
    public static double value(StationReading r, int kind) {
        return switch(kind) {
            case 0 -> r.temperature(); case 1 -> r.pressure(); case 2 -> r.windSpeed();
            case 3 -> r.rainRate(); case 4 -> r.cloudCover()*100; case 5 -> r.dewPoint();
            case 6 -> r.snowRate(); case 7 -> r.snowTotal(); default -> r.dewPoint();
        };
    }
    public static Series layout(List<StationReading> readings, int kind, int width, int height) {
        if (readings == null || readings.isEmpty() || width < 12 || height < 12)
            return new Series(List.of(), 0, 1);
        double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
        for(var reading:readings) {
            double v=value(reading,kind);
            if(!Double.isFinite(v))continue;
            min=Math.min(min,v);max=Math.max(max,v);
        }
        if(!Double.isFinite(min)||!Double.isFinite(max))return new Series(List.of(),0,1);
        if(max-min<0.02) {max+=0.5;min-=0.5;}
        else {double margin=(max-min)*0.08;max+=margin;min-=margin;}
        long first=readings.get(0).tick(),last=readings.get(readings.size()-1).tick();
        var points=new java.util.ArrayList<Point>(readings.size());
        for(int i=0;i<readings.size();i++) {
            StationReading r=readings.get(i);
            double t=last>first?(double)(r.tick()-first)/(last-first):readings.size()>1?(double)i/(readings.size()-1):0.5;
            int x=(int)Math.round(Math.max(0,Math.min(1,t))*(width-1));
            int y=(int)Math.round((1-Math.max(0,Math.min(1,(value(r,kind)-min)/(max-min))))*(height-1));
            points.add(new Point(x,y));
        }
        return new Series(List.copyOf(points),min,max);
    }
}
