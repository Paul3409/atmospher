package de.meteo;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;
/** World-scoped server synoptic preferences (not shared between saves). */
public final class SynopticConfigStore {
    private SynopticConfigStore(){}
    public static SynopticWeather.Settings load(Path root){
        Path file=root.resolve("data/meteo-synoptic.properties");
        try{
            if(!Files.exists(file))return SynopticWeather.DEFAULT;
            Properties p=new Properties();try(var in=Files.newInputStream(file)){p.load(in);}
            var d=SynopticWeather.DEFAULT;
            return new SynopticWeather.Settings(integer(p,"high",d.highStrength()),integer(p,"low",d.lowStrength()),
                integer(p,"duration",d.duration()),integer(p,"frontStrength",d.frontStrength()),integer(p,"thunder",d.thunderFrequency()),
                integer(p,"storm",d.stormStrength()),bool(p,"fronts",d.fronts()),bool(p,"hud",d.hud()),bool(p,"warnings",d.warnings()),
                bool(p,"isobars",d.isobars()),bool(p,"precip",d.precip()),bool(p,"cloudFronts",d.cloudFronts()));
        }catch(Exception e){MeteoMod.LOGGER.warn("Meteo synoptic settings load failed",e);return SynopticWeather.DEFAULT;}
    }
    private static int integer(Properties p,String name,int fallback){return Integer.parseInt(p.getProperty(name,Integer.toString(fallback)));}
    private static boolean bool(Properties p,String name,boolean fallback){return Boolean.parseBoolean(p.getProperty(name,Boolean.toString(fallback)));}
    public static void save(Path root,SynopticWeather.Settings s){
        Path file=root.resolve("data/meteo-synoptic.properties");
        try{
            Properties p=new Properties();p.setProperty("high",""+s.highStrength());p.setProperty("low",""+s.lowStrength());
            p.setProperty("duration",""+s.duration());p.setProperty("frontStrength",""+s.frontStrength());
            p.setProperty("thunder",""+s.thunderFrequency());p.setProperty("storm",""+s.stormStrength());
            p.setProperty("fronts",""+s.fronts());p.setProperty("hud",""+s.hud());p.setProperty("warnings",""+s.warnings());
            p.setProperty("isobars",""+s.isobars());p.setProperty("precip",""+s.precip());p.setProperty("cloudFronts",""+s.cloudFronts());
            Files.createDirectories(file.getParent());try(var out=Files.newOutputStream(file)){p.store(out,"Meteo V1.6 synoptic settings");}
        }catch(IOException e){MeteoMod.LOGGER.error("Cannot save synoptic settings",e);}
    }
}
