package de.meteo.client;

import de.meteo.WeatherDynamics;
import de.meteo.WeatherSettingsPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;

/** Server-authoritative O-menu controls. Updates appear only after server acknowledgement. */
public final class WeatherControls {
    private WeatherControls(){}
    private static WeatherDynamics.Settings current=WeatherDynamics.DEFAULT;
    private static boolean received;
    public static void accept(WeatherSettingsPayload payload){
        current=payload.validated();received=true;
        if(MinecraftClient.getInstance().currentScreen instanceof MeteoScreen screen)screen.syncRefresh();
    }
    public static void clear(){received=false;current=WeatherDynamics.DEFAULT;}
    public static boolean ready(){return received&&ClientPlayNetworking.canSend(WeatherSettingsPayload.ID);}
    public static WeatherDynamics.Settings current(){return current;}
    public static void request(WeatherDynamics.Settings next){
        if(ready()){current=next;ClientPlayNetworking.send(WeatherSettingsPayload.of(next));}
    }
    public static String paceName(){return new String[]{"Ruhig","Normal","Lebendig","Turbulent"}[current.pace()];}
    public static String modeName(){return new String[]{"Dynamisch","Wechselhaft","Fest"}[current.windMode()];}
    public static String compass(){return new String[]{"N","NO","O","SO","S","SW","W","NW"}[current.fixedFrom()/45];}
}
