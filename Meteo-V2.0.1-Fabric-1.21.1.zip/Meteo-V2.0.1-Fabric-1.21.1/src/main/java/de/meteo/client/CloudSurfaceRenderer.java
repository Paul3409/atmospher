package de.meteo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import de.meteo.CloudLife;
import de.meteo.CloudMotion;
import de.meteo.CloudSnapshotPayload;
import de.meteo.CloudStability;
import de.meteo.CloudSurfaceMesh;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

/** V2: one closed, opaque surface for each stable server formation. */
public final class CloudSurfaceRenderer {
    private CloudSurfaceRenderer() {}
    private static final class Cloud {
        CloudSnapshotPayload.CloudCell weather;
        CloudSurfaceMesh.Mesh mesh;
        int meshType=-1,meshQuality=-1;
        double x,z,baseY,growth;
        long seen;
        Cloud(CloudSnapshotPayload.CloudCell data,long tick){
            weather=data;x=data.x();z=data.z();baseY=data.baseY();seen=tick;
        }
    }
    private static final Map<Long,Cloud> clouds=new LinkedHashMap<>();
    private static CloudSurfaceMesh.Mesh previewMesh;
    private static int previewQuality=-1;
    private static long ticks;
    private static long id(int cx,int cz){return ((long)cx<<32)^(cz&0xffffffffL);}
    public static void clear(){clouds.clear();ticks=0;previewMesh=null;previewQuality=-1;}
    public static int count(){return clouds.size();}
    public static void accept(CloudSnapshotPayload packet){
        for(var cell:packet.cells()){
            long key=id(cell.cx(),cell.cz());
            Cloud cloud=clouds.get(key);
            if(cloud==null){cloud=new Cloud(cell,ticks);clouds.put(key,cloud);}
            cloud.weather=cell;cloud.seen=ticks;
        }
    }
    public static void tick(MinecraftClient client){
        if(client.world==null){clear();return;}
        ticks++;
        var iterator=clouds.values().iterator();
        while(iterator.hasNext()){
            Cloud cloud=iterator.next();
            boolean recent=ticks-cloud.seen<1200;
            double target=recent?CloudLife.target(cloud.weather.cover(),cloud.weather.liquid()):0;
            cloud.growth=CloudLife.approach(cloud.growth,target,1);
            cloud.baseY=CloudStability.approach(cloud.baseY,cloud.weather.baseY(),1,800);
            double elapsed=Math.min(12,Math.max(0,ticks-cloud.seen));
            var position=CloudMotion.advance(new CloudMotion.Position(cloud.weather.x(),cloud.weather.z()),
                cloud.weather.windU(),cloud.weather.windV(),elapsed*3.6);
            cloud.x=CloudStability.approach(cloud.x,position.x(),1,8);
            cloud.z=CloudStability.approach(cloud.z,position.z(),1,8);
            if(!recent&&cloud.growth<.008&&ticks-cloud.seen>7200)iterator.remove();
        }
    }
    private static void vertex(BufferBuilder buffer,Matrix4f pose,float x,float y,float z,int r,int g,int b){
        buffer.vertex(pose,x,y,z).color(r,g,b,255);
    }
    private static void face(BufferBuilder buffer,Matrix4f pose,CloudSurfaceMesh.Face f,double sunlight,int type){
        double side=f.side()==3?1.05:f.side()==2?.58:.75;
        double weather=type==7?.65:type==6||type==8?.77:1;
        double light=(.34+.66*sunlight)*side*weather*(1+f.shade()*.18);
        int r=(int)Math.max(25,Math.min(255,250*light));
        int g=(int)Math.max(27,Math.min(255,251*light));
        int b=(int)Math.max(31,Math.min(255,255*light));
        float x0=f.x0(),x1=f.x1(),y0=f.y0(),y1=f.y1(),z0=f.z0(),z1=f.z1();
        switch(f.side()){
            case 0 -> {vertex(buffer,pose,x0,y0,z0,r,g,b);vertex(buffer,pose,x0,y0,z1,r,g,b);vertex(buffer,pose,x0,y1,z1,r,g,b);vertex(buffer,pose,x0,y1,z0,r,g,b);}
            case 1 -> {vertex(buffer,pose,x1,y0,z1,r,g,b);vertex(buffer,pose,x1,y0,z0,r,g,b);vertex(buffer,pose,x1,y1,z0,r,g,b);vertex(buffer,pose,x1,y1,z1,r,g,b);}
            case 2 -> {vertex(buffer,pose,x0,y0,z1,r,g,b);vertex(buffer,pose,x0,y0,z0,r,g,b);vertex(buffer,pose,x1,y0,z0,r,g,b);vertex(buffer,pose,x1,y0,z1,r,g,b);}
            case 3 -> {vertex(buffer,pose,x0,y1,z0,r,g,b);vertex(buffer,pose,x0,y1,z1,r,g,b);vertex(buffer,pose,x1,y1,z1,r,g,b);vertex(buffer,pose,x1,y1,z0,r,g,b);}
            case 4 -> {vertex(buffer,pose,x1,y0,z0,r,g,b);vertex(buffer,pose,x0,y0,z0,r,g,b);vertex(buffer,pose,x0,y1,z0,r,g,b);vertex(buffer,pose,x1,y1,z0,r,g,b);}
            case 5 -> {vertex(buffer,pose,x0,y0,z1,r,g,b);vertex(buffer,pose,x1,y0,z1,r,g,b);vertex(buffer,pose,x1,y1,z1,r,g,b);vertex(buffer,pose,x0,y1,z1,r,g,b);}
            default -> throw new IllegalArgumentException("cloud face");
        }
    }
    private static int emit(MatrixStack stack,BufferBuilder buffer,CloudSurfaceMesh.Mesh mesh,
                            double x,double y,double z,double growth,double rangeFade,int type,double sun){
        if(mesh==null||mesh.faces().isEmpty())return 0;
        stack.push();stack.translate(x,y,z);
        stack.scale((float)(CloudLife.horizontalScale(growth)*rangeFade),
            (float)(CloudLife.verticalScale(growth)*rangeFade),
            (float)(CloudLife.horizontalScale(growth)*rangeFade));
        Matrix4f pose=stack.peek().getPositionMatrix();
        for(var face:mesh.faces())face(buffer,pose,face,sun,type);
        stack.pop();
        return mesh.faces().size();
    }
    public static void render(WorldRenderContext context){
        var client=MinecraftClient.getInstance();
        if(!CloudVolumeRenderer.enabled()||client.world==null||client.player==null||
            context.world()!=client.world||context.matrixStack()==null)return;
        if(client.world.getRegistryKey()!=net.minecraft.world.World.OVERWORLD)return;
        Vec3d eye=context.camera().getPos();
        int range=CloudVolumeRenderer.rangeBlocks();
        var visible=new ArrayList<Cloud>();
        for(Cloud cloud:clouds.values()){
            if(cloud.growth<.025)continue;
            if(Math.hypot(cloud.x-eye.x,cloud.z-eye.z)>range+80)continue;
            visible.add(cloud);
        }
        visible.sort(Comparator.comparingDouble(c->Math.hypot(c.x-eye.x,c.z-eye.z)));
        int budget=switch(CloudVolumeRenderer.optimizationName()){
            case "Stark" -> 72;case "Ausgewogen" -> 112;default -> 160;
        };
        if(visible.size()>budget)visible.subList(budget,visible.size()).clear();
        if(visible.isEmpty()&&!CloudVolumeRenderer.preview())return;
        double time=Math.floorMod(client.world.getTimeOfDay(),24000);
        double sun=Math.max(0,Math.sin(Math.PI*time/12000));
        MatrixStack stack=context.matrixStack();stack.push();stack.translate(-eye.x,-eye.y,-eye.z);
        try{
            RenderSystem.enableDepthTest();RenderSystem.depthMask(true);RenderSystem.disableBlend();
            RenderSystem.disableCull();RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            BufferBuilder buffer=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            int faces=0;
            for(Cloud cloud:visible){
                int type=cloud.weather.type();
                int detail=CloudVolumeRenderer.quality().ordinal();
                double distance=Math.hypot(cloud.x-eye.x,cloud.z-eye.z);
                if(distance>480)detail=Math.min(detail,1);
                if(distance>850)detail=0;
                if(cloud.mesh==null||cloud.meshType!=type||cloud.meshQuality!=detail){
                    cloud.mesh=CloudSurfaceMesh.build(cloud.weather.cx(),cloud.weather.cz(),type,detail);
                    cloud.meshType=type;cloud.meshQuality=detail;
                }
                double fade=Math.max(0,Math.min(1,(range+80-distance)/80));
                faces+=emit(stack,buffer,cloud.mesh,cloud.x,cloud.baseY,cloud.z,cloud.growth,fade,type,sun);
            }
            if(CloudVolumeRenderer.preview()){
                Vec3d view=client.player.getRotationVec(1);
                double x=eye.x+view.x*110,z=eye.z+view.z*110,y=eye.y+62;
                int detail=CloudVolumeRenderer.quality().ordinal();
                if(previewMesh==null||previewQuality!=detail){
                    previewMesh=CloudSurfaceMesh.build(12,24,2,detail);previewQuality=detail;
                }
                faces+=emit(stack,buffer,previewMesh,x,y,z,.85,1,2,sun);
            }
            if(faces>0)BufferRenderer.drawWithGlobalProgram(buffer.end());
        }finally{RenderSystem.enableCull();RenderSystem.depthMask(true);stack.pop();}
    }
}
