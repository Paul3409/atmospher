package de.meteo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import de.meteo.CloudSnapshotPayload;
import de.meteo.PrecipitationPhase;
import de.meteo.RainPhysics;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import org.joml.Matrix4f;
import java.nio.file.*;
import java.util.*;

/** Independent lightweight snowflake quads (not Vanilla snow particles), wind-advected and collision bounded. */
public final class SnowEffects {
    private SnowEffects(){}
    public static boolean enabled=true,drift=true;
    public static int density=1,size=1,speed=1;
    private static final class Flake {
        double x,y,z,ground,vx,vy,vz,phase;float radius;
        Flake(double x,double y,double z,double ground,double vx,double vy,double vz,float radius,double phase){
            this.x=x;this.y=y;this.z=z;this.ground=ground;this.vx=vx;this.vy=vy;this.vz=vz;this.radius=radius;this.phase=phase;
        }
    }
    private static final List<Flake> FLAKES=new ArrayList<>();
    private static net.minecraft.world.World previous;
    private static double remainder,visibleRate;
    private static Path path(){return FabricLoader.getInstance().getConfigDir().resolve("meteo-snow.properties");}
    public static void load(){try{
        if(!Files.isRegularFile(path()))return;
        Properties p=new Properties();try(var in=Files.newInputStream(path())){p.load(in);}
        enabled=Boolean.parseBoolean(p.getProperty("enabled","true"));drift=Boolean.parseBoolean(p.getProperty("drift","true"));
        density=clamp(Integer.parseInt(p.getProperty("density","1")));size=clamp(Integer.parseInt(p.getProperty("size","1")));
        speed=clamp(Integer.parseInt(p.getProperty("speed","1")));
    }catch(Exception e){System.err.println("Meteo snow settings: "+e.getMessage());}}
    private static int clamp(int v){return Math.max(0,Math.min(3,v));}
    public static void save(){try{
        Files.createDirectories(path().getParent());Properties p=new Properties();
        p.setProperty("enabled",Boolean.toString(enabled));p.setProperty("drift",Boolean.toString(drift));
        p.setProperty("density",Integer.toString(density));p.setProperty("size",Integer.toString(size));
        p.setProperty("speed",Integer.toString(speed));
        try(var out=Files.newOutputStream(path())){p.store(out,"Meteo snowflakes");}
    }catch(Exception e){System.err.println("Meteo snow settings: "+e.getMessage());}}
    public static void clear(){FLAKES.clear();previous=null;remainder=0;visibleRate=0;}
    public static void tick(MinecraftClient client){
        if(client.world!=previous){clear();previous=client.world;}
        if(client.world==null||client.player==null||!enabled){FLAKES.clear();visibleRate=0;return;}
        if(client.world.getRegistryKey()!=net.minecraft.world.World.OVERWORLD){FLAKES.clear();return;}
        double px=client.player.getX(),py=client.player.getY(),pz=client.player.getZ();
        for(Iterator<Flake> it=FLAKES.iterator();it.hasNext();){
            var f=it.next();f.phase+=.09;f.y-=f.vy;f.x+=f.vx+Math.sin(f.phase)*.011;f.z+=f.vz+Math.cos(f.phase)*.009;
            if(f.y<f.ground || Math.abs(f.x-px)>64 || Math.abs(f.z-pz)>64 || f.y<py-30 || f.y>py+67)it.remove();
        }
        CloudSnapshotPayload packet=CloudVolumeRenderer.lastSnapshot();if(packet==null)return;
        var rng=client.world.random;
        double area=0;
        for(var c:packet.cells())if(c.rainMmHour()>.1 && PrecipitationPhase.snowFraction(c.temperatureC())>.1){
            double dist=Math.hypot(Math.max(0,Math.abs(c.x()-px)-20),Math.max(0,Math.abs(c.z()-pz)-20));
            area+=RainPhysics.localRate(0,0,dist,0,c.rainMmHour(),c.type())*PrecipitationPhase.snowFraction(c.temperatureC());
        }
        visibleRate+=(Math.min(28,area)-visibleRate)*(area>visibleRate?.022:.010);
        if(visibleRate<.035)return;
        remainder+=Math.min(18,visibleRate*new double[]{.45,.9,1.5,2.25}[density]);
        int count=Math.min(Math.min((int)remainder,45),Math.max(0,550-FLAKES.size()));remainder-=count;
        for(int i=0;i<count;i++){
            double x=px+(rng.nextDouble()-.5)*58,z=pz+(rng.nextDouble()-.5)*58;
            BlockPos bp=new BlockPos((int)Math.floor(x),0,(int)Math.floor(z));
            if(!client.world.isChunkLoaded(bp))continue;
            double intensity=0,u=0,v=0;
            for(var c:packet.cells()){
                double r=RainPhysics.localRate(c.x(),c.z(),x,z,c.rainMmHour(),c.type())*PrecipitationPhase.snowFraction(c.temperatureC());
                if(r>.001){intensity+=r;u+=r*c.windU();v+=r*c.windV();}
            }
            if(intensity<.13||rng.nextDouble()>Math.min(1,intensity/4))continue;
            double ground=client.world.getTopY(Heightmap.Type.MOTION_BLOCKING,bp.getX(),bp.getZ());
            double y=py+6+rng.nextDouble()*48;if(y<ground+1)continue;
            double fall=(.055+rng.nextDouble()*.065)*new double[]{.65,.9,1.25,1.65}[speed];
            double driftFactor=drift?.020:0;
            float radius=(float)((.055+rng.nextDouble()*.045)*new double[]{.7,1,1.5,2.05}[size]);
            FLAKES.add(new Flake(x,y,z,ground,
                Math.max(-.14,Math.min(.14,driftFactor*u/Math.max(.2,intensity))),fall,
                Math.max(-.14,Math.min(.14,driftFactor*v/Math.max(.2,intensity))),radius,
                rng.nextDouble()*Math.PI*2));
        }
    }
    private static void vertex(BufferBuilder b,Matrix4f matrix,double x,double y,double z,int alpha){
        b.vertex(matrix,(float)x,(float)y,(float)z).color(246,249,255,alpha);
    }
    public static void render(WorldRenderContext ctx){
        if(!enabled||FLAKES.isEmpty()||ctx.matrixStack()==null)return;
        var client=MinecraftClient.getInstance();if(client.world==null||client.world!=ctx.world())return;
        Vec3d eye=ctx.camera().getPos();MatrixStack stack=ctx.matrixStack();stack.push();stack.translate(-eye.x,-eye.y,-eye.z);
        try{
            RenderSystem.enableDepthTest();RenderSystem.disableCull();RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            Matrix4f m=stack.peek().getPositionMatrix();
            BufferBuilder b=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            int n=0;
            for(var f:FLAKES){double d=Math.hypot(f.x-eye.x,f.z-eye.z);if(d>63)continue;
                double r=f.radius;int a=(int)(225*Math.max(.2,1-d/72));
                vertex(b,m,f.x-r,f.y,f.z,a);vertex(b,m,f.x+r,f.y,f.z,a);
                vertex(b,m,f.x+r,f.y-2*r,f.z,a);vertex(b,m,f.x-r,f.y-2*r,f.z,a);
                vertex(b,m,f.x,f.y,f.z-r,a);vertex(b,m,f.x,f.y,f.z+r,a);
                vertex(b,m,f.x,f.y-2*r,f.z+r,a);vertex(b,m,f.x,f.y-2*r,f.z-r,a);n+=2;
            }
            if(n>0)BufferRenderer.drawWithGlobalProgram(b.end());
        }finally{RenderSystem.depthMask(true);RenderSystem.disableBlend();RenderSystem.enableCull();stack.pop();}
    }
}
