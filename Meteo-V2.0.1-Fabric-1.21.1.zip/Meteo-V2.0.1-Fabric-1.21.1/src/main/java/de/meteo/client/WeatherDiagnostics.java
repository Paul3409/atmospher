package de.meteo.client;

import de.meteo.CloudDiagnosticPayload;
import net.minecraft.client.MinecraftClient;

/** Live player-local server data for the Meteo diagnostic tab. */
public final class WeatherDiagnostics {
    private WeatherDiagnostics(){}
    private static CloudDiagnosticPayload latest;
    private static long receivedAt=-1;
    public static void accept(CloudDiagnosticPayload p){latest=p;receivedAt=System.currentTimeMillis();}
    public static void clear(){latest=null;receivedAt=-1;}
    public static boolean available(){return latest!=null&&System.currentTimeMillis()-receivedAt<12000;}
    public static CloudDiagnosticPayload latest(){return available()?latest:null;}
    public static String[] rows(){
        if(!available())return new String[]{"Noch keine aktuellen Wetterdaten vom Server.",
            "Die Messwerte werden alle 2 Sekunden synchronisiert."};
        var d=latest;
        double wind=Math.hypot(d.windU(),d.windV());
        String flow=d.orographicLift()>.08?"LUV / aufsteigende Luft":
            d.orographicLift()<-.08?"LEE / absinkende Luft":"Neutral / schwache Gelaendehebung";
        String tendency=d.cover()<.09?"Wenig Wolkenwasser / wolkenarm":
            d.lift()>.08&&d.humidity()>.70?"Kondensation durch Feuchte und Hebung":
            d.orographicLift()<-.08?"Aufloesung durch absinkende Luft":"Bestehende Wolken / schwacher Aufwind";
        return new String[]{
            String.format(java.util.Locale.ROOT,"Luft: %.1f C | Taupunkt: %.1f C | Feuchte: %.0f%%",
                d.temperatureC(),d.dewPointC(),d.humidity()*100),
            String.format(java.util.Locale.ROOT,"Wolkenbasis: Y %.0f | %.0f Bl. ueber Boden",
                d.baseWorldY(),d.baseAboveGround()),
            String.format(java.util.Locale.ROOT,"Aufwind: %+.2f | Gelaende: %+.2f m/s",
                d.lift(),d.orographicLift()),
            "Orographie: "+flow,
            String.format(java.util.Locale.ROOT,"Wind: %.1f m/s | Bewoelkung: %.0f%% | Wasser: %.3f",
                wind,d.cover()*100,d.cloudWater()),
            String.format(java.util.Locale.ROOT,"Regen hier: %.2f mm/h | Formationen: %d | Schauer: %d",
                CloudVolumeRenderer.rainHere(),d.activeFormations(),d.wetFormations()),
            "Diagnose: "+tendency,
            "Alle Werte aus der Wetter-Simulation (kein Testwetter)."
        };
    }
}
