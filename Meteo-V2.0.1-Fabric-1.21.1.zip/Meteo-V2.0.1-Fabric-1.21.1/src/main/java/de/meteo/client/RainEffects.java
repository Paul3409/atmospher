package de.meteo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import de.meteo.CloudSnapshotPayload;
import de.meteo.RainPhysics;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import org.joml.Matrix4f;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

/** Custom continuous rain streaks. The exact same server rain field powers radar.
 * Raindrops are world-space objects: each reaches the local top surface, unless
 * wind moves it or it leaves the loaded world. Unlike vanilla RAIN particles,
 * their lifetime is determined by distance to terrain, not a random short timer.
 */
public final class RainEffects {
    private RainEffects() {}
    private static final class Drop {
        double x,y,z,ground,dx,dz,velocity,width,length;
        Drop(double x,double y,double z,double ground,double dx,double dz,double velocity,double width,double length){
            this.x=x;this.y=y;this.z=z;this.ground=ground;this.dx=dx;this.dz=dz;this.velocity=velocity;this.width=width;this.length=length;
        }
    }
    private static final class Splash {
        final double x,y,z;
        int age;
        Splash(double x,double y,double z){this.x=x;this.y=y;this.z=z;}
    }
    private static final List<Drop> DROPS=new ArrayList<>();
    private static final List<Splash> SPLASHES=new ArrayList<>();
    private static boolean rainEnabled=true,windDrift=true,splashEnabled=true;
    private static int size=1; // 0 fine, 1 normal, 2 large
    private static int density=1; // 0 sparse, 1 medium, 2 dense
    private static double spawnRemainder,visibleRate;
    private static net.minecraft.world.World previousWorld;
    public static void reset(){DROPS.clear();SPLASHES.clear();spawnRemainder=0;visibleRate=0;previousWorld=null;}
    public static boolean enabled(){return rainEnabled;}
    public static int size(){return size;}
    public static int density(){return density;}
    public static String sizeName(){return new String[]{"Fein","Gross","Sehr gross"}[size];}
    public static String densityName(){return new String[]{"Wenig","Normal","Dicht"}[density];}
    public static void toggle(){rainEnabled=!rainEnabled;if(!rainEnabled)DROPS.clear();save();}
    public static void cycleSize(){size=(size+1)%3;save();}
    public static void cycleDensity(){density=(density+1)%3;save();}
    public static boolean windDrift(){return windDrift;}
    public static boolean splashEnabled(){return splashEnabled;}
    public static void toggleWindDrift(){windDrift=!windDrift;save();}
    public static void toggleSplashes(){splashEnabled=!splashEnabled;if(!splashEnabled)SPLASHES.clear();save();}
    private static Path path(){return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meteo-rain.properties");}
    public static void load(){
        try{
            if(!Files.exists(path()))return;
            Properties p=new Properties();try(var in=Files.newInputStream(path())){p.load(in);}
            rainEnabled=Boolean.parseBoolean(p.getProperty("enabled","true"));
            size=Math.max(0,Math.min(2,Integer.parseInt(p.getProperty("size","1"))));
            density=Math.max(0,Math.min(2,Integer.parseInt(p.getProperty("density","1"))));
            windDrift=Boolean.parseBoolean(p.getProperty("windDrift","true"));
            splashEnabled=Boolean.parseBoolean(p.getProperty("splashes","true"));
        }catch(Exception ex){System.err.println("Meteo rain settings: "+ex.getMessage());}
    }
    private static void save(){
        try{Properties p=new Properties();p.setProperty("enabled",Boolean.toString(rainEnabled));
            p.setProperty("size",Integer.toString(size));p.setProperty("density",Integer.toString(density));
            p.setProperty("windDrift",Boolean.toString(windDrift));p.setProperty("splashes",Boolean.toString(splashEnabled));
            try(var out=Files.newOutputStream(path())){p.store(out,"Meteo visible rainfall");}
        }catch(java.io.IOException ex){System.err.println("Meteo rain settings: "+ex.getMessage());}
    }
    public static String info(){return "Regenstreifen: "+DROPS.size()+" | " + sizeName()+" / "+densityName();}
    public static void tick(MinecraftClient client){
        if(client.world!=previousWorld){DROPS.clear();SPLASHES.clear();spawnRemainder=0;previousWorld=client.world;}
        if(client.world==null||client.player==null||!rainEnabled){DROPS.clear();SPLASHES.clear();visibleRate=0;return;}
        if(client.world.getRegistryKey()!=net.minecraft.world.World.OVERWORLD){DROPS.clear();return;}
        for(Iterator<Splash> it=SPLASHES.iterator();it.hasNext();)
            if(++it.next().age>11)it.remove();
        for(Iterator<Drop> it=DROPS.iterator();it.hasNext();){
            Drop d=it.next();
            d.y-=d.velocity;
            if(windDrift){d.x+=d.dx;d.z+=d.dz;}
            if(Math.abs(d.x-client.player.getX())>80||Math.abs(d.z-client.player.getZ())>80){it.remove();continue;}
            // Block-column top is sampled again after drift: new roofs and
            // structures immediately stop falling drops.
            int bx=(int)Math.floor(d.x),bz=(int)Math.floor(d.z);
            if(client.world.isChunkLoaded(new BlockPos(bx,0,bz)))
                d.ground=client.world.getTopY(Heightmap.Type.MOTION_BLOCKING,bx,bz);
            if(d.y<=d.ground+.05){
                if(splashEnabled&&SPLASHES.size()<250)SPLASHES.add(new Splash(d.x,d.ground+.025,d.z));
                it.remove();
            }
        }
        CloudSnapshotPayload packet=CloudVolumeRenderer.lastSnapshot();
        if(packet==null)return;
        List<CloudSnapshotPayload.CloudCell> cells=packet.cells();
        double px=client.player.getX(),pz=client.player.getZ(),py=client.player.getY();
        var rng=client.world.random;
        // Sample the rainfall over the visible area, not only at the player's
        // exact X/Z: a shower 25 blocks away must remain visible from dry ground.
        double area=0;
        for(var c:cells)if(c.rainMmHour()>.15){
            double closest=Math.hypot(Math.max(0,Math.abs(c.x()-px)-30),
                                       Math.max(0,Math.abs(c.z()-pz)-30));
            area+=RainPhysics.localRate(0,0,closest,0,c.rainMmHour(),c.type());
        }
        double targetRate=Math.min(30,area);
        visibleRate+=(targetRate-visibleRate)*(targetRate>visibleRate?.025:.012);
        if(visibleRate<.04)return;
        double rate=visibleRate;
        spawnRemainder+=Math.min(28,rate*(density==0?.75:density==1?1.8:2.65));
        int n=(int)Math.floor(spawnRemainder);
        spawnRemainder-=n;
        n=Math.min(n,Math.max(0,700-DROPS.size()));
        for(int i=0;i<n;i++){
            double x=px+(rng.nextDouble()-.5)*68,z=pz+(rng.nextDouble()-.5)*68;
            int bx=(int)Math.floor(x),bz=(int)Math.floor(z);
            if(!client.world.isChunkLoaded(new BlockPos(bx,0,bz)))continue;
            int ground=client.world.getTopY(Heightmap.Type.MOTION_BLOCKING,bx,bz);
            double intensity=0,temperature=10,windX=0,windZ=0,lowestBase=Double.POSITIVE_INFINITY;
            for(var c:cells){
                if(c.rainMmHour()<.15)continue;
                double local=RainPhysics.localRate(c.x(),c.z(),x,z,c.rainMmHour(),c.type());
                if(local>.005){
                    intensity+=local;temperature=c.temperatureC();windX+=c.windU()*local;windZ+=c.windV()*local;
                    lowestBase=Math.min(lowestBase,c.baseY());
                }
            }
            if(intensity<.12||rng.nextDouble()>Math.min(1,intensity/4))continue;
            double origin=Math.min(lowestBase-2,py+45+rng.nextDouble()*12);
            // From near cloud base to the ground, as long as camera is nearby;
            // world-depth testing naturally hides drops behind intervening roofs.
            if(origin<=ground+3)continue;
            double y=ground+3+rng.nextDouble()*(origin-ground-3);
            double u=windX/Math.max(.1,intensity),v=windZ/Math.max(.1,intensity);
            if(rng.nextDouble()<de.meteo.PrecipitationPhase.snowFraction(temperature)){
                // Rendered by SnowEffects using independently controlled Meteo flakes.
            }else{
                int stage=de.meteo.RainVisualPhysics.stage(intensity);
                double speed=de.meteo.RainVisualPhysics.fallSpeed(stage,rng.nextDouble());
                double width=de.meteo.RainVisualPhysics.width(stage,size,rng.nextDouble());
                double length=de.meteo.RainVisualPhysics.length(stage,size,rng.nextDouble());
                double drift=windDrift?.018:0;
                DROPS.add(new Drop(x,y,z,ground,Math.max(-.12,Math.min(.12,u*drift)),
                    Math.max(-.12,Math.min(.12,v*drift)),speed,width,length));
            }
        }
    }
    private static void vertex(BufferBuilder b,Matrix4f m,double x,double y,double z,int alpha){
        b.vertex(m,(float)x,(float)y,(float)z).color(165,203,251,alpha);
    }
    public static void render(WorldRenderContext context){
        if(!rainEnabled||(DROPS.isEmpty()&&SPLASHES.isEmpty())||context.matrixStack()==null)return;
        var client=MinecraftClient.getInstance();
        if(client.world==null||client.world!=context.world())return;
        Vec3d eye=context.camera().getPos();
        var matrices=context.matrixStack();matrices.push();matrices.translate(-eye.x,-eye.y,-eye.z);
        try{
            RenderSystem.enableDepthTest();RenderSystem.disableCull();RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            Matrix4f m=matrices.peek().getPositionMatrix();
            BufferBuilder b=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            int emitted=0;
            for(Drop d:DROPS){
                double radius=Math.hypot(d.x-eye.x,d.z-eye.z);
                if(radius>76)continue;
                double w=d.width;
                double length=d.length;
                double top=d.y,bottom=Math.max(d.ground+.06,d.y-length);
                if(bottom>=top)continue;
                int a=(int)(160*Math.max(.2,1-radius/85));
                // Camera-facing streaks; two crossed strips are visible even when
                // moving along the horizontal camera axis.
                emitted+=2;
                vertex(b,m,d.x-w,top,d.z,a);vertex(b,m,d.x+w,top,d.z,a);
                vertex(b,m,d.x+w,bottom,d.z,a);vertex(b,m,d.x-w,bottom,d.z,a);
                vertex(b,m,d.x,top,d.z-w,a);vertex(b,m,d.x,top,d.z+w,a);
                vertex(b,m,d.x,bottom,d.z+w,a);vertex(b,m,d.x,bottom,d.z-w,a);
            }
            // Small fading horizontal surface splashes (world-space crosses).
            for(Splash p:SPLASHES){
                double radius=Math.hypot(p.x-eye.x,p.z-eye.z);
                if(radius>70)continue;
                double progress=p.age/11.0;
                double r=.08+.31*progress,y=p.y+.015;
                int a=(int)(115*(1-progress)*Math.max(.2,1-radius/75));
                emitted+=2;
                vertex(b,m,p.x-r,y,p.z-.023,a);vertex(b,m,p.x+r,y,p.z-.023,a);
                vertex(b,m,p.x+r,y,p.z+.023,a);vertex(b,m,p.x-r,y,p.z+.023,a);
                vertex(b,m,p.x-.023,y,p.z-r,a);vertex(b,m,p.x+.023,y,p.z-r,a);
                vertex(b,m,p.x+.023,y,p.z+r,a);vertex(b,m,p.x-.023,y,p.z+r,a);
            }
            if(emitted>0)BufferRenderer.drawWithGlobalProgram(b.end());
        }finally{RenderSystem.depthMask(true);RenderSystem.disableBlend();RenderSystem.enableCull();matrices.pop();}
    }
}
