package de.meteo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import de.meteo.CloudDiagnosticPayload;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.List;

/** Small, world-fixed translucent fog banks, no full-screen shader or fog API override.
 * Low-lying air, saturation, weak wind, nearby rain and night increase fog.
 * Perimeter vertex alpha tapers to zero; patches cannot become giant solid squares. */
public final class ValleyFogEffects {
    private ValleyFogEffects(){}
    public record Patch(float x,float y,float z,float radius,float alpha){}
    private static final List<Patch> BANKS=new ArrayList<>();
    private static World lastWorld;
    private static long lastUpdate=-1000;
    private static double recentRain;
    private static float strength;
    public static void reset(){BANKS.clear();lastWorld=null;lastUpdate=-1000;recentRain=0;strength=0;}
    public static String status(){return String.format(java.util.Locale.ROOT,"Nebel: %.0f%% | Nebelbänke: %d",strength*100,BANKS.size());}
    public static void tick(MinecraftClient client){
        if(client.world!=lastWorld){reset();lastWorld=client.world;}
        if(client.world==null||client.player==null||!AmbientSettings.fog){BANKS.clear();strength=0;return;}
        if(client.world.getRegistryKey()!=net.minecraft.world.World.OVERWORLD)return;
        if(client.world.getTime()-lastUpdate<40)return;
        lastUpdate=client.world.getTime();
        CloudDiagnosticPayload d=WeatherDiagnostics.latest();
        if(d==null){BANKS.clear();strength=0;return;}
        double wind=Math.hypot(d.windU(),d.windV());
        double humidity=d.humidity();
        double dewGap=d.temperatureC()-d.dewPointC();
        double sky=client.world.getSkyAngle(1f);
        double night=(sky>.68||sky<.19)?1:.35;
        recentRain=Math.max(CloudVolumeRenderer.rainHere(),recentRain*.92);
        double target=de.meteo.FogPhysics.target(humidity,dewGap,wind,recentRain,night>.7);
        strength=de.meteo.FogPhysics.approach(strength,target);
        if(strength<.07f){BANKS.clear();return;}
        int px=client.player.getBlockX(),pz=client.player.getBlockZ();
        int count=new int[]{8,14,22}[AmbientSettings.fogQuality];
        BANKS.clear();
        // Fixed grid offsets and hashing prevent flicker when the camera moves.
        int gx=Math.floorDiv(px,24),gz=Math.floorDiv(pz,24);
        for(int x=gx-4;x<=gx+4;x++)for(int z=gz-4;z<=gz+4;z++){
            long h=((long)x*73428767L)^((long)z*912931L);h=(h^(h>>>21))*0x45d9f3bL;
            if(Math.floorMod(h,7)>1)continue;
            double wx=x*24+12+((h>>>12&15)-7),wz=z*24+12+((h>>>20&15)-7);
            if(Math.hypot(wx-px,wz-pz)>82)continue;
            BlockPos check=new BlockPos((int)wx,0,(int)wz);
            if(!client.world.isChunkLoaded(check))continue;
            int ground=client.world.getTopY(Heightmap.Type.MOTION_BLOCKING,(int)wx,(int)wz);
            // Height-relative terrain basin preference; no heavy terrain scans.
            double valley=Math.max(.25,1-Math.max(0,ground-d.terrainY()-3)/35.0);
            double alpha=strength*valley;
            if(alpha<.055)continue;
            BANKS.add(new Patch((float)wx,ground+.75f,(float)wz,
                9+(int)((h>>>31)&7),(float)Math.min(.28,alpha*.23)));
            if(BANKS.size()>=count)return;
        }
    }
    private static void vertex(BufferBuilder b,Matrix4f mat,float x,float y,float z,int alpha){
        b.vertex(mat,x,y,z).color(210,226,235,alpha);
    }
    public static void render(WorldRenderContext ctx){
        if(BANKS.isEmpty()||ctx.matrixStack()==null||!AmbientSettings.fog)return;
        var client=MinecraftClient.getInstance();
        if(client.world==null||client.world!=ctx.world())return;
        Vec3d camera=ctx.camera().getPos();
        var stack=ctx.matrixStack();stack.push();stack.translate(-camera.x,-camera.y,-camera.z);
        try{
            RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.disableCull();
            RenderSystem.enableDepthTest();RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            Matrix4f m=stack.peek().getPositionMatrix();
            BufferBuilder b=Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES,VertexFormats.POSITION_COLOR);
            int n=0;
            for(var p:BANKS){
                if(Math.hypot(p.x()-camera.x,p.z()-camera.z)>86)continue;
                float x=p.x(),y=p.y(),z=p.z(),r=p.radius();
                int a=(int)(p.alpha()*255);if(a<4)continue;
                // Four triangles, transparent outer vertices, softly illuminated center.
                vertex(b,m,x,y,z,a);vertex(b,m,x-r,y,z-r,0);vertex(b,m,x+r,y,z-r,0);
                vertex(b,m,x,y,z,a);vertex(b,m,x+r,y,z-r,0);vertex(b,m,x+r,y,z+r,0);
                vertex(b,m,x,y,z,a);vertex(b,m,x+r,y,z+r,0);vertex(b,m,x-r,y,z+r,0);
                vertex(b,m,x,y,z,a);vertex(b,m,x-r,y,z+r,0);vertex(b,m,x-r,y,z-r,0);
                n++;
            }
            if(n>0)BufferRenderer.drawWithGlobalProgram(b.end());
        }finally{RenderSystem.depthMask(true);RenderSystem.enableCull();RenderSystem.disableBlend();stack.pop();}
    }
}
