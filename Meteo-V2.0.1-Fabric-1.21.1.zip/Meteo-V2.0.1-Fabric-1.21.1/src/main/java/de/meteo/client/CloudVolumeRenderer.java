package de.meteo.client;

import de.meteo.CloudSnapshotPayload;
import de.meteo.RainPhysics;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.util.Properties;

/** Settings and weather-data facade for the V2 cloud surface renderer. */
public final class CloudVolumeRenderer {
    private CloudVolumeRenderer() {}
    public enum Quality { SCHNELL, AUSGEWOGEN, HOCH, ULTRA }
    private static boolean enabled=true,preview;
    private static Quality quality=Quality.AUSGEWOGEN;
    private static int optimization=1,range=2;
    private static final int[] RANGES={256,512,768,1024,1408,1792};
    private static CloudSnapshotPayload latest;
    private static java.nio.file.Path settingsPath(){
        return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meteo-clouds.properties");
    }
    public static void loadSettings(){
        try{
            if(!Files.exists(settingsPath()))return;
            Properties p=new Properties();try(var input=Files.newInputStream(settingsPath())){p.load(input);}
            enabled=Boolean.parseBoolean(p.getProperty("enabled","true"));
            quality=Quality.valueOf(p.getProperty("quality","AUSGEWOGEN"));
            optimization=Math.max(0,Math.min(2,Integer.parseInt(p.getProperty("optimization","1"))));
            range=Math.max(0,Math.min(RANGES.length-1,Integer.parseInt(p.getProperty("range","2"))));
        }catch(Exception ignored){quality=Quality.AUSGEWOGEN;optimization=1;range=2;}
    }
    private static void saveSettings(){
        try{
            Properties p=new Properties();p.setProperty("enabled",Boolean.toString(enabled));
            p.setProperty("quality",quality.name());p.setProperty("optimization",Integer.toString(optimization));
            p.setProperty("range",Integer.toString(range));
            try(var output=Files.newOutputStream(settingsPath())){p.store(output,"Meteo cloud display settings");}
        }catch(Exception ignored){}
    }
    public static boolean enabled(){return enabled;}
    public static Quality quality(){return quality;}
    public static boolean preview(){return preview;}
    public static void setEnabled(boolean value){enabled=value;saveSettings();}
    public static void setQuality(Quality value){quality=value;saveSettings();}
    public static int rangeBlocks(){return RANGES[range];}
    public static void cycleRange(){range=(range+1)%RANGES.length;saveSettings();}
    public static String optimizationName(){return new String[]{"Aus","Ausgewogen","Stark"}[optimization];}
    public static void cycleOptimization(){optimization=(optimization+1)%3;saveSettings();}
    public static void togglePreview(){preview=!preview;}
    public static void clear(){latest=null;preview=false;CloudSurfaceRenderer.clear();}
    public static CloudSnapshotPayload lastSnapshot(){return latest;}
    public static void accept(CloudSnapshotPayload packet){
        if(MinecraftClient.getInstance().world==null)return;
        latest=packet;CloudSurfaceRenderer.accept(packet);
    }
    public static String info(){return "Wolken: "+CloudSurfaceRenderer.count()+" | geschlossene Oberflächen";}
    public static String debugReport(){return "Formationen: "+CloudSurfaceRenderer.count()+" | Renderer: V2";}
    public static String localReport(){
        var client=MinecraftClient.getInstance();
        if(client.player==null||latest==null)return "Wetterdaten: Noch kein Serverpaket empfangen";
        int cx=Math.floorDiv(client.player.getBlockX(),64),cz=Math.floorDiv(client.player.getBlockZ(),64);
        for(var cell:latest.cells())if(cell.cx()==cx&&cell.cz()==cz)
            return String.format(java.util.Locale.ROOT,"Wolken %.0f%% | Wasser %.3f | Hebung %+.2f m/s",
                cell.cover()*100,cell.liquid(),cell.lift());
        return "Wetterdaten: Zelle nicht empfangen";
    }
    public static String windReport(){
        var client=MinecraftClient.getInstance();
        if(client.player==null||latest==null)return "Winddaten werden geladen";
        int cx=Math.floorDiv(client.player.getBlockX(),64),cz=Math.floorDiv(client.player.getBlockZ(),64);
        for(var cell:latest.cells())if(cell.cx()==cx&&cell.cz()==cz){
            double speed=Math.hypot(cell.windU(),cell.windV());
            double from=(Math.toDegrees(Math.atan2(-cell.windU(),cell.windV()))+360)%360;
            return String.format(java.util.Locale.ROOT,"Wind aus %.0f Grad | %.1f m/s",from,speed);
        }
        return "Winddaten: Zelle nicht empfangen";
    }
    public static double rainHere(){
        var client=MinecraftClient.getInstance();
        if(client.player==null||latest==null)return 0;
        double rate=0;
        for(var cell:latest.cells())rate+=RainPhysics.localRate(cell.x(),cell.z(),
            client.player.getX(),client.player.getZ(),cell.rainMmHour(),cell.type());
        return Math.min(35,rate);
    }
    public static String rainReport(){
        return String.format(java.util.Locale.ROOT,"Niederschlag: %.1f mm/h | Radar: Schauer",rainHere());
    }
}
