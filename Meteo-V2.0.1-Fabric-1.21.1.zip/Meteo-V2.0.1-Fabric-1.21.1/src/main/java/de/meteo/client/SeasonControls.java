package de.meteo.client;
import de.meteo.SeasonSettingsPayload;
import de.meteo.SeasonSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
/** Synced server season settings; user interface stays vanilla. */
public final class SeasonControls {
    private SeasonControls(){}
    private static SeasonSystem.Settings settings=SeasonSystem.DEFAULT;
    private static long tick;
    public static SeasonSystem.Settings current(){return settings;}
    public static long clock(){return tick;}
    public static void accept(SeasonSettingsPayload payload){settings=payload.settings();tick=payload.worldTick();
        var client=net.minecraft.client.MinecraftClient.getInstance();
        if(client.currentScreen instanceof MeteoScreen screen)screen.syncRefresh();
    }
    public static void change(SeasonSystem.Settings value){
        if(ClientPlayNetworking.canSend(SeasonSettingsPayload.ID)){
            settings=value;ClientPlayNetworking.send(new SeasonSettingsPayload(value,tick));
        }
    }
    public static int season(long gameTick){
        if(!settings.enabled())return 1;
        if(settings.manualSeason()>=0)return settings.manualSeason();
        return (int)Math.floorMod(Math.floorDiv(gameTick,24000*settings.daysPerSeason()),4);
    }
    public static int day(long gameTick){return (int)Math.floorMod(Math.floorDiv(gameTick,24000),settings.daysPerSeason())+1;}
    public static String name(long gameTick){return new String[]{"Fruehling","Sommer","Herbst","Winter"}[season(gameTick)];}
    public static void clear(){settings=SeasonSystem.DEFAULT;tick=0;}
}
