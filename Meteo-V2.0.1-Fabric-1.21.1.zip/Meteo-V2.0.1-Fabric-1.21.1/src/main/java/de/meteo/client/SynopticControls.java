package de.meteo.client;
import de.meteo.SynopticWeather;
import de.meteo.SynopticControlPayload;
import de.meteo.SynopticMapPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
/** The server is authoritative; widgets send bounded settings and refresh after acknowledgement. */
public final class SynopticControls {
    private SynopticControls(){}
    private static SynopticWeather.Settings settings=SynopticWeather.DEFAULT;
    private static SynopticMapPayload map;
    private static de.meteo.RadarForecastMapPayload forecast;
    public static SynopticWeather.Settings current(){return settings;}
    public static SynopticMapPayload map(){return map;}
    public static de.meteo.RadarForecastMapPayload forecast(){return forecast;}
    public static void accept(de.meteo.RadarForecastMapPayload p){forecast=p;}
    public static void accept(SynopticControlPayload p){settings=p.settings();
        if(MinecraftClient.getInstance().currentScreen instanceof MeteoScreen s)s.syncRefresh();}
    public static void accept(SynopticMapPayload p){map=p;}
    public static void request(SynopticWeather.Settings next){
        if(ClientPlayNetworking.canSend(SynopticControlPayload.ID)){
            settings=next;ClientPlayNetworking.send(SynopticControlPayload.of(next));
        }
    }
    public static void clear(){settings=SynopticWeather.DEFAULT;map=null;forecast=null;}
}
