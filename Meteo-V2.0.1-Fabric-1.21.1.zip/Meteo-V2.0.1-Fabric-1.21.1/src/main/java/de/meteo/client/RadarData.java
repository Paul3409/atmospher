package de.meteo.client;
import de.meteo.RainRadarPayload;
/** Separate precipitation feed so visual cloud limits cannot hide radar rain. */
public final class RadarData {
    private RadarData(){}
    private static RainRadarPayload current;
    public static void accept(RainRadarPayload packet){current=packet;}
    public static RainRadarPayload latest(){return current;}
    public static void clear(){current=null;}
}
