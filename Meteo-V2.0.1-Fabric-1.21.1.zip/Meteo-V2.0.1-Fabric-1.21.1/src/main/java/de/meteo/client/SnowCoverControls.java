package de.meteo.client;

import de.meteo.SnowCoverPayload;
import de.meteo.SnowCoverSettings;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
/** Local copy of world settings; actual ground blocks are server-owned. */
public final class SnowCoverControls {
    private SnowCoverControls(){}
    private static SnowCoverSettings.Settings current=SnowCoverSettings.DEFAULT;
    public static SnowCoverSettings.Settings current(){return current;}
    public static void accept(SnowCoverPayload packet){current=packet.settings();
        var client=net.minecraft.client.MinecraftClient.getInstance();
        if(client.currentScreen instanceof MeteoScreen screen)screen.syncRefresh();
    }
    public static void change(SnowCoverSettings.Settings value){
        if(ClientPlayNetworking.canSend(SnowCoverPayload.ID)){
            current=value;ClientPlayNetworking.send(new SnowCoverPayload(value));
        }
    }
    public static void clear(){current=SnowCoverSettings.DEFAULT;}
}
