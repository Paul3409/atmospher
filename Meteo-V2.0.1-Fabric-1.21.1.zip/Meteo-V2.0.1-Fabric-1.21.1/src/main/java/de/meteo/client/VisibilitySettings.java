package de.meteo.client;
import java.nio.file.*;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
/** Client visual weather opacity; affects neither server forecast nor snow physics. */
public final class VisibilitySettings {
    private VisibilitySettings(){}
    public static boolean enabled=true;
    public static int intensity=2,minimumVisibility=1;
    private static Path path(){return FabricLoader.getInstance().getConfigDir().resolve("meteo-visibility.properties");}
    public static void load(){try{
        if(!Files.isRegularFile(path()))return;
        Properties p=new Properties();try(var in=Files.newInputStream(path())){p.load(in);}
        enabled=Boolean.parseBoolean(p.getProperty("enabled","true"));
        intensity=clamp(Integer.parseInt(p.getProperty("intensity","2")));
        minimumVisibility=clamp(Integer.parseInt(p.getProperty("visibility","1")));
    }catch(Exception e){System.err.println("Meteo visibility settings: "+e.getMessage());}}
    private static int clamp(int n){return Math.max(0,Math.min(3,n));}
    public static void save(){try{
        Files.createDirectories(path().getParent());Properties p=new Properties();
        p.setProperty("enabled",Boolean.toString(enabled));p.setProperty("intensity",Integer.toString(intensity));
        p.setProperty("visibility",Integer.toString(minimumVisibility));
        try(var out=Files.newOutputStream(path())){p.store(out,"Meteo rain and snow haze");}
    }catch(Exception e){System.err.println("Meteo visibility settings: "+e.getMessage());}}
}
