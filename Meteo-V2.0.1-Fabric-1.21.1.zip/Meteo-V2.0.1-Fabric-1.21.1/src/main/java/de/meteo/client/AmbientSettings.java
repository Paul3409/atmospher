package de.meteo.client;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Client-only fog controls. Never alters the weather simulation. */
public final class AmbientSettings {
    private AmbientSettings(){}
    public static boolean fog=true;
    public static int fogQuality=1; // 0 low, 1 normal, 2 high
    private static Path path(){return FabricLoader.getInstance().getConfigDir().resolve("meteo-atmosphere.properties");}
    public static void load(){try{
        if(!Files.isRegularFile(path()))return;
        Properties p=new Properties();try(var in=Files.newInputStream(path())){p.load(in);}
        fog=Boolean.parseBoolean(p.getProperty("fog","true"));
        fogQuality=clamp(Integer.parseInt(p.getProperty("fogQuality","1")));
    }catch(Exception e){System.err.println("Meteo atmosphere config: "+e.getMessage());}}
    private static int clamp(int v){return Math.max(0,Math.min(2,v));}
    public static void save(){try{
        Properties p=new Properties();p.setProperty("fog",Boolean.toString(fog));
        p.setProperty("fogQuality",Integer.toString(fogQuality));
        Files.createDirectories(path().getParent());try(var out=Files.newOutputStream(path())){p.store(out,"Meteo fog settings");}
    }catch(Exception e){System.err.println("Meteo atmosphere config: "+e.getMessage());}}
}
