package de.meteo;

/** Client interpolation of server-simulated cloud life, measured in real game ticks.
 * No player positions or random lifetime timers affect a formation.
 */
public final class CloudLife {
    private CloudLife() {}
    public static double clamp(double v) {return Double.isFinite(v)?Math.max(0,Math.min(1,v)):0;}
    /** Server cover and water are BOTH necessary for visible condensed cloud. */
    public static double target(double cover,double liquid) {
        double mass=clamp(Math.min(cover*1.35,liquid*1.85));
        // Keep tiny developing clouds tiny; water/cover changes remain continuous.
        return mass;
    }
    public static double approach(double current,double target,double ticks) {
        double duration=target>current?1600.0:2600.0; // about 80s growth / 130s fade at 20 TPS
        double alpha=1-Math.exp(-Math.max(0,Math.min(100,ticks))/duration);
        return clamp(current+(clamp(target)-current)*alpha);
    }
    /** Frontal decks are large air-mass structures.  They may become visible
     * somewhat sooner than fair-weather convection, but still need minutes to
     * develop and dissipate instead of switching an entire sky in seconds. */
    public static double approachFrontal(double current,double target,double ticks){
        double duration=target>current?2400.0:4200.0;
        double alpha=1-Math.exp(-Math.max(0,Math.min(100,ticks))/duration);
        return clamp(current+(clamp(target)-current)*alpha);
    }
    /** Avoid teleporting from zero size; approach() drives this monotonically. */
    public static double horizontalScale(double progress) {
        double x=clamp(progress);
        return .10+.90*x;
    }
    public static double verticalScale(double progress) {
        double x=clamp(progress);
        return .09+.91*x;
    }
}
