package de.meteo;
/** Lightweight terrain/cloud diagnostics. X is east, Z is south in Minecraft. */
public final class CloudPhysics {
    private CloudPhysics() {}
    public record Cloud(double lclMeters, double baseBlocks, double lift, double coverage, String kind,
                        double windSpeed, double windFromDegrees, double terrainLift, String terrainFlow) {}
    public static Cloud diagnose(double temperatureC,double dewPointC,double humidity,double u,double v,
                                 double slopeX,double slopeZ,double solar) {
        double lcl=Math.max(0,125.0*(temperatureC-dewPointC));
        double base=CloudBasePhysics.baseAboveGround(temperatureC,dewPointC);
        // Smooth terrain slope (Minecraft blocks per horizontal block) is converted to
        // a bounded proxy for orographic vertical motion. Not a resolved airflow model.
        double rawOrographic=u*slopeX+v*slopeZ;
        double orographic=1.6*Math.tanh(rawOrographic/1.6);
        double thermal=Math.max(0,solar)*0.10;
        double lift=orographic+thermal;
        double moisture=RegionalPhysics.clamp((humidity-0.48)/0.42,0,1);
        double ascent=RegionalPhysics.clamp((lift+0.06)/0.55,0,1);
        double coverage=RegionalPhysics.clamp(moisture*(0.18+0.82*ascent)-Math.max(0,-lift)*0.55,0,1);
        String kind=coverage<0.09?"clear":lift>0.28?"cumulus":lift>0.08?"cumulus humilis":"orographic haze";
        double windSpeed=Math.hypot(u,v);
        // Meteorological convention: direction FROM which wind blows, clockwise from north.
        double windFrom=(Math.toDegrees(Math.atan2(-u,v))+360.0)%360.0;
        String flow=windSpeed<0.5?"calm":orographic>0.08?"Luv":orographic< -0.08?"Lee":"neutral";
        return new Cloud(lcl,base,lift,coverage,kind,windSpeed,windFrom,orographic,flow);
    }
}
