package de.meteo;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
public record SeasonSettingsPayload(SeasonSystem.Settings settings,long worldTick) implements CustomPayload {
    public static final Id<SeasonSettingsPayload> ID=new Id<>(Identifier.of("meteo","season_settings"));
    public static final PacketCodec<RegistryByteBuf,SeasonSettingsPayload> CODEC=CustomPayload.codecOf(SeasonSettingsPayload::write,SeasonSettingsPayload::read);
    private void write(RegistryByteBuf b){b.writeBoolean(settings.enabled());b.writeVarInt(settings.daysPerSeason());
        b.writeInt(settings.manualSeason());b.writeDouble(settings.temperatureAdjust());b.writeLong(worldTick);}
    private static SeasonSettingsPayload read(RegistryByteBuf b){return new SeasonSettingsPayload(new SeasonSystem.Settings(
        b.readBoolean(),b.readVarInt(),b.readInt(),b.readDouble()),b.readLong());}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
