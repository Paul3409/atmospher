package de.meteo;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/** Server-owned sensor registry. Sampling continues with unloaded chunks, without force-loading them. */
public final class StationManager {
    private StationManager(){}
    private static StationArchive archive=new StationArchive();
    private static Path path;
    private static boolean dirty;
    private static String dimension(ServerWorld w){return w.getRegistryKey().getValue().toString();}
    public static void start(MinecraftServer server){
        path=server.getSavePath(WorldSavePath.ROOT).resolve("data").resolve("meteo-stations.bin");
        try{archive=StationArchive.load(path);MeteoMod.LOGGER.info("Meteo loaded {} station archives",archive.all().size());}
        catch(IOException e){
            MeteoMod.LOGGER.error("Could not load station archive; preserving existing file and disabling station writes",e);
            archive=new StationArchive();path=null;
        }
        dirty=false;
    }
    public static void stop(){save();archive=new StationArchive();path=null;dirty=false;}
    private static void save(){
        if(!dirty||path==null)return;
        try{archive.save(path);dirty=false;}
        catch(IOException e){MeteoMod.LOGGER.error("Failed to save Meteo station archive",e);}
    }
    public static void place(ServerWorld world,BlockPos pos){
        if(world.getRegistryKey()!=World.OVERWORLD)return;
        if(archive.activeAt(dimension(world),pos.asLong())==null){
            archive.place(dimension(world),pos.asLong());dirty=true;
        }
        save();
    }
    public static void remove(ServerWorld world,BlockPos pos){
        archive.remove(dimension(world),pos.asLong());dirty=true;save();
    }
    public static void open(ServerPlayerEntity player,BlockPos pos,int page){
        ServerWorld world=player.getServerWorld();
        if(world.getRegistryKey()!=World.OVERWORLD || !world.getBlockState(pos).isOf(MeteoMod.STATION_BLOCK))return;
        if(player.squaredDistanceTo(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5)>144)return;
        if(page<0)return;
        var station=archive.activeAt(dimension(world),pos.asLong());
        if(station==null){place(world,pos);station=archive.activeAt(dimension(world),pos.asLong());}
        if(station==null || page>=station.pages())return;
        if(ServerPlayNetworking.canSend(player,StationPagePayload.ID)){
            String name="Wetterstation "+pos.getX()+" / "+pos.getY()+" / "+pos.getZ();
            ServerPlayNetworking.send(player,new StationPagePayload(pos.asLong(),name,page,station.pages(),
                station.history.size(),station.page(page)));
        }
    }
    private static StationReading observe(AtmosphereEngine engine,ServerWorld world,StationArchive.Station station,long tick,
                                          WeatherDynamics.Settings settings){
        BlockPos pos=BlockPos.fromLong(station.pos);
        StationReading prev=station.latest();
        boolean loaded=world.getChunkManager().isChunkLoaded(pos.getX()>>4,pos.getZ()>>4);
        if(!loaded && prev!=null)return StationWeather.estimate(prev,tick,pos.getX(),pos.getZ(),settings);
        if(!loaded)return null;
        var layer=engine.sample(world,pos).layers().get(0);
        var clouds=CloudEffects.stationSky(engine,world,pos);
        double u=layer.windU(),v=layer.windV();
        double wind=Math.hypot(u,v),bearing=(Math.toDegrees(Math.atan2(-u,v))+360)%360;
        double precipitation=Math.max(0,clouds.rainMmHour());
        double rain=PrecipitationPhase.rainRate(precipitation,layer.temperatureC());
        double snow=PrecipitationPhase.snowRate(precipitation,layer.temperatureC());
        long dt=prev==null?0:Math.max(0,tick-prev.tick());
        // Integrate successive measured rates (trapezoidal rule), no extra rain on placement.
        double total=(prev==null?0:prev.rainTotal()+(.5*(prev.rainRate()+rain))*dt/72000.0);
        double snowTotal=(prev==null?0:prev.snowTotal()+(.5*(prev.snowRate()+snow))*dt/72000.0);
        double gust=Math.max(wind,Math.min(settings.maxGustKmh()/3.6,
            wind*(1.12+0.22*Math.abs(Math.sin(tick/1700.0+pos.getX()*.01)))));
        return new StationReading(tick,layer.temperatureC(),layer.dewPointC(),layer.pressureHpa(),rain,total,
            wind,gust,bearing,clouds.cover(),false,snow,snowTotal);
    }
    public static void tick(AtmosphereEngine engine,ServerWorld world,WeatherDynamics.Settings settings){
        if(world.getRegistryKey()!=World.OVERWORLD || world.getTime()%20!=0)return;
        long tick=world.getTime();boolean changed=false;
        for(var station:archive.all()){
            if(!station.active || !station.dimension.equals(dimension(world)))continue;
            if(station.lastTick!=Long.MIN_VALUE && tick>=station.lastTick && tick-station.lastTick<1200)continue;
            // A command or restored save can move time backwards; reset the cadence, never replay old intervals.
            StationReading next=observe(engine,world,station,tick,settings);
            if(next!=null){station.history.add(next);station.lastTick=tick;changed=true;}
        }
        if(changed){dirty=true;save();}
    }
}
