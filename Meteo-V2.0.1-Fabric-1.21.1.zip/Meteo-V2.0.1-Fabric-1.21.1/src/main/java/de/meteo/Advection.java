package de.meteo;
/** First-order donor-cell gradient for a signed wind component. */
public final class Advection {
    private Advection() {}
    public static double fluxGradient(double here, double upstream, double velocity) {
        // For u<0: d(phi)/dx = (phi_right - phi_here)/dx.
        return Math.abs(velocity) * (here - upstream);
    }
    public static double donorStep(double here, double upstream, double velocity, double dt, double dx) {
        return here - dt / dx * fluxGradient(here, upstream, velocity);
    }
}
