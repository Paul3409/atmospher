package de.meteo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Precipitation-only sources; independent of the truncated cloud-render list. */
public record RainRadarPayload(long tick, List<RainCell> cells) implements CustomPayload {
    public static final Id<RainRadarPayload> ID = new Id<>(Identifier.of("meteo","rain_radar"));
    public static final PacketCodec<RegistryByteBuf,RainRadarPayload> CODEC =
        CustomPayload.codecOf(RainRadarPayload::write,RainRadarPayload::read);
    public static final int MAX_CELLS=512;
    public RainRadarPayload {
        if(cells==null||cells.size()>MAX_CELLS)
            throw new IllegalArgumentException("Invalid radar count " +(cells==null?-1:cells.size()));
        cells=List.copyOf(cells);
    }
    /** Kind: 0 rain, 1 snow (diagnosed from the source-air temperature). */
    public record RainCell(float x,float z,float mmHour,byte type,byte precipitationKind) {
        public RainCell(float x,float z,float mmHour,byte type){this(x,z,mmHour,type,(byte)0);}
    }
    private void write(RegistryByteBuf b){
        if(cells.size()>MAX_CELLS)throw new IllegalArgumentException("Invalid radar count "+cells.size());
        b.writeLong(tick); b.writeVarInt(cells.size());
        for(var c:cells){b.writeFloat(c.x());b.writeFloat(c.z());b.writeFloat(c.mmHour());b.writeByte(c.type());b.writeByte(c.precipitationKind());}
    }
    private static RainRadarPayload read(RegistryByteBuf b){
        long time=b.readLong();int n=b.readVarInt();
        if(n<0||n>MAX_CELLS)throw new IllegalArgumentException("Invalid radar count "+n);
        List<RainCell> list=new ArrayList<>(n);
        for(int i=0;i<n;i++)list.add(new RainCell(b.readFloat(),b.readFloat(),b.readFloat(),b.readByte(),b.readByte()));
        return new RainRadarPayload(time,List.copyOf(list));
    }
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
