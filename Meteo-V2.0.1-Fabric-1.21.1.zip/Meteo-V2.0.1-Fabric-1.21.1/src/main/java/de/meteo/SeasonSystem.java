package de.meteo;

import java.io.*;
import java.nio.file.*;
import java.util.Properties;

/** Server-authoritative, data-only seasons. The Minecraft landscape is never recolored. */
public final class SeasonSystem {
    private SeasonSystem() {}
    public record Settings(boolean enabled,int daysPerSeason,int manualSeason,double temperatureAdjust) {
        public Settings {
            daysPerSeason=Math.max(2,Math.min(120,daysPerSeason));
            manualSeason=Math.max(-1,Math.min(3,manualSeason));
            temperatureAdjust=Double.isFinite(temperatureAdjust)?Math.max(-15,Math.min(15,temperatureAdjust)):0;
        }
    }
    public static final Settings DEFAULT=new Settings(true,14,-1,0);
    private static Settings settings=DEFAULT;
    private static Path file;
    public static Settings settings(){return settings;}
    public static void set(Settings next){settings=next;save();}
    public static void start(Path worldRoot){file=worldRoot.resolve("data/meteo-seasons.properties");settings=DEFAULT;
        if(!Files.isRegularFile(file))return;
        try(var in=Files.newInputStream(file)){
            Properties p=new Properties();p.load(in);
            settings=new Settings(Boolean.parseBoolean(p.getProperty("enabled","true")),
                Integer.parseInt(p.getProperty("days","14")),
                Integer.parseInt(p.getProperty("manual","-1")),
                Double.parseDouble(p.getProperty("adjust","0")));
        }catch(Exception e){MeteoMod.LOGGER.warn("Season settings could not be read",e);}
    }
    public static void stop(){file=null;settings=DEFAULT;}
    public static void save(){if(file==null)return;try{
        Files.createDirectories(file.getParent());Properties p=new Properties();
        p.setProperty("enabled",Boolean.toString(settings.enabled()));p.setProperty("days",Integer.toString(settings.daysPerSeason()));
        p.setProperty("manual",Integer.toString(settings.manualSeason()));p.setProperty("adjust",Double.toString(settings.temperatureAdjust()));
        try(var out=Files.newOutputStream(file)){p.store(out,"Meteo seasons: 0 spring,1 summer,2 autumn,3 winter; -1 automatic");}
    }catch(IOException e){MeteoMod.LOGGER.warn("Season settings could not be saved",e);}}
    public static int season(long worldTick){
        if(!settings.enabled())return 1;
        if(settings.manualSeason()>=0)return settings.manualSeason();
        return (int)Math.floorMod(Math.floorDiv(worldTick,24000*settings.daysPerSeason()),4);
    }
    public static int dayInSeason(long worldTick){return (int)Math.floorMod(Math.floorDiv(worldTick,24000),settings.daysPerSeason())+1;}
    public static String name(long worldTick){return new String[]{"Fruehling","Sommer","Herbst","Winter"}[season(worldTick)];}
    /** Celsius perturbation with a continuous annual cycle, plus a smaller diurnal cycle.
     * Existing biome and lapse-rate physics are preserved in AtmosphereEngine. */
    public static double offsetC(long worldTick){
        double day=Math.floorMod(worldTick,24000)/24000.0;
        double diurnal=2.5*Math.cos(2*Math.PI*(day-.60));
        if(!settings.enabled())return settings.temperatureAdjust()+diurnal;
        double phase=settings.manualSeason()>=0?settings.manualSeason()+.5:
            (double)Math.floorMod(worldTick,24000L*settings.daysPerSeason()*4)/(24000.0*settings.daysPerSeason());
        double annual=9.0*Math.sin(2*Math.PI*phase/4.0);
        return settings.temperatureAdjust()+annual+diurnal;
    }
}
