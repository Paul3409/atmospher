package de.meteo;
/** Stable cloud field membership based on world distance, humidity and lift.
 * Nearby, actively growing condensate joins into one contiguous rendered field.
 * Cloud identities remain distinct on the server and rain/radar are unaffected. */
public final class CloudFieldGrouping {
    private CloudFieldGrouping() {}
    public static boolean connected(double ax,double az,double bx,double bz,
            double aWater,double bWater,double aCover,double bCover){
        if(!Double.isFinite(ax)||!Double.isFinite(az)||!Double.isFinite(bx)||!Double.isFinite(bz))return false;
        if(aWater<.15||bWater<.15||aCover<.25||bCover<.25)return false;
        return Math.hypot(ax-bx,az-bz)<100;
    }
    public static double expansion(int size){return Math.min(1.9,1.0+Math.max(0,size-1)*.21);}
}
