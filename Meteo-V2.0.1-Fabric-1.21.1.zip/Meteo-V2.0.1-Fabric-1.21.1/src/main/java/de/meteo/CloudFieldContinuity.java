package de.meteo;
/** Spatial hysteresis and view-edge alpha: NEVER changes the simulation. */
public final class CloudFieldContinuity {
    private CloudFieldContinuity() {}
    /** Existing neighbours have looser merge thresholds to avoid oscillation. */
    public static boolean connected(double ax,double az,double bx,double bz,
            double aw,double bw,double ac,double bc,boolean alreadyConnected) {
        if(!Double.isFinite(ax)||!Double.isFinite(az)||!Double.isFinite(bx)||!Double.isFinite(bz))return false;
        double distance=Math.hypot(ax-bx,az-bz);
        double minWater=alreadyConnected?.09:.15;
        double minCover=alreadyConnected?.17:.25;
        return distance<(alreadyConnected?125:100)
            && aw>=minWater && bw>=minWater && ac>=minCover && bc>=minCover;
    }
    /** 1 inside view distance, easing to zero over a finite edge region. */
    public static double rangeFade(double distance,double range,double edge) {
        if(!Double.isFinite(distance)||!Double.isFinite(range)||range<=0)return 0;
        double start=Math.max(0,range-Math.max(1,edge));
        double t=Math.max(0,Math.min(1,(range-distance)/Math.max(1,range-start)));
        return t*t*(3-2*t);
    }
}
