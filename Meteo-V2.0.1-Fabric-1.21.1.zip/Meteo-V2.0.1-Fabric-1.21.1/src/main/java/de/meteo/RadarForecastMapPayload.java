package de.meteo;
import java.util.*;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
/** Separate forecast channel: live observation packets cannot overwrite selected forecast. */
public record RadarForecastMapPayload(int hours,SynopticMapPayload map) implements CustomPayload {
    public static final Id<RadarForecastMapPayload> ID=new Id<>(Identifier.of("meteo","forecast_map"));
    public static final PacketCodec<RegistryByteBuf,RadarForecastMapPayload> CODEC=CustomPayload.codecOf(RadarForecastMapPayload::write,RadarForecastMapPayload::read);
    private void write(RegistryByteBuf b){
        b.writeVarInt(hours);b.writeLong(map.tick());b.writeInt(map.originX());b.writeInt(map.originZ());
        for(var pt:map.grid()){b.writeFloat(pt.pressure());b.writeFloat(pt.front());b.writeByte(pt.type());b.writeFloat(pt.rainPotential());}
        b.writeVarInt(map.frontLines().size());
        for(var line:map.frontLines()){
            b.writeByte(line.type());b.writeVarInt(line.points().size());
            for(var pt:line.points()){b.writeFloat(pt.x());b.writeFloat(pt.z());}
        }
    }
    private static RadarForecastMapPayload read(RegistryByteBuf b){
        int h=b.readVarInt();long tick=b.readLong();int x=b.readInt(),z=b.readInt();
        var grid=new ArrayList<SynopticMapPayload.MapPoint>(SynopticMapPayload.MAX);
        for(int i=0;i<SynopticMapPayload.MAX;i++)grid.add(new SynopticMapPayload.MapPoint(b.readFloat(),b.readFloat(),b.readByte(),b.readFloat()));
        if(h<0||h>12)throw new IllegalArgumentException("Invalid forecast window");
        int count=b.readVarInt();if(count<0||count>90)throw new IllegalArgumentException("Invalid front line count");
        var lines=new ArrayList<SynopticMapPayload.FrontLine>();
        for(int j=0;j<count;j++){
            byte type=b.readByte();int length=b.readVarInt();if(length<2||length>90)throw new IllegalArgumentException("Invalid front path");
            var points=new ArrayList<SynopticWeather.FrontPoint>();
            for(int k=0;k<length;k++)points.add(new SynopticWeather.FrontPoint(b.readFloat(),b.readFloat(),type));
            lines.add(new SynopticMapPayload.FrontLine(type,List.copyOf(points)));
        }
        return new RadarForecastMapPayload(h,new SynopticMapPayload(tick,x,z,grid,lines));
    }
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
