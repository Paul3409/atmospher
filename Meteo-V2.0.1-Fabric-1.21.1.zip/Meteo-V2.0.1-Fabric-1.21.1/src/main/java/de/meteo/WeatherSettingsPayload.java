package de.meteo;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server-authoritative controls, also used as a server-to-client acknowledgement. */
public record WeatherSettingsPayload(int pace,int windMode,int variability,int fixedFrom,int meanWindKmh,int maxGustKmh) implements CustomPayload {
    public WeatherSettingsPayload(int pace,int windMode,int variability,int fixedFrom){
        this(pace,windMode,variability,fixedFrom,15,50);
    }
    public static final Id<WeatherSettingsPayload> ID=new Id<>(Identifier.of("meteo","weather_settings"));
    public static final PacketCodec<RegistryByteBuf,WeatherSettingsPayload> CODEC=CustomPayload.codecOf(WeatherSettingsPayload::write,WeatherSettingsPayload::read);
    private void write(RegistryByteBuf b){b.writeVarInt(pace);b.writeVarInt(windMode);b.writeVarInt(variability);
        b.writeVarInt(fixedFrom);b.writeVarInt(meanWindKmh);b.writeVarInt(maxGustKmh);}
    private static WeatherSettingsPayload read(RegistryByteBuf b){return new WeatherSettingsPayload(b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarInt());}
    public WeatherDynamics.Settings validated(){return new WeatherDynamics.Settings(pace,windMode,variability,fixedFrom,meanWindKmh,maxGustKmh);}
    public static WeatherSettingsPayload of(WeatherDynamics.Settings s){return new WeatherSettingsPayload(s.pace(),s.windMode(),s.variability(),s.fixedFrom(),s.meanWindKmh(),s.maxGustKmh());}
    @Override public Id<? extends CustomPayload> getId(){return ID;}
}
