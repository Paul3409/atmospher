package de.meteo;
import java.util.List;
/** Run with javac/java without a Minecraft runtime. */
public final class StationChartTest {
    private static StationReading r(long tick,double temp){return new StationReading(tick,temp,temp-3,1000+tick/1200.,2,1,3,4,270,.7,false);}
    private static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args){
        var readings=List.of(r(0,10),r(1200,12),r(2400,9),r(3600,13));
        for(int kind=0;kind<6;kind++){
            var s=StationChart.layout(readings,kind,200,100);
            check(s.points().size()==4,"missing points for chart "+kind);
            for(var p:s.points())check(p.x()>=0&&p.x()<200&&p.y()>=0&&p.y()<100,"point outside chart");
            check(s.maximum()>s.minimum(),"degenerate axis");
            check(s.points().get(0).x()==0&&s.points().get(3).x()==199,"time axis");
        }
        var flat=StationChart.layout(List.of(r(0,10),r(1200,10)),0,200,100);
        check(flat.points().size()==2&&flat.maximum()>flat.minimum(),"flat series");
        check(StationChart.layout(List.of(r(0,10)),0,200,100).points().size()==1,"single reading");
        check(StationChart.layout(List.of(),0,200,100).points().isEmpty(),"empty history");
        System.out.println("StationChartTest OK: all 6 charts, empty, single, flat and bounds");
    }
}
