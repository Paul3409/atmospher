package de.meteo;

public final class CloudSurfaceMeshTest {
    public static void main(String[] args){
        for(int type=0;type<=9;type++){
            var mesh=CloudSurfaceMesh.build(13,-8,type,1);
            if(mesh.faces().isEmpty()||mesh.faces().size()>650)
                throw new AssertionError("missing or too expensive cloud surface "+type);
            if(!mesh.equals(CloudSurfaceMesh.build(13,-8,type,1)))
                throw new AssertionError("cloud geometry changes between frames "+type);
            for(var face:mesh.faces())if(!Float.isFinite(face.y0())||!Float.isFinite(face.y1())||
                face.y1()<face.y0())throw new AssertionError("invalid face "+type);
        }
        if(CloudSurfaceMesh.build(13,-8,7,1).height()<=CloudSurfaceMesh.build(13,-8,3,1).height())
            throw new AssertionError("storm cloud must tower above stratus");
        System.out.println("V2 cloud shells: deterministic, bounded and finite");
    }
}
