package de.meteo;
public class CloudPhysicsTest {
 public static void main(String[] args) {
  var luv=CloudPhysics.diagnose(14,12,.87,8,0,.10,0,.6);
  var lee=CloudPhysics.diagnose(14,12,.87,8,0,-.10,0,.6);
  if(!luv.terrainFlow().equals("Luv")||!lee.terrainFlow().equals("Lee"))throw new AssertionError("Luv/Lee classification");
  if(luv.coverage()<=lee.coverage())throw new AssertionError("Windward cloud coverage should exceed lee");
  if(luv.lclMeters()!=250)throw new AssertionError("LCL estimate");
  if(Math.abs(luv.windFromDegrees()-270)>0.001)throw new AssertionError("Eastward wind comes from west");
  var north=CloudPhysics.diagnose(14,12,.87,0,8,0,.1,0);
  if(Math.abs(north.windFromDegrees()-0)>0.001)throw new AssertionError("Southward wind should come from north (0 degrees)");
  if(luv.coverage()<0||luv.coverage()>1)throw new AssertionError("coverage bounds");
  var extreme=CloudPhysics.diagnose(14,12,.87,30,0,1,0,1);
  if(extreme.terrainLift()>1.61)throw new AssertionError("orographic limit");
  System.out.println("Cloud physics: PASS (Luv/Lee, wind direction, LCL, bounded lift)");
 }
}
