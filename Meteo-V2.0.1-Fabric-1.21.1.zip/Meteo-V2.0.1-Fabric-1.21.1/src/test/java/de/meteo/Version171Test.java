package de.meteo;
public final class Version171Test {
    private static void yes(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    public static void main(String[] args){
        yes(SnowCoverPhysics.depositChance(8,-3,2)>SnowCoverPhysics.depositChance(2,-3,2),"heavy snow collects faster");
        yes(SnowCoverPhysics.depositChance(8,-3,3)>SnowCoverPhysics.depositChance(8,-3,1),"adjustable accumulation");
        yes(SnowCoverPhysics.depositChance(8,1.5,2)<SnowCoverPhysics.depositChance(8,-2,2),"sleet accumulates little");
        yes(SnowCoverPhysics.depositChance(10,4,3)==0,"warm rain cannot place snow");
        yes(SnowCoverPhysics.meltChance(-1,2)==0,"frozen snow remains");
        yes(SnowCoverPhysics.meltChance(0,2)<SnowCoverPhysics.meltChance(3,2),"thaw accelerates above 1 C");
        yes(SnowCoverPhysics.meltChance(3,3)>SnowCoverPhysics.meltChance(3,1),"melt adjustable");
        yes(SnowCoverPhysics.nextLayers(0,true,0,1,20,-3,3,2)==1,"new snow layer");
        yes(SnowCoverPhysics.nextLayers(7,true,0,1,20,-3,3,2)==8,"snow reaches 8 layers");
        yes(SnowCoverPhysics.nextLayers(8,true,0,1,20,-3,3,2)==8,"snow max 8");
        yes(SnowCoverPhysics.nextLayers(6,false,1,0,0,4,2,3)==5,"warm snow melts");
        yes(SnowCoverPhysics.nextLayers(6,false,1,0,0,-3,2,3)==6,"cold snow survives");
        yes(CloudOptimization.groupingInterval(0)==1&&CloudOptimization.groupingInterval(1)==6&&CloudOptimization.groupingInterval(2)==12,"cloud budget cadence");
        yes(!CloudOptimization.hiddenBehind(80,-80,2),"never cull near clouds");
        yes(CloudOptimization.hiddenBehind(500,-400,1),"cull clouds far behind view");
        yes(!CloudOptimization.hiddenBehind(500,100,2),"do not cull forward clouds");
        yes(CloudOptimization.detail(3,100,2)==3,"full detail nearby");
        yes(CloudOptimization.detail(3,900,2)==0,"far cloud LOD");
        yes(CloudOptimization.bucket(159,159)!=CloudOptimization.bucket(160,160),"spatial bin boundary");
        System.out.println("V1.7.1 OK: snow phases, accumulation/thaw, layer limits, cloud grouping and LOD");
    }
}
