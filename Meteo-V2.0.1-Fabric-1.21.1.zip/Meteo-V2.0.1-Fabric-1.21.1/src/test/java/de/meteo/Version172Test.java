package de.meteo;

/** Independent, deterministic tests for V1.7.2's physical coupling and
 * terrain constraints. Run with the normal JDK; Fabric is not required. */
public final class Version172Test {
    private static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    private static void near(double a,double b,double eps,String why){check(Math.abs(a-b)<eps,why+": "+a+" vs "+b);}
    public static void main(String[] args){
        SynopticRuntime.clear();SynopticRuntime.set(SynopticWeather.DEFAULT);
        var cfg=SynopticWeather.DEFAULT;
        boolean foundAhead=false,foundActive=false;
        for(int x=-1600;x<=3200;x+=160)for(int z=-1600;z<=3200;z+=160){
            var now=SynopticWeather.at(7500,x,z,cfg);
            var ahead=SynopticWeather.at(14700,x,z,cfg);
            var stage=FrontalCloudPhysics.at(now,ahead,.92);
            check(stage.core()>=0&&stage.core()<=1,"bounded front cloud core");
            check(stage.advance()>=0&&stage.advance()<=1,"bounded front high veil");
            if(stage.approaching()){
                foundAhead=true;
                check(FrontalCloudPhysics.saturationReduction(stage)>0,"prefront condensation");
                check(FrontalCloudPhysics.highVeil(stage,.75)>0,"separate high cloud before frontal core");
            }
            if(stage.core()>.40){
                foundActive=true;
                check(FrontalCloudPhysics.visualType(stage,(byte)1,.35,.60)==6 ||
                      FrontalCloudPhysics.visualType(stage,(byte)1,.35,.60)==7,"visible active frontal deck");
            }
        }
        // Atmosphere/HUD/Clouds share a bounded server-side synoptic sample cache.
        var beforeManual=SynopticRuntime.fieldAt(7500,0,0);
        near(beforeManual.pressureOffset(),SynopticRuntime.fieldAt(7510,4,4).pressureOffset(),1e-9,
            "nearby read shares deterministic synoptic field");
        SynopticRuntime.create(0,0,7500,true);
        var afterManual=SynopticRuntime.fieldAt(7500,0,0);
        check(afterManual.pressureHpa()<beforeManual.pressureHpa()-8,
            "manual pressure creation invalidates weather field cache");
        SynopticRuntime.clear();
        near(beforeManual.pressureHpa(),SynopticRuntime.fieldAt(7500,0,0).pressureHpa(),1e-6,
            "clearing pressure centres invalidates cached field");
        check(foundAhead,"front has an approaching-high-cloud zone");
        check(foundActive,"same synoptic map contains active front clouds");
        var dry=FrontalCloudPhysics.at(new SynopticWeather.State(997,-16,1,(byte)2,1,0,0,0),
             new SynopticWeather.State(997,-16,1,(byte)2,1,0,0,0),.10);
        check(dry.core()>0,"synoptic signal exists even in dry air");
        check(FrontalCloudPhysics.visualType(dry,(byte)1,0,0)==1,"dry frontal map does not fake condensate");
        var free=TerrainCloudFlow.steer(0,0,2,0,110,65,64,64,0);
        check(!free.obstructed()&&free.x()==2,"clear air advects normally");
        var rise=TerrainCloudFlow.steer(0,0,2,0,110,111,112,111,.3);
        check(rise.obstructed()&&!rise.stalled()&&rise.minimumBase()>=125,"lift climbs over gentle ridge");
        var turn=TerrainCloudFlow.steer(0,0,2,0,110,150,73,153,-.15);
        check(turn.obstructed()&&!turn.stalled()&&turn.z()>0,"lower flank diverts visible cloud");
        var block=TerrainCloudFlow.steer(0,0,2,0,110,150,155,154,-.4);
        check(block.stalled()&&block.x()==0&&block.z()==0,"high impassable ridge stalls cloud");
        near(TerrainCloudFlow.clearBase(90,100),114,1e-6,"mountain face never intersects low cloud base");
        check(TerrainCloudFlow.clearBase(180,100)==180,"already high clouds unaffected");
        System.out.println("V1.7.2 PASS: matching front signals, cloud stages, moisture gate, orography, no terrain penetration");
    }
}
