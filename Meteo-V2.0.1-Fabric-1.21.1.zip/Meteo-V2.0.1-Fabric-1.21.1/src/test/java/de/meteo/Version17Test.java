package de.meteo;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public class Version17Test {
 static void ck(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  Path root=Files.createTempDirectory("meteo-v17-test");SeasonSystem.start(root);
  ck(SeasonSystem.season(0)==0,"spring");
  ck(SeasonSystem.season(14L*24000)==1,"summer");
  ck(SeasonSystem.season(28L*24000)==2,"autumn");
  ck(SeasonSystem.season(42L*24000)==3,"winter");
  double summer=SeasonSystem.offsetC(20L*24000), winter=SeasonSystem.offsetC(48L*24000);
  ck(summer>winter+12,"yearly cycle must cool winter");
  SeasonSystem.set(new SeasonSystem.Settings(true,7,3,-3));
  ck(SeasonSystem.season(0)==3,"manual winter");SeasonSystem.start(root);
  ck(SeasonSystem.settings().manualSeason()==3,"save/reload seasons");
  ck(PrecipitationPhase.snowFraction(-4)==1&&PrecipitationPhase.snowFraction(6)==0,"snow boundaries");
  ck(Math.abs(PrecipitationPhase.rainRate(10,1)+PrecipitationPhase.snowRate(10,1)-10)<1e-8,"rain-snow conservation");
  var archive=new StationArchive();long pos=12345678L;archive.place("minecraft:overworld",pos);
  var a=archive.activeAt("minecraft:overworld",pos);
  a.history.add(new StationReading(100,0,-3,1013,0,1,2,3,180,.5,false,8.5,12.3));
  Path file=root.resolve("stations.bin");archive.save(file);
  var loaded=StationArchive.load(file).activeAt("minecraft:overworld",pos);
  ck(loaded!=null&&loaded.latest().snowTotal()==12.3&&loaded.latest().snowRate()==8.5,"station V2 persistence");
  // A real V1.6-compatible archive is accepted without losing historical data.
  Path old=root.resolve("old.bin");try(var out=new DataOutputStream(Files.newOutputStream(old))){
   out.writeInt(0x4d535431);out.writeInt(1);out.writeInt(1);out.writeLong(1);out.writeLong(2);
   out.writeUTF("minecraft:overworld");out.writeLong(pos);out.writeBoolean(true);out.writeLong(0);out.writeInt(1);
   out.writeLong(12);for(double v:new double[]{11,7,1002,5,6,4,6,270,.6})out.writeDouble(v);out.writeBoolean(false);
  }
  var legacy=StationArchive.load(old).activeAt("minecraft:overworld",pos).latest();
  ck(legacy.snowRate()==0&&legacy.rainRate()==5,"legacy archive migration");
  for(int type:new int[]{4,5,6,7,8,9}){
    var mesh=CloudVoxelMesh.buildHybrid(12,23,0,0,125,type,.95f,.99f,1.2f,0);
    ck(!mesh.outer().isEmpty(),"cloud type "+type+" has no mesh");
    ck(mesh.outer().size()<15000,"cloud type "+type+" too complex");
  }
  var readings=List.of(a.latest(),new StationReading(130,1,0,1012,3,2,3,4,270,.2,false,2,14));
  for(int chart=0;chart<8;chart++)ck(StationChart.layout(readings,chart,240,70).points().size()==2,"chart "+chart);
  System.out.println("Version17Test OK: seasons, persistent settings, old+new station archives, snow phases, cloud meshes, 8 charts");
 }
}
