package de.meteo;
import java.util.*;
/** No Minecraft engine required: front geometry, map packets, moisture forecast. */
public final class V174SynopticContractTest {
    private static void check(boolean value,String msg){if(!value)throw new AssertionError(msg);}
    public static void main(String[] args) throws Exception {
        SynopticRuntime.clear();
        var settings=SynopticWeather.DEFAULT;
        var paths=SynopticWeather.paths(2400,-2200,-2200,2200,2200,settings);
        check(!paths.isEmpty(),"front geometry must exist in central region");
        int seen=0,positive=0;
        for(var path:paths){
            check(path.size()>=2,"paths must contain line segments");
            byte type=path.get(0).type();
            for(int i=0;i<path.size();i++){
                var pt=path.get(i);
                check(pt.type()==type,"one front line has one type");
                if(i>0){var prev=path.get(i-1);check(Math.hypot(pt.x()-prev.x(),pt.z()-prev.z())<80,"front path must be continuous");}
                var state=SynopticWeather.at(2400,pt.x(),pt.z(),settings);
                if(state.frontIntensity()>.32 && state.frontType()==pt.type())positive++;
                seen++;
            }
        }
        check(positive>seen*.56,"rendered paths must coincide with actual synoptic front field");
        var map=SynopticMapPayload.around(1000,0,0,2400,settings);
        check(map.grid().size()==SynopticMapPayload.MAX,"map has expected dimensions");
        check(!map.frontLines().isEmpty(),"radar contains actual front geometry");
        double peak=map.grid().stream().mapToDouble(SynopticMapPayload.MapPoint::rainPotential).max().orElse(0);
        check(peak>0,"fronts have an explicitly labelled forecast rain potential");
        for(var pt:map.grid()){
            check(pt.rainPotential()>=0&&pt.rainPotential()<=20,"potential remains bounded");
        }
        var dry=FrontalCloudPhysics.precipitationPotential(new SynopticWeather.State(1005,0,0,(byte)0,1,0,0,0));
        check(dry==0,"clear weather cannot invent forecast rain");
        var cold=FrontalCloudPhysics.at(new SynopticWeather.State(985,-28,.9,(byte)2,1.3,-2,3,0),
                new SynopticWeather.State(985,-28,.7,(byte)2,1.3,-2,3,0),1);
        check(cold.core()>.75&&cold.ascent()>.30,"front supplies its own cloud ascent");
        System.out.println("V174 PASS: paths="+paths.size()+", aligned="+positive+"/"+seen+", rainPotential="+peak);
    }
}
