package de.meteo;
public class CloudFieldPhysicsTest {
 public static void main(String[] args){
  var zero=new CloudFieldPhysics.State(0,0);
  var growing=zero;
  for(int i=0;i<20;i++)growing=CloudFieldPhysics.advance(growing,.85,1,.9,0,0,36);
  if(growing.cover()<.5)throw new AssertionError("Clouds should grow gradually");
  var evaporating=CloudFieldPhysics.advance(growing,0,-1,.3,0,0,36);
  if(evaporating.cover()<=0||evaporating.cover()>=growing.cover())throw new AssertionError("Clouds must decay gradually");
  var advected=CloudFieldPhysics.advance(zero,0,0,.8,1,.5,36);
  if(advected.water()<=0)throw new AssertionError("Upstream cloud water should be transported");
  if(!CloudFieldPhysics.classify(.8,1,.9,.8,.8).equals("cumulus congestus"))throw new AssertionError("Tall cumulus");
  System.out.println("Cloud field physics PASS");
 }
}
