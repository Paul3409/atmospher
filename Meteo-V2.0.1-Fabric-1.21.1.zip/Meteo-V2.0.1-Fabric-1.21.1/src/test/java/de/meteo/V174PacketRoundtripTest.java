package de.meteo;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.registry.DynamicRegistryManager;
import io.netty.buffer.Unpooled;
import java.lang.reflect.Method;
import java.util.*;
public final class V174PacketRoundtripTest {
    private static void check(boolean x,String m){if(!x)throw new AssertionError(m);}
    @SuppressWarnings("unchecked")
    private static <T> T roundtrip(T value,Class<T> cl) throws Exception {
        Method write=cl.getDeclaredMethod("write",RegistryByteBuf.class);write.setAccessible(true);
        Method read=cl.getDeclaredMethod("read",RegistryByteBuf.class);read.setAccessible(true);
        // Minecraft 1.21.1: RegistryByteBuf requires a Netty ByteBuf and registry manager.
        // A fresh readerIndex(0) makes the same buffer available to the decoder.
        var buf=new RegistryByteBuf(Unpooled.buffer(),DynamicRegistryManager.EMPTY);
        try {
            write.invoke(value,buf);
            buf.readerIndex(0);
            return (T)read.invoke(null,buf);
        } finally {
            buf.release();
        }
    }
    public static void main(String[] args) throws Exception {
        var map=SynopticMapPayload.around(100,0,0,2400,SynopticWeather.DEFAULT);
        var unpacked=roundtrip(map,SynopticMapPayload.class);
        check(unpacked.grid().equals(map.grid()),"current radar grids roundtrip");
        check(unpacked.frontLines().equals(map.frontLines()),"continuous radar front paths roundtrip");
        var forecast=new RadarForecastMapPayload(9,map);
        var forecastParsed=roundtrip(forecast,RadarForecastMapPayload.class);
        check(forecastParsed.map().equals(map)&&forecastParsed.hours()==9,"9h forecast roundtrip");
        var clouds=new ArrayList<CloudSnapshotPayload.CloudCell>();
        for(int i=0;i<416;i++)clouds.add(new CloudSnapshotPayload.CloudCell(i,i,123,234,300,.5f,.3f,.2f,1,1,(byte)5,0,1,.8f,0));
        var snap=roundtrip(new CloudSnapshotPayload(42,clouds),CloudSnapshotPayload.class);
        check(snap.cells().size()==416,"416 cloud packet entries allowed");
        System.out.println("V174 PASS: live radar, forecast, front paths, 416-cloud packet serialized");
    }
}
