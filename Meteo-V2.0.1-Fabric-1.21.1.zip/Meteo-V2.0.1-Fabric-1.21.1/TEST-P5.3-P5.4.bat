@echo off
setlocal
cd /d "%~dp0"
if not exist "build\p53-test" mkdir "build\p53-test"
javac -encoding UTF-8 -d "build\p53-test" "src\main\java\de\meteo\RegionalPhysics.java" "src\main\java\de\meteo\CloudBasePhysics.java" "src\main\java\de\meteo\CloudPhysics.java" "tests\de\meteo\P53PhysicsTest.java"
if errorlevel 1 (echo FEHLER bei der Kompilierung & pause & exit /b 1)
java -cp "build\p53-test" de.meteo.P53PhysicsTest
if errorlevel 1 (echo FEHLER im Physiktest & pause & exit /b 1)
echo Tests erfolgreich.
pause
