from pathlib import Path
root=Path(__file__).resolve().parent.parent
src=root/'src/main/java/de/meteo'
resources=root/'src/main/resources/assets/meteo'
assert not (src/'client/WeatherSounds.java').exists()
assert not (resources/'sounds.json').exists()
assert not (resources/'sounds').exists()
for p in src.rglob('*.java'):
    assert 'WeatherSounds' not in p.read_text(),p
    assert 'WIND_SOUND' not in p.read_text(),p
    assert 'RAIN_SOUND' not in p.read_text(),p
    assert 'THUNDER_SOUND' not in p.read_text(),p
menu=(src/'client/MeteoScreen.java').read_text()
assert '"Sound"' not in menu
assert 'METEO V1.5.1' in menu
server=(src/'MeteoMod.java').read_text()
for name in ['CloudSnapshotPayload','CloudDiagnosticPayload','RainRadarPayload']:
    assert f'ServerPlayNetworking.canSend(player,{name}.ID)' in server
assert 'ServerLifecycleEvents.SERVER_STOPPED' in server
assert 'ServerLifecycleEvents.SERVER_STARTED' in server
engine=(src/'AtmosphereEngine.java').read_text()
assert 'regions.clear();' in engine and 'MAX_REGIONS=24' in engine
assert 'if(regions.size()>=24)regions.clear()' not in engine
assert 'long wd=worldTime-c.world;' in engine
radar=(src/'RainRadarPayload.java').read_text()
assert 'MAX_CELLS=512' in radar
assert 'if(cells.size()>MAX_CELLS)' in radar
assert 'mod_version=1.5.1' in (root/'gradle.properties').read_text()
print('V1.4.1 source checks OK')
