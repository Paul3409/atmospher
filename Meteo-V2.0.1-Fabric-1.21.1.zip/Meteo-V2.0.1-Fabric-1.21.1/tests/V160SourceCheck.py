from pathlib import Path
r=Path(__file__).resolve().parent.parent
s=r/'src/main/java/de/meteo'
assert 'mod_version=1.6.0' in (r/'gradle.properties').read_text()
assert not (r/'src/main/resources/assets/meteo/sounds').exists()
assert not (r/'src/main/resources/assets/meteo/sounds.json').exists()
for f in s.rglob('*.java'):
    text=f.read_text()
    assert 'WeatherSounds' not in text,f
server=(s/'MeteoMod.java').read_text()
for id in ('CloudSnapshotPayload','CloudDiagnosticPayload','RainRadarPayload','SynopticControlPayload','SynopticMapPayload'):
    assert id in server
assert 'SERVER_STOPPING' in server and 'saveAtmosphere()' in server
assert 'WeatherSettingsStore.save' in server and 'SynopticConfigStore.save' in server
for name in ('save(', 'load('):
    assert name in (s/'AtmosphereEngine.java').read_text()
    assert name in (s/'CloudEffects.java').read_text()
radar=(s/'client/RadarScreen.java').read_text()
for word in ('drawPressureContours','drawPressureCentres','Warm','Kalt','Okklusion','RAIN_TILE'):
    assert word in radar
menu=(s/'client/MeteoScreen.java').read_text()
for word in ('Hoch erzeugen','Tief erzeugen','Manuelle Druckgebiete löschen','Fronten','Anzeige','Grundwind'):
    assert word in menu
assert 'HudRenderCallback.EVENT.register' in (s/'client/MeteoClient.java').read_text()
print('V1.6.0 source integration and resource checks OK')
