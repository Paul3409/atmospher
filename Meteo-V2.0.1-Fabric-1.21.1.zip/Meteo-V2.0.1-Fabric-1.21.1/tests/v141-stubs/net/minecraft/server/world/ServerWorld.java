package net.minecraft.server.world;
import net.minecraft.util.math.BlockPos;import net.minecraft.world.Heightmap;
public class ServerWorld {
 private long time,skyTime; private final Key key=new Key();
 public long getTime(){return time;} public long getTimeOfDay(){return skyTime;} public void setTime(long t){time=t;} public void setSkyTime(long t){skyTime=t;}
 public Key getRegistryKey(){return key;}
 public int getTopY(Heightmap.Type type,int x,int z){return 64;}
 public Holder getBiome(BlockPos p){return new Holder();}
 public static class Key {public String getValue(){return "minecraft:overworld";}}
 public static class Holder {public Biome value(){return new Biome();}}
 public static class Biome {public float getTemperature(){return 0.8f;}}
}
