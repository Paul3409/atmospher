package net.minecraft.network.codec;
public interface PacketCodec<B,P> {void encode(B b,P p);P decode(B b);}