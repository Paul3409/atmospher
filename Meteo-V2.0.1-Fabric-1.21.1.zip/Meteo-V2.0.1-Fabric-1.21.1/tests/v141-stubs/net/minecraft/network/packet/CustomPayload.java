package net.minecraft.network.packet;
import net.minecraft.network.codec.PacketCodec;import java.util.function.BiConsumer;import java.util.function.Function;
public interface CustomPayload {
 record Id<T extends CustomPayload>(net.minecraft.util.Identifier id){}
 Id<? extends CustomPayload> getId();
 static <B,T extends CustomPayload> PacketCodec<B,T> codecOf(BiConsumer<T,B> write,Function<B,T> read){return new PacketCodec<>(){
 public void encode(B b,T p){write.accept(p,b);}public T decode(B b){return read.apply(b);}};}
}
