package net.minecraft.network;
import java.io.*;
public class RegistryByteBuf {
 private final ByteArrayOutputStream out=new ByteArrayOutputStream(); private DataOutputStream dos=new DataOutputStream(out); private DataInputStream dis;
 public static RegistryByteBuf from(byte[] bytes){var b=new RegistryByteBuf();b.dis=new DataInputStream(new ByteArrayInputStream(bytes));return b;}
 public byte[] bytes(){return out.toByteArray();}
 public void writeLong(long v){try{dos.writeLong(v);}catch(Exception e){throw new RuntimeException(e);}}
 public long readLong(){try{return dis.readLong();}catch(Exception e){throw new RuntimeException(e);}}
 public void writeVarInt(int v){try{while((v&-128)!=0){dos.writeByte((v&127)|128);v>>>=7;}dos.writeByte(v);}catch(Exception e){throw new RuntimeException(e);}}
 public int readVarInt(){try{int numRead=0,result=0,read;do{read=dis.readUnsignedByte();result|=(read&127)<<(7*numRead++);if(numRead>5)throw new IllegalArgumentException();}while((read&128)!=0);return result;}catch(Exception e){throw new RuntimeException(e);}}
 public void writeFloat(float v){try{dos.writeFloat(v);}catch(Exception e){throw new RuntimeException(e);}}
 public float readFloat(){try{return dis.readFloat();}catch(Exception e){throw new RuntimeException(e);}}
 public void writeDouble(double v){try{dos.writeDouble(v);}catch(Exception e){throw new RuntimeException(e);}}
 public double readDouble(){try{return dis.readDouble();}catch(Exception e){throw new RuntimeException(e);}}
 public void writeBoolean(boolean v){try{dos.writeBoolean(v);}catch(Exception e){throw new RuntimeException(e);}}
 public boolean readBoolean(){try{return dis.readBoolean();}catch(Exception e){throw new RuntimeException(e);}}
 public void writeString(String v,int max){if(v.length()>max)throw new IllegalArgumentException();try{dos.writeUTF(v);}catch(Exception e){throw new RuntimeException(e);}}
 public String readString(int max){try{String v=dis.readUTF();if(v.length()>max)throw new IllegalArgumentException();return v;}catch(Exception e){throw new RuntimeException(e);}}
 public void writeByte(int v){try{dos.writeByte(v);}catch(Exception e){throw new RuntimeException(e);}}
 public byte readByte(){try{return dis.readByte();}catch(Exception e){throw new RuntimeException(e);}}
}
