package net.minecraft.server.network;
import net.minecraft.util.math.BlockPos;
public class ServerPlayerEntity {
    public double getX(){return 0;}
    public double getZ(){return 0;}
    public int getBlockX(){return 0;}
    public int getBlockZ(){return 0;}
    public BlockPos getBlockPos(){return new BlockPos(0,64,0);}
}
