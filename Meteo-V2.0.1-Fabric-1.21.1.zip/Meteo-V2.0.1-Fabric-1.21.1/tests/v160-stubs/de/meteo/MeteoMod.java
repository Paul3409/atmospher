package de.meteo;
public final class MeteoMod {
    public static final Logger LOGGER=new Logger();
    public static class Logger {
        public void info(String s,Object... values){}
        public void warn(String s,Object... values){System.err.println(s);}
        public void error(String s,Object... values){System.err.println(s);}
    }
}
