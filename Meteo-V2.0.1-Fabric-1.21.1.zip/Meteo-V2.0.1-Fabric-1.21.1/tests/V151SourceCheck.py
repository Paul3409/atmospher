from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
src=root/'src/main/java/de/meteo'
for p in (root/'src/main/resources').rglob('*.json'):json.loads(p.read_text(encoding='utf-8'))
assert 'mod_version=1.5.1' in (root/'gradle.properties').read_text()
menu=(src/'client/MeteoScreen.java').read_text()
assert 'String[] paceNames={"Ruhig","Normal","Lebendig","Turbulent"}' in menu
assert 'String[] modes={"Dynamisch","Wechselhaft","Fest"}' in menu
assert 'choice,s.windMode()' in menu and 's.pace(),choice' in menu
server=(src/'MeteoMod.java').read_text()
assert 'StationManager.tick(ENGINE,world,settings)' in server
assert 'getHostProfile()' in server
assert 'StationRequestPayload.ID' in server and 'StationPagePayload.ID' in server
assert 'ServerPlayNetworking.canSend(player,StationPagePayload.ID)' in (src/'StationManager.java').read_text()
assert 'isChunkLoaded' in (src/'StationManager.java').read_text()
assert 'StationWeather.estimate' in (src/'StationManager.java').read_text()
assert 'CloudEffects.stationSky' in (src/'StationManager.java').read_text()
assert 'RainPhysics.localRate' in (src/'CloudEffects.java').read_text()
assert 'WeatherSounds' not in (src/'client/MeteoClient.java').read_text()
assert not (root/'src/main/resources/assets/meteo/sounds.json').exists()
print('V1.5.1 source, menu, network, archive and resource checks OK')
