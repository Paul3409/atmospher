package de.meteo;
public class MoisturePhysicsTest {
  static void near(double a,double b){if(Math.abs(a-b)>1e-9)throw new AssertionError(a+" != "+b);}
  public static void main(String[] args){
    var a=new MoisturePhysics.Parcel(.8,.4);var b=new MoisturePhysics.Parcel(.2,.1);
    var a2=MoisturePhysics.retain(a,.25);var b2=MoisturePhysics.exchange(a,b,.25);
    near(a.total()+b.total(),a2.total()+b2.total());
    var phase=MoisturePhysics.phase(a, .6, 0, 30);
    near(a.total(),phase.parcel().total()+phase.precipitation());
    if(phase.condensation()<=0)throw new AssertionError("no condensation");
    var evaporation=MoisturePhysics.phase(new MoisturePhysics.Parcel(.2,.3),.9,0,30);
    if(evaporation.evaporation()<=0)throw new AssertionError("no evaporation");
    System.out.println("MoisturePhysicsTest OK");
  }
}
