package de.meteo;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.RegistryByteBuf;
import java.lang.reflect.Field;
import java.util.*;
public final class V141StabilityTest {
 static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 @SuppressWarnings("unchecked") static Map<String,?> regions(AtmosphereEngine a)throws Exception{
  Field f=AtmosphereEngine.class.getDeclaredField("regions");f.setAccessible(true);return (Map<String,?>)f.get(a);
 }
 static BlockPos pos(int region){return new BlockPos(region*11*256,64,0);}
 public static void main(String[] args)throws Exception{
  var a=new AtmosphereEngine();var first=new ServerWorld();first.setTime(100);
  var sample=a.sample(first,pos(0));check(sample.steps()==0,"initial grid steps");
  a.tick(first);first.setTime(101);a.tick(first);
  check(a.sample(first,pos(0)).steps()>0,"normal simulation ticks");
  long steps=a.sample(first,pos(0)).steps();
  // A /time set sky-clock jump must not affect simulation tick continuity.
  first.setSkyTime(18000);first.setTime(102);a.tick(first);
  check(a.sample(first,pos(0)).steps()>steps,"continued tick after clock change");
  for(int i=1;i<24;i++)a.sample(first,pos(i));
  check(regions(a).size()==24,"cache fills exactly 24");
  a.sample(first,pos(0)); // most recently used, should survive eviction
  a.sample(first,pos(24));
  check(regions(a).size()==24,"cache bounded at 24");
  check(regions(a).containsKey("minecraft:overworld:0:0"),"recent region survives");
  check(!regions(a).containsKey("minecraft:overworld:1:0"),"oldest region evicted");
  var second=new ServerWorld();second.setTime(500);
  check(a.sample(second,pos(0)).steps()==0,"new world has fresh grid");
  check(regions(a).size()==1,"new world clears old regions");
  a.reset();check(regions(a).isEmpty(),"server shutdown resets cache");
  var cell=new RainRadarPayload.RainCell(0,0,2.0f,(byte)1);
  var list=new ArrayList<RainRadarPayload.RainCell>();
  for(int i=0;i<512;i++)list.add(cell);
  var packet=new RainRadarPayload(42,List.copyOf(list));
  var b=new RegistryByteBuf();RainRadarPayload.CODEC.encode(b,packet);
  var decoded=RainRadarPayload.CODEC.decode(RegistryByteBuf.from(b.bytes()));
  check(decoded.cells().size()==512,"512 cell packet roundtrip");
  list.add(cell);boolean threw=false;
  try{new RainRadarPayload(43,list);}catch(IllegalArgumentException ex){threw=true;}
  check(threw,"513 cells rejected before write");
  System.out.println("V1.4.1 tests OK: world isolation, bounded LRU, tick continuity, radar codec limits");
 }
}
