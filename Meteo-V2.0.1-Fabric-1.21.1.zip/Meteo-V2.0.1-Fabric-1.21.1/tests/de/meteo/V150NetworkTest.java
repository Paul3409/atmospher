package de.meteo;
import net.minecraft.network.RegistryByteBuf;
public final class V150NetworkTest {
    public static void main(String[] args){
        var expected=new WeatherDynamics.Settings(3,1,85,315);
        var packet=WeatherSettingsPayload.of(expected);
        var b=new RegistryByteBuf();WeatherSettingsPayload.CODEC.encode(b,packet);
        var decoded=WeatherSettingsPayload.CODEC.decode(RegistryByteBuf.from(b.bytes()));
        if(!decoded.validated().equals(expected))throw new AssertionError("settings packet roundtrip");
        var invalid=new WeatherSettingsPayload(99,-1,999,-45).validated();
        if(invalid.pace()!=3||invalid.windMode()!=0||invalid.variability()!=100||invalid.fixedFrom()!=315)
            throw new AssertionError("server setting validation");
        System.out.println("V1.5.0 network payload and validation PASS");
    }
}
