package de.meteo;
import java.util.List;

/** Regression for visible, broad, meteorologically gated v1.1 cloud geometry. */
public final class CloudEvolutionTest {
    private static void check(boolean yes,String message){if(!yes)throw new AssertionError(message);}
    private static double[] bounds(List<CloudVoxelMesh.Face> faces){
        double[] b={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,
                    Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
        for(var f:faces){b[0]=Math.min(b[0],f.x0());b[1]=Math.min(b[1],f.y0());b[2]=Math.min(b[2],f.z0());
                          b[3]=Math.max(b[3],f.x1());b[4]=Math.max(b[4],f.y1());b[5]=Math.max(b[5],f.z1());}
        return b;
    }
    public static void main(String[]args){
        for(int t=0;t<5;t++){
            var dry=CloudVoxelMesh.build(0,0,158,t,.83f,.0f,.7f,1);
            check(dry.isEmpty(),"dry grid must not render cloud type "+t);
            var m=CloudVoxelMesh.build(0,0,158,t,.8f,.7f,1.2f,1);
            check(m.size()>200,"large billowing mesh expected for type "+t);
            check(m.equals(CloudVoxelMesh.build(0,0,158,t,.8f,.7f,1.2f,1)),"stable seeded geometry");
            float maxOcclusion=0;for(var f:m){check(f.occlusion()>=0&&f.occlusion()<=1,"light bounds");maxOcclusion=Math.max(maxOcclusion,f.occlusion());}
            check(maxOcclusion>.2,"lower cloud needs some sky occlusion");
            double[] b=bounds(m);System.out.printf("type=%d width=%.1f height=%.1f faces=%d%n",t,b[3]-b[0],b[4]-b[1],m.size());
        }
        var cum=bounds(CloudVoxelMesh.build(0,0,158,1,.8f,.7f,1.2f,1));
        var con=bounds(CloudVoxelMesh.build(0,0,158,2,.8f,.7f,1.2f,1));
        check(cum[3]-cum[0]>cum[4]-cum[1],"cumulus must be broader than tall");
        check(con[4]-con[1] > 1.3*(cum[4]-cum[1]),"congestus must tower above cumulus");
        check(CloudVolumeField.density(0,.30,0,1,42) > CloudVolumeField.density(.99,.9,.99,1,42),"central cloud must be denser");
        System.out.println("CloudEvolutionTest PASSED");
    }
}
