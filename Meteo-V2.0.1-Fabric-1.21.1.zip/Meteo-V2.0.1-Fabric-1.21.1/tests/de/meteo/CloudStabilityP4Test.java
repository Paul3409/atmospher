package de.meteo;
/** P4 regression: no one-frame jump for grouping, dropout or slow evaporation. */
public final class CloudStabilityP4Test {
    public static void main(String[] args){
        double scale=1;
        for(int i=0;i<20;i++)scale=CloudStability.approach(scale,3.4,1,340);
        if(scale<1 || scale>1.17)throw new AssertionError("field jumped in first second "+scale);
        double opacity=1;
        for(int i=0;i<20;i++)opacity=CloudStability.approach(opacity,0,1,190);
        if(opacity<.88 || opacity>1)throw new AssertionError("field vanished in first second "+opacity);
        double growth=1;
        for(int i=0;i<20;i++)growth=CloudLife.approach(growth,0,1);
        if(growth<.98)throw new AssertionError("cloud evaporated in first second "+growth);
        for(int i=0;i<2600;i++)growth=CloudLife.approach(growth,0,1);
        if(growth>=.40)throw new AssertionError("cloud never dissipated "+growth);
        System.out.println("PASS P4: smooth group expansion, membership fade, cloud dissolution");
    }
}
