package de.meteo;
/** Radar visibility and gentle fog response regression tests. */
public final class RadarFogPhysicsTest {
    private static void require(boolean v,String message){if(!v)throw new AssertionError(message);}
    public static void main(String[] args){
        // Source lies 16 blocks east: must produce local rain when sampled.
        double near=RainPhysics.localRate(16,0,0,0,2.5,(byte)4);
        double remote=RainPhysics.localRate(800,0,0,0,2.5,(byte)4);
        require(near>.1,"near stratocumulus rain should register");
        require(remote<near,"distant precip should not paint center");
        double calmFog=FogPhysics.target(.97,0.2,1,0,true);
        double dryFog=FogPhysics.target(.38,13,6,0,false);
        double windyFog=FogPhysics.target(.97,.2,20,0,true);
        require(calmFog>dryFog+.3,"saturated air should become foggy");
        require(windyFog<calmFog,"strong wind should suppress fog");
        float value=0;
        for(int i=0;i<20;i++)value=FogPhysics.approach(value,calmFog);
        require(value>0&&value<=1,"fog opacity should rise smoothly");
        float previous=value;value=FogPhysics.approach(value,0);
        require(value<previous&&value>0,"fog must fade without an abrupt reset");
        System.out.println("RadarFogPhysicsTest PASSED");
    }
}
