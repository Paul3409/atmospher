package de.meteo;
import java.nio.file.Files;
import java.util.EnumSet;
/** Deterministic regression checks for the synoptic map, pressure tools and saved centres. */
public final class V160SynopticTest {
    private static void ok(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    public static void main(String[] args)throws Exception {
        var defaults=SynopticWeather.DEFAULT;
        double min=10000,max=-10000;
        boolean warm=false,cold=false,occlusion=false;
        for(int x=-4600;x<=4600;x+=160)for(int z=-4600;z<=4600;z+=160){
            var w=SynopticWeather.at(70000,x,z,defaults);
            min=Math.min(min,w.pressureHpa());max=Math.max(max,w.pressureHpa());
            if(w.frontIntensity()>.25){
                warm|=w.frontType()==1;cold|=w.frontType()==2;occlusion|=w.frontType()==3;
            }
            ok(Double.isFinite(w.pressureHpa())&&Double.isFinite(w.windU())&&Double.isFinite(w.humidityFactor()),"finite values");
        }
        ok(min<1010&&max>1016,"low and high pressure regions must be available: "+min+" / "+max);
        ok(warm&&cold&&occlusion,"three independent front types must exist");
        var before=SynopticWeather.at(70000,0,0,defaults);
        var after=SynopticWeather.at(70000,0,0,defaults);
        ok(before.equals(after),"same time+position must produce the same field");
        var strong=SynopticWeather.at(70000,0,0,new SynopticWeather.Settings(200,200,1,100,100,100,true,true,true,true,true,true));
        ok(Math.abs(strong.pressureOffset())>=Math.abs(before.pressureOffset())*.9,"pressure strength control");
        SynopticRuntime.clear();
        var original=SynopticWeather.at(120000,120,70,defaults).pressureHpa();
        SynopticRuntime.create(120,70,120000,true);
        var manual=SynopticWeather.at(120000,120,70,defaults).pressureHpa();
        ok(manual<original-11,"operator low influences the physical pressure model");
        var root=Files.createTempDirectory("meteo-v160-synoptic-");
        SynopticRuntime.save(root);SynopticRuntime.clear();SynopticRuntime.load(root);
        ok(SynopticRuntime.centres().size()==1,"manual centre survives world reload");
        var reloaded=SynopticWeather.at(120000,120,70,defaults).pressureHpa();
        ok(Math.abs(reloaded-manual)<1e-8,"pressure state restored at same simulated time");
        SynopticRuntime.clear();
        for(int i=0;i<20;i++)SynopticRuntime.create(i*80,0,120000,true);
        ok(SynopticRuntime.centres().size()==12,"cap user-created systems");
        SynopticRuntime.clear();
        var fixed=new WeatherDynamics.Settings(2,2,100,90);
        for(int i=0;i<30;i++){
            var state=WeatherDynamics.at(i*8000,0,0,fixed);
            ok(state.targetU()<0&&Math.abs(state.targetV())<1e-8,"fixed wind must ignore pressure rotation");
        }
        System.out.printf("V1.6.0 PASS: pressure %.1f..%.1f hPa; warm/cold/occluded fronts; persistent operator systems%n",min,max);
    }
}
