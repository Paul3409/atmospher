package de.meteo;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import java.nio.file.*;
import java.util.*;
/** Checks region/cloud save roundtrips using minimal Minecraft stubs. */
public final class V160PersistenceTest {
    static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
    public static void main(String[] args)throws Exception {
        Path dir=Files.createTempDirectory("meteo-state-");
        var world=new ServerWorld();world.setTime(100);
        var engine=new AtmosphereEngine();
        engine.sample(world,new BlockPos(75,66,32));
        engine.tick(world);
        for(int i=101;i<121;i++){world.setTime(i);engine.tick(world);}
        double elapsed=engine.simulatedSeconds();
        var before=engine.sample(world,new BlockPos(75,66,32));
        ok(before.steps()>0,"region advanced");
        engine.save(dir.resolve("regions.gz"));
        var restored=new AtmosphereEngine();
        restored.load(world,dir.resolve("regions.gz"));
        var after=restored.sample(world,new BlockPos(75,66,32));
        ok(after.steps()==before.steps(),"grid step survived save");
        ok(after.layers().get(0).pressureHpa()==before.layers().get(0).pressureHpa(),"pressure survived save");
        ok(Math.abs(restored.simulatedSeconds()-elapsed)<1e-7,"simulated time survived save");
        CloudEffects.reset();
        CloudEffects.at(engine,world,new BlockPos(32,66,32));
        Path clouds=dir.resolve("clouds.gz");CloudEffects.save(clouds);
        ok(Files.size(clouds)>0,"cloud file nonempty");
        CloudEffects.reset();CloudEffects.load(world,clouds);
        CloudEffects.save(dir.resolve("clouds-second.gz"));
        ok(Files.size(dir.resolve("clouds-second.gz"))>0,"cloud state loaded and re-saved");
        ok(Files.mismatch(clouds,dir.resolve("clouds-second.gz"))==-1,"cloud state is lossless across reload");
        // Invalid archives must not be silently overwritten by automatic saving.
        Path corrupt=dir.resolve("corrupt.gz");Files.write(corrupt,new byte[]{1,2,3,4,5});
        var broken=new AtmosphereEngine();broken.load(world,corrupt);broken.save(corrupt);
        ok(Files.size(corrupt)==5,"corrupt atmosphere archive kept untouched");
        System.out.println("V1.6.0 persistent regional weather, simulated time and cloud state roundtrip OK");
    }
}
