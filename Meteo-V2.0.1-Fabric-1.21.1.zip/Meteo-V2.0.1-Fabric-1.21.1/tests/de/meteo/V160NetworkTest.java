package de.meteo;
import net.minecraft.network.RegistryByteBuf;
/** 1.6 packet codecs smoke tested with the existing isolated Minecraft ByteBuf stubs. */
public final class V160NetworkTest {
    static void ok(boolean yes,String reason){if(!yes)throw new AssertionError(reason);}
    public static void main(String[] args){
        var s=SynopticWeather.DEFAULT;
        var config=SynopticControlPayload.of(s);var b=new RegistryByteBuf();
        SynopticControlPayload.CODEC.encode(b,config);
        var restored=SynopticControlPayload.CODEC.decode(RegistryByteBuf.from(b.bytes()));
        ok(restored.settings().equals(s),"synoptic settings packet roundtrip");
        var pressure=SynopticMapPayload.around(55,140,700,85000,s);
        ok(pressure.grid().size()==825,"33x25 map");
        b=new RegistryByteBuf();SynopticMapPayload.CODEC.encode(b,pressure);
        var decoded=SynopticMapPayload.CODEC.decode(RegistryByteBuf.from(b.bytes()));
        ok(decoded.tick()==55&&decoded.grid().equals(pressure.grid()),"pressure/front map packet roundtrip");
        b=new RegistryByteBuf();ManualPressurePayload.CODEC.encode(b,new ManualPressurePayload(2));
        ok(ManualPressurePayload.CODEC.decode(RegistryByteBuf.from(b.bytes())).action()==2,"manual pressure command");
        System.out.println("V1.6.0 synoptic settings, map grid and operator pressure packet codecs OK");
    }
}
