package de.meteo;
public final class P5CombinedTest {
    private static void ok(boolean b,String msg){if(!b)throw new AssertionError(msg);}
    public static void main(String[] args){
        ok(CloudFieldContinuity.connected(0,0,95,0,.4,.4,.8,.8,false),"merge");
        ok(!CloudFieldContinuity.connected(0,0,110,0,.4,.4,.8,.8,false),"no immediate merge");
        ok(CloudFieldContinuity.connected(0,0,110,0,.4,.4,.8,.8,true),"hysteresis");
        ok(!CloudFieldContinuity.connected(0,0,130,0,.4,.4,.8,.8,true),"split after threshold");
        ok(!CloudFieldContinuity.connected(0,0,50,0,.01,.5,.8,.8,true),"no dry cloud groups");
        ok(CloudFieldContinuity.rangeFade(0,512,80)==1,"inside range");
        ok(CloudFieldContinuity.rangeFade(512,512,80)==0,"edge zero");
        ok(CloudFieldContinuity.rangeFade(472,512,80)>.4,"smooth edge");
        ok(CloudLife.approach(1,0,1)>.999,"no instant vanish");
        double v=1;for(int i=0;i<20;i++)v=CloudLife.approach(v,0,1);
        ok(v>.98,"fade longer than one second");
        ok(RainVisualPhysics.stage(.4)==0,"drizzle");
        ok(RainVisualPhysics.stage(3)==1,"shower");
        ok(RainVisualPhysics.stage(12)==2,"heavy rain");
        ok(RainVisualPhysics.length(2,2,.5)>RainVisualPhysics.length(0,0,.5),"heavy rain streaks longer");
        ok(RainVisualPhysics.width(2,2,.5)>RainVisualPhysics.width(0,0,.5),"heavy rain streaks wider");
        ok(RainVisualPhysics.fallSpeed(2,.5)>RainVisualPhysics.fallSpeed(0,.5),"fall speed");
        System.out.println("P5 Cloud Stability + Rain 2.0: 16 checks OK");
    }
}
