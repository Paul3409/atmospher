package de.meteo;
import java.util.List;

/** Pure JVM regression tests, no Minecraft dependencies. */
public final class Meteo120Test {
    static void ok(boolean v,String message){if(!v)throw new AssertionError(message);}
    static void near(double x,double expected,double tol,String what){ok(Math.abs(x-expected)<=tol,what+" ("+x+")");}
    public static void main(String[]args){
        var a=new CloudMotion.Position(100.25,-73.0);
        var b=CloudMotion.advance(a,9,0,72);
        ok(b.x()>a.x()&&b.z()==a.z(),"wind moves stable anchored cloud");
        near(CloudMotion.advance(b,-9,0,72).x(),a.x(),1e-7,"reversible advection");
        ok(CloudMotion.intersects(100,0,150,0,60,0),"inside cloud is visible");
        ok(CloudMotion.intersects(100,0,200,0,60,40),"boundary visible");
        ok(!CloudMotion.intersects(100,0,400,0,60,40),"distant clouds culled");
        near(RainPhysics.rainRate(.01,72),4,1e-8,"normalized rain sink to mm/h");
        ok(RainPhysics.localRate(0,0,0,0,12)==12,"rain peaks below core");
        near(RainPhysics.localRate(0,0,90,0,12),0,0,"dry outside shower");
        ok(RainPhysics.snow(-2)&&!RainPhysics.snow(10),"snow phase");
        var windward=CloudPhysics.diagnose(16,13,.86,8,0,.22,0,.35);
        var leeward=CloudPhysics.diagnose(16,13,.86,8,0,-.22,0,.35);
        ok(windward.terrainFlow().equals("Luv")&&leeward.terrainFlow().equals("Lee"),"Luv and Lee detected");
        ok(windward.coverage()>leeward.coverage(),"Luv makes more cloud than Lee");
        var lush=MoisturePhysics.phase(new MoisturePhysics.Parcel(.9,.7),.58,.9,72);
        var lee=MoisturePhysics.phase(new MoisturePhysics.Parcel(.9,.7),1.1,-.5,72);
        ok(lush.precipitation()>0&&lee.precipitation()==0,"rising moist parcel showers; sinking parcel is dry");
        ok(lush.parcel().liquid()>0,"saturated parcel retains cloud water");
        near(lush.parcel().total()+lush.precipitation(),1.6,1e-8,"conserved condensate with rain sink");
        var one=CloudVoxelMesh.build(9,12,999.5f,-420.25f,164,2,.8f,.7f,.8f,1);
        var two=CloudVoxelMesh.build(9,12,1009.5f,-420.25f,164,2,.8f,.7f,.8f,1);
        ok(!one.isEmpty()&&one.size()==two.size(),"mesh follows advected center");
        for(int i=0;i<one.size();i++){
            near(two.get(i).x0()-one.get(i).x0(),10,1e-4,"stable moved face x");
            near(two.get(i).z0()-one.get(i).z0(),0,1e-4,"stable moved face z");
        }
        ok(CloudVoxelMesh.build(9,12,1009.5f,-420.25f,164,2,.8f,0,.8f,1).isEmpty(),"zero water = no clouds");
        System.out.println("PASS Meteo120Test: cloud movement, visibility, rain budget, snow, mesh translation");
    }
}
