package de.meteo;
public final class P53PhysicsTest {
    static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args){
        double moist=CloudBasePhysics.baseAboveGround(15,14);
        double dry=CloudBasePhysics.baseAboveGround(20,10);
        check(dry>moist,"Dry air must give higher cloud base");
        check(moist>=38&&dry<=160,"Cloud base should fit MC world");
        check(CloudBasePhysics.baseAboveGround(20,20)>=38,"Cumulus minimum height");
        double b=Double.NaN;
        for(int i=0;i<10;i++)b=CloudBasePhysics.relax(b,100,72);
        check(b==100,"Constant target must stay constant");
        double initial=CloudBasePhysics.relax(80,140,72);
        check(initial>80&&initial<95,"Cloud height must not jump at first update");
        double last=80;
        for(int i=0;i<30;i++){double next=CloudBasePhysics.relax(last,140,72);
            check(next>=last&&next<140.0001,"Monotonic relaxation");last=next;}
        double wetWindward=CloudBasePhysics.adjustedSaturation(.8,.9,.9,.5);
        double wetLee=CloudBasePhysics.adjustedSaturation(-.8,-.7,.9,.5);
        check(wetWindward<wetLee,"Wet windward slope should condense more than lee");
        check(CloudBasePhysics.adjustedSaturation(.8,.9,.4,.5)>wetWindward,
                "Wet orographic ascent should work more strongly than dry ascent");
        var cloud=CloudPhysics.diagnose(15,12,.85,6,0,.1,0,.5);
        check(Double.isFinite(cloud.baseBlocks()),"LCL finite");
        System.out.println("PASS P5.3 cloud height, smoothing, and windward/lee conditions");
    }
}
