package de.meteo;
/** Standalone deterministic tests for wind, synoptic variability and bounded integration. */
public final class V150DynamicsTest {
    static void ok(boolean b,String why){if(!b)throw new AssertionError(why);}
    static double direction(WeatherDynamics.State s){return Math.atan2(s.targetV(),s.targetU());}
    static double diff(double a,double b){return Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));}
    public static void main(String[] args){
        var lively=WeatherDynamics.DEFAULT;
        var calm=new WeatherDynamics.Settings(0,0,65,270);
        var variable=new WeatherDynamics.Settings(2,1,100,270);
        var fixed=new WeatherDynamics.Settings(2,2,100,90);
        ok(new WeatherDynamics.Settings(20,-5,500,-90).pace()==3,"pace clamped");
        ok(new WeatherDynamics.Settings(20,-5,500,-90).variability()==100,"variability clamped");
        ok(new WeatherDynamics.Settings(20,-5,500,-90).fixedFrom()==270,"bearing normalized");
        double maxTurn=0,maxNeighbor=0,humidityMin=10,humidityMax=0;
        var first=WeatherDynamics.at(0,0,0,lively);
        for(int i=1;i<=1000;i++){
            double t=i*360; // 5 real seconds, repeated over 83 real minutes
            var state=WeatherDynamics.at(t,0,0,lively);
            var previous=WeatherDynamics.at(t-360,0,0,lively);
            maxTurn=Math.max(maxTurn,diff(direction(state),direction(first)));
            maxNeighbor=Math.max(maxNeighbor,diff(direction(state),direction(previous)));
            humidityMin=Math.min(humidityMin,state.humidityFactor());
            humidityMax=Math.max(humidityMax,state.humidityFactor());
            ok(Double.isFinite(state.targetU())&&Double.isFinite(state.targetV()),"finite winds");
            ok(Math.hypot(state.targetU(),state.targetV())<10,"bounded wind");
        }
        ok(maxTurn>1.2,"direction must actually change over time: "+maxTurn);
        ok(maxNeighbor<0.09,"no abrupt 5-second wind changes: "+maxNeighbor);
        ok(humidityMax-humidityMin>.35,"moist and dry weather phases should alternate");
        var a=WeatherDynamics.at(0,0,0,calm);
        var b=WeatherDynamics.at(0,0,0,variable);
        ok(diff(direction(a),direction(b))>.1,"wind mode changes variability");
        for(int i=0;i<100;i++){
            var state=WeatherDynamics.at(i*10000,0,0,fixed);
            // Wind FROM east means flow toward west, U < 0, V near zero.
            ok(state.targetU()<0&&Math.abs(state.targetV())<1e-8,"fixed meteorological direction");
        }
        var g=new RegionalPhysics.Grid();
        for(int x=0;x<RegionalPhysics.N;x++)for(int z=0;z<RegionalPhysics.N;z++){
            g.t[x][z]=16;g.baseline[x][z]=16;g.q[x][z]=.008;g.baselineQ[x][z]=.008;
            g.u[x][z]=4;g.v[x][z]=2;g.p[x][z]=0;
        }
        for(int i=0;i<24000;i++)RegionalPhysics.step(g,6,lively);
        for(int x=0;x<RegionalPhysics.N;x++)for(int z=0;z<RegionalPhysics.N;z++){
            ok(Double.isFinite(g.t[x][z])&&g.t[x][z]>-30&&g.t[x][z]<50,"temperature stable");
            ok(Double.isFinite(g.q[x][z])&&g.q[x][z]>0&&g.q[x][z]<.02,"humidity stable");
            ok(Double.isFinite(g.p[x][z])&&Math.abs(g.p[x][z])<10,"pressure stable");
            ok(Math.hypot(g.u[x][z],g.v[x][z])<20,"wind stable");
        }
        System.out.printf("V1.5.0 PASS: direction span %.1f deg; max 5s change %.2f deg; humidity %.2f..%.2f%n",
            Math.toDegrees(maxTurn),Math.toDegrees(maxNeighbor),humidityMin,humidityMax);
    }
}
