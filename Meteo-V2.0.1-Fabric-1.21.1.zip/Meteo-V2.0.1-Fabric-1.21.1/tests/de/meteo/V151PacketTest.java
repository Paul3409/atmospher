package de.meteo;
import java.util.*;
import net.minecraft.network.RegistryByteBuf;
public final class V151PacketTest {
 public static void main(String[] args){
    List<StationReading> list=new ArrayList<>();
    for(int i=0;i<100;i++)list.add(new StationReading(i*1200,12,8,1011,.5,i*.01,2,3,90,.3,i%2==0));
    var packet=new StationPagePayload(123L,"Bergstation",0,3,250,list);
    var buf=new RegistryByteBuf();StationPagePayload.CODEC.encode(buf,packet);
    var restored=StationPagePayload.CODEC.decode(RegistryByteBuf.from(buf.bytes()));
    if(!restored.equals(packet))throw new AssertionError("Station page codec roundtrip");
    var request=new StationRequestPayload(123L,2);
    var requestBuf=new RegistryByteBuf();StationRequestPayload.CODEC.encode(requestBuf,request);
    if(!StationRequestPayload.CODEC.decode(RegistryByteBuf.from(requestBuf.bytes())).equals(request))throw new AssertionError("Request codec");
    try{new StationPagePayload(0,"x",0,1,101,Collections.nCopies(101,list.get(0)));throw new AssertionError("Oversized page accepted");}
    catch(IllegalArgumentException expected){}
    System.out.println("V1.5.1 station network packet codec and bounds: OK");
 }
}
