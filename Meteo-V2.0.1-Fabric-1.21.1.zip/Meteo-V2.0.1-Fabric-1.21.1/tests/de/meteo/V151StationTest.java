package de.meteo;

import java.nio.file.*;
import java.util.*;

/** Pure Java persistence, paging, independence and offline projection regression. */
public final class V151StationTest {
    private static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    public static void main(String[] args)throws Exception {
        Path file=Files.createTempDirectory("meteo-stations-test").resolve("archive.bin");
        StationArchive a=new StationArchive();
        var mountain=a.place("minecraft:overworld",123L);
        var valley=a.place("minecraft:overworld",456L);
        check(!mountain.id.equals(valley.id),"Station IDs must be independent");
        check(a.place("minecraft:overworld",123L)==mountain,"Same position must not duplicate active station");
        for(int i=0;i<250;i++){
            mountain.history.add(new StationReading(i*1200L,8+i*.01,5,1005+i*.02,1, i/60.0,3,4,270,.4,false));
            valley.history.add(new StationReading(i*1200L,15,11,1010,0,0,2,3,180,.1,false));
        }
        check(mountain.pages()==3,"History paging");
        check(mountain.page(0).size()==100 && mountain.page(2).size()==50,"Page sizes");
        check(mountain.page(0).get(0).tick()==150*1200L,"Newest page offset");
        var projected=StationWeather.estimate(mountain.latest(),mountain.latest().tick()+1200,0,0,WeatherDynamics.DEFAULT);
        check(projected.estimated(),"Unloaded station measurements must be marked modeled");
        check(projected.rainTotal()>=mountain.latest().rainTotal(),"Rain accumulation monotonic");
        a.remove("minecraft:overworld",123L);
        check(a.activeAt("minecraft:overworld",123L)==null,"Removed station inactive");
        a.save(file);
        var b=StationArchive.load(file);
        check(b.all().size()==2,"All archives survive reload");
        check(b.byId(mountain.id).history.size()==250,"Full history survives reload");
        check(!b.byId(mountain.id).active,"Removal status persists");
        check(b.activeAt("minecraft:overworld",456L).history.size()==250,"Other station remains active");
        var replaced=b.place("minecraft:overworld",123L);
        check(!replaced.id.equals(mountain.id),"Replacement station has independent archive");
        b.save(file);
        check(StationArchive.load(file).all().size()==3,"Replacement archives preserved");
        System.out.println("V1.5.1 station archive, independent measurements, paging, restart and projection: OK");
    }
}
