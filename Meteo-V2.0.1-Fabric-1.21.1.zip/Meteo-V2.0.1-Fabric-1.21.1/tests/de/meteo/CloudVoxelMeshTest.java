package de.meteo;

public final class CloudVoxelMeshTest {
    public static void main(String[] args){
        if(!CloudVoxelMesh.build(0,0,150,1,.0f,.8f,.6f,1).isEmpty())throw new AssertionError("Cloud without coverage");
        if(!CloudVoxelMesh.build(0,0,150,1,.8f,.0f,.6f,1).isEmpty())throw new AssertionError("Cloud without water");
        for(int type=0;type<5;type++){
            var faces=CloudVoxelMesh.build(10,-3,165,type,.85f,.7f,1.4f,1);
            if(faces.size()<100)throw new AssertionError("Invisible mesh type "+type+" "+faces.size());
            for(var f:faces)if(!(f.x1()>f.x0()&&f.y1()>f.y0()&&f.z1()>f.z0()))throw new AssertionError("Bad face");
            if(!faces.equals(CloudVoxelMesh.build(10,-3,165,type,.85f,.7f,1.4f,1)))throw new AssertionError("Non-deterministic mesh");
            System.out.println("type="+type+" visible exterior faces="+faces.size());
        }
        var low=CloudVoxelMesh.build(2,4,160,2,.95f,.95f,2.0f,0);
        var high=CloudVoxelMesh.build(2,4,160,2,.95f,.95f,2.0f,2);
        if(high.size()<=low.size())throw new AssertionError("Quality scaling failed");
        System.out.println("CloudVoxelMeshTest PASSED");
    }
}
