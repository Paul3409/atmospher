package de.meteo;

/** Regression tests for P4: slow advection, intentionally slower cloud life, rain smoothing. */
public final class Meteo121Test {
    private Meteo121Test(){}
    private static void ok(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    private static void near(double actual,double expected,double eps,String title){
        ok(Math.abs(actual-expected)<=eps,title+": "+actual+" vs "+expected);
    }
    public static void main(String[] args){
        var origin=new CloudMotion.Position(123.25,-45.5);
        var moved=CloudMotion.advance(origin,10,-4,72);
        near(moved.x()-origin.x(),1.5,1e-8,"72x weather clock no longer speeds up visible clouds");
        near(moved.z()-origin.z(),-.6,1e-8,"wind direction maintained");
        near(CloudMotion.advance(moved,-10,4,72).x(),origin.x(),1e-8,"reversible movement");
        double speed=Math.hypot(moved.x()-origin.x(),moved.z()-origin.z());
        ok(speed<2,"normal wind moves less than 2 blocks per real second");
        ok(CloudMotion.intersects(moved.x(),moved.z(),moved.x(),moved.z(),60,0),"inside cloud still visible");
        ok(!CloudMotion.intersects(moved.x(),moved.z(),moved.x()+400,moved.z(),60,200),"remote volume culled");

        ok(CloudLife.target(0,1)==0,"no cover means no cloud");
        ok(CloudLife.target(1,0)==0,"no water means no cloud");
        double tiny=CloudLife.target(.1,.09),large=CloudLife.target(.85,.9);
        ok(tiny>0&&tiny<large,"tiny physical clouds produce tiny visual clouds");
        double progress=0,prev=0;
        for(int i=0;i<160;i++){
            progress=CloudLife.approach(progress,large,1);
            ok(progress>prev&&progress<large,"life grows continuously, never jumps to target");
            prev=progress;
        }
        double largeWidth=CloudLife.horizontalScale(progress);
        ok(largeWidth>.15&&largeWidth<.4,"P4 formation starts noticeably smaller after 8s");
        for(int i=0;i<160;i++){
            prev=progress;
            progress=CloudLife.approach(progress,0,1);
            ok(progress<prev&&progress>=0,"cloud dissipates smoothly");
        }
        ok(CloudLife.horizontalScale(progress)<largeWidth,"dissipation shrinks the geometry");
        near(CloudLife.approach(.5,.5,1),.5,1e-10,"stable cloud remains stable");

        double rain=0;
        for(int i=0;i<20;i++){
            double before=rain;
            rain=RainPhysics.smoothRate(rain,15,72);
            ok(rain>=before&&rain<=15,"shower ramps up smoothly");
        }
        ok(rain>14,"showers attain realistic model target");
        for(int i=0;i<15;i++)rain=RainPhysics.smoothRate(rain,0,72);
        ok(rain<.6,"showers dissipate when condensation stops");
        near(RainPhysics.localRate(0,0,0,0,8),8,1e-9,"radar intensity matches shower core");
        near(RainPhysics.localRate(0,0,120,0,8),0,1e-9,"radar outside precipitation footprint stays dry");

        var single=CloudVoxelMesh.build(12,24,0f,0f,145f,1,1f,.95f,.5f,1);
        ok(!single.isEmpty(),"stable cloud mesh can be cached for life of formation");
        var again=CloudVoxelMesh.build(12,24,0f,0f,145f,1,1f,.95f,.5f,1);
        ok(single.equals(again),"local-space cloud mesh deterministic");
        System.out.println("PASS Meteo121Test: slowed clouds, smooth growth/dissipation, stable 3D mesh, coherent showers");
    }
}
