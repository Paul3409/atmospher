package de.meteo;
public final class P6CloudLayersTest {
  private static void check(boolean good,String message){if(!good)throw new AssertionError(message);}
  public static void main(String[] args){
    check(HighCloudPhysics.iceContent(.30,-15)==0,"Dry upper air cannot form cirrus");
    check(HighCloudPhysics.iceContent(.90,-25)>.40,"Moist high air forms cirrus");
    check(HighCloudPhysics.baseY(320,85,.8)>200,"Cirrus above low clouds");
    var cirrus=CloudVoxelMesh.buildHybrid(2,3,0,0,258,5,.65f,.55f,0,1);
    check(!cirrus.outer().isEmpty(),"Cirrus should have feather-like voxel geometry");
    check(cirrus.core().isEmpty(),"Cirrus remains thin/translucent");
    var cumulus=CloudVoxelMesh.buildHybrid(2,3,0,0,158,1,.9f,.9f,.3f,1);
    check(!cumulus.outer().isEmpty(),"Existing cumulus geometry intact");
    double rate=StratiformRain.target(.97,.8,.6,0);
    check(rate>1,"Moist cloud decks yield persistent precipitation");
    check(StratiformRain.target(.3,.8,.6,0)==0,"Dry cloud decks remain dry");
    check(StratiformRain.relax(rate,0,3)>0,"Stratiform rain does not vanish in one frame");
    check(RainPhysics.localRate(0,0,80,0,3,(byte)4)>0,"Stratocumulus rain reaches nearby valley");
    check(RainPhysics.localRate(0,0,80,0,3,(byte)1)==0,"Convective shafts stay local");
    check(RainPhysics.localRate(0,0,0,0,5,(byte)5)==0,"Cirrus never rains");
    System.out.println("P6 layers + rain OK");
  }
}
