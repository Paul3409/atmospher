package de.meteo;
public final class PhysicsSelfTest {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        for(double wind:new double[]{-18,-5,5,18}){
            double t=20;
            for(int i=0;i<14400;i++){
                t=Advection.donorStep(t,10,wind,6,256);
                check(Double.isFinite(t)&&t>=9.999&&t<=20.001,"advection "+wind);
            }
        }
        double e=Thermodynamics.saturationVaporPressureHpa(20)*.5;
        double q=Thermodynamics.specificHumidityKgKg(e,1013.25);
        check(Math.abs(Thermodynamics.vaporPressureFromSpecificHumidityHpa(q,1013.25)-e)<1e-8,"q roundtrip");
        check(Math.abs(Thermodynamics.dewPointC(e)-9.27)<.2,"dew point");
        RegionalPhysics.Grid g=new RegionalPhysics.Grid();
        for(int x=0;x<RegionalPhysics.N;x++)for(int z=0;z<RegionalPhysics.N;z++){
            g.t[x][z]=18;g.baseline[x][z]=18;g.q[x][z]=.008;g.baselineQ[x][z]=.008;
            g.p[x][z]=2*Math.sin(x*.3+z*.2);g.u[x][z]=4;g.v[x][z]=2;
        }
        for(int i=0;i<14400;i++)RegionalPhysics.step(g,6);
        check(Math.abs(g.seconds-86400)<1e-6,"24h clock");
        double minT=100,maxT=-100,minP=100,maxP=-100,maxWind=0,minQ=100,maxQ=0;
        for(int x=0;x<RegionalPhysics.N;x++)for(int z=0;z<RegionalPhysics.N;z++){
            minT=Math.min(minT,g.t[x][z]);maxT=Math.max(maxT,g.t[x][z]);
            minP=Math.min(minP,g.p[x][z]);maxP=Math.max(maxP,g.p[x][z]);
            minQ=Math.min(minQ,g.q[x][z]);maxQ=Math.max(maxQ,g.q[x][z]);
            maxWind=Math.max(maxWind,Math.hypot(g.u[x][z],g.v[x][z]));
        }
        check(minT>14&&maxT<22,"temperature remains physically bounded");
        check(minQ>0.003&&maxQ<0.012,"humidity remains bounded through fronts");
        check(minP>-5&&maxP<5,"pressure runaway");
        check(maxWind<20,"wind runaway: "+maxWind);
        System.out.printf("PASS 24h: T %.3f..%.3f C, q %.5f..%.5f kg/kg, p %.2f..%.2f hPa, wind max %.2f m/s%n",minT,maxT,minQ,maxQ,minP,maxP,maxWind);
    }
}
