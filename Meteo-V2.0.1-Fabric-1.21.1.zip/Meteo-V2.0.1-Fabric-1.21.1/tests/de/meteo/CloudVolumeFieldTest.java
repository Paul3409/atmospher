package de.meteo;
public final class CloudVolumeFieldTest {
    private static void assertTrue(boolean yes,String reason){if(!yes)throw new AssertionError(reason);}
    public static void main(String[] args){
        assertTrue(CloudVolumeField.build(0,0,140,1,0,0).isEmpty(),"dry cloud must be invisible");
        var cum=CloudVolumeField.build(1,2,140,1,.65f,.55f);
        var layer=CloudVolumeField.build(1,2,140,3,.65f,.55f);
        assertTrue(!cum.isEmpty()&&!layer.isEmpty(),"wet clouds must generate voxels");
        assertTrue(cum.equals(CloudVolumeField.build(1,2,140,1,.65f,.55f)),"cloud geometry must be deterministic");
        for(var v:cum){assertTrue(v.opacity()>0&&v.opacity()<=.095f,"opacity bound");assertTrue(v.y()>=140&&v.y()<195,"height bound");}
        assertTrue(CloudVolumeField.density(2,.5,0,2,123)==0,"outside volume");
        assertTrue(CloudVolumeField.noise(.2,.4,.8,17)==CloudVolumeField.noise(.2,.4,.8,17),"noise stable");
        System.out.println("OK: 3D density clouds, moisture gating, determinism, opacity and bounds");
    }
}
