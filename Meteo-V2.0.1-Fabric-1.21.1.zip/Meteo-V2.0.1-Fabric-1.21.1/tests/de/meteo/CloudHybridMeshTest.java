package de.meteo;

/** Standalone P2 geometry regression test, no Minecraft runtime required. */
public final class CloudHybridMeshTest {
    public static void main(String[] args) {
        for(int type=0;type<=4;type++) {
            var layers=CloudVoxelMesh.buildHybrid(7,-3,0,0,150,type,1f,.95f,1.1f,2);
            if(layers.outer().isEmpty())throw new AssertionError("No outer skin type="+type);
            if(layers.core().size()>layers.outer().size()*2)
                throw new AssertionError("Unexpected inner surface size type="+type);
            var same=CloudVoxelMesh.buildHybrid(7,-3,0,0,150,type,1f,.95f,1.1f,2);
            if(!layers.equals(same))throw new AssertionError("Unstable cloud seed type="+type);
            if(!CloudVoxelMesh.buildHybrid(7,-3,0,0,150,type,1f,0f,1.1f,2).outer().isEmpty())
                throw new AssertionError("Cloud without condensate type="+type);
            for(var f:layers.core()){
                if(!Float.isFinite(f.x0())||!Float.isFinite(f.y0())||!Float.isFinite(f.z0()))
                    throw new AssertionError("Non-finite core vertex");
                if(f.x1()<=f.x0()||f.y1()<=f.y0()||f.z1()<=f.z0())
                    throw new AssertionError("Invalid core quad");
            }
            System.out.println("type="+type+" skin="+layers.outer().size()+" core="+layers.core().size());
        }
        System.out.println("CloudHybridMeshTest PASSED");
    }
}
