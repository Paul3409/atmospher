@echo off
cd /d "%~dp0"
call TEST-V1.7.0.bat
