@echo off
setlocal
cd /d "%~dp0"
if not exist "build\p5-test" mkdir "build\p5-test"
javac -encoding UTF-8 -d "build\p5-test" "src\main\java\de\meteo\CloudLife.java" "src\main\java\de\meteo\CloudStability.java" "src\main\java\de\meteo\CloudFieldContinuity.java" "src\main\java\de\meteo\RainVisualPhysics.java" "tests\de\meteo\P5CombinedTest.java"
if errorlevel 1 (echo FEHLER beim Javac-Test & pause & exit /b 1)
java -cp "build\p5-test" de.meteo.P5CombinedTest
if errorlevel 1 (echo FEHLER beim Test & pause & exit /b 1)
echo P5 Tests erfolgreich.
pause
