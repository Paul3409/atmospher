@echo off
setlocal
cd /d "%~dp0"
if not exist temp-tests mkdir temp-tests
javac -encoding UTF-8 -d temp-tests src\main\java\de\meteo\CloudVolumeField.java src\main\java\de\meteo\CloudVoxelMesh.java tests\de\meteo\CloudVolumeFieldTest.java tests\de\meteo\CloudVoxelMeshTest.java tests\de\meteo\CloudEvolutionTest.java
if errorlevel 1 (echo FEHLER beim Wolkentest. & pause & exit /b 1)
java -cp temp-tests de.meteo.CloudVolumeFieldTest
if errorlevel 1 (pause & exit /b 1)
java -cp temp-tests de.meteo.CloudVoxelMeshTest
if errorlevel 1 (pause & exit /b 1)
java -cp temp-tests de.meteo.CloudEvolutionTest
if errorlevel 1 (pause & exit /b 1)
echo 3D-Wolkentests erfolgreich.
pause
