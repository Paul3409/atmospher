@echo off
setlocal
cd /d "%~dp0"
echo METEO V1.7.0 - Fabric Build
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
if errorlevel 1 (
 echo.
 echo BUILD FEHLGESCHLAGEN - bitte den ersten Gradle-Fehler an ChatGPT senden.
) else (
 echo.
 echo BUILD SUCCESSFUL - normales Mod-JAR in build\libs
)
pause
