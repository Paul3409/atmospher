# Meteo V1.7.4 – Buildfix für Minecraft 1.21.1

## Was wurde korrigiert?

Der vollständige Gradle-Build der ersten V1.7.4 scheiterte in `:compileTestJava`, weil die hinzugefügte Testklasse `V174PacketRoundtripTest.java` einen parameterlosen Konstruktor `new RegistryByteBuf()` verwendete. Dieser Konstruktor existiert in Minecraft 1.21.1 nicht.

Die Testklasse verwendet nun `new RegistryByteBuf(Unpooled.buffer(), DynamicRegistryManager.EMPTY)` und setzt nach dem Schreiben `readerIndex(0)`. Der Puffer wird anschließend freigegeben. Die eigentlichen Wetter- und Mod-Klassen wurden bei diesem Buildfix nicht verändert.

## Erneut bauen

Entpacke diese ZIP in einen **neuen** Projektordner und führe darin aus:

```cmd
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
```

Die Mod-JAR befindet sich bei Erfolg unter `build\libs`. Nicht die `-sources.jar` installieren. Alte Meteo-JAR im `mods`-Ordner vorher entfernen. Bestehende Welt vorher sichern.

## Teststatus

Der konkrete Konstruktorfehler ist im Quellcode korrigiert; ein vollständiger Fabric-Loom-Build wurde in dieser Umgebung nicht ausgeführt und muss unter Windows geprüft werden.
