# Meteo V1.7.3 – Frontwolken, synoptische Feuchte und Gebirgshindernisse

**Minecraft 1.21.1 · Fabric · Java 21**. Vollständiges Quellprojekt. Baut und installiert die Mod **anstelle** der alten Meteo-JAR – nicht zusätzlich.

## Was gegenüber V1.7.2 tatsächlich neu ist

1. **Fronten erzeugen einen eigenen hohen Wolkenschleier.** `FrontalCloudPhysics.highVeil(...)` errechnet Eiswolken aus der aktuellen und der vorauslaufenden synoptischen Front. Diese zusätzliche hohe Wolkenschicht ist nicht mehr vom Wasser einer bereits bestehenden niedrigen Wolke abhängig. Nur wenn eine Front in der Wetterkarte existiert, erhält sie dieses Zusatzsignal.
2. **Frontale Kondensation ist stärker und schneller.** `FrontalCloudPhysics.saturationReduction(...)` senkt die Sättigungsschwelle des vorhandenen Wasserdampfreservoirs bei Hebung. Ein beschleunigter, gradueller Wolkenaufbau (`responseSeconds`) führt im Frontkern früher zu dunkleren Wolken. Niederschlag erfordert trotzdem tatsächlich kondensiertes Wasser, nicht nur eine Frontmarkierung.
3. **Bisher fehlende Feuchte-Kopplung behoben.** `AtmosphereEngine` benutzt jetzt `synoptic.humidityFactor()` für den Wasserdampfgehalt. Diese Information wurde in V1.7.2 berechnet, aber am Wetterort bislang ignoriert.
4. **Frontwolken früher sichtbar.** Hohe Eiswolken verwenden eine schnellere, sanfte Wachstumszeit im Client. Frontbewölkung bekommt einen eigenen Platz in der Snapshot-Priorisierung. Das Erfassungsgebiet für herannahende Wolken wurde schrittweise erweitert.
5. **Berge statt Geisterwolken.** Vor jeder Server-Wolkenbewegung werden auch Zwischenpunkte auf dem Weg geprüft. Die Höhenproben sind für die Dauer eines Ticks zwischengespeichert; ungeladene Chunks werden nicht eigens geladen. Kleine Hindernisse können überströmt, mögliche Flanken umströmt und unpassierbare Berge luvseitig angestaut werden. Die Client-Vorhersage ist auf höchstens 12 Ticks begrenzt, damit sie nicht minutenlang geradlinig durch Felsen läuft.
6. **Weniger geometrische Isobaren.** `SynopticWeather` verwendet leicht deformierte, zeitlich wandernde Druckfelder. Druckkarte und lokale Atmosphäre nutzen dieselbe Funktion.
7. **Erhalt der V1.7.1-Funktionen.** Schneeakkumulation, Schnee-/Regenpartikel, Jahreszeiten, Wetterstationen, UI- und Cloud-Stil bleiben erhalten. Das gespeicherte Wolkenformat wurde nicht geändert.

## Wichtig – Was V1.7.3 NICHT verspricht

Meteo ist weiterhin ein vereinfachtes Minecraft-Wettermodell, keine vollständige Atmosphärenströmungssimulation. Wolkenumströmung an komplexen Berglandschaften ist eine Näherung anhand **geladener** Geländespalten. Der Wolkenkörper ist kein geometrisch exaktes kollidierendes Fluid; an extremen Felskanten kann es weiterhin Darstellungsfehler geben.

Radarprognosen von +3/+6/+9 Stunden zeigen **Druck und Fronten**, keine zuverlässig berechnete künftige Niederschlagskarte. Aktueller Regen/Schnee stammt aus den serverseitigen Wolkenwasserzellen. Das ist ausdrücklich keine künstlich gemalte Front-Regenfläche.

Die geänderten Kern-Serverklassen wurden mit **Java 21 und Minecraft-Teststellvertretern** kompiliert. Pure-Java-Physiktests wurden separat durchgeführt. **Ein vollständiger Fabric-Loom-Build sowie der echte In-Game-Test wurden hier nicht durchgeführt.**

## Installation / Build

1. Vorher die Welt sichern.
2. Vollständige ZIP in einen neuen Ordner entpacken.
3. `TEST-V1.7.3.bat` ausführen oder im Ordner mit `build.gradle` per CMD:

   `"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace`

4. Nach `BUILD SUCCESSFUL` die **normale** JAR aus `build\libs` in den Minecraft-`mods`-Ordner legen. Vorher die alte Meteo-JAR entfernen.
5. Welt starten und **Radar (R)** prüfen: auf eine heranrückende Kalt-/Warmfront warten oder im O-Menü eine lokale Tiefdrucklage erzeugen. Erst in der Ferne hohe Schleier, dann bei Feuchte dichtere dunkle Bewölkung; erst nach genügend Kondensation Regen/Schnee. In den Bergen Luv/Lee und die Frontbewegung vergleichen.

### Fürs Debugging

Wenn das Radar Fronten zeigt, der Himmel aber weiterhin leer bleibt, bitte einen Screenshot mit R-Radar und einen Screenshot mit Blick zum Front-Horizont schicken und im O-Menü prüfen, ob **Wolken an Fronten** aktiv ist. Zusätzlich gern Java-Fehlerausgabe oder Screenshot der Wolken-Diagnose teilen. Diese Version ist nicht als garantiert fehlerfrei bezeichnet.
