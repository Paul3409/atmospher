# Meteo V1.7.4 – Fronten, Horizonte, Radar, Gebirge

**Minecraft Java 1.21.1 · Fabric · Java 21 · vollständiges Gradle-Quellprojekt**

Diese Version setzt auf V1.7.3 auf. Sie ersetzt V1.7.3; bitte keinesfalls beide Meteo-JARs gleichzeitig installieren.

## Wichtige Korrekturen

1. **Radarfronten sind echte Kurven:** Die früheren teils kreuzenden, abgerissenen Pixellinien aus einzelnen Raster-Maxima werden nicht mehr benutzt. Warm-/Kalt-/Okklusionsfronten haben zusammenhängende, serverseitig berechnete Verläufe. Genau diese Geometrie erzeugt auch den Front-Hebungsfaktor des Weltwetters.
2. **Frontwolken am noch ungeladenen Horizont:** Die Front selbst kann dünne, hoch gelegene Eiswolken sichtbar machen, bevor gewöhnliche, gespeicherte Wolkenzellen in der Ferne existieren. Diese Fernwolkenschleier sind rein visuell; sie lösen keine erfundenen Regen- oder Schneequellen aus. In geladenen Chunks können aktive Fronten zusätzlich dichtere, dunkle Wolken bilden.
3. **Aktive Wolkenbildung:** Frontaler Aufstieg und reale Wasserdampfkondensation sind weiterhin physikalisch gekoppelt, Frontkern-Wolkenbedeckung ist aber früher sichtbar. Der Test simuliert die wirkliche `CloudEffects`-Aktualisierung über 600 Ticks bei einer aktiven feuchten Front.
4. **Berge:** Vorhandene Gelände-Routenprüfung (Hebung / seitliches Abdriften / Staubewölkung) bleibt. Zusätzliche hohe Fernwolken liegen über der normalen Bauhöhe und lösen keine Chunk-Generierung aus; dunkle frontale Fernwolken werden nur über bereits geladenem und untersuchtem Gelände platziert.
5. **Prognose +3/+6/+9 h:** Druck, Frontlinien und eingefärbtes **Niederschlagspotenzial** aus dem zukünftigen synoptischen Frontfeld. **Keine exakte Niederschlagsvorhersage:** Eine deterministische Zukunftssimulation jeder realen Wolkenwasserzelle existiert derzeit nicht. Gemessene Regen-/Schneeechos in +0 h beruhen weiterhin auf den echten aktiven Niederschlagszellen.
6. **Netzwerk:** Ein Wolkenpaket hatte bisher eine harte 384-Objekt-Grenze, obwohl der Server bis zu 416 Objekte erzeugen konnte. Die Übertragung akzeptiert jetzt 416; die laufende Auswahl wird aus Rücksicht auf schwächere GPUs auf 384 begrenzt.
7. **Druckkarte:** Leicht großräumig verbogene Isobaren mit derselben zusätzlichen physikalischen Druckkomponente auf Radar und in der Atmosphäre.

## Was nicht geändert wird

Schneeschichten und Schmelzverhalten aus V1.7.1, Jahreszeiten, Wetterstationen und ihre Archive, UI-Grundstil, vorhandene Wolkenvoxeloptik, Partikel und Einstellungen. Das persistierte Format der bestehenden Wolkenzellen bleibt kompatibel.

## Ausdrückliche Grenzen

- Eine Front auf der 1536-Block-Karte muss **nicht** unmittelbar über der Spielfigur stehen: 0 % *lokale* Bewölkung ist in Entfernung zur eigentlichen Front möglich. Hochwolken auf dem Horizont können schon vorher erkennbar sein.
- Geländewirkung ist eine gebietsweise Näherung anhand *bereits geladener* Geländeproben; eine exakte 3D-Fluid-Kollision aller transparenten Wolkenvoxel mit jedem Bergblock ist noch nicht implementiert.
- Das Prognoseradar zeigt *Potenzial* statt numerisch vorherberechneter Wasserzellen. Farben in der Zukunft dürfen nicht mit aktuellen Radar-Messungen gleichgesetzt werden.
- Echte Fabric-Loom-Kompilierung und der Spieltest in Minecraft sind **noch nicht durchgeführt**. Hier verfügbar waren Java-21-Pure-Tests sowie eine Kompilation des Haupt-Servers mit Minecraft-Testklassen. Das ist kein Ersatz für `gradle clean build` auf dem Rechner des Spielers.

## Installation / Build

1. Spielwelt sichern.
2. Diesen ZIP-Ordner vollständig entpacken, neue Eingabeaufforderung in Ordner mit `build.gradle`.
3. `TEST-V1.7.4.bat` doppelklicken oder:

    "C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace

4. Nach **BUILD SUCCESSFUL** die neu erzeugte Standard-JAR aus `build\libs` in den `mods`-Ordner, bisherige Meteo-JAR vorher entfernen. `-sources.jar` nicht installieren.

## Test in der Minecraft-Welt

- `R` öffnen, Tief und Kaltfront auf der Karte finden, Zeit +0h und +3/+6/+9h vergleichen. Kaltfront = blaue zusammenhängende Linie, Warmfront = rot, Okklusion = lila. Prognose-Echos sind ausdrücklich **Potenzial**.
- In Blickrichtung der heranziehenden Front hochgelegene Wolkenfahnen beobachten; beim weiteren Heranziehen wird die Front dunkler, **wenn** feuchte Wolkenpakete in geladenen Chunks entstehen.
- Im O-Menü prüfen: Fronten und „Wolken an Fronten“ eingeschaltet. Achtung: Lokale Werte am Haus beziehen sich nur auf den Hausstandort, nicht die gesamte Radarkarte.
- Am Berg verschiedene Windrichtungen testen. Grenzen auf extremen Hängen bitte mit Blickrichtung, Wolkenhöhe und Einstellungen dokumentieren.
- Winter testen: Schneefall, Anhäufung und Schmelztemperaturen wie in V1.7.1.

Bei **BUILD FAILED** bitte die **erste tatsächliche Fehlermeldung** kopieren – keine 200 Zeilen nachfolgende Stacktrace-Meldungen nötig.
