# Meteo Renderer P2 – Voxel Hybrid Clouds

## Was geändert wurde

Basis ist **Meteo v1.2.1**, nicht P1. Die kantigen Wolkenkörper bleiben erhalten.

- `CloudVoxelMesh.buildHybrid`: erzeugt eine transparente äußere Voxeloberfläche und einen durch eine Voxel-Erosion verkleinerten dichten Kern.
- `CloudVolumeRenderer`: zeichnet den Kern deckend mit Tiefentest und anschließend die äußeren Flächen halbtransparent, nach Kameradistanz sortiert, ohne Tiefenschreibzugriff.
- Transparenz variiert nach Lage am Rand, Wolkentyp, Abschattung und kleinräumiger Variation; Cirrus/Schichtwolken sind etwas durchscheinender.
- Unterseiten etwas aufgehellt, damit kein schwarzer Beton-Eindruck entsteht.
- Bestehende Wetter-, Bewegungs-, Schauer-, Radar- und GUI-Klassen wurden nicht verändert.

## Build (Windows CMD)

Im Ordner `Meteo-Renderer-P2`:

```
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
```

Nach erfolgreichem Build die alte Meteo-JAR im Mods-Ordner **sichern/entfernen** und die neue JAR aus `build\libs` einsetzen. Nicht beide Versionen gleichzeitig laden.

## Tests und Grenzen

- Java-Tests für die 3D-Form und die neuen zwei Wolkenschichten bestanden.
- **Der vollständige Fabric-Gradle-Build konnte hier nicht ausgeführt werden**, da in dieser Umgebung kein Gradle/Fabric-Cache vorhanden ist.
- Transparenz mit Minecraft-Shadern und Mods muss im Spiel überprüft werden. Sortierte transparente Quads können sich bei sich durchdringenden Wolken noch überlagern; P2 ist kein volumetrischer Raymarching-Renderer.
- Mögliche Performancekosten: zusätzliche Innenflächen und das Sortieren der transparenten Außenflächen pro Frame.

Bitte bei Tageslicht einmal von der Seite und einmal von unten fotografieren; zusätzlich FPS und etwaige dunkle Transparenzartefakte notieren.
