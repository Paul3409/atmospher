@echo off
setlocal
if not exist build\v141-tests mkdir build\v141-tests
javac -encoding UTF-8 -d build\v141-tests tests\v141-stubs\net\minecraft\util\math\BlockPos.java tests\v141-stubs\net\minecraft\world\Heightmap.java tests\v141-stubs\net\minecraft\server\world\ServerWorld.java tests\v141-stubs\net\minecraft\util\Identifier.java tests\v141-stubs\net\minecraft\network\RegistryByteBuf.java tests\v141-stubs\net\minecraft\network\codec\PacketCodec.java tests\v141-stubs\net\minecraft\network\packet\CustomPayload.java src\main\java\de\meteo\Thermodynamics.java src\main\java\de\meteo\RegionalPhysics.java src\main\java\de\meteo\WeatherDynamics.java src\main\java\de\meteo\AtmosphereEngine.java src\main\java\de\meteo\RainRadarPayload.java tests\de\meteo\V141StabilityTest.java
if errorlevel 1 exit /b 1
java -cp build\v141-tests de.meteo.V141StabilityTest
pause
