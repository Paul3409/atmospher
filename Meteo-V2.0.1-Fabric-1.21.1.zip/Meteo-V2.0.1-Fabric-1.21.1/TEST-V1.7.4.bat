@echo off
setlocal
cd /d "%~dp0"
echo METEO V1.7.4 - Minecraft 1.21.1 Fabric - Java 21
echo Baue vollstaendiges Gradle-Projekt...
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
if errorlevel 1 (
  echo.
  echo BUILD FAILED - bitte die ERSTE echte Fehlermeldung senden.
) else (
  echo.
  echo BUILD SUCCESSFUL - Mod-JAR liegt in build\libs
  echo Alte Meteo-JAR aus mods entfernen. NICHT die -sources.jar kopieren.
)
pause
