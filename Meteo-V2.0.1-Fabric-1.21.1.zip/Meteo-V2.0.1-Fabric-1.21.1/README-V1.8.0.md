# Meteo V1.8.0 – stabile und realistischere Wetterdarstellung

V1.8.0 bündelt die überarbeitete Wolkenphysik und Darstellung für Fabric 1.21.1.

- Wolken wachsen und zerfallen über längere Zeiträume.
- Feste Identitäten verhindern springende entfernte Frontwolken.
- Wolkenformen und Höhen wechseln mit weichen Übergängen.
- Front- und Regenwolken sind strukturierter und weniger flächig.
- Wolkenlicht, Niederschlagsstärke und Windabdrift reagieren sanfter.
- Begrenzte Partikel- und Meshbudgets bleiben für integrierte Intel-Grafik aktiv.

Vor der Installation ältere Meteo-JARs aus dem Mods-Ordner entfernen. Welten bleiben mit dem bestehenden Speicherformat kompatibel.
