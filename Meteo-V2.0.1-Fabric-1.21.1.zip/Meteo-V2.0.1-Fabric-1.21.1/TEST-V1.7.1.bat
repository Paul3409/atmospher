@echo off
setlocal
cd /d "%~dp0"
echo Meteo V1.7.1 - Fabric build
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
if errorlevel 1 (
  echo BUILD FEHLGESCHLAGEN - bitte die ersten Java-Fehler senden.
) else (
  echo BUILD SUCCESSFUL - JAR in build\libs
)
pause
