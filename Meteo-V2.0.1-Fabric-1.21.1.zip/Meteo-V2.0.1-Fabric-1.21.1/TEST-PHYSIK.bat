@echo off
setlocal
cd /d "%~dp0"
if not exist "build\physics-test" mkdir "build\physics-test"
javac -encoding UTF-8 -d "build\physics-test" "src\main\java\de\meteo\Advection.java" "src\main\java\de\meteo\Thermodynamics.java" "src\main\java\de\meteo\RegionalPhysics.java" "tests\de\meteo\PhysicsSelfTest.java"
if errorlevel 1 (echo TEST FAILED: Java-Kompilierung & pause & exit /b 1)
java -cp "build\physics-test" de.meteo.PhysicsSelfTest
if errorlevel 1 (echo TEST FAILED & pause & exit /b 1)
echo Alle Physik-Selbsttests bestanden.
pause
