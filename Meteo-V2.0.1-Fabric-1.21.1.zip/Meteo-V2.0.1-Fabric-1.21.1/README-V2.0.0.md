# Meteo V2.0.0 – neue Wolkendarstellung

Die sichtbaren Wolken werden nun als geschlossene Oberflächen aus stabilen Wetterzellen aufgebaut. Verschachtelte transparente Würfel und die Vergrößerung zusammengefasster Wolkenfelder entfallen. Cumulus, Schichtwolken, Cirrus, Nimbostratus und Gewitterwolken besitzen eigene begrenzte Formen.

Das Wettermodell, Niederschlag, Radar und gespeicherte Weltdaten bleiben kompatibel. Qualität, Sichtweite und Optimierung begrenzen die Zeichenlast auf schwächeren Geräten. Vor dem Start ältere Meteo-JARs aus dem Mods-Ordner entfernen.
