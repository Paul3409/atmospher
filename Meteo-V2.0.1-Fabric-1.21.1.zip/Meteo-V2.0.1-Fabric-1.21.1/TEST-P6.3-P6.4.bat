@echo off
setlocal
if not exist build\p63-tests mkdir build\p63-tests
javac -encoding UTF-8 -d build\p63-tests src\main\java\de\meteo\FogPhysics.java src\main\java\de\meteo\StratiformRain.java src\main\java\de\meteo\RainPhysics.java tests\de\meteo\RadarFogPhysicsTest.java
if errorlevel 1 exit /b 1
java -cp build\p63-tests de.meteo.RadarFogPhysicsTest
pause
