@echo off
setlocal
if not exist build\cloud-test mkdir build\cloud-test
javac -d build\cloud-test src\main\java\de\meteo\RegionalPhysics.java src\main\java\de\meteo\CloudPhysics.java src\test\java\de\meteo\CloudPhysicsTest.java
if errorlevel 1 (pause & exit /b 1)
java -cp build\cloud-test de.meteo.CloudPhysicsTest
pause
