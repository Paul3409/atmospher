@echo off
setlocal
if not exist build\p6-test mkdir build\p6-test
javac -encoding UTF-8 -d build\p6-test src\main\java\de\meteo\HighCloudPhysics.java src\main\java\de\meteo\StratiformRain.java src\main\java\de\meteo\CloudVolumeField.java src\main\java\de\meteo\CloudVoxelMesh.java src\main\java\de\meteo\CloudFieldPhysics.java src\main\java\de\meteo\RainPhysics.java tests\de\meteo\P6CloudLayersTest.java
if errorlevel 1 exit /b 1
java -cp build\p6-test de.meteo.P6CloudLayersTest
pause
