@echo off
setlocal
cd /d "%~dp0"
if not exist "build\weather-test" mkdir "build\weather-test"
javac -encoding UTF-8 -d "build\weather-test" ^
 "src\main\java\de\meteo\Advection.java" ^
 "src\main\java\de\meteo\Thermodynamics.java" ^
 "src\main\java\de\meteo\RegionalPhysics.java" ^
 "src\main\java\de\meteo\CloudPhysics.java" ^
 "src\main\java\de\meteo\CloudFieldPhysics.java" ^
 "src\main\java\de\meteo\MoisturePhysics.java" ^
 "src\main\java\de\meteo\CloudMotion.java" ^
 "src\main\java\de\meteo\CloudLife.java" ^
 "src\main\java\de\meteo\RainPhysics.java" ^
 "src\main\java\de\meteo\CloudVolumeField.java" ^
 "src\main\java\de\meteo\CloudVoxelMesh.java" ^
 "tests\de\meteo\Meteo120Test.java" ^
 "tests\de\meteo\Meteo121Test.java"
if errorlevel 1 (echo FEHLER: Kompilierung & pause & exit /b 1)
java -cp "build\weather-test" de.meteo.Meteo120Test
if errorlevel 1 (echo FEHLER: v1.2-Test & pause & exit /b 1)
java -cp "build\weather-test" de.meteo.Meteo121Test
if errorlevel 1 (echo FEHLER: v1.2.1-Test & pause & exit /b 1)
echo ALLE TESTS BESTANDEN
pause
