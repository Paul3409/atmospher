@echo off
setlocal
cd /d "%~dp0"
echo METEO V1.7.2 - Fabric 1.21.1 - Java 21
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
if errorlevel 1 (
 echo BUILD FEHLGESCHLAGEN - bitte die ersten echten Fehler aus der Ausgabe senden.
) else (
 echo BUILD SUCCESSFUL - die Haupt-JAR liegt in build\libs
)
pause
