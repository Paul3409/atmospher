@echo off
setlocal
cd /d "%~dp0"
if not exist "build\p4-test" mkdir "build\p4-test"
javac -encoding UTF-8 -d "build\p4-test" "src\main\java\de\meteo\CloudLife.java" "src\main\java\de\meteo\CloudStability.java" "tests\de\meteo\CloudStabilityP4Test.java"
if errorlevel 1 (echo FEHLER: Javac & pause & exit /b 1)
java -cp "build\p4-test" de.meteo.CloudStabilityP4Test
if errorlevel 1 (echo FEHLER: P4-Test & pause & exit /b 1)
echo P4-Test erfolgreich.
pause
