@echo off
setlocal
if not exist build\v150-tests mkdir build\v150-tests
javac -encoding UTF-8 -d build\v150-tests tests\v141-stubs\net\minecraft\util\Identifier.java tests\v141-stubs\net\minecraft\network\RegistryByteBuf.java tests\v141-stubs\net\minecraft\network\codec\PacketCodec.java tests\v141-stubs\net\minecraft\network\packet\CustomPayload.java src\main\java\de\meteo\RegionalPhysics.java src\main\java\de\meteo\WeatherDynamics.java src\main\java\de\meteo\WeatherSettingsPayload.java tests\de\meteo\V150DynamicsTest.java tests\de\meteo\V150NetworkTest.java
if errorlevel 1 exit /b 1
java -cp build\v150-tests de.meteo.V150DynamicsTest
if errorlevel 1 exit /b 1
java -cp build\v150-tests de.meteo.V150NetworkTest
if errorlevel 1 exit /b 1
call TEST-V1.4.1.bat
