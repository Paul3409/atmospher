# Meteo V1.7.2 – Synoptik, Frontwolken und Berge

Fabric 1.21.1 / Java 21 / Gradle. Vollständiges Mod-Quellprojekt.

## Korrekturen

- **Wetterkarte und lokale Atmosphäre**: Druckgebiete, frontal bedingte Temperaturänderungen und großräumige Windkomponenten fließen nun auch in die atmosphärischen Messwerte ein. Die Karte stellt den Druck auf dem Modell-Referenzniveau dar; Höhen- und Bergstationen zeigen den davon abweichenden lokalen Luftdruck.
- **Frontaufzug**: Ein Frontgebiet wird am selben Koordinaten-/Simulationszeitfeld wie das Radar erkannt. Ein zeitlich vorausberechneter Frontwert ermöglicht bei ausreichender Luftfeuchtigkeit zunächst dünne hohe Wolken. Im aktivierten Frontbereich verstärken Hebung und Abkühlung die Kondensation des existierenden Wolkenwassers. Dunkle Frontwolken entstehen bei genügend sichtbarer Kondensation; die Niederschlagsrate stammt weiterhin aus dem Cloud-Water-Modell.
- **Bergbewegung**: Tiefe Wolken prüfen ihr Terrain auf dem nächsten Bewegungsschritt: Überströmen bei ausreichender Hebung, seitliches Ablenken entlang einer tieferen Flanke oder Verharren auf der Luvseite. Es werden keine Chunks für diese Routenprüfung geladen. Größere Wolken erhalten eine zusätzliche konservative Höhenfreigabe für nahe geladene Bergkämme.
- **Wetterkarte ↔ Niederschlag**: Quellen ohne hinreichendes Wolkenwasser und Wolkendeckung erzeugen keine neuen Radarreflexionen bzw. sichtbaren Regen-/Schneefall. Alle lokalen Quellen benutzen dieselbe Niederschlagsprüfung. Kurze Nachläufe der Regenrate werden stärker gedämpft, wenn eine Wolke verdunstet.
- **Fernansicht**: Von 320 Hauptwolkenplätzen sind bis zu 95 gezielt für ankommende Frontwolken reserviert, damit der Frontbereich am Horizont nicht durch zahllose nahe Wolken verdrängt wird.
- **Leistung**: Die synoptischen Wetterfeldabfragen sind mit einem begrenzten 32-Block-/120-Simulationssekunden-Cache versehen. Kartenprognosen benutzen weiterhin ihr eigenes direktes Raster. Keine zusätzliche dauerhafte Chunkbelastung.

## Unverändert

- Grundformen und Renderstil der Cumulus-, Stratocumulus-, Cirrus-, Cb- und Nimbostratuswolken.
- Persönliche Grafik- und Snow-Cover-Einstellungen; Schnee-Schichten im Weltordner.
- Vorhandene Stationen, Archivformat, normale Regen- und Schneeflocken, keine Meteo-eigenen Sounds.

## Hinweise

Dies ist ein **vereinfachtes Minecraft-Wettermodell**. Eine wetterphysikalische 1:1-Reproduktion echter Fronten und lückenlose Kollision aller halbtransparenten Wolkenoberflächen mit jedem Block sind nicht möglich. Die neue Höhenprüfung ist eine Vorsichtsmaßnahme für niedrige Wolken in **geladenen Gebieten**, kein fluiddynamischer 3D-Gebirgssimulator. Die +3/+6/+9-h-Radarvorschau bleibt ausdrücklich eine Vorhersage von Druck und Fronten, nicht der Niederschlagszellen.

**Welt vor dem Update sichern.** Ohne Fabric-Bibliotheken war hier kein vollständiger Minecraft-Build möglich. Für den nächsten Schritt bitte das Windows-Gradle-Kommando ausführen und bei Fehlern die *ersten* Kompilier-/Startfehler senden.
