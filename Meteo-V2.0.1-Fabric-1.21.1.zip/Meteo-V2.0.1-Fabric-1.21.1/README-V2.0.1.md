# Meteo V2.0.1 – Wolkenoberflächen-Korrektur

Die neue V2-Wolkendarstellung erhält begrenzte Höhenunterschiede zwischen benachbarten Cloudlets. Dadurch entstehen keine senkrechten dunklen Wände und keine kilometerhohen Platten mehr. Gewitterwolken behalten ihre größeren Türme.
