import dev.atmosphere.AtmosphereSettings;
import java.nio.file.*;
import java.util.Properties;
import java.io.*;
import java.lang.reflect.Method;

public final class FogSettingsTest {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
  Path folder=Files.createTempDirectory("atmosphere-fog-test-");
  System.setProperty("atmosphere.test.config",folder.toString());
  var s=AtmosphereSettings.get();ck(s.atmosphericFog&&s.fogStrength==100,"Missing default/migration");
  Method load=AtmosphereSettings.class.getDeclaredMethod("load");load.setAccessible(true);
  ck(!s.cloudFocus,"Legacy settings unexpectedly enable isolated view");
  for(boolean focus:new boolean[]{true,false}){
   s.cloudFocus=focus;s.save();
   ck(((AtmosphereSettings)load.invoke(null)).cloudFocus==focus,"Cloud view preference round-trip");
  }
  for(int value:new int[]{0,1,50,100,150,200})for(boolean enabled:new boolean[]{false,true}){
   s.fogStrength=value;s.atmosphericFog=enabled;s.save();
   var restored=(AtmosphereSettings)load.invoke(null);
   ck(restored.fogStrength==value&&restored.atmosphericFog==enabled,"Fog preference round-trip");
  }
  for(String input:new String[]{"-20","500","oops"}){
   Properties p=new Properties();p.setProperty("fogStrength",input);
   try(var out=Files.newOutputStream(folder.resolve("atmosphere.properties"))){p.store(out,"test");}
   var restored=(AtmosphereSettings)load.invoke(null);
   int expected=input.equals("oops")?100:input.equals("500")?200:0;
   ck(restored.fogStrength==expected,"Fog preference not clamped/defaulted");
  }
  System.out.println("PASS: actual settings fog migration, switch/gain round-trip and invalid value bounds (loader test double)");
 }
}
