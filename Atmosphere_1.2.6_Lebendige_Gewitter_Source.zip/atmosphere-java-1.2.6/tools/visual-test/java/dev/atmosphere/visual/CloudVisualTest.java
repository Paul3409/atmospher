package dev.atmosphere.visual;

import dev.atmosphere.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.client.gui.screen.TitleScreen;

/** Development fixture using only checked Yarn 1.21.1 entry points. */
public final class CloudVisualTest implements ClientModInitializer {
    private int tick;
    private int bootTicks;
    private boolean startRequested;
    @Override public void onInitializeClient(){
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            bootTicks++;
            if(client.world==null||client.player==null||client.getServer()==null){
                if(bootTicks%100==0)System.out.println("ATMOSPHERE_VISUAL bootstrap screen="+
                        (client.currentScreen==null?"none":client.currentScreen.getClass().getName()));
                if(!startRequested&&client.isFinishedLoading()&&client.getOverlay()==null
                        &&client.currentScreen instanceof TitleScreen){
                    startRequested=true;
                    System.out.println("ATMOSPHERE_VISUAL opening isolated CloudPreview directly");
                    client.createIntegratedServerLoader().start("CloudPreview",client::scheduleStop);
                }
                if(bootTicks==1200){
                    ScreenshotRecorder.saveScreenshot(client.runDirectory,"00-bootstrap.png",client.getFramebuffer(),
                            text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
                }
                if(bootTicks>1400)client.scheduleStop();
                return;
            }
            tick++;var s=AtmosphereSettings.get();
            if(tick==1){
                s.cloudFocus=true;s.customClouds=true;s.adaptiveGraphics=false;s.cloudDetail=2;s.quality=2;
                s.particles=false;s.weatherSounds=false;s.hud=false;s.atmosphericFog=false;s.weatherSpeed=1;
                s.visualLightning=false;s.cloudShadows=false;s.tornadoChance=4;
                StormEvents.spawnTest(client.getServer(),0,0);
                client.options.hudHidden=true;
                client.getNetworkHandler().sendChatCommand("gamemode spectator");
                client.getNetworkHandler().sendChatCommand("tp @s 880 420 660 127 5");
                System.out.println("ATMOSPHERE_VISUAL world ready");
            }
            if(tick==600)ScreenshotRecorder.saveScreenshot(client.runDirectory,"01-outside-focus.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==620)client.getNetworkHandler().sendChatCommand("tp @s 260 85 170 130 -8");
            if(tick==780)ScreenshotRecorder.saveScreenshot(client.runDirectory,"02-below-focus.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==800){s.cloudFocus=false;client.getNetworkHandler().sendChatCommand("tp @s 880 420 660 127 5");}
            if(tick==960)ScreenshotRecorder.saveScreenshot(client.runDirectory,"03-outside-scene.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==1000){
                StormEvents.clear(client.getServer());s.cloudFocus=false;s.stormFrequency=0;
                StormEvents.spawn(client.getServer(),WeatherCells.THUNDER,0,0);
                client.getNetworkHandler().sendChatCommand("tp @s 650 300 550 130 5");
            }
            if(tick==1700)ScreenshotRecorder.saveScreenshot(client.runDirectory,"04-ordinary-cell.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==1800)client.scheduleStop();
        });
    }
}
