package dev.atmosphere.visual;

import dev.atmosphere.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.client.gui.screen.TitleScreen;

/** Development fixture using only checked Yarn 1.21.1 entry points. */
public final class CloudVisualTest implements ClientModInitializer {
    private int tick;
    private int bootTicks;
    private boolean startRequested;
    private static void nearHook(net.minecraft.client.MinecraftClient client){
        var e=StormEvents.current();if(e==null)return;
        long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());double a=StormEvolution.manualAngle(seed);
        double x=e.x()+(.05*Math.cos(a)+.35*Math.sin(a))*e.radius();
        double z=e.z()+(.05*Math.sin(a)-.35*Math.cos(a))*e.radius();
        client.getNetworkHandler().sendChatCommand("tp @s "+(x+130)+" 85 "+(z+130)+" 135 -12");
    }
    private static void tailSide(net.minecraft.client.MinecraftClient client){
        var e=StormEvents.current();if(e==null)return;
        long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());double a=StormEvolution.manualAngle(seed);
        double wx=Math.cos(a),wz=Math.sin(a);
        double rootX=e.x()+(.05*wx+.35*wz)*e.radius(),rootZ=e.z()+(.05*wz-.35*wx)*e.radius();
        double tx=-.28*wx-wz,tz=-.28*wz+wx,n=Math.hypot(tx,tz);tx/=n;tz/=n;
        double targetX=rootX+tx*110,targetZ=rootZ+tz*110;
        double x=targetX+tz*500,z=targetZ-tx*500;
        double yaw=Math.toDegrees(Math.atan2(-(targetX-x),targetZ-z));
        client.getNetworkHandler().sendChatCommand("tp @s "+x+" 90 "+z+" "+yaw+" -8");
    }
    @Override public void onInitializeClient(){
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            bootTicks++;
            if(client.world==null||client.player==null||client.getServer()==null){
                if(bootTicks%100==0)System.out.println("ATMOSPHERE_VISUAL bootstrap screen="+
                        (client.currentScreen==null?"none":client.currentScreen.getClass().getName()));
                if(!startRequested&&client.isFinishedLoading()&&client.getOverlay()==null
                        &&client.currentScreen instanceof TitleScreen){
                    startRequested=true;
                    System.out.println("ATMOSPHERE_VISUAL opening isolated CloudPreview directly");
                    client.createIntegratedServerLoader().start("CloudPreview",client::scheduleStop);
                }
                if(bootTicks==1200){
                    ScreenshotRecorder.saveScreenshot(client.runDirectory,"00-bootstrap.png",client.getFramebuffer(),
                            text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
                }
                if(bootTicks>1400)client.scheduleStop();
                return;
            }
            tick++;var s=AtmosphereSettings.get();
            if(tick==1){
                s.cloudFocus=true;s.customClouds=true;s.adaptiveGraphics=false;s.cloudDetail=2;s.quality=2;
                s.particles=false;s.weatherSounds=false;s.hud=false;s.atmosphericFog=false;s.weatherSpeed=1;
                s.visualLightning=false;s.cloudShadows=false;s.tornadoChance=0;
                StormEvents.spawnTest(client.getServer(),0,0);
                client.options.hudHidden=true;
                client.getNetworkHandler().sendChatCommand("gamemode spectator");
                client.getNetworkHandler().sendChatCommand("tp @s 880 420 660 127 5");
                System.out.println("ATMOSPHERE_VISUAL world ready");
            }
            if(tick==220)nearHook(client);
            if(tick==300)ScreenshotRecorder.saveScreenshot(client.runDirectory,"05-funnel.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==480){
                var e=StormEvents.current();long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());
                double phase=e.phase(client.world.getTimeOfDay(),s);
                double activity=StormEvolution.tornadoActivity(seed,WeatherCells.lifecycle(phase),phase,StormEvents.chanceFor(seed,s.tornadoCode()));
                if(activity<.99)throw new IllegalStateException("Test tornado did not reach ground-contact phase: "+activity);
                System.out.println("ATMOSPHERE_VISUAL guaranteed tornado activity="+activity+" at phase="+phase);
                ScreenshotRecorder.saveScreenshot(client.runDirectory,"06-ground-contact.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            }
            if(tick==500)client.getNetworkHandler().sendChatCommand("tp @s 880 420 660 127 5");
            if(tick==600)ScreenshotRecorder.saveScreenshot(client.runDirectory,"01-outside-focus.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==620)nearHook(client);
            if(tick==780)ScreenshotRecorder.saveScreenshot(client.runDirectory,"02-below-focus.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==800){s.cloudFocus=false;client.getNetworkHandler().sendChatCommand("tp @s 880 420 660 127 5");}
            if(tick==960)ScreenshotRecorder.saveScreenshot(client.runDirectory,"03-outside-scene.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==980)tailSide(client);
            if(tick==1060||tick==1080)ScreenshotRecorder.saveScreenshot(client.runDirectory,"07-tail-side-"+tick+".png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==1150){
                StormEvents.clear(client.getServer());s.cloudFocus=false;s.stormFrequency=0;
                StormEvents.spawn(client.getServer(),WeatherCells.THUNDER,0,0);
                client.getNetworkHandler().sendChatCommand("tp @s 650 300 550 130 5");
            }
            if(tick==1850)ScreenshotRecorder.saveScreenshot(client.runDirectory,"04-ordinary-cell.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==1950)client.scheduleStop();
        });
    }
}
