#version 150
uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float CloudFogStart;
uniform float TextureMask;
uniform float CloudFogEnd;
uniform vec4 FogColor;
in vec4 vertexColor;
in vec2 texCoord0;
in float vertexDistance;
out vec4 fragColor;
// Mature supercells are opaque. Thin/fading background hulls use sorted alpha,
// with back-face culling and depth writes instead of stippled screen-door holes.
void main() {
    float coverage = clamp(vertexColor.a * ColorModulator.a, 0.0, 1.0)
            * mix(1.0, texture(Sampler0, texCoord0).a, TextureMask);
    if (coverage < 0.01) discard;
    vec3 tint = vertexColor.rgb * ColorModulator.rgb;
    tint *= 0.96 + 0.04 * texture(Sampler0, texCoord0).r;
    float fog = smoothstep(CloudFogStart, max(CloudFogStart + 0.001, CloudFogEnd), vertexDistance);
    fragColor = vec4(mix(tint, FogColor.rgb, fog), coverage);
}
