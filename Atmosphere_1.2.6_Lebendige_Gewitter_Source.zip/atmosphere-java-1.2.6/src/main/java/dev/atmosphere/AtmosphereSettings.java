package dev.atmosphere;

import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;

/** Global preferences shared in an integrated Minecraft instance (not network-synchronised). */
public final class AtmosphereSettings {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("atmosphere.properties");
    private static final AtmosphereSettings INSTANCE = load();
    public static AtmosphereSettings get() { return INSTANCE; }

    public boolean hud = true;
    public boolean particles = true;
    public boolean seasonalColors = true;
    public boolean snowAccumulation = true;
    public boolean leafFall = false; // experimental / OFF by default to protect builds
    public boolean replaceVanillaRain = true;
    public boolean forecast = true;
    public boolean customClouds = true;
    public boolean atmosphericFog = true;
    public int fogStrength = 100; // Weather fog multiplier, 0..200 percent
    public boolean sunsetLighting = true;
    /** 1.1.5: purely optical rainbow when sun and rain overlap. */
    public boolean rainbow = true;
    public int radarRange = 1; // 0=500, 1=1500, 2=3000 blocks
    public int seasonOffset = 0;
    public int mode = 0; // auto, dry, manual precipitation
    public int precipitationMmH = 15; // 0..150, directly editable in menu
    public int precipitationType = 0; // 0 automatic, 1 rain, 2 snow, 3 graupel, 4 hail
    public boolean cloudShadows = true;
    public int temperatureOffset = 0;
    public int quality = 1; // 0 Leicht, 1 Ausgewogen, 2 Hoch, 3 Ultra
    public int cloudDetail = -1; // -1 follows the overall graphics preset
    public boolean cloudFocus = false; // Visual single-supercell comparison only
    public int weatherSpeed = 1; // Weather systems, not the Minecraft day-night cycle
    public boolean weatherSounds = true;
    public boolean visualLightning = true;
    public int lightningFrequency = 2; // 0=Selten,1=Normal,2=Haeufig,3=Extrem
    public int tornadoPercent=25;
    public int tornadoCode(){return tornadoChance==5?1000+tornadoPercent:tornadoChance;}
    public int tornadoChance = 1; // 0=Aus, 1=Selten, 2=Normal, 3=Haeufig, 4=Immer, 5=Prozent
    public boolean windGusts = true;
    // Weather Revolution: kilometres per hour, not percentage.
    public boolean manualWind = false;
    public int windKmh = 35, gustKmh = 80, windDirectionDegrees = 270;
    public int stormFrequency = 100, stormStrength = 100;
    public int weatherExperience = 2; // 0=natural, 2=balanced, 4=cinematic
    // 1.1.4: 100% preserves the pressure response of 1.1.3.
    public int highPressureStrength = 100, lowPressureStrength = 100; // 0..200 %
    public int pressureLifetime = 1; // 0=shorter, 1=normal, 2=longer
    public int lightningBrightness = 100, lightningSize = 100; // 25..200 %
    public int thunderVolume = 100; // 0..200 %
    public int windAmbientVolume = 40; // 0..100%, includes gentle breeze
    public int tornadoVolume = 70; // 0..100%, dedicated spatial roar
    public int radarResolution = 1; // 0=schnell, 1=ausgewogen, 2=hoch
    public boolean radarIsobars = false, adaptiveGraphics = true;
    // 1.0: Adjustable budgets without touching naturally occurring snow.
    public int snowRadius = 160; // loaded chunks only, 64..224 blocks
    public int snowGrowth = 4, snowMelt = 4; // 1..5


    private static AtmosphereSettings load() {
        AtmosphereSettings s = new AtmosphereSettings();
        if (!Files.isRegularFile(FILE)) return s;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            s.hud = Boolean.parseBoolean(p.getProperty("hud", "true"));
            s.particles = Boolean.parseBoolean(p.getProperty("particles", "true"));
            s.seasonalColors = Boolean.parseBoolean(p.getProperty("seasonalColors", "true"));
            s.snowAccumulation = Boolean.parseBoolean(p.getProperty("snowAccumulation", "true"));
            s.leafFall = false; // No block damage, even if an older config enabled it
            s.replaceVanillaRain = Boolean.parseBoolean(p.getProperty("replaceVanillaRain", "true"));
            s.customClouds = Boolean.parseBoolean(p.getProperty("customClouds", "true"));
            s.atmosphericFog = Boolean.parseBoolean(p.getProperty("atmosphericFog", "true"));
            s.fogStrength = clamp(parse(p.getProperty("fogStrength"),100),0,200);
            s.sunsetLighting = Boolean.parseBoolean(p.getProperty("sunsetLighting", "true"));
            s.rainbow = Boolean.parseBoolean(p.getProperty("rainbow", "true"));
            s.radarRange = clamp(parse(p.getProperty("radarRange"), 1), 0, 2);
            s.seasonOffset = clamp(parse(p.getProperty("seasonOffset"), 0), 0, 3);
            s.mode = clamp(parse(p.getProperty("mode"), 0), 0, 2);
            int legacyIndex = clamp(parse(p.getProperty("rateIndex"), 4), 0, WeatherModel.RATES.length - 1);
            s.precipitationMmH = clamp(parse(p.getProperty("precipitationMmH"), WeatherModel.RATES[legacyIndex]), 0, 150);
            s.precipitationType = clamp(parse(p.getProperty("precipitationType"), 0), 0, 4);
            s.cloudShadows = Boolean.parseBoolean(p.getProperty("cloudShadows", "true"));
            s.temperatureOffset = clamp(parse(p.getProperty("temperatureOffset"), 0), -40, 40);
            s.quality = clamp(parse(p.getProperty("quality"), 1), 0, 3);
            s.cloudDetail = clamp(parse(p.getProperty("cloudDetail"), -1), -1, 3);
            s.cloudFocus = Boolean.parseBoolean(p.getProperty("cloudFocus","false"));
            int speed = parse(p.getProperty("weatherSpeed"), 1);
            s.weatherSpeed = (speed == 2 || speed == 5 || speed == 10 || speed == 20) ? speed : 1;
            s.weatherSounds = Boolean.parseBoolean(p.getProperty("weatherSounds", "true"));
            s.visualLightning = Boolean.parseBoolean(p.getProperty("visualLightning", "true"));
            s.lightningFrequency = clamp(parse(p.getProperty("lightningFrequency"),2),0,3);
            s.tornadoChance = clamp(parse(p.getProperty("tornadoChance"),1),0,5);
            s.tornadoPercent=clamp(parse(p.getProperty("tornadoPercent"),25),0,100);
            s.windGusts = Boolean.parseBoolean(p.getProperty("windGusts", "true"));
            s.manualWind = Boolean.parseBoolean(p.getProperty("manualWind", "false"));
            s.windKmh = clamp(parse(p.getProperty("windKmh"),35),0,150);
            s.gustKmh = clamp(parse(p.getProperty("gustKmh"),80),s.windKmh,200);
            s.windDirectionDegrees = clamp(parse(p.getProperty("windDirectionDegrees"),270),0,359);
            s.stormFrequency = clamp(parse(p.getProperty("stormFrequency"),100),0,200);
            s.stormStrength = clamp(parse(p.getProperty("stormStrength"),100),0,200);
            s.weatherExperience = clamp(parse(p.getProperty("weatherExperience"),2),0,4);
            s.highPressureStrength = clamp(parse(p.getProperty("highPressureStrength"),100),0,200);
            s.lowPressureStrength = clamp(parse(p.getProperty("lowPressureStrength"),100),0,200);
            s.pressureLifetime = clamp(parse(p.getProperty("pressureLifetime"),1),0,2);
            s.lightningBrightness = clamp(parse(p.getProperty("lightningBrightness"),100),25,200);
            s.lightningSize = clamp(parse(p.getProperty("lightningSize"),100),25,200);
            s.thunderVolume = clamp(parse(p.getProperty("thunderVolume"),100),0,200);
            s.windAmbientVolume = clamp(parse(p.getProperty("windAmbientVolume"),40),0,100);
            s.tornadoVolume = clamp(parse(p.getProperty("tornadoVolume"),70),0,100);
            s.radarResolution = clamp(parse(p.getProperty("radarResolution"),1),0,2);
            s.radarIsobars = Boolean.parseBoolean(p.getProperty("radarIsobars","false"));
            s.adaptiveGraphics = Boolean.parseBoolean(p.getProperty("adaptiveGraphics","true"));
            s.snowRadius = clamp(parse(p.getProperty("snowRadius"),160),64,224);
            s.snowGrowth = clamp(parse(p.getProperty("snowGrowth"),4),1,5);
            s.snowMelt = clamp(parse(p.getProperty("snowMelt"),4),1,5);
        } catch (IOException | IllegalArgumentException ex) { System.err.println("[Atmosphere] Unable to load settings: " + ex); }
        return s;
    }

    public synchronized void save() {
        Properties p = new Properties();
        p.setProperty("hud", Boolean.toString(hud));
        p.setProperty("particles", Boolean.toString(particles));
        p.setProperty("seasonalColors", Boolean.toString(seasonalColors));
        p.setProperty("snowAccumulation", Boolean.toString(snowAccumulation));
        p.setProperty("leafFall", Boolean.toString(leafFall));
        p.setProperty("replaceVanillaRain", Boolean.toString(replaceVanillaRain));
        p.setProperty("customClouds", Boolean.toString(customClouds));
        p.setProperty("atmosphericFog", Boolean.toString(atmosphericFog));
        p.setProperty("fogStrength", Integer.toString(fogStrength));
        p.setProperty("sunsetLighting", Boolean.toString(sunsetLighting));
        p.setProperty("rainbow", Boolean.toString(rainbow));
        p.setProperty("radarRange", Integer.toString(radarRange));
        p.setProperty("seasonOffset", Integer.toString(seasonOffset));
        p.setProperty("mode", Integer.toString(mode));
        p.setProperty("precipitationMmH", Integer.toString(precipitationMmH));
        p.setProperty("precipitationType", Integer.toString(precipitationType));
        p.setProperty("cloudShadows", Boolean.toString(cloudShadows));
        p.setProperty("temperatureOffset", Integer.toString(temperatureOffset));
        p.setProperty("quality", Integer.toString(quality));
        p.setProperty("cloudDetail", Integer.toString(cloudDetail));
        p.setProperty("cloudFocus", Boolean.toString(cloudFocus));
        p.setProperty("weatherSpeed", Integer.toString(weatherSpeed));
        p.setProperty("weatherSounds", Boolean.toString(weatherSounds));
        p.setProperty("visualLightning", Boolean.toString(visualLightning));
        p.setProperty("lightningFrequency",Integer.toString(lightningFrequency));
        p.setProperty("tornadoChance",Integer.toString(tornadoChance));
        p.setProperty("tornadoPercent",Integer.toString(tornadoPercent));
        p.setProperty("windGusts", Boolean.toString(windGusts));
        p.setProperty("manualWind", Boolean.toString(manualWind));
        p.setProperty("windKmh", Integer.toString(windKmh));
        p.setProperty("gustKmh", Integer.toString(gustKmh));
        p.setProperty("windDirectionDegrees", Integer.toString(windDirectionDegrees));
        p.setProperty("stormFrequency", Integer.toString(stormFrequency));
        p.setProperty("stormStrength", Integer.toString(stormStrength));
        p.setProperty("weatherExperience",Integer.toString(weatherExperience));
        p.setProperty("highPressureStrength", Integer.toString(highPressureStrength));
        p.setProperty("lowPressureStrength", Integer.toString(lowPressureStrength));
        p.setProperty("pressureLifetime", Integer.toString(pressureLifetime));
        p.setProperty("lightningBrightness", Integer.toString(lightningBrightness));
        p.setProperty("lightningSize", Integer.toString(lightningSize));
        p.setProperty("thunderVolume", Integer.toString(thunderVolume));
        p.setProperty("windAmbientVolume", Integer.toString(windAmbientVolume));
        p.setProperty("tornadoVolume",Integer.toString(tornadoVolume));
        p.setProperty("radarResolution", Integer.toString(radarResolution));
        p.setProperty("radarIsobars", Boolean.toString(radarIsobars));
        p.setProperty("adaptiveGraphics", Boolean.toString(adaptiveGraphics));
        p.setProperty("snowRadius", Integer.toString(snowRadius));
        p.setProperty("snowGrowth", Integer.toString(snowGrowth));
        p.setProperty("snowMelt", Integer.toString(snowMelt));
        try {
            SettingsStorage.write(FILE,p,"Atmosphere 1.2.6 preferences");
        } catch (IOException ex) { System.err.println("[Atmosphere] Unable to save settings: " + ex); }
    }
    private static int parse(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (NumberFormatException ex) { return fallback; }
    }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
}
