package dev.atmosphere;

import java.util.ArrayList;
import java.util.List;

/** Storm-relative, deterministic advection; never camera-facing or random per frame. */
public final class StormAttachments {
    private StormAttachments(){}
    public record Puff(double along,double across,double y,double width,double height,double depth,double alpha,long seed){}
    public static List<Puff> tail(long seed,double radius,double growth,double ticks){
        var out=new ArrayList<Puff>();double strength=WeatherCells.smooth(.42,.78,growth);
        if(strength<.01)return out;
        double length=radius*(1.00+.45*WeatherCells.hash(seed,0,1811));
        double cycle=220+100*WeatherCells.hash(seed,1,1811);
        for(int i=0;i<24;i++){
            double age=ticks/cycle+i/24.0;age-=Math.floor(age);
            double s=1-age;
            double envelope=WeatherCells.smooth(0,.13,age)*(1-WeatherCells.smooth(.88,1,age));
            double w=radius*(.035+.020*WeatherCells.hash(seed,i,1812))*(1+.4*age);
            out.add(new Puff(.05*radius-.28*length*s,-.35*radius+length*s,
                    -SupercellGeometry.lowering(growth)+12-22*s+3*Math.sin(s*8+seed%17),
                    w,4+5*age,w*.70,220*strength*envelope,seed^i*1337L));
        }
        return out;
    }
    public static List<Puff> scud(long seed,double radius,double growth,double ticks){
        var out=new ArrayList<Puff>();double strength=WeatherCells.smooth(.30,.70,growth);
        if(strength<.01)return out;
        for(int i=0;i<12;i++){
            double duration=170+160*WeatherCells.hash(seed,i,1821);
            double clock=ticks/duration+WeatherCells.hash(seed,i,1822),age=clock-Math.floor(clock);
            long life=seed^((long)Math.floor(clock)*100003+i*7919L);
            double a=WeatherCells.hash(life,i,1823)*Math.PI*2;
            double d=radius*(.24+.62*WeatherCells.hash(life,i,1824));
            boolean inflow=i%3!=0;double travel=inflow?1-.42*age:1+.20*age;
            double size=9+15*WeatherCells.hash(life,i,1825);
            double fade=WeatherCells.smooth(0,.18,age)*(1-WeatherCells.smooth(.72,1,age));
            out.add(new Puff(Math.cos(a)*d*travel,Math.sin(a)*d*travel,
                    -32-26*WeatherCells.hash(life,i,1826)+age*(inflow?42:12),
                    size,4+size*.20,size*(.45+.4*WeatherCells.hash(life,i,1827)),
                    185*strength*fade,life));
        }
        return out;
    }
    /** Under-cloud self-shadow, with a broad transition instead of black flat caps. */
    public static double underside(double ny){return .62+.38*WeatherCells.smooth(-.55,.35,ny);}
}
