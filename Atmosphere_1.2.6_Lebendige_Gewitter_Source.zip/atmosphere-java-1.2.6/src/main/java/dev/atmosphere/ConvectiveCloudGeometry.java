package dev.atmosphere;

/** One capped, billowing surface for non-supercell convection, including its anvil. */
public final class ConvectiveCloudGeometry {
    private ConvectiveCloudGeometry(){}
    private static double[] pos(long seed,double t,double a,double radius,double base,double height,
                                double wx,double wz,double growth,double phase,int type){
        double mature=type==WeatherCells.SHOWER?0:WeatherCells.smooth(.45,.88,growth)*WeatherCells.smooth(.16,.40,phase);
        double remnant=WeatherCells.smooth(.65,.78,phase)*(1-WeatherCells.smooth(.90,.99,phase));
        double spread=Math.max(mature,remnant*.85);
        double variant=WeatherCells.hash(seed,0,1801);
        double r=(.31+.27*Math.exp(-Math.pow((t-.17)/.15,2))
                +.18*Math.exp(-Math.pow((t-.56)/.25,2))
                +spread*(.62+.48*variant)*Math.exp(-Math.pow((t-.86)/.14,2)))
                *WeatherCells.smooth(0,.10,t)*Math.sqrt(1-WeatherCells.smooth(.94,1,t));
        double n=CloudNoise.billow(Math.cos(a)*1.6,t*4.5,Math.sin(a)*1.6,seed);
        r*=radius*(1+n*.80)*(1+.10*Math.sin(a*3+variant*6)*Math.sin(Math.PI*t));
        double tilt=height*(.08+.14*variant)*t*t;
        double lean=tilt+radius*.25*spread*WeatherCells.smooth(.66,.93,t);
        double thick=1+.18*(WeatherCells.hash(seed,1,1801)-.5);
        return new double[]{Math.cos(a)*r+wx*lean,base+height*t+height*.025*n*Math.sin(Math.PI*t),
                Math.sin(a)*r*thick+wz*lean};
    }
    public static CloudGeometry.Point point(long seed,double t,double a,double radius,double base,double height,
                                            double wx,double wz,double growth,double phase,int type){
        var p=pos(seed,t,a,radius,base,height,wx,wz,growth,phase,type);
        if(t<=0||t>=1)return new CloudGeometry.Point(p[0],p[1],p[2],0,t<.5?-1:1,0);
        var q=pos(seed,t+.0001,a,radius,base,height,wx,wz,growth,phase,type);
        var r=pos(seed,t,a+.0001,radius,base,height,wx,wz,growth,phase,type);
        double x=q[0]-p[0],y=q[1]-p[1],z=q[2]-p[2],u=r[0]-p[0],v=r[1]-p[1],w=r[2]-p[2];
        double nx=y*w-z*v,ny=z*u-x*w,nz=x*v-y*u;
        double length=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));
        return new CloudGeometry.Point(p[0],p[1],p[2],nx/length,ny/length,nz/length);
    }
}
