package dev.atmosphere;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.Heightmap;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.entity.effect.StatusEffects;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Closed cloud meshes with a dedicated 1.21.1 depth-writing render pass.
 * All views use the same surfaces; light/shadow are artistic approximations,
 * not raymarched volumetrics. Lowered supercell bases may extend below Y=100.
 */
public final class AtmosphereClouds {
    private static final Identifier CLOUD = Identifier.of("atmosphere", "textures/environment/cloud_surface.png");
    private static final Identifier RAIN = Identifier.of("atmosphere", "textures/environment/rain_veil.png");
    private static final Identifier SHADOW = Identifier.of("atmosphere", "textures/environment/cloud_shadow.png");
    /** Black alpha mask: translucent blending then always darkens the ground. */
    private static final RenderLayer SHADOW_LAYER = RenderLayer.getEntityTranslucentCull(SHADOW);
    /** 1.1.7: current sun azimuth for cloud self-shadowing, updated per frame. */
    private static double RENDER_SUN_AZIMUTH = 0;
    private static int adaptiveDrop=0;
    private static long lastAdaptiveTick=Long.MIN_VALUE;
    private record CloudMeshKey(long seed,int sides,int levels,double width,double depth,double height,
                                double base,double wx,double wz,double layer){}
    private static final Map<CloudMeshKey,CloudGeometry.Point[][]> CLOUD_MESHES=new HashMap<>();
    private record StormMeshKey(long id,int sides,int levels,double base,double height,double jetX,double jetZ,
                                double growth,long tick){}
    private static final Map<StormMeshKey,SupercellGeometry.Point[][]> STORM_MESHES=new HashMap<>();
    private static final Map<Long,CloudGeometry.Point[][]> CONVECTIVE_MESHES=new HashMap<>();
    private record RainPatch(double x,double z,double bottom,double top,double half,int alpha,boolean snow){}
    private record RainKey(long id,int quality){}
    private static final Map<RainKey,List<RainPatch>> RAIN_PATCHES=new HashMap<>();
    private static long rainTick=Long.MIN_VALUE;
    private static net.minecraft.client.world.ClientWorld rainWorld;
    private static long meshTick=Long.MIN_VALUE;
    private AtmosphereClouds() {}
    private static int effectiveDetail(AtmosphereSettings s, MinecraftClient client) {
        int desired=s.cloudDetail<0?s.quality:s.cloudDetail;
        if(!s.adaptiveGraphics){adaptiveDrop=0;return desired;}
        if(client.world!=null && (lastAdaptiveTick==Long.MIN_VALUE
                || client.world.getTime()<lastAdaptiveTick
                || client.world.getTime()-lastAdaptiveTick>=80)) {
            lastAdaptiveTick=client.world.getTime();
            int fps=client.getCurrentFps();
            if(fps>0 && fps<29) adaptiveDrop=Math.min(2,adaptiveDrop+1);
            else if(fps>46) adaptiveDrop=Math.max(0,adaptiveDrop-1);
        }
        return desired==0?0:Math.max(1,desired-adaptiveDrop);
    }

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(AtmosphereClouds::render); }

    private static void render(WorldRenderContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        AtmosphereSettings s = AtmosphereSettings.get();
        if (!s.customClouds || client.world == null || client.player == null || ctx.consumers() == null
                || ctx.matrixStack() == null || client.world.getRegistryKey() != World.OVERWORLD) return;
        if(meshTick!=client.world.getTime()){CLOUD_MESHES.clear();STORM_MESHES.clear();CONVECTIVE_MESHES.clear();meshTick=client.world.getTime();}
        VertexConsumerProvider consumers = ctx.consumers();
        VertexConsumer v = consumers.getBuffer(CloudRenderPipeline.layer());
        List<Consumer<VertexConsumer>> rainEffects=new ArrayList<>(),vortexEffects=new ArrayList<>();
        List<double[]> shadows = new ArrayList<>();
        MatrixStack matrix = ctx.matrixStack();
        Vec3d cam = ctx.camera().getPos();
        long time = client.world.getTimeOfDay();
        WeatherModel.Weather local = WeatherModel.sample(cam.x, cam.z, time, s);
        double rainMist=Math.min(.92,Math.max(0,(local.rainMmH()-25)/130.0));
        double weatherFog=WeatherFog.density(local.fog(),rainMist,s.atmosphericFog,s.fogStrength);
        if(cam.y>=95)weatherFog=Math.max(weatherFog,CloudField.immersion(cam.x,cam.y,cam.z,time,s));
        boolean restrictiveFog=ctx.camera().getSubmersionType()!=CameraSubmersionType.NONE
                || client.player.hasStatusEffect(StatusEffects.BLINDNESS)
                || client.player.hasStatusEffect(StatusEffects.DARKNESS);
        CloudRenderPipeline.visibility(weatherFog,restrictiveFog);
        double days = ClimateClock.days(time,s.weatherSpeed);
        List<WeatherCells.Cell> sceneStorms=new ArrayList<>(WeatherCells.nearby(cam.x,cam.z,days,2600));
        WeatherCells.Cell manualFocus=null;
        for(var event:StormEvents.events()){
            double age=event.ageDays(time,s);if(age>=event.lifeDays())continue;
            double phase=event.phase(time,s);
            double growth=WeatherCells.lifecycle(phase);
            long seed=StormEvolution.manualSeed(event.started(),event.x(),event.z());
            double a=StormEvolution.manualAngle(seed);
            WeatherCells.Cell manual=new WeatherCells.Cell(event.type(),event.x(),event.z(),event.radius(),
                    growth,growth,WeatherCells.smooth(.35,.85,growth),growth*.85,
                    Math.cos(a),Math.sin(a),seed,phase,0,event.lifeDays());
            sceneStorms.add(manual);
            if(manual.type()==WeatherCells.SUPERCELL&&manual.growth()>.15)manualFocus=manual;
        }
        WeatherCells.Cell focus=manualFocus;
        if(s.cloudFocus&&manualFocus==null)for(var cell:sceneStorms)if(cell.type()==WeatherCells.SUPERCELL&&cell.growth()>.15
                &&(focus==null||Math.hypot(cell.x()-cam.x,cell.z()-cam.z)<Math.hypot(focus.x()-cam.x,focus.z()-cam.z)))focus=cell;
        // The field must move independently of the viewer. Using local wind at
        // camera.x/z here made ALL clouds teleport as the player crossed wind gradients.
        double driftX = CloudField.driftX(days), driftZ = CloudField.driftZ(days);
        int cloudQuality = effectiveDetail(s,client);
        int radius = switch (cloudQuality) { case 0 -> 3; case 2 -> 6; case 3 -> 8; default -> 5; };
        double spacing = CloudField.SPACING;
        int gx = (int)Math.floor((cam.x - driftX) / spacing);
        int gz = (int)Math.floor((cam.z - driftZ) / spacing);
        double dayCycle = Math.floorMod(time, 24000L) / 24000.0;
        RENDER_SUN_AZIMUTH = dayCycle * Math.PI * 2.0;
        double daylight = Math.max(.20, .55 + .45 * Math.cos(2 * Math.PI * (dayCycle - .25)));
        double sunset = Math.max(Math.exp(-Math.pow(dayCycle / .075, 2)), Math.exp(-Math.pow((dayCycle - .5) / .075, 2)));
        int shadowCount = 0;
        if(!s.cloudFocus)for (int iz = -radius; iz <= radius; iz++) for (int ix = -radius; ix <= radius; ix++) {
            int cx = gx + ix, cz = gz + iz;
            double x = CloudField.centerX(cx, cz, days);
            double z = CloudField.centerZ(cx, cz, days);
            double distance = Math.hypot(x - cam.x, z - cam.z);
            double viewFade = CloudField.viewFade(distance, (radius + .4) * spacing);
            viewFade*=CloudScene.backgroundVisibility(x,z,sceneStorms);
            if (viewFade < .008) continue;
            WeatherModel.Weather w = WeatherModel.sample(x, z, time, s);
            double coverage = CloudField.coverage(cx, cz, w.cloudiness());
            // Thin high cloud layer exists independently of the lower cumulus deck.
            // Low mesh counts protect integrated GPUs.
            double cirrusCover = WeatherCells.smooth(-.12,.12,
                    (.24+.54*w.cloudiness()) - rand(cx,cz,309));
            if (cloudQuality >= 1 && rand(cx,cz,307)<.29 && cirrusCover>.01) {
                double[] highWind = StormEvolution.altitudeWind(w.windX(),w.windZ(),420,cx*1039L+cz,days);
                double hx=x + highWind[0]*20*Math.sin(days*.33+cx*.2);
                double hz=z + highWind[1]*20*Math.sin(days*.33+cz*.2);
                double span=72+rand(cx,cz,311)*95;
                double thin=2.2+rand(cx,cz,312)*3.4;
                shell(v,matrix,cam,hx,397+rand(cx,cz,313)*38,hz,span,thin,span*.40,
                        7,3,cx,cz,310,218*daylight+26,226*daylight+24,237*daylight+18,111*viewFade*cirrusCover);
                if(cloudQuality>=2) shell(v,matrix,cam,hx+span*.48,403+rand(cx,cz,314)*32,hz-span*.26,
                        span*.70,thin*.55,span*.25,7,3,cx,cz,315,
                        218*daylight+23,226*daylight+20,236*daylight+15,87*viewFade*cirrusCover);
            }
            if (coverage < .012) continue;
            double layer=CloudField.layered(cx,cz,w.cloudiness(),w.storm());
            double development=Math.max(CloudField.development(cx,cz,days),layer*.72);
            double storm=w.storm();
            double width=(84+44*rand(cx,cz,31)+storm*75)*(.50+development*.70)*(1+.38*layer);
            double depth=width*(.84+rand(cx,cz,34)*.43);
            double bottom=Math.max(101,w.cloudBase()+(rand(cx,cz,35)-.5)*25);
            double height=width*(.42+.32*rand(cx,cz,36))*(.35+development)
                    *(1+storm*.85)*(1-.76*layer);
            double opacity=coverage*viewFade*WeatherCells.smooth(0,.22,development);
            if(opacity<.008)continue;
            int meshLon=cloudQuality>=3?40:cloudQuality>=2?32:cloudQuality==0?18:26;
            int meshLat=cloudQuality>=3?22:cloudQuality>=2?18:cloudQuality==0?12:15;
            if(distance>spacing*3){meshLon=Math.max(16,meshLon/2);meshLat=Math.max(10,meshLat/2);}
            double flash=AtmosphereAudioLightning.flashNear(x,z,time);
            double tint=.69+.29*daylight;
            drawCloudBody(v,matrix,cam,cx*1000003L+cz,x,z,width*.86,depth*.88,height,bottom,
                    w.windX(),w.windZ(),layer,meshLon,meshLat,
                    213*tint-35*storm+flash*86,220*tint-33*storm+flash*95,
                    232*tint-29*storm+flash*105,238*opacity);
            if (s.cloudShadows && opacity>.15 && daylight > .29 && distance < 410 && shadowCount < 12) {
                shadowCount++;
                double azimuth = dayCycle * Math.PI * 2;
                double offset = Math.min(108, (bottom - 65) * .23);
                shadows.add(new double[]{x - Math.cos(azimuth)*offset, z - Math.sin(azimuth)*offset,
                        width * 1.5, clamp((int)((14 + 62 * w.cloudiness() + 15 * storm)*opacity))});
            }
        }
        // A storm is rendered exactly once. No decorative ellipsoid bridges.
        for(var cell:sceneStorms){
            if(cell.growth()<.035||Math.hypot(cell.x()-cam.x,cell.z()-cam.z)>2400)continue;
            if(s.cloudFocus&&cell!=focus)continue;
            var weather=WeatherModel.sample(cell.x(),cell.z(),time,s);
            renderStormTower(v,matrix,cam,cell,weather,s,cloudQuality,daylight,sunset,time,rainEffects,vortexEffects);
        }
        // 0.9.1: cold-front shelf follows the SAME ONE curved polyline as radar.
        // Bounded low-poly spans; rare and heavier near mature powerful fronts.
        if (!s.cloudFocus && cloudQuality>=1) {
            int frontalMeshes=0;
            for(SynopticSystems.SystemInfo low:SynopticSystems.systems(cam.x,cam.z,days,1900)) {
                if(!low.low() || low.strength()<.52 || frontalMeshes>=36)continue;
                for(int i=1;i<=30 && frontalMeshes<36;i++) {
                    double t=i/31.0;
                    SynopticSystems.FrontPoint pos=SynopticSystems.frontPoint(low,0,t);
                    double dist=Math.hypot(pos.x()-cam.x,pos.z()-cam.z);
                    if(dist>1450)continue;
                    WeatherModel.Weather fw=WeatherModel.sample(pos.x(),pos.z(),time,s);
                    double active=Math.min(1,fw.front()*2.0)*CloudScene.backgroundVisibility(pos.x(),pos.z(),sceneStorms);
                    if(active<.09)continue;
                    double base=Math.max(103,fw.cloudBase());
                    // Scalloped base, broad dark leading edge, uneven height.
                    double bow=Math.sin(t*19+(low.id()%1000003)*.001)*15;
                    double shelfWidth=94+82*active;
                    shell(v,matrix,cam,pos.x(),base+17+bow*.20,pos.z(),
                        shelfWidth,16+11*active,83+26*active,9,4,low.id(),i,951,
                        94+63*daylight,105+60*daylight,118+55*daylight,145+85*active);
                    if(cloudQuality>=1) shell(v,matrix,cam,pos.x()-24,base+37+bow*.20,pos.z()+15,
                        shelfWidth*.69,13+12*active,36+28*active,7,3,low.id(),i,952,
                        100+72*daylight,110+68*daylight,123+58*daylight,133+85*active);
                    frontalMeshes++;
                }
            }
        }
        // Separate batches: never reuse a VertexConsumer after switching its layer.
        if(!vortexEffects.isEmpty()){
            VertexConsumer effect=consumers.getBuffer(RenderLayer.getEntityTranslucent(CLOUD));
            for(var draw:vortexEffects)draw.accept(effect);
        }
        if(!rainEffects.isEmpty()){
            VertexConsumer effect=consumers.getBuffer(RenderLayer.getEntityTranslucent(RAIN));
            for(var draw:rainEffects)draw.accept(effect);
        }
        if (!shadows.isEmpty()) {
            VertexConsumer shadowVertices = consumers.getBuffer(SHADOW_LAYER);
            for (double[] sh : shadows) drawShadow(client, shadowVertices, matrix, cam, sh[0], sh[1], sh[2], (int)sh[3]);
        }
    }

    private static void renderStormTower(VertexConsumer v, MatrixStack matrix, Vec3d cam,
                                         WeatherCells.Cell c, WeatherModel.Weather w,
                                         AtmosphereSettings s, int cloudQuality,
                                         double daylight, double sunset, long time,
                                         List<Consumer<VertexConsumer>> rainEffects,List<Consumer<VertexConsumer>> vortexEffects) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        double g = c.growth();
        long animationTime=client.world.getTime();
        double flash = AtmosphereAudioLightning.flashNear(c.x(), c.z(), time);
        double rx = c.radius() * (.22 + .36*g);
        double rz = rx * (c.type() == WeatherCells.SQUALL ? 1.3 : .83);
        double base = Math.max(c.type()==WeatherCells.SUPERCELL?180:112,w.cloudBase());
        double rareGiant=(c.type()>=WeatherCells.SEVERE && WeatherCells.hash(c.id(),44,991)>.965)?1.52:1;
        double height = (c.type() == WeatherCells.SHOWER ? 95 : c.type() == WeatherCells.THUNDER ? 185 :
                c.type() == WeatherCells.SEVERE ? 275 : 355) * WeatherCells.smooth(.04,.9,g)*rareGiant;
        if(height<8) return;
        int rings = switch(cloudQuality) { case 0 -> 8; case 2 -> 16; case 3 -> 20; default -> 12; };
        int stacks = switch(cloudQuality) { case 0 -> 5; case 2 -> 10; case 3 -> 12; default -> 8; };
        int towers = switch(cloudQuality) { case 0 -> 3; case 2 -> 8; case 3 -> 10; default -> 5; };
        if (Math.hypot(c.x()-cam.x,c.z()-cam.z) > 950) {
            rings = Math.max(7,rings/2);
            stacks = Math.max(4,stacks/2);
            towers = Math.max(3,towers/2);
        }
        double dark = c.type() >= WeatherCells.SEVERE ? 38 : c.type()>=WeatherCells.THUNDER ? 22 : 0;
        double brightness = .58+.42*daylight;
        if(c.type()==WeatherCells.SUPERCELL) {
            double[] jet=SynopticSystems.upperWind(c.x(),c.z(),ClimateClock.days(time,s.weatherSpeed),.9);
            drawSupercellBody(v,matrix,cam,c,base,height,jet[0],jet[1],cloudQuality,brightness,flash);
        } else {
            drawConvectiveBody(v,matrix,cam,c,base,height,cloudQuality,brightness,flash);
        }
        if(c.type()>=WeatherCells.THUNDER){
            if(c.type()==WeatherCells.SUPERCELL)drawAttachments(v,matrix,cam,c,base,animationTime,brightness,true);
            drawAttachments(v,matrix,cam,c,base,animationTime,brightness,false);
        }
        if(c.type()==WeatherCells.SUPERCELL && g>.36) {
            // The wall cloud sits over the rear-flank hook instead of orbiting the cell.
            double hookAlong=.05*c.radius(),hookAcross=-.35*c.radius();
            double wx=c.x()+hookAlong*c.windX()-hookAcross*c.windZ();
            double wz=c.z()+hookAlong*c.windZ()+hookAcross*c.windX();
            double wr=rx*.36*g;
            BlockPos groundPos=BlockPos.ofFloored(wx,cam.y,wz);
            boolean groundLoaded=client.world.isChunkLoaded(groundPos);
            double ground=groundLoaded?client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                    groundPos.getX(),groundPos.getZ()):base-80;
            double mesoBottom=base-SupercellGeometry.lowering(g);
            double activity=StormEvolution.tornadoActivity(c.id(),g,c.phase(),StormEvents.chanceFor(c.id(),s.tornadoCode()));
            if(activity>.02 && c.rotation()>.22 && groundLoaded && mesoBottom>ground+4) {
                vortexEffects.add(effect->{
                double bottom=mesoBottom+(ground-.5-mesoBottom)*StormEvolution.smooth(.02,.85,activity);
                drawVortex(effect,matrix,cam,wx,wz,mesoBottom+2,bottom,wr*.50,
                        TornadoGeometry.type(c.id()),c.id(),animationTime,cloudQuality,brightness,
                        225*StormEvolution.smooth(0,.20,activity),c.phase());
                if(activity>.60)drawDust(effect,matrix,cam,wx,wz,ground,wr*.70,c.id(),animationTime,
                        cloudQuality,brightness,StormEvolution.smooth(.60,.88,activity),
                        TornadoDust.material(client.world,BlockPos.ofFloored(wx,ground-1,wz)));
                });
            }
        }
        if(!s.cloudFocus&&g>.20)queuePrecipitation(rainEffects,matrix,cam,c,base,time,s,cloudQuality);
        if(!s.cloudFocus&&c.type()!=WeatherCells.SUPERCELL&&GustFront.maturity(g,c.type())>.02)
            drawShelfCloud(v,matrix,cam,c,base,cloudQuality,brightness);
        // Visual downburst / microburst: lateral outflow cloudlets underneath a
        // severe rain core. There is NO force applied to players or blocks.
        if(!s.cloudFocus&&c.type()!=WeatherCells.SUPERCELL&&c.type()>=WeatherCells.SEVERE && g>.70 && c.rotation()>.48 && cloudQuality>=1) {
            double pulse = .55+.45*Math.sin(time*.026+c.id());
            for(int side=0;side<4;side++) {
                double angle=side*Math.PI*.5+time*.004;
                double ox=c.x()+Math.cos(angle)*rx*.86;
                double oz=c.z()+Math.sin(angle)*rz*.86;
                shell(v,matrix,cam,ox,base+13,oz,16+11*pulse,11,17+10*pulse,
                        7,4,c.id(),79+side,151*brightness,161*brightness,178*brightness,142);
            }
        }
        // Storm-scale squall line: adjacent independently evolving updraft columns,
        // not a single inflated blob. A mild arc follows the front direction.
        if(!s.cloudFocus&&c.type()==WeatherCells.SQUALL && g>.17) {
            int columns=cloudQuality==0?2:cloudQuality>=2?5:3;
            for(int i=0;i<columns;i++) {
                double t=(i-(columns-1)/2.0);
                double along=t*rx*.67;
                double bow=rx*.15*Math.cos(t*1.1);
                double x=c.x()-c.windZ()*along+c.windX()*bow;
                double z=c.z()+c.windX()*along+c.windZ()*bow;
                double localG=g*(.68+.32*Math.sin(1.6*i+(c.id()%1000003)*.001+g*4));
                double towerH=height*(.48+.36*localG);
                double yy=Math.max(103+towerH*.44,base+towerH*.56);
                shell(v,matrix,cam,x,yy,z,rx*.34,towerH*.43,rx*.33,
                        rings,stacks,c.id(),125+i,
                        165*brightness+flash*92,174*brightness+flash*95,
                        191*brightness+flash*102,207);
                // Squall line stratification: a mid-level dense band and a
                // thin upper outflow deck; the storm base is rendered above.
                shell(v,matrix,cam,x,base+44+localG*19,z,
                        rx*.46,8+4*localG,rx*.45,rings,stacks,c.id(),145+i,
                        137*brightness+flash*86,151*brightness+flash*94,
                        172*brightness+flash*105,185);
                shell(v,matrix,cam,x,base+96+localG*28,z,
                        rx*.50,6+3*localG,rx*.43,rings,stacks,c.id(),165+i,
                        180*brightness+flash*92,190*brightness+flash*98,
                        209*brightness+flash*110,132);
            }
        }
    }

    private static void drawAttachments(VertexConsumer v,MatrixStack m,Vec3d cam,WeatherCells.Cell c,
                                         double base,long tick,double light,boolean tail){
        var puffs=tail?StormAttachments.tail(c.id(),c.radius(),c.growth(),tick)
                :StormAttachments.scud(c.id(),c.radius(),c.growth(),tick);
        for(var p:puffs){
            double x=c.x()+p.along()*c.windX()-p.across()*c.windZ();
            double z=c.z()+p.along()*c.windZ()+p.across()*c.windX();
            // Never put decorative cloud fragments into terrain, and never load a chunk.
            var client=MinecraftClient.getInstance();var at=BlockPos.ofFloored(x,base+p.y(),z);
            if(client.world.isChunkLoaded(at)&&client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,at.getX(),at.getZ())>base+p.y()-3)continue;
            drawCloudBody(v,m,cam,p.seed(),x,z,p.width(),p.depth(),p.height(),base+p.y(),
                    c.windX(),c.windZ(),0,20,12,151*light,159*light,170*light,p.alpha());
        }
    }
    private static void drawConvectiveBody(VertexConsumer v,MatrixStack m,Vec3d cam,WeatherCells.Cell c,
                                           double base,double height,int quality,double light,double flash){
        int rows=quality>=2?36:28,cols=quality>=2?56:40;
        double remnant=WeatherCells.smooth(.65,.78,c.phase())*(1-WeatherCells.smooth(.90,.99,c.phase()));
        double fullHeight=Math.max(height,(c.type()==WeatherCells.SHOWER?95:c.type()==WeatherCells.THUNDER?185:275)*remnant*.85);
        var mesh=CONVECTIVE_MESHES.get(c.id());
        if(mesh==null){mesh=new CloudGeometry.Point[rows+1][cols+1];
        for(int j=0;j<=rows;j++)for(int i=0;i<=cols;i++){
            var p=ConvectiveCloudGeometry.point(c.id(),1-j/(double)rows,i*Math.PI*2/cols,
                    c.radius()*(.65+.12*WeatherCells.hash(c.id(),0,1831)),base,fullHeight,
                    c.windX(),c.windZ(),c.growth(),c.phase(),c.type());
            mesh[j][i]=p;
        }
        CONVECTIVE_MESHES.put(c.id(),mesh);}
        drawCloudSurface(v,m,cam,mesh,c.x(),c.z(),190*light+flash*70,200*light+flash*75,
                214*light+flash*80,245*WeatherCells.smooth(.03,.2,c.growth()));
    }
    private static void queuePrecipitation(List<Consumer<VertexConsumer>> effects,MatrixStack m,Vec3d cam,
                                           WeatherCells.Cell c,double base,long time,AtmosphereSettings settings,int quality){
        var world=MinecraftClient.getInstance().world;long now=world.getTime();
        if(rainWorld!=world||now<rainTick||now-rainTick>=20){
            RAIN_PATCHES.clear();rainTick=now;rainWorld=world;
        }
        RainKey key=new RainKey(c.id(),quality);
        var patches=RAIN_PATCHES.get(key);
        if(patches==null){patches=new ArrayList<>();
        int n=quality==0?7:11;double step=c.radius()*2.8/n;
        // One storm-relative rain volume, sampled from the same field as the radar.
        // Soft overlapping tiles replace detached cylinders and decorative blue shafts.
        for(int j=0;j<n;j++)for(int i=0;i<n;i++){
            double along=-1.4*c.radius()+(i+.5)*step,across=-1.4*c.radius()+(j+.5)*step;
            double own=StormEvolution.rainProfile(along,across,c.radius(),c.id(),c.type(),c.growth());
            if(own<.035)continue;
            double x=c.x()+along*c.windX()-across*c.windZ(),z=c.z()+along*c.windZ()+across*c.windX();
            var weather=WeatherModel.sample(x,z,time,settings);
            double rate=weather.rainMmH();if(rate<.3)continue;
            var client=MinecraftClient.getInstance();var at=BlockPos.ofFloored(x,base,z);
            double ground=client.world.isChunkLoaded(at)?client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,at.getX(),at.getZ()):66;
            double humidity=weather.humidity();
            double bottom=humidity<.48?Math.max(ground+15,base-35):ground+.3;
            if(bottom>base-4)continue;
            int alpha=(int)(78*WeatherCells.smooth(.3,45,rate)*WeatherCells.smooth(.035,.25,own));
            if(alpha<2)continue;
            boolean snow=weather.precipitationKind()==1;
            patches.add(new RainPatch(x,z,bottom,base+5,step*.83,alpha,snow));
        }
        if(RAIN_PATCHES.size()>96)RAIN_PATCHES.clear();
        RAIN_PATCHES.put(key,patches);}
        for(var p:patches)effects.add(v->drawRainTile(v,m,cam,p.x(),p.z(),p.bottom(),p.top(),p.half(),
                p.alpha(),c.windX(),c.windZ(),p.snow()));
    }
    private static void drawRainTile(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,double bottom,
                                     double top,double half,int alpha,double wx,double wz,boolean snow){
        // Crossed soft sheets give a continuous volume from different viewpoints.
        for(int axis=0;axis<2;axis++){
            double dx=(axis==0?wx:-wz)*half,dz=(axis==0?wz:wx)*half;
            int r=snow?209:137,g=snow?218:153,b=snow?228:174;
            put(v,m,(float)(x-dx-cam.x),(float)(top-cam.y),(float)(z-dz-cam.z),0,0,r,g,b,alpha,0,1,0);
            put(v,m,(float)(x+dx-cam.x),(float)(top-cam.y),(float)(z+dz-cam.z),1,0,r,g,b,alpha,0,1,0);
            put(v,m,(float)(x+dx-cam.x),(float)(bottom-cam.y),(float)(z+dz-cam.z),1,1,r,g,b,alpha,0,1,0);
            put(v,m,(float)(x-dx-cam.x),(float)(bottom-cam.y),(float)(z-dz-cam.z),0,1,r,g,b,alpha,0,1,0);
        }
    }
    private static double lyBase(double base,double height,double part) {
        return base+height*(.13+.80*part);
    }

    private static void drawCloudBody(VertexConsumer v,MatrixStack m,Vec3d cam,long seed,double x,double z,
                                      double width,double depth,double height,double base,double wx,double wz,
                                      double layer,int sides,int levels,double red,double green,double blue,double alpha){
        CloudMeshKey key=new CloudMeshKey(seed,sides,levels,width,depth,height,base,wx,wz,layer);
        CloudGeometry.Point[][] mesh=CLOUD_MESHES.get(key);
        if(mesh==null){
            mesh=new CloudGeometry.Point[levels+1][sides+1];
            var rounded=CloudGeometry.unitMesh(seed,sides,levels,false);
            var layered=CloudGeometry.unitMesh(seed,sides,levels,true);
            for(int j=0;j<=levels;j++)for(int i=0;i<=sides;i++)
                mesh[j][i]=CloudGeometry.transform(rounded[j][i],layered[j][i],layer,width,depth,height,base,wx,wz);
            if(CLOUD_MESHES.size()>=384)CLOUD_MESHES.clear();
            CLOUD_MESHES.put(key,mesh);
        }
        drawCloudSurface(v,m,cam,mesh,x,z,red,green,blue,alpha);
    }
    private static void drawCloudSurface(VertexConsumer v,MatrixStack m,Vec3d cam,CloudGeometry.Point[][] mesh,
                                          double x,double z,double red,double green,double blue,double alpha){
        int levels=mesh.length-1,sides=mesh[0].length-1;
        for(int j=0;j<levels;j++)for(int i=0;i<sides;i++)for(int k=0;k<4;k++){
            int row=j+(k>=2?1:0),col=i+(k==1||k==2?1:0);
            var p=mesh[row][col];
            double shade=CloudLighting.shade(p.nx(),p.ny(),p.nz(),RENDER_SUN_AZIMUTH)*StormAttachments.underside(p.ny());
            putCloud(v,m,(float)(x+p.x()-cam.x),(float)(p.y()-cam.y),(float)(z+p.z()-cam.z),
                    col/(float)sides,row/(float)levels,clamp((int)(red*shade)),clamp((int)(green*shade)),
                    clamp((int)(blue*shade)),clamp((int)alpha),
                    (float)p.nx(),(float)p.ny(),(float)p.nz());
        }
    }

    private static void drawSupercellBody(VertexConsumer v,MatrixStack m,Vec3d cam,WeatherCells.Cell cell,
                                          double base,double height,double jetX,double jetZ,int quality,double light,double flash) {
        int sides=CloudScene.stormSides(quality),levels=CloudScene.stormLevels(quality);
        if(Math.hypot(cell.x()-cam.x,cell.z()-cam.z)>1600)sides=Math.max(48,sides/2);
        long tick=MinecraftClient.getInstance().world.getTime();
        StormMeshKey key=new StormMeshKey(cell.id(),sides,levels,base,height,jetX,jetZ,cell.growth(),tick);
        SupercellGeometry.Point[][] points=STORM_MESHES.get(key);
        if(points==null){
            points=new SupercellGeometry.Point[levels+1][sides+1];
            for(int j=0;j<=levels;j++)for(int i=0;i<=sides;i++)
                points[j][i]=SupercellGeometry.point(cell.id(),j/(double)levels,i*Math.PI*2/sides,
                        cell.radius(),base,height,cell.windX(),cell.windZ(),jetX,jetZ,cell.growth(),tick,
                        SupercellGeometry.lowering(cell.growth()));
            if(STORM_MESHES.size()>=64)STORM_MESHES.clear();
            STORM_MESHES.put(key,points);
        }
        for(int j=0;j<levels;j++)for(int i=0;i<sides;i++)for(int k=0;k<4;k++) {
            int row=j+(k==1||k==2?1:0),col=i+(k>=2?1:0);
            var p=points[row][col];
            double shade=CloudLighting.shade(p.nx(),p.ny(),p.nz(),RENDER_SUN_AZIMUTH)*StormAttachments.underside(p.ny());
            double alpha=255*StormEvolution.smooth(.02,.25,cell.growth());
            putCloud(v,m,(float)(cell.x()+p.x()-cam.x),(float)(p.y()-cam.y),(float)(cell.z()+p.z()-cam.z),
                    col/(float)sides,row/(float)levels,
                    clamp((int)(193*light*shade+flash*65)),clamp((int)(201*light*shade+flash*70)),
                    clamp((int)(215*light*shade+flash*75)),(int)alpha,(float)p.nx(),(float)p.ny(),(float)p.nz());
        }
    }

    /** One connected low arc, with its visible leading edge on the model's gust boundary. */
    private static void drawShelfCloud(VertexConsumer v,MatrixStack m,Vec3d cam,WeatherCells.Cell cell,
                                       double base,int quality,double light) {
        int spans=quality>=2?48:quality==0?20:32,rings=quality>=2?14:10;
        double power=GustFront.maturity(cell.growth(),cell.type());
        for(int j=0;j<spans;j++)for(int i=0;i<rings;i++)for(int k=0;k<4;k++) {
            double side=(j+(k>=2?1.0:0))/spans;
            double angle=(i+(k==1||k==2?1.0:0))*Math.PI*2/rings;
            var p=ShelfCloudGeometry.point(side,angle,cell.radius(),base,cell.growth(),cell.type());
            double x=cell.x()+p.along()*cell.windX()-p.across()*cell.windZ();
            double z=cell.z()+p.along()*cell.windZ()+p.across()*cell.windX();
            double shade=.40+.48*Math.max(0,p.normalY())+.08*Math.max(0,p.normalAlong());
            putCloud(v,m,(float)(x-cam.x),(float)(p.y()-cam.y),(float)(z-cam.z),
                    (float)side,(float)(angle/(Math.PI*2)),clamp((int)(160*light*shade)),
                    clamp((int)(170*light*shade)),clamp((int)(184*light*shade)),(int)(228*power),
                    (float)(p.normalAlong()*cell.windX()),(float)p.normalY(),(float)(p.normalAlong()*cell.windZ()));
        }
    }

    /** A continuous rotating tube, independent of the cloud ellipsoid height clamp. */
    private static void drawVortex(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                   double top,double bottom,double scale,int type,long seed,long time,
                                   int quality,double light,double alpha) {
        drawVortex(v,m,cam,x,z,top,bottom,scale,type,seed,time,quality,light,alpha,.55);
    }
    private static void drawVortex(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                   double top,double bottom,double scale,int type,long seed,long time,
                                   int quality,double light,double alpha,double phase) {
        int sides=quality>=2?32:quality==0?16:24, levels=quality>=2?20:12;
        for(int j=0;j<levels;j++)for(int i=0;i<sides;i++) {
            double t0=j/(double)levels,t1=(j+1.0)/levels;
            double a0=i*Math.PI*2/sides,a1=(i+1.0)*Math.PI*2/sides;
            TornadoGeometry.Point p0=TornadoGeometry.point(seed,t0,a0,time,top,bottom,scale,type,phase);
            TornadoGeometry.Point p1=TornadoGeometry.point(seed,t1,a0,time,top,bottom,scale,type,phase);
            TornadoGeometry.Point p2=TornadoGeometry.point(seed,t1,a1,time,top,bottom,scale,type,phase);
            TornadoGeometry.Point p3=TornadoGeometry.point(seed,t0,a1,time,top,bottom,scale,type,phase);
            vortexQuad(v,m,cam,x,z,p0,p1,p2,p3,(float)i/sides,(float)(i+1)/sides,
                    (float)t0,(float)t1,light,alpha,seed,-1);
        }
    }
    private static void drawDust(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                 double ground,double scale,long seed,long time,int quality,double light,double alpha,int material) {
        int sides=quality>=2?32:16;
        for(int j=0;j<3;j++)for(int i=0;i<sides;i++) {
            TornadoGeometry.Point[] p=new TornadoGeometry.Point[4];
            for(int k=0;k<4;k++) {
                double ring=(j+(k==1||k==2?1:0))/3.0;
                double a=(i+(k>=2?1:0))*Math.PI*2/sides+time*.025;
                double radius=scale*(.24+ring*1.25)*(1+.14*Math.sin(a*5+(seed%1000003)*.001));
                double y=ground+.15+Math.sin(ring*Math.PI)*(7+3*Math.sin(a*3+time*.013));
                p[k]=new TornadoGeometry.Point(Math.cos(a)*radius,y,Math.sin(a)*radius,Math.cos(a),Math.sin(a));
            }
            vortexQuad(v,m,cam,x,z,p[0],p[1],p[2],p[3],0,1,0,1,light,170*alpha,seed,material);
        }
    }
    private static void vortexQuad(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                    TornadoGeometry.Point p0,TornadoGeometry.Point p1,TornadoGeometry.Point p2,TornadoGeometry.Point p3,
                                    float u0,float u1,float t0,float t1,double light,double alpha,long seed,int material) {
        TornadoGeometry.Point[] points={p0,p1,p2,p3};
        for(int k=0;k<4;k++) {
            var p=points[k];
            double shade=.70+.25*Math.max(0,p.nx()*Math.cos(RENDER_SUN_AZIMUTH)+p.nz()*Math.sin(RENDER_SUN_AZIMUTH));
            int r=clamp((int)((material<0?112:TornadoDust.red(material))*light*shade));
            int g=clamp((int)((material<0?119:TornadoDust.green(material))*light*shade));
            int b=clamp((int)((material<0?128:TornadoDust.blue(material))*light*shade));
            put(v,m,(float)(x+p.x()-cam.x),(float)(p.y()-cam.y),(float)(z+p.z()-cam.z),
                    k<2?u0:u1,k==0||k==3?t0:t1,r,g,b,clamp((int)alpha),(float)p.nx(),0,(float)p.nz());
        }
    }

    // Storm cells have a single stable id plus a lobe index, while the older
    // cloud grid supplies two coordinates plus a lobe index. Accept both forms.
    // This overload fixes the Alpha 0.6 build without changing cloud geometry.
    private static void shell(VertexConsumer v, MatrixStack m, Vec3d cam,
                              double x, double y, double z, double rx, double ry, double rz,
                              int lon, int lat, long cellId, int lobe,
                              double red, double green, double blue, double alpha) {
        shell(v, m, cam, x, y, z, rx, ry, rz,
                lon, lat, cellId, 0L, lobe, red, green, blue, alpha);
    }

    private static void shell(VertexConsumer v, MatrixStack m, Vec3d cam,
                              double x, double y, double z, double rx, double ry, double rz,
                              int lon, int lat, long ix, long iz, int l,
                              double red, double green, double blue, double alpha) {
        long seed=ix*1000003L^iz*341873128712L^l*2177342783L;
        double layer=ry<Math.min(rx,rz)*.25?1:0;
        drawCloudBody(v,m,cam,seed,x,z,rx,rz,Math.max(.5,ry*2),Math.max(100.2,y-ry),0,0,layer,
                Math.max(24,lon),Math.max(16,lat),red,green,blue,alpha);
    }

    private static void drawShadow(MinecraftClient client, VertexConsumer v, MatrixStack m, Vec3d cam,
                                   double centerX, double centerZ, double size, int opacity) {
        // The shadow texture carries its own soft cloud-shaped alpha mask, so one
        // quad per cloud is enough; the old 4x4 grid only re-tiled the same blur.
        int cells = 1;
        for (int iz = 0; iz < cells; iz++) for (int ix = 0; ix < cells; ix++) {
            double x0 = centerX - size*.5 + size*ix/cells;
            double x1 = centerX - size*.5 + size*(ix+1)/cells;
            double z0 = centerZ - size*.5 + size*iz/cells;
            double z1 = centerZ - size*.5 + size*(iz+1)/cells;
            BlockPos at = BlockPos.ofFloored((x0+x1)*.5, cam.y, (z0+z1)*.5);
            if (!client.world.isChunkLoaded(at)) continue;
            int y = client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                    (int)((x0+x1)*.5), (int)((z0+z1)*.5));
            if (y <= client.world.getBottomY() || y >= client.world.getTopY() - 1) continue;
            float fy = (float)(y - cam.y + .045);
            float ax = (float)(x0 - cam.x), bx = (float)(x1 - cam.x);
            float az = (float)(z0 - cam.z), bz = (float)(z1 - cam.z);
            float u0 = ix/(float)cells, u1 = (ix+1)/(float)cells;
            float v0 = iz/(float)cells, v1 = (iz+1)/(float)cells;
            // 1.1.5: the old 12/18/28 tint on a white texture washed the grass out.
            // The mask is black now, so a neutral tint always stays a shadow.
            put(v,m,ax,fy,az,u0,v0, 255,255,255,opacity,0,1,0);
            put(v,m,ax,fy,bz,u0,v1, 255,255,255,opacity,0,1,0);
            put(v,m,bx,fy,bz,u1,v1, 255,255,255,opacity,0,1,0);
            put(v,m,bx,fy,az,u1,v0, 255,255,255,opacity,0,1,0);
        }
    }
    /** Translucent rain shaft. Unlike cloud shells, rain may extend below Y=100.
     * Pure client geometry: no world modification or rain entity is involved.
     */
    private static void drawRainVeil(VertexConsumer v,MatrixStack m,Vec3d cam,
                                     double x,double z,double bottom,double top,double radius,int alpha) {
        for(int segment=0;segment<16;segment++) {
            double angle=segment*Math.PI*2/16;
            double ex=Math.cos(angle)*radius,ez=Math.sin(angle)*radius;
            double bx=Math.cos(angle+Math.PI*2/16)*radius,bz=Math.sin(angle+Math.PI*2/16)*radius;
            float nx=(float)Math.cos(angle+Math.PI/16),nz=(float)Math.sin(angle+Math.PI/16);
            put(v,m,(float)(x+ex-cam.x),(float)(top-cam.y),(float)(z+ez-cam.z),
                    0,0,170,185,202,alpha,nx,0,nz);
            put(v,m,(float)(x+bx-cam.x),(float)(top-cam.y),(float)(z+bz-cam.z),
                    1,0,170,185,202,alpha,nx,0,nz);
            put(v,m,(float)(x+bx-cam.x),(float)(bottom-cam.y),(float)(z+bz-cam.z),
                    1,1,157,174,195,alpha,nx,0,nz);
            put(v,m,(float)(x+ex-cam.x),(float)(bottom-cam.y),(float)(z+ez-cam.z),
                    0,1,157,174,195,alpha,nx,0,nz);
        }
    }

    private static void putCloud(VertexConsumer v,MatrixStack m,float x,float y,float z,float u,float texV,
                                 int r,int g,int b,int a,float nx,float ny,float nz){
        v.vertex(m.peek().getPositionMatrix(),x,y,z).texture(u,texV).color(r,g,b,a);
    }
    private static void put(VertexConsumer v, MatrixStack m, float x, float y, float z, float u, float texV,
                            int r, int g, int b, int a, float nx, float ny, float nz) {
        v.vertex(m.peek().getPositionMatrix(), x,y,z).color(r,g,b,a).texture(u,texV)
                .overlay(OverlayTexture.DEFAULT_UV).light(0xF000F0).normal(m.peek(),nx,ny,nz);
    }
    private static int clamp(int n) { return Math.max(0, Math.min(255, n)); }
    private static double rand(long x, long z, long salt) {
        long h = x * 341873128712L ^ z * 132897987541L ^ salt * 2177342783L;
        h ^= h >>> 30; h *= -4658895280553007687L;
        h ^= h >>> 27; h *= -7723592293110705685L;
        h ^= h >>> 31;
        return (h >>> 11) * 0x1.0p-53;
    }
}
