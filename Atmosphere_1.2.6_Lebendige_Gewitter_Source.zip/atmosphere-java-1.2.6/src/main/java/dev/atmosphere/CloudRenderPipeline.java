package dev.atmosphere;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/** Minecraft 1.21.1 pipeline. CoreShaderRegistrationCallback belongs to rendering-v1
 * 5.0.5+df16efd019 in Fabric API 0.115.6+1.21.1. No later RenderPipeline API. */
public final class CloudRenderPipeline extends RenderLayer {
    private static final Identifier TEXTURE=Identifier.of("atmosphere","textures/environment/cloud_surface.png");
    private static final Identifier RAIN_TEXTURE=Identifier.of("atmosphere","textures/environment/rain_veil.png");
    // Qualify explicitly: RenderLayer inherits a different nested RenderPhase.ShaderProgram.
    private static net.minecraft.client.gl.ShaderProgram shader;
    private static float fogStart=900,fogEnd=2600;
    private static final RenderLayer LAYER=new CloudRenderPipeline(false);
    private static final RenderLayer PRECIPITATION=new CloudRenderPipeline(true);
    private CloudRenderPipeline(boolean rain){
        super(rain?"atmosphere_precipitation":"atmosphere_cloud_hull",VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS,
                262144,false,true,()->begin(rain),CloudRenderPipeline::end);
    }
    public static void register(){
        CoreShaderRegistrationCallback.EVENT.register(context->context.register(
                Identifier.of("atmosphere","cloud_hull"),VertexFormats.POSITION_TEXTURE_COLOR,p->shader=p));
    }
    public static RenderLayer layer(){return LAYER;}
    public static RenderLayer precipitation(){return PRECIPITATION;}
    public static void visibility(double weatherFog,boolean restrictiveVanillaFog){
        if(restrictiveVanillaFog){
            fogStart=RenderSystem.getShaderFogStart();fogEnd=RenderSystem.getShaderFogEnd();
            return;
        }
        fogEnd=weatherFog<.12?2600:(float)WeatherFog.visibility(weatherFog);
        fogStart=weatherFog<.12?900:fogEnd*.08f;
    }
    private static void begin(boolean rain){
        RenderSystem.setShader(()->shader);RenderSystem.setShaderTexture(0,rain?RAIN_TEXTURE:TEXTURE);
        if(shader!=null){
            var start=shader.getUniform("CloudFogStart");var end=shader.getUniform("CloudFogEnd");
            if(start!=null)start.set(fogStart);if(end!=null)end.set(fogEnd);
            var mask=shader.getUniform("TextureMask");if(mask!=null)mask.set(rain?1f:0f);
        }
        RenderSystem.enableDepthTest();RenderSystem.depthFunc(515);RenderSystem.depthMask(!rain);
        if(rain)RenderSystem.disableCull();else RenderSystem.enableCull();
        RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
    }
    private static void end(){
        RenderSystem.depthMask(true);RenderSystem.enableCull();RenderSystem.disableBlend();
    }
}
