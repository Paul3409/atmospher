package de.meteo;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.AbstractBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.ActionResult;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static net.minecraft.server.command.CommandManager.literal;

public final class MeteoMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("meteo");
    public static final MeteoStationBlock STATION_BLOCK = Registry.register(Registries.BLOCK,
        Identifier.of("meteo","weather_station"),new MeteoStationBlock(AbstractBlock.Settings.create().strength(2.0f)));
    private static final AtmosphereEngine ENGINE = new AtmosphereEngine();
    private static WeatherDynamics.Settings settings=WeatherDynamics.DEFAULT;
    private static java.nio.file.Path saveRoot;
    private static void saveAtmosphere(){
        if(saveRoot==null)return;
        ENGINE.save(saveRoot.resolve("data/meteo-atmosphere.bin.gz"));
        CloudEffects.save(saveRoot.resolve("data/meteo-clouds.bin.gz"));
        SynopticRuntime.save(saveRoot);
    }
    private static void sendSynoptic(net.minecraft.server.network.ServerPlayerEntity player){
        if(ServerPlayNetworking.canSend(player,SynopticControlPayload.ID))
            ServerPlayNetworking.send(player,SynopticControlPayload.of(SynopticRuntime.current()));
    }
    private static void sendSettings(net.minecraft.server.network.ServerPlayerEntity player){
        if(ServerPlayNetworking.canSend(player,WeatherSettingsPayload.ID))
            ServerPlayNetworking.send(player,WeatherSettingsPayload.of(settings));
    }
    private static void sendSeasons(net.minecraft.server.network.ServerPlayerEntity player){
        if(ServerPlayNetworking.canSend(player,SeasonSettingsPayload.ID))
            ServerPlayNetworking.send(player,new SeasonSettingsPayload(SeasonSystem.settings(),player.getServerWorld().getTimeOfDay()));
    }
    private static void sendSnowCover(net.minecraft.server.network.ServerPlayerEntity player){
        if(ServerPlayNetworking.canSend(player,SnowCoverPayload.ID))
            ServerPlayNetworking.send(player,new SnowCoverPayload(SnowCoverSettings.current()));
    }
    private static boolean mayEdit(net.minecraft.server.network.ServerPlayerEntity player){
        return player.hasPermissionLevel(2)||(player.getServer().isSingleplayer() &&
            player.getServer().getHostProfile()!=null && player.getUuid().equals(player.getServer().getHostProfile().getId()));
    }
    private static String compass(double degrees){
        String[] names={"N","NE","E","SE","S","SW","W","NW"};
        return names[((int)Math.floor((degrees+22.5)/45.0))%8];
    }
    @Override public void onInitialize() {
        LOGGER.info("Meteo V1.8.0: stable realistic cloud and precipitation rendering");
        Registry.register(Registries.ITEM,Identifier.of("meteo","weather_station"),
            new BlockItem(STATION_BLOCK,new Item.Settings()));
        ServerLifecycleEvents.SERVER_STARTED.register(server->{
            saveRoot=server.getSavePath(net.minecraft.util.WorldSavePath.ROOT);
            settings=WeatherSettingsStore.load();ENGINE.setDynamics(settings);
            SynopticRuntime.set(SynopticConfigStore.load(saveRoot));
            SynopticRuntime.load(saveRoot);
            SeasonSystem.start(saveRoot);
            SnowCoverSettings.start(saveRoot);
            ENGINE.load(server.getOverworld(),saveRoot.resolve("data/meteo-atmosphere.bin.gz"));
            CloudEffects.load(server.getOverworld(),saveRoot.resolve("data/meteo-clouds.bin.gz"));
            StationManager.start(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server->saveAtmosphere());
        ServerLifecycleEvents.SERVER_STOPPED.register(server->{StationManager.stop();SeasonSystem.stop();SnowCoverSettings.stop();ENGINE.reset();CloudEffects.reset();saveRoot=null;});
        PayloadTypeRegistry.playS2C().register(SeasonSettingsPayload.ID,SeasonSettingsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SnowCoverPayload.ID,SnowCoverPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SnowCoverPayload.ID,SnowCoverPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SeasonSettingsPayload.ID,SeasonSettingsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CloudSnapshotPayload.ID,CloudSnapshotPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CloudDiagnosticPayload.ID,CloudDiagnosticPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(RainRadarPayload.ID,RainRadarPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(WeatherSettingsPayload.ID,WeatherSettingsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SynopticControlPayload.ID,SynopticControlPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SynopticControlPayload.ID,SynopticControlPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SynopticMapPayload.ID,SynopticMapPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RadarForecastRequestPayload.ID,RadarForecastRequestPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(RadarForecastMapPayload.ID,RadarForecastMapPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ManualPressurePayload.ID,ManualPressurePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(WeatherSettingsPayload.ID,WeatherSettingsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StationPagePayload.ID,StationPagePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(StationRequestPayload.ID,StationRequestPayload.CODEC);
        UseBlockCallback.EVENT.register((player,world,hand,hit)->{
            if(!world.getBlockState(hit.getBlockPos()).isOf(STATION_BLOCK))return ActionResult.PASS;
            if(!world.isClient && player instanceof net.minecraft.server.network.ServerPlayerEntity serverPlayer)
                StationManager.open(serverPlayer,hit.getBlockPos(),0);
            return ActionResult.SUCCESS;
        });
        ServerPlayNetworking.registerGlobalReceiver(StationRequestPayload.ID,(payload,context)->{
            if(payload.page()>=0 && payload.page()<1000000)
                StationManager.open(context.player(),BlockPos.fromLong(payload.position()),payload.page());
        });
        ServerPlayConnectionEvents.JOIN.register((handler,sender,server)->{
            sendSettings(handler.player);sendSynoptic(handler.player);sendSeasons(handler.player);sendSnowCover(handler.player);
        });
        ServerPlayNetworking.registerGlobalReceiver(RadarForecastRequestPayload.ID,(payload,context)->{
            int hours=payload.hours();
            if(hours<0||hours>12||hours%3!=0)return;
            var player=context.player();
            if(ServerPlayNetworking.canSend(player,RadarForecastMapPayload.ID)){
                var preview=SynopticMapPayload.around(player.getServerWorld().getTime(),player.getBlockX(),player.getBlockZ(),
                    ENGINE.simulatedSeconds()+hours*3600.0,SynopticRuntime.current());
                ServerPlayNetworking.send(player,new RadarForecastMapPayload(hours,preview));
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(SnowCoverPayload.ID,(payload,context)->{
            var player=context.player();
            if(!mayEdit(player)){sendSnowCover(player);return;}
            SnowCoverSettings.change(payload.settings());
            for(var online:player.getServer().getPlayerManager().getPlayerList())sendSnowCover(online);
        });
        ServerPlayNetworking.registerGlobalReceiver(SeasonSettingsPayload.ID,(payload,context)->{
            var player=context.player();
            if(!mayEdit(player)){sendSeasons(player);return;}
            SeasonSystem.set(payload.settings());
            for(var online:player.getServer().getPlayerManager().getPlayerList())sendSeasons(online);
        });
        ServerPlayNetworking.registerGlobalReceiver(ManualPressurePayload.ID,(payload,context)->{
            var player=context.player();
            boolean owner=player.getServer().isSingleplayer() && player.getServer().getHostProfile()!=null
                && player.getUuid().equals(player.getServer().getHostProfile().getId());
            if(!player.hasPermissionLevel(2)&&!owner)return;
            if(payload.action()==1)SynopticRuntime.create(player.getX(),player.getZ(),ENGINE.simulatedSeconds(),false);
            else if(payload.action()==2)SynopticRuntime.create(player.getX(),player.getZ(),ENGINE.simulatedSeconds(),true);
            else if(payload.action()==3)SynopticRuntime.clear();
            else return;
            if(saveRoot!=null)SynopticRuntime.save(saveRoot);
        });
        ServerPlayNetworking.registerGlobalReceiver(SynopticControlPayload.ID,(payload,context)->{
            var player=context.player();
            boolean owner=player.getServer().isSingleplayer() && player.getServer().getHostProfile()!=null
                && player.getUuid().equals(player.getServer().getHostProfile().getId());
            if(!player.hasPermissionLevel(2)&&!owner){sendSynoptic(player);return;}
            var next=payload.settings();SynopticRuntime.set(next);
            if(saveRoot!=null)SynopticConfigStore.save(saveRoot,next);
            for(var online:player.getServer().getPlayerManager().getPlayerList())sendSynoptic(online);
        });
        ServerPlayNetworking.registerGlobalReceiver(WeatherSettingsPayload.ID,(payload,context)->{
            // All weather settings belong to the server; only the operator may change them.
            var player=context.player();
            boolean owner=player.getServer().isSingleplayer() && player.getServer().getHostProfile()!=null
                && player.getUuid().equals(player.getServer().getHostProfile().getId());
            if(!player.hasPermissionLevel(2) && !owner){sendSettings(player);return;}
            settings=payload.validated();
            ENGINE.setDynamics(settings);
            WeatherSettingsStore.save(settings);
            for(var online:player.getServer().getPlayerManager().getPlayerList())sendSettings(online);
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getRegistryKey() != net.minecraft.world.World.OVERWORLD) return;
            // Avoid Minecraft's global weather: showers are genuinely local client-side particles.
            if (world.getTime() % 200 == 0) world.setWeather(6000, 0, false, false);
            ENGINE.tick(world);
            if(world.getTime()%2400==0)saveAtmosphere();
            CloudEffects.tick(ENGINE,world);
            SnowCoverEngine.tick(ENGINE,world);
            StationManager.tick(ENGINE,world,settings);
            if(world.getTime()%40==0){
                for(var player:world.getPlayers()){
                    if(ServerPlayNetworking.canSend(player,CloudSnapshotPayload.ID))
                        ServerPlayNetworking.send(player,CloudEffects.snapshot(ENGINE,world,player));
                    if(ServerPlayNetworking.canSend(player,CloudDiagnosticPayload.ID))
                        ServerPlayNetworking.send(player,CloudEffects.diagnosticSnapshot(ENGINE,world,player));
                    if(ServerPlayNetworking.canSend(player,RainRadarPayload.ID))
                        ServerPlayNetworking.send(player,CloudEffects.radarSnapshot(world,player));
                    if(world.getTime()%100==0 && ServerPlayNetworking.canSend(player,SynopticMapPayload.ID))
                        ServerPlayNetworking.send(player,SynopticMapPayload.around(world.getTime(),player.getBlockX(),
                            player.getBlockZ(),ENGINE.simulatedSeconds(),SynopticRuntime.current()));
                }
            }
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(literal("meteo")
                .then(literal("clouds").executes(ctx -> {
                    var player=ctx.getSource().getPlayerOrThrow();
                    var report=CloudEffects.at(ENGINE,player.getServerWorld(),player.getBlockPos());
                    var cloud=report.diagnostic();
                    String msg=String.format(java.util.Locale.ROOT,"Meteo clouds | type %s | cover %.0f%% | LCL %.0f m | base +%.0f blocks | lift %.2f m/s",report.type(),report.cover()*100,cloud.lclMeters(),cloud.baseBlocks(),cloud.lift());
                    ctx.getSource().sendFeedback(() -> Text.literal(msg),false);
                    String wind=String.format(java.util.Locale.ROOT,
                        "Meteo wind | from %.0f deg (%s) | speed %.1f m/s | terrain %s | orographic %.2f m/s",
                        cloud.windFromDegrees(), compass(cloud.windFromDegrees()), cloud.windSpeed(),
                        cloud.terrainFlow(), cloud.terrainLift());
                    ctx.getSource().sendFeedback(() -> Text.literal(wind),false);
                    String state=String.format(java.util.Locale.ROOT,
                        "Meteo field | cloud water %.3f | RH %.0f%% | solar %.2f | spatial 64 blocks | updates %d",
                        report.water(),report.humidity()*100,report.solar(),report.updates());
                    ctx.getSource().sendFeedback(() -> Text.literal(state),false);
                    String budget=String.format(java.util.Locale.ROOT,
                        "Meteo budget | dWater %+.5f | condensation %.5f | evaporation %.5f | transport %+.5f | fog %s | rain %s",
                        report.deltaWater(),report.condensation(),report.evaporation(),report.transport(),
                        report.fog()?"yes":"no",report.rain()?"yes":"no");
                    ctx.getSource().sendFeedback(() -> Text.literal(budget),false);
                    String reservoirs=String.format(java.util.Locale.ROOT,
                        "Meteo moisture | vapor %.4f | liquid %.4f | rain sink %.5f | cell 64 blocks",
                        report.vapor(),report.water(),report.precipitation());
                    ctx.getSource().sendFeedback(() -> Text.literal(reservoirs),false);
                    String showers=String.format(java.util.Locale.ROOT,
                        "Meteo shower | %.2f mm/h | formation at X %.1f Z %.1f | local: %s",
                        report.rainMmHour(),report.cloudX(),report.cloudZ(),report.rain()?"rain/snow":"dry");
                    ctx.getSource().sendFeedback(() -> Text.literal(showers),false);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(literal("visual").executes(ctx -> {
                    var player=ctx.getSource().getPlayerOrThrow();
                    boolean supported=ServerPlayNetworking.canSend(player,CloudSnapshotPayload.ID);
                    String msg="Meteo 3D cloud volume | client channel "+(supported?"ready":"not registered")
                        +" | server sync every 40 ticks | moving clouds | nearby snapshots";
                    ctx.getSource().sendFeedback(() -> Text.literal(msg),false);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(literal("inspect").executes(ctx -> {
                    var player = ctx.getSource().getPlayerOrThrow();
                    ServerWorld world = player.getServerWorld();
                    BlockPos pos = player.getBlockPos();
                    var sample = ENGINE.sample(world, pos);
                    ctx.getSource().sendFeedback(() -> Text.literal("Meteo | x=" + pos.getX() + " z=" + pos.getZ() + " | ground=" + sample.terrainHeight() + "m | steps=" + sample.steps() + " | sim=" + String.format(java.util.Locale.ROOT, "%.1f", sample.simulatedSeconds() / 3600.0) + "h"), false);
                    for (var layer : sample.layers()) {
                        String line = String.format(java.util.Locale.ROOT,
                            "%s: %.1f C | %.0f hPa | RH %.0f%% | wind %.1f m/s | w %.2f m/s",
                            layer.name(), layer.temperatureC(), layer.pressureHpa(), layer.relativeHumidity() * 100,
                            Math.hypot(layer.windU(), layer.windV()), layer.verticalWind());
                        ctx.getSource().sendFeedback(() -> Text.literal(line), false);
                        String diagnostics = String.format(java.util.Locale.ROOT,
                            "  dew %.1f C | q %.2f g/kg | theta %.1f K",
                            layer.dewPointC(), layer.specificHumidityGkg(), layer.potentialTemperatureK());
                        ctx.getSource().sendFeedback(() -> Text.literal(diagnostics), false);
                    }
                    return Command.SINGLE_SUCCESS;
                }))
            )
        );
    }
}
