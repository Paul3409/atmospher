package de.meteo.client;

import de.meteo.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

/** Vanilla Minecraft fonts/buttons, no background blur. All pages fit smaller GUI-scaled screens. */
public final class MeteoScreen extends Screen {
    private static final String[] TABS={"Wetter","Jahreszeiten","Grafik","Wolken","Wind","Schnee",
        "Niederschlag","Druck","Fronten","Radar","Anzeige","Diagnose"};
    private static final String[] SMALL={"Wetter","Saison","Grafik","Wolken","Wind","Schnee",
        "Regen","Druck","Fronten","Radar","Anzeige","Daten"};
    private static int tab=0;
    private int left,contentW,top,contentTop,row,half;
    public MeteoScreen(){super(Text.literal("Meteo V1.8.0 | Wetter & Atmosphaere"));}
    private static Text t(String s){return Text.literal(s);}
    private void add(int x,int y,int w,String label,Runnable task){
        if(y+20>height-27)return;
        addDrawableChild(ButtonWidget.builder(t(label),b->task.run()).dimensions(x,y,Math.max(28,w),20).build());
    }
    private void full(int n,String label,Runnable task){add(left,contentTop+n*row,contentW,label,task);}
    private void two(int n,String a,Runnable taskA,String b,Runnable taskB){
        add(left,contentTop+n*row,half,a,taskA);
        add(left+half+6,contentTop+n*row,contentW-half-6,b,taskB);
    }
    private void refresh(){clearChildren();init();}
    public void syncRefresh(){refresh();}
    private void seasons(java.util.function.UnaryOperator<SeasonSystem.Settings> change){
        SeasonControls.change(change.apply(SeasonControls.current()));refresh();
    }
    private void snowCover(java.util.function.UnaryOperator<SnowCoverSettings.Settings> change){
        SnowCoverControls.change(change.apply(SnowCoverControls.current()));refresh();
    }
    private void weather(java.util.function.UnaryOperator<WeatherDynamics.Settings> change){
        WeatherControls.request(change.apply(WeatherControls.current()));refresh();
    }
    private void syn(java.util.function.UnaryOperator<SynopticWeather.Settings> change){
        SynopticControls.request(change.apply(SynopticControls.current()));refresh();
    }
    private void manual(int action){if(ClientPlayNetworking.canSend(ManualPressurePayload.ID))
        ClientPlayNetworking.send(new ManualPressurePayload(action));}
    private static String yes(boolean b){return b?"AN":"AUS";}
    @Override protected void init(){
        contentW=Math.min(600,width-16);left=(width-contentW)/2;top=19;
        row=height<280?22:26;half=(contentW-6)/2;
        int tabGap=3,tw=(contentW-5*tabGap)/6;
        for(int i=0;i<TABS.length;i++){
            final int target=i,r=i/6,c=i%6;
            int x=left+c*(tw+tabGap),y=top+r*23;
            addDrawableChild(ButtonWidget.builder(t((tab==i?"[":"")+(width<540?SMALL[i]:TABS[i])+(tab==i?"]":"")),b->{tab=target;refresh();})
                .dimensions(x,y,c==5?left+contentW-x:tw,20).build());
        }
        contentTop=top+55;
        var d=WeatherControls.current();var s=SynopticControls.current();var season=SeasonControls.current();
        switch(tab){
            case 0 -> {
                full(0,"Synoptisches Wetterradar (R)",()->MinecraftClient.getInstance().setScreen(new RadarScreen()));
                full(1,"Wetterwechsel: "+WeatherControls.paceName(),()->weather(a->new WeatherDynamics.Settings(
                    (a.pace()+1)%4,a.windMode(),a.variability(),a.fixedFrom(),a.meanWindKmh(),a.maxGustKmh())));
                full(2,"Lokale Wetterwarnungen: "+yes(s.warnings()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),
                    a.fronts(),a.hud(),!a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
                full(3,"Wetteranzeige oben links: "+yes(s.hud()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),
                    a.fronts(),!a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
            }
            case 1 -> {
                full(0,"Jahreszeiten: "+yes(season.enabled()),()->seasons(a->new SeasonSystem.Settings(!a.enabled(),a.daysPerSeason(),a.manualSeason(),a.temperatureAdjust())));
                full(1,"Saisonlänge: "+season.daysPerSeason()+" Tage",()->seasons(a->new SeasonSystem.Settings(a.enabled(),
                    a.daysPerSeason()>=56?7:a.daysPerSeason()*2,a.manualSeason(),a.temperatureAdjust())));
                String label=season.manualSeason()<0?"Automatisch":new String[]{"Fruehling","Sommer","Herbst","Winter"}[season.manualSeason()];
                full(2,"Jahreszeit: "+label,()->seasons(a->new SeasonSystem.Settings(a.enabled(),a.daysPerSeason(),
                    a.manualSeason()>=3?-1:a.manualSeason()+1,a.temperatureAdjust())));
                two(3,"Temperatur: "+String.format(java.util.Locale.GERMANY,"%+.0f °C",season.temperatureAdjust()),
                    ()->seasons(a->new SeasonSystem.Settings(a.enabled(),a.daysPerSeason(),a.manualSeason(),
                        a.temperatureAdjust()>=10?-10:a.temperatureAdjust()+2)),
                    "Temperatur zurücksetzen",()->seasons(a->new SeasonSystem.Settings(a.enabled(),a.daysPerSeason(),a.manualSeason(),0)));
            }
            case 2 -> {
                two(0,"Grafik: "+CloudVolumeRenderer.quality(),()->{var v=CloudVolumeRenderer.Quality.values();
                    CloudVolumeRenderer.setQuality(v[(CloudVolumeRenderer.quality().ordinal()+1)%v.length]);refresh();},
                    "Wolken: "+yes(CloudVolumeRenderer.enabled()),()->{CloudVolumeRenderer.setEnabled(!CloudVolumeRenderer.enabled());refresh();});
                two(1,"Wetternebel: "+yes(AmbientSettings.fog),()->{AmbientSettings.fog=!AmbientSettings.fog;AmbientSettings.save();refresh();},
                    "Nebelqualität: "+new String[]{"Niedrig","Normal","Hoch"}[AmbientSettings.fogQuality],()->{
                        AmbientSettings.fogQuality=(AmbientSettings.fogQuality+1)%3;AmbientSettings.save();refresh();});
                full(2,"Niederschlags-Sichttrübung: "+yes(VisibilitySettings.enabled),()->{
                    VisibilitySettings.enabled=!VisibilitySettings.enabled;VisibilitySettings.save();refresh();});
            }
            case 3 -> {
                full(0,"Wolkensichtweite: "+CloudVolumeRenderer.rangeBlocks()+" Blöcke",()->{CloudVolumeRenderer.cycleRange();refresh();});
                full(1,"Wolkenqualität: "+CloudVolumeRenderer.quality(),()->{var v=CloudVolumeRenderer.Quality.values();
                    CloudVolumeRenderer.setQuality(v[(CloudVolumeRenderer.quality().ordinal()+1)%v.length]);refresh();});
                full(2,"Wolkenoptimierung: "+CloudVolumeRenderer.optimizationName(),()->{
                    CloudVolumeRenderer.cycleOptimization();refresh();});
                full(3,"Testwolke: "+yes(CloudVolumeRenderer.preview()),()->{CloudVolumeRenderer.togglePreview();refresh();});
            }
            case 4 -> {
                full(0,"Windmodus: "+WeatherControls.modeName(),()->weather(a->new WeatherDynamics.Settings(
                    a.pace(),(a.windMode()+1)%3,a.variability(),a.fixedFrom(),a.meanWindKmh(),a.maxGustKmh())));
                two(1,"Variabilität: "+d.variability()+"%",()->weather(a->new WeatherDynamics.Settings(
                    a.pace(),a.windMode(),(a.variability()+10)%110,a.fixedFrom(),a.meanWindKmh(),a.maxGustKmh())),
                    "Windrichtung: "+WeatherControls.compass(),()->weather(a->new WeatherDynamics.Settings(
                    a.pace(),a.windMode(),a.variability(),(a.fixedFrom()+45)%360,a.meanWindKmh(),a.maxGustKmh())));
                two(2,"Grundwind: "+d.meanWindKmh()+" km/h",()->weather(a->new WeatherDynamics.Settings(
                    a.pace(),a.windMode(),a.variability(),a.fixedFrom(),(a.meanWindKmh()+5)%105,a.maxGustKmh())),
                    "Böen max: "+d.maxGustKmh()+" km/h",()->weather(a->new WeatherDynamics.Settings(
                    a.pace(),a.windMode(),a.variability(),a.fixedFrom(),a.meanWindKmh(),(a.maxGustKmh()+10)%170)));
            }
            case 5 -> {
                full(0,"Eigene Meteo-Schneeflocken: "+yes(SnowEffects.enabled),()->{SnowEffects.enabled=!SnowEffects.enabled;SnowEffects.save();refresh();});
                two(1,"Flockendichte: "+SnowEffects.density,()->{SnowEffects.density=(SnowEffects.density+1)%4;SnowEffects.save();refresh();},
                    "Flockengröße: "+SnowEffects.size,()->{SnowEffects.size=(SnowEffects.size+1)%4;SnowEffects.save();refresh();});
                two(2,"Fallgeschwindigkeit: "+SnowEffects.speed,()->{SnowEffects.speed=(SnowEffects.speed+1)%4;SnowEffects.save();refresh();},
                    "Winddrift: "+yes(SnowEffects.drift),()->{SnowEffects.drift=!SnowEffects.drift;SnowEffects.save();refresh();});
                var cover=SnowCoverControls.current();
                two(3,"Schneedecke: "+yes(cover.enabled()),()->snowCover(c->new SnowCoverSettings.Settings(
                    !c.enabled(),c.radius(),c.accumulation(),c.melt())),
                    "Radius: "+cover.radius()+" Bl.",()->snowCover(c->new SnowCoverSettings.Settings(
                    c.enabled(),c.radius()==50?75:c.radius()==75?100:c.radius()==100?150:50,c.accumulation(),c.melt())));
                two(4,"Ansammlung: "+new String[]{"Aus","Langsam","Normal","Schnell"}[cover.accumulation()],
                    ()->snowCover(c->new SnowCoverSettings.Settings(c.enabled(),c.radius(),(c.accumulation()+1)%4,c.melt())),
                    "Schmelze: "+new String[]{"Aus","Langsam","Normal","Schnell"}[cover.melt()],
                    ()->snowCover(c->new SnowCoverSettings.Settings(c.enabled(),c.radius(),c.accumulation(),(c.melt()+1)%4)));
            }
            case 6 -> {
                full(0,"Regenpartikel: "+yes(RainEffects.enabled()),()->{RainEffects.toggle();refresh();});
                two(1,"Regendichte: "+RainEffects.densityName(),()->{RainEffects.cycleDensity();refresh();},
                    "Tropfengröße: "+RainEffects.sizeName(),()->{RainEffects.cycleSize();refresh();});
                two(2,"Winddrift: "+yes(RainEffects.windDrift()),()->{RainEffects.toggleWindDrift();refresh();},
                    "Spritzer: "+yes(RainEffects.splashEnabled()),()->{RainEffects.toggleSplashes();refresh();});
                two(3,"Sichttrübung: "+new String[]{"Aus","Dezent","Normal","Stark"}[VisibilitySettings.intensity],()->{
                    VisibilitySettings.intensity=(VisibilitySettings.intensity+1)%4;VisibilitySettings.save();refresh();},
                    "Sichtweite: "+new String[]{"Weit","Normal","Kurz","Sehr kurz"}[VisibilitySettings.minimumVisibility],()->{
                    VisibilitySettings.minimumVisibility=(VisibilitySettings.minimumVisibility+1)%4;VisibilitySettings.save();refresh();});
            }
            case 7 -> {
                two(0,"Hochdruck: "+s.highStrength()+"%",()->syn(a->new SynopticWeather.Settings(
                    (a.highStrength()+25)%225,a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())),
                    "Tiefdruck: "+s.lowStrength()+"%",()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),(a.lowStrength()+25)%225,a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
                full(1,"Dauer: "+new String[]{"Kurz","Normal","Lang","Sehr lang"}[s.duration()],()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),(a.duration()+1)%4,a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
                two(2,"Hoch erzeugen",()->manual(1),"Tief erzeugen",()->manual(2));
                full(3,"Manuelle Druckgebiete löschen",()->manual(3));
            }
            case 8 -> {
                full(0,"Warm-, Kalt- & Okklusionsfronten: "+yes(s.fronts()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),!a.fronts(),a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
                full(1,"Frontenstärke: "+s.frontStrength()+"%",()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),(a.frontStrength()+25)%225,a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
                full(2,"Dunkle Wolkenfronten: "+yes(s.cloudFronts()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),a.isobars(),a.precip(),!a.cloudFronts())));
            }
            case 9 -> {
                full(0,"Radar öffnen (R)",()->MinecraftClient.getInstance().setScreen(new RadarScreen()));
                two(1,"Isobaren: "+yes(s.isobars()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),!a.isobars(),a.precip(),a.cloudFronts())),
                    "Niederschlag: "+yes(s.precip()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),a.warnings(),a.isobars(),!a.precip(),a.cloudFronts())));
                two(2,"Radarqualität: "+RadarScreen.qualityName(),()->{RadarScreen.cycleQuality();refresh();},
                    "Vorhersage im Radar",()->MinecraftClient.getInstance().setScreen(new RadarScreen()));
            }
            case 10 -> {
                full(0,"Wetteranzeige (H): "+yes(s.hud()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),!a.hud(),a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
                full(1,"Lokale Warnungen: "+yes(s.warnings()),()->syn(a->new SynopticWeather.Settings(
                    a.highStrength(),a.lowStrength(),a.duration(),a.frontStrength(),a.thunderFrequency(),a.stormStrength(),a.fronts(),a.hud(),!a.warnings(),a.isobars(),a.precip(),a.cloudFronts())));
            }
            case 11 -> {}
        }
        addDrawableChild(ButtonWidget.builder(t("Fertig"),b->close()).dimensions(left,height-24,contentW,20).build());
    }
    @Override public void renderBackground(DrawContext g,int mx,int my,float dt){
        // Opaque enough to read, without Minecraft's background blur shader.
        g.fill(0,0,width,height,0xf0182534);
    }
    @Override public void render(DrawContext g,int mx,int my,float dt){
        renderBackground(g,mx,my,dt);
        g.drawCenteredTextWithShadow(textRenderer,t("METEO V1.8.0 | Wetter & Atmosphaere"),width/2,6,0xfff5f5f5);
        if(tab==11){var lines=WeatherDiagnostics.rows();for(int i=0;i<lines.length;i++){
            int y=contentTop+4+i*12;if(y<height-30)
                g.drawCenteredTextWithShadow(textRenderer,t(lines[i]),width/2,y,0xffeeeeee);
        }}
        super.render(g,mx,my,dt);
    }
    @Override public void close(){MinecraftClient.getInstance().setScreen(null);}
    @Override public boolean shouldPause(){return false;}
}
