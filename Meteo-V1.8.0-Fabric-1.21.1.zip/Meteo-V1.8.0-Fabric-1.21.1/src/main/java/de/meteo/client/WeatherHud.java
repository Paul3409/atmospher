package de.meteo.client;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import java.util.Locale;
/** Vanilla Minecraft pixel font: unobtrusive optional top-left forecast and local warnings. */
public final class WeatherHud {
    private WeatherHud(){}
    private static boolean localEnabled=true;
    public static void toggle(){localEnabled=!localEnabled;}
    public static void render(DrawContext g,RenderTickCounter counter){
        var client=MinecraftClient.getInstance();
        if(!localEnabled||client.player==null||client.world==null||client.options.hudHidden||
           client.currentScreen!=null||!SynopticControls.current().hud())return;
        var d=WeatherDiagnostics.latest();if(d==null)return;
        var map=SynopticControls.map();
        int pressure=1013;
        if(map!=null && !map.grid().isEmpty())pressure=Math.round(map.grid().get(
            de.meteo.SynopticMapPayload.ROWS/2*de.meteo.SynopticMapPayload.COLS+de.meteo.SynopticMapPayload.COLS/2).pressure());
        double u=d.windU(),v=d.windV(),speed=Math.hypot(u,v);
        int from=(int)Math.round((Math.toDegrees(Math.atan2(-u,v))+360)%360);
        String[] dirs={"N","NO","O","SO","S","SW","W","NW"};
        String dir=dirs[((from+22)/45)%8];
        double rain=d.rainMmHour();
        double snowFraction=de.meteo.PrecipitationPhase.snowFraction(d.temperatureC());
        double snow=rain*snowFraction,liquid=rain-snow;
        String weather=rain>4?(snowFraction>.5?"Starker Schneefall":"Starker Regen"):
            rain>.1?(snowFraction>.5?"Schneefall":"Regen"):d.cover()>.7?"Bedeckt":d.cover()>.3?"Wolkig":"Aufgelockert";
        long time=client.world.getTimeOfDay();
        var season=SeasonControls.current();
        String name=season.enabled()?SeasonControls.name(time):"Ohne Jahreszeiten";
        String day=season.enabled()?" "+SeasonControls.day(time)+"/"+season.daysPerSeason():"";
        String[] lines={
            "METEO V1.8.0 | "+name+day+" | "+weather,
            String.format(Locale.GERMANY,"T: %.1f °C | Regen: %.1f | Schnee: %.1f mm/h",d.temperatureC(),liquid,snow),
            String.format(Locale.GERMANY,"Wind: %.0f km/h %s | Wolken: %.0f%%",speed*3.6,dir,d.cover()*100),
            String.format(Locale.GERMANY,"Luftdruck (NN): %d hPa | R: Radar",pressure)
        };
        int max=0;for(String l:lines)max=Math.max(max,client.textRenderer.getWidth(l));
        g.fill(7,7,max+21,64,0xc822324a);
        for(int i=0;i<lines.length;i++)g.drawTextWithShadow(client.textRenderer,Text.literal(lines[i]),13,13+i*12,
            i==0?0xfff4f8ff:i==3?0xffffd482:0xffdbe7ee);
        if(!SynopticControls.current().warnings())return;
        String warning=snow>=18&&speed>=12?"Warnung: Schneesturm am Standort":
            snow>=12?"Warnung: Starker Schneefall":liquid>=16?"Warnung: Starkregen am Standort":
            speed>=17?"Warnung: Starke Windboeen":null;
        if(warning==null&&map!=null){
            var center=map.grid().get(de.meteo.SynopticMapPayload.ROWS/2*de.meteo.SynopticMapPayload.COLS+
                de.meteo.SynopticMapPayload.COLS/2);
            if(center.front()>.73f)warning=switch(center.type()){
                case 1->"Hinweis: Warmfront am Standort";
                case 2->"Hinweis: Kaltfront am Standort";
                case 3->"Hinweis: Okklusionsfront am Standort";
                default->null;
            };
        }
        if(warning!=null){int y=68;int w=Math.max(max+21,client.textRenderer.getWidth(warning)+20);
            g.fill(7,y,w+7,y+25,0xcf1b293c);
            g.fill(7,y,10,y+25,0xffffd05b);
            g.drawTextWithShadow(client.textRenderer,Text.literal(warning),16,y+7,0xffffdc7f);
        }
    }
}
