"""Representative mathematical condensation distribution, not a game render."""
import pathlib,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=pathlib.Path(__file__).resolve().parents[1]
source=(root/'src/main/java/dev/atmosphere/companion/CloudRenderer.java').read_text()
table=source.split('private static final double[][] LOBES={',1)[1].split('};',1)[0]
lobes=np.array([[float(v) for v in row.split(',')] for row in re.findall(r'\{([^{}]+)\}',table)])
rng=np.random.default_rng(512041)
index=rng.integers(0,len(lobes),240); a=rng.uniform(0,2*np.pi,240); h=rng.uniform(-1,1,240)
r=np.cbrt(rng.random(240)); ring=np.sqrt(1-h*h); l=lobes[index]
x=l[:,0]+l[:,3]*r*ring*np.cos(a); y=l[:,1]+l[:,4]*r*h; z=l[:,2]+l[:,5]*r*ring*np.sin(a)
fig,axes=plt.subplots(1,2,figsize=(11,4),facecolor='#abc5e8')
for ax,v,title in zip(axes,(x,z),('Vorderansicht','Seitenansicht')):
    ax.set_facecolor('#abc5e8')
    for size,alpha in ((1800,.025),(950,.035),(400,.06)):
        ax.scatter(v,y,s=size,c='#303943',alpha=alpha,edgecolors='none')
    ax.set_xlim(-160,160);ax.set_ylim(-55,105);ax.set_aspect('equal');ax.set_title(title);ax.axis('off')
fig.suptitle('Kondensations-Verteilung: mathematische Skizze, kein Ingame-Bild')
fig.savefig(root/'cloud-condensation-preview.png',dpi=150,bbox_inches='tight')
