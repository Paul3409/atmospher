"""Mathematical preview of the renderer's lobe equations, not an ingame image."""
import pathlib, re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

root = pathlib.Path(__file__).resolve().parents[1]
source = (root/'src/main/java/dev/atmosphere/companion/CloudRenderer.java').read_text()
table = source.split('private static final double[][] LOBES = {', 1)[1].split('};', 1)[0]
lobes = [[float(n) for n in row.split(',')] for row in re.findall(r'\{([^{}]+)\}', table)]
n = 16
fig = plt.figure(figsize=(11, 5), facecolor='#b7c9e2')
for panel, view in enumerate(((10, -75), (28, -55)), 1):
    ax = fig.add_subplot(1, 2, panel, projection='3d', facecolor='#b7c9e2')
    polys, colors = [], []
    for seed, (ox, oy, oz, rx, ry, rz) in enumerate(lobes[:10]):
        def point(a,b):
            theta=2*np.pi*a/n; phi=np.pi*b/(n//2)
            wave=1+.095*np.sin(3*theta+seed)*np.sin(phi)**2+.055*np.cos(5*theta+2*phi+seed)
            shade=.39+.19*max(0,np.cos(phi))+.035*np.sin(theta*3+phi*5+seed)
            return (ox+rx*np.sin(phi)*np.cos(theta)*wave, oz+rz*np.sin(phi)*np.sin(theta)*wave, oy+ry*np.cos(phi)*wave), shade
        for a in range(n):
            for b in range(n//2):
                points = [point(a,b),point(a+1,b),point(a+1,b+1),point(a,b+1)]
                polys.append([p[0] for p in points])
                shade=max(0,min(1,sum(p[1] for p in points)/4))
                colors.append((shade,shade*1.02,shade*1.06,1))
    ax.add_collection3d(Poly3DCollection(polys, facecolors=colors, edgecolors='none'))
    ax.set(xlim=(-145,145),ylim=(-145,145),zlim=(-30,100))
    ax.set_box_aspect((290,290,130)); ax.view_init(*view); ax.set_axis_off()
fig.suptitle('Atmosphere 0.1.0 – mathematisches Geometriemodell (kein Ingame-Bild)')
fig.savefig(root/'cloud-math-preview.png',dpi=150,bbox_inches='tight')
