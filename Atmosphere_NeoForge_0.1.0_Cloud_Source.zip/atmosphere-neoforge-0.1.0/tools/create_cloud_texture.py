"""Generate a soft, irregular condensation sprite from deterministic noise."""
from pathlib import Path
import math, random
from PIL import Image

size=128
rng=random.Random(7921)
waves=[(rng.uniform(.08,.26),rng.uniform(.08,.26),rng.uniform(0,2*math.pi),rng.uniform(.4,1)) for _ in range(18)]
image=Image.new('RGBA',(size,size))
for y in range(size):
    for x in range(size):
        dx=(x+0.5-size/2)/(size/2); dy=(y+0.5-size/2)/(size/2)
        r=math.hypot(dx,dy)
        envelope=max(0,min(1,(1-r)/.47))
        envelope=envelope*envelope*(3-2*envelope)
        noise=sum(a*math.sin(x*fx+y*fy+p) for fx,fy,p,a in waves)/sum(w[3] for w in waves)
        density=max(0,min(1,envelope*(.65+.6*noise)))
        image.putpixel((x,y),(255,255,255,round(density*255)))
path=Path(__file__).resolve().parents[1]/'src/main/resources/assets/atmosphere_companion/textures/cloud_puff.png'
path.parent.mkdir(parents=True,exist_ok=True)
image.save(path)
