package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Included only with -PsmokeTest; never included in the published foundation JAR. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class NeoSmoke {
    private static int ticks,boot;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("atmosphere.smokeTest"))return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null){
            if(++boot%200==0)System.out.println("ATMOSPHERE_NEO_WAIT screen="+(mc.screen==null?"none":mc.screen.getClass().getName()));
            if(boot>1800)mc.stop();
            return;
        }
        ticks++;
        if(ticks==30){
            mc.options.hideGui=true;
            mc.player.connection.sendCommand("gamemode spectator");
            mc.player.connection.sendCommand("tp @s 0 110 0 0 -15");
            System.out.println("ATMOSPHERE_NEO_WORLD_READY");
        }
        if(ticks==100)Screenshot.grab(mc.gameDirectory,"neo-underside.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==150)mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
        if(ticks==500)Screenshot.grab(mc.gameDirectory,"neo-foundation.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==580)mc.stop();
    }
}
