package dev.atmosphere.companion;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client-only options: each one affects the renderer immediately. */
public final class CloudConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue HEIGHT;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;
    public enum Quality { LOW, MEDIUM, HIGH }
    static {
        var builder = new ModConfigSpec.Builder();
        builder.push("clouds");
        HEIGHT = builder.comment("Cloud base height in world coordinates (blocks).").defineInRange("height", 160, 96, 256);
        QUALITY = builder.comment("Number of condensation sprites; higher uses more graphics resources.").defineEnum("quality", Quality.MEDIUM);
        builder.pop();
        SPEC = builder.build();
    }
    private CloudConfig() {}
}
