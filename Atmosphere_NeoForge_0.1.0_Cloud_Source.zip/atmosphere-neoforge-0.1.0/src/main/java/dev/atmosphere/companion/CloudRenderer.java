package dev.atmosphere.companion;

import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Experimental client-only condensation: no weather or precipitation simulation. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class CloudRenderer {
    private static final double GRID=512.0;
    private static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,"textures/cloud_puff.png");
    private static final double[][] LOBES={
        {0,0,0,90,25,68},{-55,2,0,58,26,56},{55,4,0,61,28,55},
        {0,8,46,60,30,50},{0,8,-46,64,31,50},{-35,23,20,48,30,45},
        {35,26,-12,52,33,48},{0,38,0,48,33,48},{-70,-5,24,36,18,30},
        {72,-4,-22,37,19,34},{-18,-13,-42,39,18,31},{28,-13,40,39,18,32}
    };
    private record Puff(float x,float y,float z,float size,float shade) {}
    private record Draw(Puff p,float x,float y,float z,double distance) {}
    private static List<Puff> puffs;
    private static CloudConfig.Quality cachedQuality;
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var quality=CloudConfig.QUALITY.get();
        if(puffs==null||cachedQuality!=quality)prepare(quality);
        var cam=event.getCamera().getPosition();
        int cx=(int)Math.floor(cam.x/GRID),cz=(int)Math.floor(cam.z/GRID);
        var visible=new ArrayList<Draw>();
        for(int gx=cx-1;gx<=cx+1;gx++)for(int gz=cz-1;gz<=cz+1;gz++){
            double ox=gx*GRID-cam.x,oy=CloudConfig.HEIGHT.get()-cam.y,oz=gz*GRID-cam.z;
            if(ox*ox+oz*oz>420*420)continue;
            for(Puff p:puffs){
                float x=(float)(ox+p.x),y=(float)(oy+p.y),z=(float)(oz+p.z);
                visible.add(new Draw(p,x,y,z,(double)x*x+(double)y*y+(double)z*z));
            }
        }
        visible.sort(Comparator.comparingDouble(Draw::distance).reversed());
        var camera=event.getCamera();
        Vector3f right=new Vector3f(1,0,0).rotate(camera.rotation());
        Vector3f up=new Vector3f(0,1,0).rotate(camera.rotation());
        Matrix4f mat=event.getPoseStack().last().pose();
        var buffers=mc.renderBuffers().bufferSource();
        var type=RenderType.entityTranslucent(TEXTURE);
        var out=buffers.getBuffer(type);
        for(Draw d:visible){
            float s=d.p.size,shade=d.p.shade;
            corner(out,mat,d,right,up,-s,-s,0,1,shade);
            corner(out,mat,d,right,up, s,-s,1,1,shade);
            corner(out,mat,d,right,up, s, s,1,0,shade);
            corner(out,mat,d,right,up,-s, s,0,0,shade);
        }
        buffers.endBatch(type);
    }
    private static void corner(VertexConsumer out,Matrix4f m,Draw d,Vector3f r,Vector3f u,float a,float b,float tx,float ty,float shade){
        out.addVertex(m,d.x+r.x*a+u.x*b,d.y+r.y*a+u.y*b,d.z+r.z*a+u.z*b)
            .setColor(shade,shade*1.02f,shade*1.06f,.19f).setUv(tx,ty)
            .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(0,1,0);
    }
    private static void prepare(CloudConfig.Quality quality){
        cachedQuality=quality;
        int count=quality==CloudConfig.Quality.LOW?120:quality==CloudConfig.Quality.MEDIUM?240:400;
        Random random=new Random(512041);
        var result=new ArrayList<Puff>(count);
        for(int i=0;i<count;i++){
            double[] l=LOBES[random.nextInt(LOBES.length)];
            double a=random.nextDouble()*Math.PI*2, h=random.nextDouble()*2-1;
            double radius=Math.cbrt(random.nextDouble()), ring=Math.sqrt(1-h*h);
            float x=(float)(l[0]+l[3]*radius*ring*Math.cos(a));
            float y=(float)(l[1]+l[4]*radius*h);
            float z=(float)(l[2]+l[5]*radius*ring*Math.sin(a));
            float size=15+random.nextFloat()*16;
            float shade=Math.max(.31f,Math.min(.67f,.43f+y*.0022f+random.nextFloat()*.06f));
            result.add(new Puff(x,y,z,size,shade));
        }
        puffs=List.copyOf(result);
    }
    private CloudRenderer(){}
}
