package dev.atmosphere.companion;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** A first independent deterministic cloud field. Not a weather simulation. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID, value=Dist.CLIENT)
public final class CloudRenderer {
    private static final double GRID = 512.0;
    private static final double[][] LOBES = {
        {0,0,0,90,27,72}, {-58,3,0,58,24,58}, {55,5,0,63,29,57},
        {0,8,48,62,30,51}, {5,8,-48,66,31,53}, {-35,25,20,50,29,47},
        {35,28,-12,55,34,51}, {0,40,0,50,34,50}, {-70,-5,25,35,17,32},
        {75,-4,-22,38,18,35}, {-18,-12,-44,38,16,31}, {28,-13,42,39,17,34}
    };
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if (event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        var mc=Minecraft.getInstance();
        if (mc.level==null || mc.level.dimension()!=Level.OVERWORLD) return;
        var camera=event.getCamera().getPosition();
        int cx=(int)Math.floor(camera.x/GRID), cz=(int)Math.floor(camera.z/GRID);
        var buffers=mc.renderBuffers().bufferSource();
        var out=buffers.getBuffer(RenderType.debugQuads());
        Matrix4f matrix=event.getPoseStack().last().pose();
        var quality=CloudConfig.QUALITY.get();
        int segments=quality==CloudConfig.Quality.LOW?10:quality==CloudConfig.Quality.MEDIUM?16:24;
        int count=quality==CloudConfig.Quality.LOW?7:quality==CloudConfig.Quality.MEDIUM?10:12;
        for(int gx=cx-1;gx<=cx+1;gx++) for(int gz=cz-1;gz<=cz+1;gz++) {
            double x=gx*GRID-camera.x, z=gz*GRID-camera.z;
            if(x*x+z*z>420*420)continue;
            double y=CloudConfig.HEIGHT.get()-camera.y;
            for(int i=0;i<count;i++) drawLobe(out,matrix,x,y,z,LOBES[i],segments,i);
        }
        buffers.endBatch(RenderType.debugQuads());
    }
    private static void drawLobe(VertexConsumer out, Matrix4f mat,double x,double y,double z,double[] l,int n,int seed) {
        int rings=n/2;
        for(int a=0;a<n;a++) for(int b=0;b<rings;b++) {
            vertex(out,mat,x,y,z,l,a,b,n,rings,seed);
            vertex(out,mat,x,y,z,l,a+1,b,n,rings,seed);
            vertex(out,mat,x,y,z,l,a+1,b+1,n,rings,seed);
            vertex(out,mat,x,y,z,l,a,b+1,n,rings,seed);
        }
    }
    private static void vertex(VertexConsumer out,Matrix4f mat,double x,double y,double z,double[] l,int a,int b,int n,int rings,int seed) {
        double theta=2*Math.PI*a/n, phi=Math.PI*b/rings;
        double wave=1+0.095*Math.sin(3*theta+seed)*Math.sin(phi)*Math.sin(phi)+0.055*Math.cos(5*theta+2*phi+seed);
        double sx=Math.sin(phi)*Math.cos(theta), sy=Math.cos(phi), sz=Math.sin(phi)*Math.sin(theta);
        float shade=(float)(0.39+0.19*Math.max(0,sy)+0.035*Math.sin(theta*3+phi*5+seed));
        out.addVertex(mat,(float)(x+l[0]+l[3]*sx*wave),(float)(y+l[1]+l[4]*sy*wave),(float)(z+l[2]+l[5]*sz*wave))
            .setColor(shade,shade*1.02f,shade*1.06f,1f);
    }
}
