# Atmosphere – unabhängiger Neustart 0.1.0

Eigenständige Grundlage für Minecraft 1.21.1, NeoForge 21.1.219 und Java 21. Keine Abhängigkeit von Simple Clouds oder einer anderen Wettermod. Ein eigener Wolkenrenderer und Wetterfunktionen sind noch nicht implementiert.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
