# Atmosphere – unabhängiger Neustart 0.1.0

Eigenständiges experimentelles Kondensationsmodell für Minecraft 1.21.1, NeoForge 21.1.219 und Java 21. Keine Abhängigkeit von Simple Clouds oder einer anderen Wettermod. Es simuliert kein Wetter und erzeugt keinen Niederschlag. Die Bildqualität und Leistung müssen noch im Spiel geprüft werden.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Die Einstellungen für Wolkenhöhe und Qualität liegen im NeoForge-Modmenü bei Atmosphere Companion unter Konfiguration. Nur die Oberwelt enthält experimentelle Wolken. Das Modell ist derzeit statisch und ersetzt nicht die Vanilla-Wolken.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
