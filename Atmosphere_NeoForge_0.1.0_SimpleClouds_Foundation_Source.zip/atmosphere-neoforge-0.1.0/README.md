# Atmosphere Companion 0.1.0 – Neustart

Neue, separate Grundlage fuer Minecraft genau 1.21.1, NeoForge genau 21.1.219 und Java 21.
Kein Fabric-Port, kein Import alter Welten und keine Wiederverwendung des alten Wolkenrenderers.

Das originale Simple Clouds ist eine separat erforderliche Mod. Die Companion-JAR registriert sich und prueft ihre Abhaengigkeit; sie hat noch keine eigenen Wetterfunktionen, Sirenen oder Radaroberflaechen. Simple Clouds allein besitzt Wolken und Wetter. Kein Simple-Clouds-Quellcode oder dessen Assets werden in unsere JAR kopiert.

## Abhaengigkeiten und Entwicklung

tools/resolve_clouds.py laedt nur offizielle, passende Modrinth-Versionen fuer 1.21.1/NeoForge in die Wegwerf-Testinstallation run/mods, prueft SHA-512 und protokolliert genaue Versionen/Dateinamen in build/thirdparty-lock.json.
Es akzeptiert nur die Simple-Clouds-0.7.x-Reihe, keine experimentelle neueste Minecraft-Version. Ist keine passende Version vorhanden, bricht es ab.
Drittanbieter-JARs werden weder in die Quell-ZIP noch in unsere Build-JAR eingebettet.
Lizenzbedingungen von Simple Clouds und Abhaengigkeiten gelten eigenstaendig.

Gradle 8.14.3 und Java 21: gradle clean build. BUILD_WINDOWS.bat nutzt Gradle im PATH.
gradle runClient nutzt run/mods. Nur mit -PsmokeTest wird die separate Testklasse mitkompiliert; Produktions-Build ohne diese Option ausfuehren.
Die CI erstellt eine neue natuerliche Testwelt und versucht mit dem originalen Renderer echte Clientbilder aufzunehmen. Keine Bilder oder Funktionen als erfolgreich getestet betrachten, bevor die entsprechende CI-Stufe erfolgreich ist.

## Schutz bestehender Daten / Sicherheit

Keine bisherige Fabric-Welt oder deren Sirenenbloecke mit diesem neuen Profil oeffnen. Nur eine neue Testwelt benutzen; fuer eine Migration ist gesonderte Planung notwendig.
Die fruehere Chrome-Warnung ist weiterhin ungeklärt. Ein neuer Modloader oder neuer Build ist keine Sicherheitsfreigabe. Es erfolgt keine unabhaengige Malware-Pruefung und es wird keine Umgehung von Schutzfunktionen empfohlen.
