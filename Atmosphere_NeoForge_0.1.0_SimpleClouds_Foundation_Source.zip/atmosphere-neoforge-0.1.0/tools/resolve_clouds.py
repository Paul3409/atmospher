"""Resolve official NeoForge 1.21.1 runtime mods; never bundle them in our JAR."""
import hashlib,io,json,pathlib,urllib.request,urllib.parse,zipfile,tomllib
root=pathlib.Path(__file__).resolve().parents[1]
api='https://api.modrinth.com/v2/'
def request(url):
 req=urllib.request.Request(url,headers={'User-Agent':'Atmosphere-private-development/0.1.0'})
 with urllib.request.urlopen(req,timeout=90) as response:return response.read()
def info(path):return json.loads(request(api+path))
def compatible(v):return '1.21.1' in v['game_versions'] and 'neoforge' in v['loaders']
def resolve(project):
 query=urllib.parse.urlencode({'loaders':'["neoforge"]','game_versions':'["1.21.1"]'})
 versions=info('project/'+project+'/version?'+query)
 if project=='simple-clouds':versions=[v for v in versions if v['version_number'].startswith('0.7.3')]
 if not versions:raise RuntimeError('No explicitly supported NeoForge 1.21.1 version for '+project)
 return versions[0]
target=root/'run/mods';target.mkdir(parents=True,exist_ok=True)
lock=[];seen=set();ids=set()
def install(v):
 if v['id'] in seen:return
 if not compatible(v):raise RuntimeError('Wrong Minecraft version/loader: '+v['version_number'])
 seen.add(v['id'])
 f=next((f for f in v['files'] if f.get('primary')),v['files'][0])
 if not f['filename'].endswith('.jar') or pathlib.Path(f['filename']).name!=f['filename']:raise RuntimeError('Unexpected filename')
 if not f['url'].startswith('https://cdn.modrinth.com/'):raise RuntimeError('Unexpected download host')
 data=request(f['url'])
 if hashlib.sha512(data).hexdigest()!=f['hashes']['sha512']:raise RuntimeError('Publisher hash mismatch')
 with zipfile.ZipFile(io.BytesIO(data)) as jar:
  path='META-INF/neoforge.mods.toml'
  if path not in jar.namelist():raise RuntimeError('Not a NeoForge mod: '+f['filename'])
  metadata=tomllib.loads(jar.read(path).decode())
  modids=[m['modId'] for m in metadata['mods']];ids.update(modids)
  if 'META-INF/jarjar/metadata.json' in jar.namelist():
   nested=json.loads(jar.read('META-INF/jarjar/metadata.json'))
   for entry in nested.get('jars',[]):
    with zipfile.ZipFile(io.BytesIO(jar.read(entry['path']))) as child:
     if 'META-INF/neoforge.mods.toml' in child.namelist():
      childmeta=tomllib.loads(child.read('META-INF/neoforge.mods.toml').decode())
      for m in childmeta.get('mods',[]):
       ids.add(m['modId']);modids.append(m['modId'])
       print('EMBEDDED_OFFICIAL',m['modId'],m.get('version','unknown'))
 (target/f['filename']).write_bytes(data)
 lock.append({'project_id':v['project_id'],'version':v['version_number'],'version_id':v['id'],'filename':f['filename'],'url':f['url'],'sha512':f['hashes']['sha512'],'mod_ids':modids})
 print('OFFICIAL_RUNTIME',f['filename'],','.join(modids))
 for dep in v.get('dependencies',[]):
  if dep['dependency_type']=='required':
   child=info('version/'+dep['version_id']) if dep.get('version_id') else resolve(dep['project_id'])
   install(child)
install(resolve('simple-clouds'))
if 'crackerslib' not in ids:raise RuntimeError('Official all-JAR does not contain required CrackersLib; refusing to guess a replacement')
if not {'simpleclouds','crackerslib'}<=ids:raise RuntimeError('Missing required official mods')
(root/'build').mkdir(exist_ok=True)
(root/'build/thirdparty-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
print('Pinned official runtime; SHA-512 checks are integrity checks, NOT malware clearance.')
