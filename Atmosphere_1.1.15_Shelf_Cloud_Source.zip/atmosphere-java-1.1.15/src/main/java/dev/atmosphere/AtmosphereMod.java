package dev.atmosphere;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public final class AtmosphereMod implements ModInitializer {
    public static final SimpleParticleType RAIN_STREAK = FabricParticleTypes.simple(false);
    public static final SimpleParticleType SNOW_FLAKE = FabricParticleTypes.simple(false);
    public static final SimpleParticleType GRAUPEL = FabricParticleTypes.simple(false);
    public static final SimpleParticleType HAIL = FabricParticleTypes.simple(false);
    public static final SimpleParticleType VORTEX_DUST = FabricParticleTypes.simple(false);
    public static final SoundEvent TORNADO_ROAR = registerSound("tornado_roar");

    public static final SoundEvent RAIN_LIGHT = registerSound("rain_light");
    public static final SoundEvent RAIN_HEAVY = registerSound("rain_heavy");
    public static final SoundEvent WIND_SOUND = registerSound("wind");
    public static final SoundEvent SNOW_WIND = registerSound("snow_wind");
    public static final SoundEvent GRAUPEL_SOUND = registerSound("graupel");
    public static final SoundEvent HAIL_SOUND = registerSound("hail");
    public static final SoundEvent THUNDER_NEAR = registerSound("thunder_near");
    public static final SoundEvent THUNDER_FAR = registerSound("thunder_far");

    public static final SoundEvent RAIN_MEDIUM = registerSound("rain_medium");
    public static final SoundEvent RAIN_ROOF = registerSound("rain_roof");
    public static final SoundEvent WIND_GUST = registerSound("wind_gust");
    public static final SoundEvent WIND_STRONG = registerSound("wind_strong");
    public static final SoundEvent THUNDER_DISTANT = registerSound("thunder_distant");

    public static final SoundEvent WIND_FRONT = registerSound("wind_front");
    public static final SoundEvent WIND_FOREST = registerSound("wind_forest");
    public static final SoundEvent WIND_ROOF = registerSound("wind_roof");
    public static final SoundEvent WIND_DOWNBURST = registerSound("wind_downburst");
    public static final SoundEvent WIND_LIGHT = registerSound("wind_light");
    public static final SoundEvent WIND_SWIRL = registerSound("wind_swirl");
    public static final SoundEvent STORM_APPROACH = registerSound("storm_approach");
    public static final SoundEvent BLIZZARD = registerSound("blizzard");
    public static final SoundEvent SNOW_LIGHT = registerSound("snow_light");
    public static final SoundEvent SNOW_GUST = registerSound("snow_gust");
    public static final SoundEvent RAIN_EXTREME = registerSound("rain_extreme");
    public static final SoundEvent DRIZZLE = registerSound("drizzle");
    public static final SoundEvent THUNDER_RUMBLE = registerSound("thunder_rumble");
    public static final SoundEvent THUNDER_MULTI = registerSound("thunder_multi");
    public static final SoundEvent THUNDER_CRACK = registerSound("thunder_crack");
    public static final SoundEvent THUNDER_DEEP = registerSound("thunder_deep");
    public static final SoundEvent THUNDER_ROLL = registerSound("thunder_roll");
    public static final SoundEvent HAIL_HEAVY = registerSound("hail_heavy");
    public static final SoundEvent HAIL_LIGHT = registerSound("hail_light");
    public static final SoundEvent HEAVY_RAIN_CLASSIC = registerSound("heavy_rain");
    public static final SoundEvent WIND_BASE_CLASSIC = registerSound("wind_base");
    private static SoundEvent registerSound(String path) {
        Identifier id = Identifier.of("atmosphere", path);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    @Override public void onInitialize() {
        Registry.register(Registries.PARTICLE_TYPE, Identifier.of("atmosphere", "rain_streak"), RAIN_STREAK);
        Registry.register(Registries.PARTICLE_TYPE, Identifier.of("atmosphere", "snow_flake"), SNOW_FLAKE);
        Registry.register(Registries.PARTICLE_TYPE, Identifier.of("atmosphere", "graupel"), GRAUPEL);
        Registry.register(Registries.PARTICLE_TYPE, Identifier.of("atmosphere", "hail"), HAIL);
        Registry.register(Registries.PARTICLE_TYPE, Identifier.of("atmosphere", "vortex_dust"), VORTEX_DUST);
        // Atmosphere storms are harmless client effects. Disable naturally
        // generated vanilla thunder in integrated worlds to avoid fire/damage.
        // Commands deliberately summoning lightning are outside this safeguard.
        ServerTickEvents.START_WORLD_TICK.register(world -> {
            if (world.getRegistryKey() == World.OVERWORLD && !world.getServer().isDedicated()
                    && world.isThundering()) world.setWeather(6000, 0, false, false);
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            // Local worlds only: settings are deliberately not sent across a network.
            if (world.getRegistryKey() != World.OVERWORLD || world.getServer().isDedicated()) return;
            SnowAndLeaves.tick(world, AtmosphereSettings.get());
            if (world.getTime() % 40 == 0) { StormEvents.sync(world); ManualPressureSystems.sync(world); }
        });
    }
}
