from pathlib import Path
r=Path(__file__).resolve().parent.parent
base=r/'src/main/java/de/meteo'
cloud=(base/'client/CloudVolumeRenderer.java').read_text()
assert 'CloudStability.approach' in cloud and 'clientTicks' in cloud
assert 'lastSeenTick>1800' in cloud
assert 'fieldTarget' in cloud and 'visibilityTarget' in cloud
assert 'if(receiveClientTick>=0&&Math.abs' not in cloud
assert 'for(Volume v:active)' in cloud
rain=(base/'client/RainEffects.java').read_text()
assert 'Heightmap.Type.MOTION_BLOCKING' in rain and 'd.y<=d.ground' in rain
assert 'DROPS.add' in rain and 'WorldRenderContext' in rain
menu=(base/'client/MeteoScreen.java').read_text()
for tab in ('Wetter','Grafik','Wind','Schnee','Druck','Diagnose'):assert tab in menu
for control in ('Tropfengröße','Regendichte','Regenstreifen'):assert control in menu
assert 'WorldRenderEvents.LAST.register(RainEffects::render)' in (base/'client/MeteoClient.java').read_text()
assert 'mod_version=1.5.1' in (r/'gradle.properties').read_text()
print('PASS P4 source regression: stable clouds, custom rain, six-tab UI, client hook')
