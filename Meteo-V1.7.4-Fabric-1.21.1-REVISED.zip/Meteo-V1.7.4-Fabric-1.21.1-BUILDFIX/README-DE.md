**AKTUELL V1.7.4:** Bitte zuerst `README-V1.7.4.md` lesen.

**NEU V1.7.1:** Siehe README-V1.7.1.md und V1.7.1-TESTPLAN.md.

# Meteo V1.7.0 – Minecraft Java 1.21.1 / Fabric / Java 21

Vollständiges Quellprojekt auf Basis von Meteo V1.6.0. Die gewohnten Wolken-, Regen-, Wind-, Radar- und Stationssysteme wurden **weiterentwickelt**, nicht ersetzt. Die Mod fügt keine Sounds hinzu und färbt Biome/Bäume jahreszeitlich nicht um.

## Bauen

1. ZIP vollständig entpacken.
2. Windows-CMD **im Verzeichnis mit `build.gradle`** öffnen.
3. Bauen mit:

    "C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace

4. Nach `BUILD SUCCESSFUL` die normale JAR (nicht `-sources.jar`) aus `build\libs` in `mods` installieren. Alte Meteo-JAR entfernen.
5. **Vor dem ersten Start eine Sicherheitskopie von Nebelthal anlegen.** Die Stationen erhalten eine aktualisierte Archivdatei; das alte v1-Archiv wird noch gelesen, aber das neue Format ist für ältere Meteo-Versionen nicht rückwärtskompatibel.

## V1.7.0 – neue Funktionen

- **Daten-Jahreszeiten**: Frühling, Sommer, Herbst, Winter; 7/14/28/56 Tage; automatisch oder manuell; eingestellter Temperaturversatz. Jahreszeit pro Welt in `data/meteo-seasons.properties` gespeichert. Keine Blätter-, Gras- oder Schneelandschaftsumfärbung.
- **Jahreszeitliches Wetter**: Tagesgang und saisonale Kälte/Wärme ergänzen die ursprüngliche, höhenabhängige Lufttemperatur. Daraus berechnen sich Regen-/Schneeübergänge am jeweiligen Ort.
- **Eigene Flockenrenderer**: unabhängig von Vanilla-Partikeln; Dichte, Größe, Fallgeschwindigkeit, Winddrift. Regendrops bleiben, bei Mischphasen werden beide Arten möglich. Client-Einstellungen `config/meteo-snow.properties`.
- **Sichttrübung**: einstellbare Distanzhüllen rund um die Kamera, im Schnee heller, im Regen grauer. Fernsicht bei starkem Niederschlag eingeschränkt; die direkte Umgebung und Benutzeroberfläche bleiben lesbar. Das ist eine leichte, eigene Annäherung an atmosphärischen Dunst und **kein vollwertiger Minecraft-Fog-Shader**. Client-Einstellungen `config/meteo-visibility.properties`.
- **Wolkentypen**: wetterabhängiger Cumulonimbus mit Turm/Ambossansatz, breiter Nimbostratus, größerer Stratocumulus, lückiger mittelhoher Altocumulus; breite dunkle Frontdecke. Bestehende Voxel-Wolkenoptik bleibt. Cb wird nur bei passend hohen Kondensat- und Hebungswerten ausgelöst.
- **Fernsicht Wolken**: Anzeigeauswahl von 256 bis 1792 Blöcken; vereinfachte Meshes in mittlerer/großer Entfernung. Wichtig: Wolken können nur dort gezeigt werden, wo der Server tatsächlich Formationen simuliert und überträgt. Höhere Reichweite garantiert keine dauerhaft gefüllten Horizonte.
- **Synoptisches Radar**: breites, klassisches Minecraft-Raster, weiße Drucklinien, Hoch/Tief, dünnere farbige Fronten, feinere Niederschlagspixel und Qualitätsregler Niedrig/Normal/Hoch. Vorhersage +3/+6/+9 Stunden aus der Druck-/Frontsimulation (keine ungesicherte Regenprognose).
- **O-Menü / Stationen**: klassische Schaltflächen, Minecraft-Standardschrift, kein eigener Blur; zwölf aufgeräumte Einstellungsseiten. Stationsanzeige / Archiv verwenden eine höhenabhängig kompakte Anordnung.
- **HUD & Warnungen**: Jahreszeit und Tag, Regen-/Schneerate, bei Starkschnee/Schneesturm entsprechende Hinweise.
- **Wetterstationen**: Schneefallrate (mm/h Wasseräquivalent) und akkumulierter Schneeniederschlag (mm Wasseräquivalent) mit zwei zusätzlichen Diagrammen und Archivspalten. Alte V1.5/1.6-Archive werden eingelesen.

## Steuerung

O: Einstellungen; R: synoptisches Radar; H: Wetteranzeige; Rechtsklick auf Meteo-Wetterstation für Archiv.

## Was noch nicht behauptet werden kann

Die eigenständigen Java-21-Tests und eine Syntaxprüfung sind erfolgreich. Ein **vollständiger Fabric-Loom-Build und ein Start von Minecraft** waren in dieser Umgebung nicht möglich (Gradle/Fabric-Artefakte fehlen und Download ist nicht verfügbar). Falls der Windows-Build fehlschlägt, bitte den **ersten Fehlerblock** der Ausgabe schicken. Die echten Darstellungen von Schnee, Radar, Nebel und Menüs müssen in Minecraft getestet werden. Druck-/Frontvorhersagen sind vereinfachte Simulationen; keine präzisen numerischen Wettervorhersagen.
