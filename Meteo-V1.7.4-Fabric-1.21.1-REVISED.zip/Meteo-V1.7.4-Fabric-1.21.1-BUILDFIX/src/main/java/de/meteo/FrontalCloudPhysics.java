package de.meteo;

/** Shared synoptic forcing for real, evolving cloud parcels and their high-cloud veil.
 * Intensity and type originate from the same world-space field as the synoptic radar.
 * This is a mesoscale approximation rather than a full atmospheric solver.
 */
public final class FrontalCloudPhysics {
    private FrontalCloudPhysics() {}
    public record Stage(double advance,double core,double ascent,byte type) {
        public boolean approaching(){return advance>.045 && core<.50;}
        public boolean active(){return core>.17;}
    }
    private static double clamp(double v,double min,double max){return Math.max(min,Math.min(max,v));}
    public static Stage at(SynopticWeather.State now,SynopticWeather.State future,double humidity){
        // Front visibility must not be gated by pre-existing cloud condensate.
        // Dry air reduces condensate, but cannot erase a synoptic front entirely.
        double moist=.50+.50*clamp((humidity-.28)/.60,0,1);
        double intensity=clamp(now.frontIntensity(),0,1);
        double coming=clamp(future.frontIntensity(),0,1);
        double core=intensity*moist;
        // Ahead of the advancing band: a broad leading high-cloud envelope,
        // narrowing into a thick deck as the actual frontal zone arrives.
        double advance=clamp((Math.pow(Math.max(intensity,coming),.60)-intensity*.50)*moist,0,1);
        byte type=intensity>=.13?now.frontType():future.frontType();
        double lift=(type==2?.52:type==3?.42:.32)*core+.10*advance;
        return new Stage(advance,core,lift,type);
    }
    /** Modelled synoptic precipitation POSSIBILITY, not observed cloud-water rain.
     * Forecast radar must label this as potential; observation still uses real cells. */
    public static double precipitationPotential(SynopticWeather.State state){
        double front=clamp(state.frontIntensity(),0,1);
        double moisture=clamp((state.humidityFactor()-1)/.32,0,1);
        return front<.15?0:clamp((front-.15)*moisture*15,0,20);
    }
    /** Physical lifting lowers the saturation threshold of the existing vapor parcel. */
    public static double saturationReduction(Stage stage){
        double cold=stage.type()==2?1.0:stage.type()==1?.79:.89;
        return clamp((stage.core()*.43+stage.advance()*.09)*cold,0,.49);
    }
    /** Faster formation at the frontal band, but no spontaneous rain in a dry parcel. */
    public static double responseSeconds(Stage stage){return 900-650*clamp(stage.core(),0,1);}
    /** Thin ice veil before the front, diagnostically sampled in upper air. */
    public static double highVeil(Stage stage,double upperRh){
        double humidity=clamp((upperRh-.24)/.58,0,1);
        return clamp((stage.advance()*.61+stage.core()*.28)*(.38+.62*humidity),0,.75);
    }
    public static byte visualType(Stage stage,byte original,double liquid,double cover){
        if(stage.core()>.39 && cover>.19 && liquid>.12)
            return (byte)(stage.type()==2&&cover>.47&&liquid>.28?7:6);
        // Low clouds cannot be replaced by a visually high veil. That veil is
        // a separate upper layer with independent cloud identity.
        return original;
    }
}
