package de.meteo.client;

import de.meteo.CloudSnapshotPayload;
import de.meteo.CloudDiagnosticPayload;
import de.meteo.RainRadarPayload;
import de.meteo.WeatherSettingsPayload;
import de.meteo.StationPagePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class MeteoClient implements ClientModInitializer {
    private static KeyBinding OPEN_MENU,OPEN_RADAR,TOGGLE_HUD;
    @Override public void onInitializeClient(){
        CloudVolumeRenderer.loadSettings();RadarScreen.loadQuality();
        RainEffects.load();SnowEffects.load();VisibilitySettings.load();
        AmbientSettings.load();
        ClientPlayNetworking.registerGlobalReceiver(de.meteo.SnowCoverPayload.ID,
            (payload,context)->context.client().execute(()->SnowCoverControls.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(de.meteo.SeasonSettingsPayload.ID,
            (payload,context)->context.client().execute(()->SeasonControls.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(CloudSnapshotPayload.ID,
            (payload,context)->context.client().execute(()->CloudVolumeRenderer.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(CloudDiagnosticPayload.ID,
            (payload,context)->context.client().execute(()->WeatherDiagnostics.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(RainRadarPayload.ID,
            (payload,context)->context.client().execute(()->RadarData.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(de.meteo.SynopticControlPayload.ID,
            (payload,context)->context.client().execute(()->SynopticControls.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(de.meteo.RadarForecastMapPayload.ID,
            (payload,context)->context.client().execute(()->SynopticControls.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(de.meteo.SynopticMapPayload.ID,
            (payload,context)->context.client().execute(()->SynopticControls.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(WeatherSettingsPayload.ID,
            (payload,context)->context.client().execute(()->WeatherControls.accept(payload)));
        ClientPlayNetworking.registerGlobalReceiver(StationPagePayload.ID,(payload,context)->context.client().execute(()->{
            if(context.client().currentScreen instanceof StationScreen stationScreen)stationScreen.accept(payload);
            else context.client().setScreen(new StationScreen(payload));
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->{
            CloudVolumeRenderer.clear();RainEffects.reset();WeatherDiagnostics.clear();
            RadarData.clear();ValleyFogEffects.reset();SnowEffects.clear();WeatherVisibility.reset();
            SeasonControls.clear();SnowCoverControls.clear();WeatherControls.clear();SynopticControls.clear();
        });
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register(WeatherHud::render);
        WorldRenderEvents.LAST.register(CloudVolumeRenderer::render);
        WorldRenderEvents.LAST.register(RainEffects::render);
        WorldRenderEvents.LAST.register(SnowEffects::render);
        WorldRenderEvents.LAST.register(WeatherVisibility::render);
        WorldRenderEvents.LAST.register(ValleyFogEffects::render);
        OPEN_MENU=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.meteo.menu",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_O,"category.meteo"));
        OPEN_RADAR=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.meteo.radar",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_R,"category.meteo"));
        TOGGLE_HUD=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.meteo.hud",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_H,"category.meteo"));
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            CloudVolumeRenderer.tick(client);
            RainEffects.tick(client);SnowEffects.tick(client);WeatherVisibility.tick(client);
            ValleyFogEffects.tick(client);
            while(TOGGLE_HUD.wasPressed())WeatherHud.toggle();
            while(OPEN_RADAR.wasPressed())if(client.player!=null)client.setScreen(new RadarScreen());
            while(OPEN_MENU.wasPressed()){
                if(client.player!=null)client.setScreen(new MeteoScreen());
            }
        });
    }
}
