package de.meteo.client;

import de.meteo.StationPagePayload;
import de.meteo.StationChart;
import de.meteo.StationReading;
import de.meteo.StationRequestPayload;
import java.util.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** A small server-sourced station display with five chart types and a paged full archive. */
public final class StationScreen extends Screen {
    private static final int WHITE=0xfff9f9f9,MUTED=0xffc5d1da,ACCENT=0xffffdc74;
    private static final String[] CHARTS={"Temperatur","Luftdruck","Wind","Regen","Bewölkung","Taupunkt","Schneefall","Schneesumme"};
    private StationPagePayload data;
    private StationReading latest;
    private int tab=0,chart=0,rowOffset=0;
    public StationScreen(StationPagePayload data){super(Text.literal("Meteo Wetterstation"));accept(data);}
    public void accept(StationPagePayload packet){
        if(data!=null && data.position()!=packet.position())return;
        if(data==null || data.page()!=packet.page())rowOffset=0;
        data=packet;
        if(packet.page()==0 && !packet.readings().isEmpty())latest=packet.readings().get(packet.readings().size()-1);
        if(client!=null){clearChildren();init();}
    }
    private static Text txt(String s){return Text.literal(s);}
    private static String f(double v,int digits){return String.format(Locale.GERMANY,"%."+digits+"f",v);}
    private int left(){return Math.max(8,(width-Math.min(560,width-16))/2);}
    private int top(){return 20;}
    private int panelW(){return Math.min(560,width-16);}
    private int panelH(){return height-28;}
    private void button(int x,int y,int w,String label,Runnable action){
        addDrawableChild(ButtonWidget.builder(txt(label),b->action.run()).dimensions(x,y,Math.max(30,w),20).build());
    }
    private void refresh(){clearChildren();init();}
    private void request(int page){
        if(page<0||page>=data.pages())return;
        if(ClientPlayNetworking.canSend(StationRequestPayload.ID))
            ClientPlayNetworking.send(new StationRequestPayload(data.position(),page));
    }
    @Override protected void init(){
        int x=left()+12,y=top()+29,w=panelW()-24,third=(w-8)/3;
        for(int i=0;i<3;i++){
            final int n=i;
            button(x+i*(third+4),y,i==2?w-i*(third+4):third,
                (tab==i?"[":"")+new String[]{"Aktuell","Diagramm","Archiv"}[i]+(tab==i?"]":""),()->{tab=n;refresh();});
        }
        if(tab==1){
            button(x,y+28,(w-6)/2,"< "+CHARTS[chart],()->{chart=(chart+CHARTS.length-1)%CHARTS.length;refresh();});
            button(x+(w+6)/2,y+28,(w-6)/2,CHARTS[chart]+" >",()->{chart=(chart+1)%CHARTS.length;refresh();});
        }
        if(tab==2){
            button(x,y+28,(w-6)/2,"Ältere Messungen",()->request(data.page()+1));
            button(x+(w+6)/2,y+28,(w-6)/2,"Neuere Messungen",()->request(data.page()-1));
            button(x,y+54,(w-6)/2,"10 ältere Einträge",()->{rowOffset=Math.min(Math.max(0,data.readings().size()-1),rowOffset+10);refresh();});
            button(x+(w+6)/2,y+54,(w-6)/2,"10 neuere Einträge",()->{rowOffset=Math.max(0,rowOffset-10);refresh();});
        }
        button(x,top()+panelH()-20,w,"Schließen",this::close);
    }
    private void line(DrawContext g,String s,int x,int y,int color){g.drawTextWithShadow(textRenderer,txt(s),x,y,color);}
    @Override public void renderBackground(DrawContext g,int mx,int my,float dt){g.fill(0,0,width,height,0xf0182636);}
    /** Pixel line with inclusive endpoints, avoiding texture-dependent antialiasing. */
    private static void stroke(DrawContext g,int x0,int y0,int x1,int y1,int color){
        int dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,err=dx+dy;
        for(;;){g.fill(x0,y0,x0+2,y0+2,color);if(x0==x1&&y0==y1)break;
            int e=2*err;if(e>=dy){err+=dy;x0+=sx;}if(e<=dx){err+=dx;y0+=sy;}}
    }
    private void chart(DrawContext g,int x,int y,int w,int h){
        g.fill(x,y,x+w,y+h,0xff16465d);
        int pl=x+45,pt=y+13,pw=Math.max(12,w-58),ph=Math.max(12,h-37);
        for(int i=0;i<=4;i++){
            int yy=pt+ph*i/4;
            g.fill(pl,yy,pl+pw,yy+1,0xff5f8794);
        }
        for(int i=0;i<=5;i++){
            int xx=pl+pw*i/5;
            g.fill(xx,pt,xx+1,pt+ph,0xff497786);
        }
        var series=StationChart.layout(data.readings(),chart,pw,ph);
        var points=series.points();
        line(g,f(series.maximum(),1),x+3,pt-3,MUTED);
        line(g,f(series.minimum(),1),x+3,pt+ph-7,MUTED);
        if(points.isEmpty()){
            line(g,"Keine Messwerte für dieses Diagramm",pl+8,pt+ph/2,WHITE);
            return;
        }
        for(int i=0;i<points.size();i++){
            var a=points.get(i);
            int ax=pl+a.x(),ay=pt+a.y();
            if(i>0){var b=points.get(i-1);stroke(g,pl+b.x(),pt+b.y(),ax,ay,ACCENT);}
            g.fill(ax-2,ay-2,ax+3,ay+3,0xffffe6a0);
        }
        if(points.size()==1)line(g,"Erste Messung – weitere Werte folgen",pl+8,pt+ph/2,WHITE);
        line(g,"Älter",pl,pt+ph+8,MUTED);
        line(g,"Neuer",pl+pw-28,pt+ph+8,MUTED);
    }
    @Override public void render(DrawContext g,int mx,int my,float dt){
        renderBackground(g,mx,my,dt);
        int x=left(),y=top(),w=panelW(),h=panelH();

        line(g,"METEO V1.7.4 | "+data.name(),x+12,y+5,WHITE);
        line(g,data.total()+" Messungen | 1 Messung / Minute",x+12,y+17,MUTED);
        int sy=y+58;
        if(tab==0){
            if(latest==null){line(g,"Erste Messung wird vorbereitet ...",x+12,sy,WHITE);}
            else{
                String[] rows={
                    "Temperatur: "+f(latest.temperature(),1)+" °C    Taupunkt: "+f(latest.dewPoint(),1)+" °C",
                    "Luftdruck: "+f(latest.pressure(),1)+" hPa",
                    "Wind: "+f(latest.windSpeed(),1)+" m/s aus "+f(latest.windFrom(),0)+"°   Böen: "+f(latest.gustSpeed(),1)+" m/s",
                    "Regen: "+f(latest.rainRate(),2)+" mm/h   Summe: "+f(latest.rainTotal(),2)+" mm",
                    "Schnee: "+f(latest.snowRate(),2)+" mm/h   Summe: "+f(latest.snowTotal(),2)+" mm",
                    "Bewölkung: "+f(latest.cloudCover()*100,0)+" %",
                    latest.estimated()?"Fernmessung (berechnet)":"Lokale Stationsmessung"
                };
                int spacing=Math.max(11,Math.min(21,(height-sy-50)/rows.length));
                for(int i=0;i<rows.length;i++)if(sy+i*spacing<height-31)
                    line(g,rows[i],x+12,sy+i*spacing,i==6?ACCENT:WHITE);
            }
        }else if(tab==1){
            int chartY=y+90,chartH=Math.max(46,h-135);
            chart(g,x+12,chartY,w-24,chartH);
            line(g,"Messwerte: "+data.readings().size()+" | Seite "+(data.page()+1)+"/"+data.pages(),x+12,y+h-31,MUTED);
        }else{
            line(g,"Archivseite "+(data.page()+1)+"/"+data.pages(),x+12,y+105,MUTED);
            var rows=data.readings();
            int maxLines=Math.max(1,(height-(y+135)-32)/14);
            int count=Math.min(maxLines,Math.max(0,rows.size()-rowOffset));
            for(int i=0;i<count;i++){
                var r=rows.get(rows.size()-1-rowOffset-i);
                line(g,"Tick "+r.tick()+"  "+f(r.temperature(),1)+"°C  "+f(r.pressure(),0)+"hPa  R "+f(r.rainRate(),1)+"  S "+f(r.snowRate(),1)+(r.estimated()?" ~":""),
                    x+12,y+130+i*14,i%2==0?WHITE:MUTED);
            }
        }
        super.render(g,mx,my,dt);
    }
    @Override public boolean shouldPause(){return false;}
}
