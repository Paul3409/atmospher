package de.meteo.client;
import com.mojang.blaze3d.systems.RenderSystem;
import de.meteo.PrecipitationPhase;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Sparse view-centered transparent distance shells: snow whitens, rain darkens far scenery.
 * No mixin and no framebuffer blurring; world depth keeps foreground sharp. */
public final class WeatherVisibility {
    private WeatherVisibility(){}
    private static double amount,snow;
    public static void reset(){amount=0;snow=0;}
    public static void tick(MinecraftClient client){
        if(!VisibilitySettings.enabled || client.world==null||client.player==null){amount*=.93;snow*=.95;return;}
        var d=WeatherDiagnostics.latest();if(d==null)return;
        double intensity=Math.min(1,Math.max(0,(d.rainMmHour()-1.0)/22));
        double goal=Math.sqrt(intensity)*new double[]{0,.42,.75,1.0}[VisibilitySettings.intensity];
        // Visibility is an accumulated air-mass effect.  Keep the client response
        // deliberately slower than the simulation tick so a passing cell does not
        // look like an instant white flash.
        amount+=(goal-amount)*.009;
        snow+=(PrecipitationPhase.snowFraction(d.temperatureC())-snow)*.008;
    }
    private static void vertex(BufferBuilder b,Matrix4f m,double x,double y,double z,int r,int g,int bl,int a){
        b.vertex(m,(float)x,(float)y,(float)z).color(r,g,bl,a);
    }
    private static void quad(BufferBuilder b,Matrix4f m,double x0,double y0,double z0,
                             double x1,double y1,double z1,int r,int g,int bl,int a){
        vertex(b,m,x0,y0,z0,r,g,bl,a);vertex(b,m,x1,y0,z1,r,g,bl,a);
        vertex(b,m,x1,y1,z1,r,g,bl,a);vertex(b,m,x0,y1,z0,r,g,bl,a);
    }
    public static void render(WorldRenderContext context){
        if(amount<.02||context.matrixStack()==null)return;
        var client=MinecraftClient.getInstance();if(client.world==null||client.world!=context.world())return;
        Vec3d eye=context.camera().getPos();MatrixStack s=context.matrixStack();s.push();
        // World coordinates: shells stand at fixed distances from the camera, never affect HUD/text.
        s.translate(-eye.x,-eye.y,-eye.z);
        try{
            RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.disableCull();
            RenderSystem.enableDepthTest();RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            Matrix4f m=s.peek().getPositionMatrix();
            BufferBuilder b=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            double distanceScale=new double[]{1.15,1.0,.85,.68}[VisibilitySettings.minimumVisibility];
            int red=(int)(113+(240-113)*snow),green=(int)(127+(244-127)*snow),blue=(int)(139+(250-139)*snow);
            for(int layer=0;layer<3;layer++){
                double r=(30+layer*27)*distanceScale;
                int a=(int)(Math.min(112,amount*(28+layer*18)));
                double y0=eye.y-105,y1=eye.y+105;
                quad(b,m,eye.x-r,y0,eye.z-r,eye.x+r,y1,eye.z-r,red,green,blue,a);
                quad(b,m,eye.x+r,y0,eye.z+r,eye.x-r,y1,eye.z+r,red,green,blue,a);
                quad(b,m,eye.x-r,y0,eye.z+r,eye.x-r,y1,eye.z-r,red,green,blue,a);
                quad(b,m,eye.x+r,y0,eye.z-r,eye.x+r,y1,eye.z+r,red,green,blue,a);
            }
            BufferRenderer.drawWithGlobalProgram(b.end());
        }finally{RenderSystem.depthMask(true);RenderSystem.disableBlend();RenderSystem.enableCull();s.pop();}
    }
}
