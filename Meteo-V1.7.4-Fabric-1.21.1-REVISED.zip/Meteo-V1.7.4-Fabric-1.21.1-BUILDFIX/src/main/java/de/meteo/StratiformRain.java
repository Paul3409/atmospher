package de.meteo;
/** Slowly varying, weak-to-moderate stratiform rain fed by moist low cloud decks. */
public final class StratiformRain {
    private StratiformRain() {}
    public static double target(double humidity,double cover,double liquid,double lift){
        if(!Double.isFinite(humidity)||!Double.isFinite(cover)||!Double.isFinite(liquid))return 0;
        double saturation=Math.max(0,Math.min(1,(humidity-.74)/.24));
        double extent=Math.max(0,Math.min(1,(cover-.24)/.52));
        double water=Math.max(0,Math.min(1,(liquid-.08)/.40));
        double subsidence=Math.max(.20,1-Math.max(0,-lift)*.45);
        return 4.5*saturation*extent*water*subsidence;
    }
    public static double relax(double previous,double target,double seconds){
        double timeConstant=target>previous?330:720;
        return Math.max(0,previous+(Math.max(0,target)-Math.max(0,previous))
            *(1-Math.exp(-Math.max(0,Math.min(seconds,120))/timeConstant)));
    }
    public static double footprint(double cloudX,double cloudZ,double x,double z,double rate){
        if(rate<=0)return 0;
        // A broad moving deck, not a circular 40-block shower shaft.
        double dx=(x-cloudX)/145.0,dz=(z-cloudZ)/105.0;
        double radius=Math.hypot(dx,dz);
        double q=Math.max(0,Math.min(1,(1.16-radius)/.32));
        return rate*q*q*(3-2*q);
    }
}
