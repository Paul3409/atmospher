package de.meteo;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import java.util.HashMap;
import java.util.Map;

/** Spatially anchored, slowly evolving cloud-water cells (64x64 blocks).
 * Only the server evolves these states; v0.8 sends snapshots to a separate client renderer.
 */
public final class CloudEffects {
    private CloudEffects() {}
    private static final int CELL=64;
    private static final int MAX_CELLS=4096;
    private static final int[][] SMALL_CLOUD_PROBES={{1,0},{-1,0},{0,1},{0,-1}};
    private static final int[][] LARGE_CLOUD_PROBES={{1,0},{-1,0},{0,1},{0,-1},
        {1,1},{-1,1},{1,-1},{-1,-1}};
    private static final Map<String,Cell> cells=new HashMap<>();
    // The integrated server may be recreated without restarting the Minecraft
    // client. Never carry cloud age, wind or water into a different save world.
    private static ServerWorld activeWorld;
    private static boolean storageWritable=true;
    public static void reset(){cells.clear();heightCache.clear();cachedHeightTick=Long.MIN_VALUE;activeWorld=null;storageWritable=true;}
    private static void ensureWorld(ServerWorld world){
        if(activeWorld!=world){cells.clear();heightCache.clear();cachedHeightTick=Long.MIN_VALUE;activeWorld=world;}
    }
    private static final class Cell {
        CloudFieldPhysics.State state=new CloudFieldPhysics.State(0,0);
        MoisturePhysics.Parcel moisture=new MoisturePhysics.Parcel(0.72,0);
        double precipitation, rainMmHour, stratiformMmHour;
        double cloudX=Double.NaN, cloudZ=Double.NaN, cloudBaseY=Double.NaN;
        long lastVisitedTick;
        long lastTick=-1;
        CloudPhysics.Cloud diagnostic;
        double humidity,solar,deltaWater,condensation,evaporation,transport,temperature;
        FrontalCloudPhysics.Stage frontStage=new FrontalCloudPhysics.Stage(0,0,0,(byte)0);
        double ageSeconds;
        long updateCount;
    }
    public record CloudReport(CloudPhysics.Cloud diagnostic,double cover,double water,String type,
                              double humidity,double solar,double deltaWater,double condensation,double evaporation,
                              double transport,double temperature,long updates,boolean fog,boolean rain, double vapor,double precipitation,double rainMmHour,double cloudX,double cloudZ) {}
    private static String key(ServerWorld w,int cx,int cz){return w.getRegistryKey().getValue()+":"+cx+":"+cz;}
    private static Cell cell(ServerWorld w,int cx,int cz){
        ensureWorld(w);
        String key=key(w,cx,cz);
        Cell c=cells.get(key);
        if(c==null){
            if(cells.size()>=MAX_CELLS){
                // Remove stale formations without abruptly deleting every visible cloud.
                long now=w.getTime();
                cells.entrySet().removeIf(e->now-e.getValue().lastVisitedTick>6000);
                if(cells.size()>=MAX_CELLS){
                    String oldest=null;long age=Long.MAX_VALUE;
                    for(var entry:cells.entrySet())if(entry.getValue().lastVisitedTick<age){age=entry.getValue().lastVisitedTick;oldest=entry.getKey();}
                    if(oldest!=null)cells.remove(oldest);
                }
            }
            c=new Cell();cells.put(key,c);
        }
        c.lastVisitedTick=w.getTime();
        return c;
    }
    private static double neighborConvectiveSupport(ServerWorld world,int cx,int cz){
        double support=0;
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)if(dx!=0||dz!=0){
            Cell n=cells.get(key(world,cx+dx,cz+dz));
            if(n==null||n.diagnostic==null)continue;
            support=Math.max(support,Math.min(n.state.cover(),n.moisture.liquid()*1.5)/Math.max(1,Math.hypot(dx,dz)));
        }
        return Math.max(0,Math.min(1,support));
    }
    private static int height(ServerWorld world,int x,int z){return world.getTopY(Heightmap.Type.WORLD_SURFACE,x,z);}
    private static CloudPhysics.Cloud diagnose(AtmosphereEngine engine,ServerWorld world,int x,int z){
        var s=engine.sample(world,new BlockPos(x,height(world,x,z)+2,z)).layers().get(0);
        double sx=0,sz=0;
        int[] radii={24,48,96};double[] weights={.20,.45,.35};
        for(int i=0;i<radii.length;i++){
            int r=radii[i];double dx=0,dz=0;
            for(int offset:new int[]{-r/2,0,r/2}){
                dx+=(height(world,x+r,z+offset)-height(world,x-r,z+offset))/(2.0*r);
                dz+=(height(world,x+offset,z+r)-height(world,x+offset,z-r))/(2.0*r);
            }
            sx+=weights[i]*dx/3;sz+=weights[i]*dz/3;
        }
        long time=Math.floorMod(world.getTimeOfDay(),24000);
        double solar=Math.max(0,Math.sin(Math.PI*time/12000.0));
        CloudPhysics.Cloud original=CloudPhysics.diagnose(s.temperatureC(),s.dewPointC(),s.relativeHumidity(),s.windU(),s.windV(),sx,sz,solar);
        var cfg=SynopticRuntime.current();
        if(!cfg.cloudFronts()||!cfg.fronts())return original;
        var stage=frontStage(engine,x,z,s.relativeHumidity());
        if(stage.core()<.04&&stage.advance()<.07)return original;
        // The thin leading veil precedes the main frontal uplift. The active
        // frontal core supplies stronger ascent while lee still contributes.
        return new CloudPhysics.Cloud(original.lclMeters(),original.baseBlocks(),original.lift()+stage.ascent(),
            Math.min(1,original.coverage()+.35*stage.core()+.08*stage.advance()),original.kind(),original.windSpeed(),
            original.windFromDegrees(),original.terrainLift(),original.terrainFlow());
    }
    /** Advance-map and current-map samples drive the same physical frontal cloud. */
    private static FrontalCloudPhysics.Stage frontStage(AtmosphereEngine engine,double x,double z,double humidity){
        var cfg=SynopticRuntime.current();
        if(!cfg.fronts()||!cfg.cloudFronts())return new FrontalCloudPhysics.Stage(0,0,0,(byte)0);
        double seconds=engine.simulatedSeconds();
        return FrontalCloudPhysics.at(
            SynopticRuntime.fieldAt(seconds,x,z),
            SynopticRuntime.fieldAt(seconds+7200,x,z),humidity);
    }
    private static boolean loaded(ServerWorld world,double x,double z){
        return Double.isFinite(x)&&Double.isFinite(z)&&
            world.getChunkManager().isChunkLoaded(Math.floorDiv((int)Math.floor(x),16),Math.floorDiv((int)Math.floor(z),16));
    }
    /** Never cause chunk loading just to check a cloud's possible route. */
    private static int loadedHeight(ServerWorld world,double x,double z,int fallback){
        return loaded(world,x,z)?height(world,(int)Math.floor(x),(int)Math.floor(z)):fallback;
    }
    /** Only cache loaded heightmap columns; never generate chunks for clouds.
     * Entries last one world tick and reuse probes among nearby clouds.
     */
    private static final Map<Long,Integer> heightCache=new HashMap<>();
    private static long cachedHeightTick=Long.MIN_VALUE;
    private static int cachedHeight(ServerWorld world,double x,double z,int fallback){
        if(!loaded(world,x,z))return fallback;
        long tick=world.getTime();
        if(cachedHeightTick!=tick){heightCache.clear();cachedHeightTick=tick;}
        int bx=Math.floorDiv((int)Math.floor(x),8),bz=Math.floorDiv((int)Math.floor(z),8);
        long k=((long)bx<<32)^(bz&0xffffffffL);
        Integer h=heightCache.get(k);
        if(h!=null)return h;
        int y=height(world,bx*8+4,bz*8+4);
        if(heightCache.size()>8192)heightCache.clear();
        heightCache.put(k,y);
        return y;
    }
    /** Check the full swept route, not just the start and destination. */
    private static void moveOverTerrain(ServerWorld world,Cell c,double u,double v,double dt,double lift){
        var next=CloudMotion.advance(new CloudMotion.Position(c.cloudX,c.cloudZ),u,v,dt);
        double dx=next.x()-c.cloudX,dz=next.z()-c.cloudZ;
        double length=Math.hypot(dx,dz);
        if(length<1e-5)return;
        if(!loaded(world,next.x(),next.z()))return;
        int here=cachedHeight(world,c.cloudX,c.cloudZ,world.getBottomY());
        double candidateBase=TerrainCloudFlow.clearBase(c.cloudBaseY,here);
        // A ridge between packet positions must also block low clouds.
        int pathHeight=here;
        for(int i=1;i<=4;i++){
            double fraction=i/4.0;
            double px=c.cloudX+dx*fraction,pz=c.cloudZ+dz*fraction;
            if(!loaded(world,px,pz))return;
            pathHeight=Math.max(pathHeight,cachedHeight(world,px,pz,pathHeight));
        }
        double sideX=-dz/length,sideZ=dx/length;
        int left=cachedHeight(world,next.x()+sideX*40,next.z()+sideZ*40,pathHeight);
        int right=cachedHeight(world,next.x()-sideX*40,next.z()-sideZ*40,pathHeight);
        var route=TerrainCloudFlow.steer(c.cloudX,c.cloudZ,next.x(),next.z(),candidateBase,
            pathHeight,left,right,lift);
        if(route.stalled())return;
        if(!loaded(world,route.x(),route.z()))return;
        int newHeight=cachedHeight(world,route.x(),route.z(),pathHeight);
        double minimum=Math.max(route.minimumBase(),newHeight+TerrainCloudFlow.CLEARANCE);
        // A side route is refused if its actual height needs an impossible lift.
        if(minimum-candidateBase>20 && lift<=.12)return;
        if(minimum-candidateBase>35)return;
        c.cloudX=route.x();c.cloudZ=route.z();
        c.cloudBaseY=Math.max(candidateBase,minimum);
    }
    private static void update(AtmosphereEngine engine,ServerWorld world,int cx,int cz){
        Cell c=cell(world,cx,cz);long tick=world.getTime();
        if(c.lastTick>=0&&tick-c.lastTick<20)return;
        if(!Double.isFinite(c.cloudX)){
            c.cloudX=cx*CELL+CELL/2;
            c.cloudZ=cz*CELL+CELL/2;
        }
        // Sample terrain and air at the actual moving cloud, not at its birth cell.
        int x=(int)Math.floor(c.cloudX),z=(int)Math.floor(c.cloudZ);
        CloudPhysics.Cloud d=diagnose(engine,world,x,z);
        var layer=engine.sample(world,new BlockPos(x,height(world,x,z)+2,z)).layers().get(0);
        long time=Math.floorMod(world.getTimeOfDay(),24000);
        double solar=Math.max(0,Math.sin(Math.PI*time/12000.0));
        double dt=c.lastTick<0?0:Math.min(120,(tick-c.lastTick)*3.6);
        c.lastTick=tick;
        c.ageSeconds+=dt;
        // A travelling cloud cannot instantly jump to the local terrain height.
        // Smooth the absolute cloud altitude independently of its moving parcel.
        double targetBase=Math.min(world.getTopY()-12,height(world,x,z)+d.baseBlocks());
        c.cloudBaseY=TerrainCloudFlow.clearBase(CloudBasePhysics.relax(c.cloudBaseY,targetBase,dt),height(world,x,z));
        c.diagnostic=d;c.humidity=layer.relativeHumidity();c.solar=solar;c.temperature=layer.temperatureC();
        if(dt>0){
            moveOverTerrain(world,c,layer.windU(),layer.windV(),dt,d.terrainLift());
        }
        if(dt==0){
            double initial=Math.max(0,Math.min(.055,d.coverage()*.10));
            c.moisture=new MoisturePhysics.Parcel(Math.max(.1,c.humidity),initial);
            c.state=new CloudFieldPhysics.State(initial,0);
            return;
        }
        double before=c.moisture.liquid();
        // The liquid parcel now MOVES with its formation. Transferring liquid
        // between old seed-cell IDs would double-advect condensate and cause
        // apparently spontaneous clouds to pop up at stationary grid nodes.
        // Environmental mixing replaces depleted vapor with local air moisture.
        double vaporMix=(c.humidity-c.moisture.vapor())*(1-Math.exp(-dt/420));
        MoisturePhysics.Parcel advected=new MoisturePhysics.Parcel(
            Math.max(0,c.moisture.vapor()+vaporMix),c.moisture.liquid());
        c.transport=vaporMix;
        // True ascent lowers saturation threshold; lee subsidence raises it.
        // This makes a moist windward slope condense and a lee slope evaporate.
        var frontal=frontStage(engine,c.cloudX,c.cloudZ,c.humidity);
        c.frontStage=frontal;
        double targetSaturation=CloudBasePhysics.adjustedSaturation(
            d.terrainLift(),d.lift(),c.humidity,solar);
        // A frontal ascent is allowed to condense the parcel before the rain
        // arrives. This consumes simulated vapor; it does not fabricate rain.
        targetSaturation=Math.max(.25,targetSaturation-FrontalCloudPhysics.saturationReduction(frontal));
        MoisturePhysics.Phase phase=MoisturePhysics.phase(advected,targetSaturation,d.lift(),dt);
        c.moisture=phase.parcel();
        c.condensation=phase.condensation();c.evaporation=phase.evaporation();
        c.precipitation=phase.precipitation();
        var storm=ThunderstormPhysics.diagnose(c.state.cover(),c.moisture.liquid(),d.lift(),c.humidity,solar,c.ageSeconds);
        double shear=Math.abs(layer.windU()-layer.windV())+Math.abs(layer.windU()+layer.windV())*.35;
        double neighborSupport=neighborConvectiveSupport(world,cx,cz);
        var squall=OrganizedStormPhysics.squall(frontal.core(),frontal.advance(),d.lift(),c.humidity,shear,Math.max(storm.strength(),neighborSupport*.72));
        var supercell=SupercellPhysics.diagnose(storm.strength(),d.lift(),c.humidity,shear,c.ageSeconds,frontal.core());
        double instantaneousRain=RainPhysics.rainRate(c.precipitation,dt)*(1+storm.updraft()*.65+squall.potential()*.22+(supercell.supercell()?supercell.updraft()*.20:0));
        // Rain is an evolving shower, not a pulse that disappears on a single update.
        c.rainMmHour=RainPhysics.smoothRate(c.rainMmHour,instantaneousRain,dt);
        // Persistent precipitation when broad low-layer condensate stays moist.
        // Avoid a pulse: this separate reservoir relaxes over several simulated minutes.
        String cloudKind=CloudFieldPhysics.classify(c.state.cover(),d.lift(),c.humidity,solar,c.state.water(),c.ageSeconds);
        double deckTarget=(cloudKind.equals("stratus")||cloudKind.equals("stratocumulus"))
            ? StratiformRain.target(c.humidity,c.state.cover(),c.moisture.liquid(),d.lift()) : 0;
        if(frontal.core()>.25 && c.moisture.liquid()>.20 && c.state.cover()>.22){
            // The same condensate reservoir supports a wider precipitation band
            // as it matures; no precipitation in a cloudless/dry frontal cell.
            deckTarget=Math.max(deckTarget,StratiformRain.target(
                c.humidity,Math.max(c.state.cover(),frontal.core()*.65),
                c.moisture.liquid(),d.lift()));
        }
        c.stratiformMmHour=StratiformRain.relax(c.stratiformMmHour,deckTarget,dt);
        c.rainMmHour=Math.max(c.rainMmHour,c.stratiformMmHour);
        // Dry lee air also erodes existing cloud water rather than merely
        // reducing the rate of new condensation.
        if(d.lift() < -.08 || storm.downdraft()>.20){
            double lee=Math.min(.30,Math.max(0,-d.lift()*.25)+storm.downdraft()*.08);
            double evaporated=Math.min(c.moisture.liquid(),Math.max(0,
                c.moisture.liquid()*(1-Math.exp(-dt*lee/190))));
            c.moisture=new MoisturePhysics.Parcel(Math.max(0,c.moisture.vapor()+evaporated),
                Math.max(0,c.moisture.liquid()-evaporated));
            c.evaporation+=evaporated;
        }
        c.deltaWater=c.moisture.liquid()-before;
        // A frontal cloud deck should be visible before its condensate becomes
        // a rain-producing core. Its minimum opacity reflects frontal ascent,
        // but rain is still determined exclusively from the real water parcel.
        double frontalCover=Math.max(frontal.core()>.20?frontal.core()*(.22+.42*Math.min(1,c.moisture.liquid()*2)):0,frontal.advance()>.05?frontal.advance()*.18:0);
        double coverTarget=CloudFieldPhysics.clamp(Math.max(c.moisture.liquid()*1.22,frontalCover),0,1);
        double smooth=c.state.cover()+(coverTarget-c.state.cover())*(1-Math.exp(-dt/FrontalCloudPhysics.responseSeconds(frontal)));
        c.state=new CloudFieldPhysics.State(coverTarget,CloudFieldPhysics.clamp(smooth,0,1));
        // A residual rain-rate tail may persist for a short time, but cannot
        // continue at full intensity after the cloud itself has evaporated.
        if(c.state.cover()<.08&&c.moisture.liquid()<.07)
            c.rainMmHour=RainPhysics.smoothRate(c.rainMmHour,0,dt*4);
        if(c.state.cover()<.08&&c.moisture.liquid()<.07&&c.rainMmHour<.05)c.ageSeconds=0;
        c.updateCount++;
    }
    /** Source must still contain cloud water for rain/snow or radar echoes. */
    private static boolean raining(Cell c){
        return c.rainMmHour>.05 && c.moisture.liquid()>.052 && c.state.cover()>.075;
    }
    public static CloudReport at(AtmosphereEngine engine,ServerWorld world,BlockPos pos){
        int cx=Math.floorDiv(pos.getX(),CELL),cz=Math.floorDiv(pos.getZ(),CELL);
        update(engine,world,cx,cz);
        Cell c=cell(world,cx,cz);
        return new CloudReport(c.diagnostic,c.state.cover(),c.state.water(),
            CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water()),
            c.humidity,c.solar,c.deltaWater,c.condensation,c.evaporation,c.transport,
            c.temperature,c.updateCount,c.humidity>0.96&&c.diagnostic.baseBlocks()<=15&&c.state.cover()>0.18,
            raining(c),c.moisture.vapor(),c.precipitation,raining(c)?c.rainMmHour:0,c.cloudX,c.cloudZ);
    }
    /** Local station precipitation from all actual nearby moving cloud sources, not only the seed cell. */
    public record StationSky(double cover,double rainMmHour) {}
    public static StationSky stationSky(AtmosphereEngine engine,ServerWorld world,BlockPos pos){
        // Seed the station cell when loaded; never call this method for unloaded chunks.
        at(engine,world,pos);
        double cover=0,rain=0;
        String dimension=world.getRegistryKey().getValue()+":";
        for(var entry:cells.entrySet()){
            if(!entry.getKey().startsWith(dimension))continue;
            Cell c=entry.getValue();
            if(c.diagnostic==null||!Double.isFinite(c.cloudX)||!Double.isFinite(c.cloudZ))continue;
            double dist=Math.hypot(c.cloudX-pos.getX(),c.cloudZ-pos.getZ());
            if(dist>170)continue;
            double weight=Math.max(0,1-dist/120.0);
            cover=Math.max(cover,c.state.cover()*weight);
            String kind=CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water(),c.ageSeconds);
            byte type=(byte)(kind.equals("stratocumulus")?4:kind.equals("stratus")?3:kind.equals("cumulus congestus")?2:1);
            if(raining(c))rain+=RainPhysics.localRate(c.cloudX,c.cloudZ,pos.getX(),pos.getZ(),c.rainMmHour,type);
        }
        return new StationSky(Math.min(1,cover),Math.min(35,Math.max(0,rain)));
    }

    /** Read the already active moving rain cells without seeding additional weather
     * formations. Used by ground accumulation in loaded chunks only. */
    public static double precipitationAt(ServerWorld world,int x,int z){
        ensureWorld(world);
        String dimension=world.getRegistryKey().getValue()+":";
        double rain=0;
        for(var entry:cells.entrySet()){
            if(!entry.getKey().startsWith(dimension))continue;
            Cell c=entry.getValue();
            if(c.diagnostic==null||!Double.isFinite(c.cloudX)||!Double.isFinite(c.cloudZ)||!raining(c))continue;
            if(Math.abs(c.cloudX-x)>170||Math.abs(c.cloudZ-z)>170)continue;
            String kind=CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water(),c.ageSeconds);
            byte type=(byte)(kind.equals("stratocumulus")?4:kind.equals("stratus")?3:kind.equals("cumulus congestus")?2:1);
            rain+=RainPhysics.localRate(c.cloudX,c.cloudZ,x,z,c.rainMmHour,type);
        }
        return Math.min(35,Math.max(0,rain));
    }

    /** All moving formations near the viewer, including clouds whose birth cell
     * is no longer within the player's neighborhood. Seed IDs remain unchanged.
     * Weather is sampled at the CURRENT formation position on the server. */
    public static CloudSnapshotPayload snapshot(AtmosphereEngine engine,ServerWorld world,ServerPlayerEntity player){
        ensureWorld(world);
        BlockPos pos=player.getBlockPos();
        int pcx=Math.floorDiv(pos.getX(),CELL),pcz=Math.floorDiv(pos.getZ(),CELL);
        // Seed incoming air; existing moving clouds are collected separately.
        for(int dx=-22;dx<=22;dx++)for(int dz=-22;dz<=22;dz++){
            // Populate the outer horizon progressively to avoid a massive
            // all-at-once terrain scan when the player first joins.
            int ring=Math.max(Math.abs(dx),Math.abs(dz));
            if((ring<=3 || Math.floorMod(dx*19+dz*31,Math.max(8,ring*4))==Math.floorMod(world.getTime()/20,Math.max(8,ring*4)))
                && loaded(world,(pcx+dx)*CELL+CELL/2.0,(pcz+dz)*CELL+CELL/2.0))
                update(engine,world,pcx+dx,pcz+dz);
        }
        String dimension=world.getRegistryKey().getValue()+":";
        java.util.List<Map.Entry<String,Cell>> nearby=new java.util.ArrayList<>();
        for(var entry:cells.entrySet()){
            if(!entry.getKey().startsWith(dimension))continue;
            Cell c=entry.getValue();
            if(c.diagnostic==null||!Double.isFinite(c.cloudX))continue;
            if(!loaded(world,c.cloudX,c.cloudZ))continue;
            if(CloudMotion.intersects(c.cloudX,c.cloudZ,pos.getX(),pos.getZ(),90,1800))nearby.add(entry);
        }
        nearby.sort(java.util.Comparator.comparingDouble(e->
            Math.hypot(e.getValue().cloudX-pos.getX(),e.getValue().cloudZ-pos.getZ())));
        // Prioritise nearby clouds AND a limited quota of approaching front
        // cells on the horizon. Otherwise the 320-cell snapshot quota is used
        // up by local ordinary clouds and the radar's approaching front has no
        // visible counterpart until it is almost overhead.
        java.util.List<Map.Entry<String,Cell>> chosen=new java.util.ArrayList<>(320);
        java.util.Set<String> chosenKeys=new java.util.HashSet<>();
        for(var entry:nearby){
            if(chosen.size()>=225)break;
            chosen.add(entry);chosenKeys.add(entry.getKey());
        }
        java.util.List<Map.Entry<String,Cell>> frontal=new java.util.ArrayList<>();
        for(var entry:nearby){
            var stage=entry.getValue().frontStage;
            if(!chosenKeys.contains(entry.getKey())&&
                (stage.core()>.23||stage.advance()>.10)&&
                entry.getValue().moisture.liquid()>.035)frontal.add(entry);
        }
        frontal.sort(java.util.Comparator.comparingDouble((Map.Entry<String,Cell> e)->
            -(e.getValue().frontStage.core()+e.getValue().frontStage.advance()*.7)));
        for(var entry:frontal){
            if(chosen.size()>=320)break;
            chosen.add(entry);chosenKeys.add(entry.getKey());
        }
        for(var entry:nearby){
            if(chosen.size()>=320)break;
            if(chosenKeys.add(entry.getKey()))chosen.add(entry);
        }
        java.util.List<CloudSnapshotPayload.CloudCell> result=new java.util.ArrayList<>();
        for(var entry:chosen){
            String[] pieces=entry.getKey().substring(dimension.length()).split(":");
            int cx=Integer.parseInt(pieces[0]),cz=Integer.parseInt(pieces[1]);
            Cell c=entry.getValue();
            int x=(int)Math.floor(c.cloudX),z=(int)Math.floor(c.cloudZ);
            double base=Double.isFinite(c.cloudBaseY)?c.cloudBaseY:
                Math.min(world.getTopY()-12,height(world,x,z)+c.diagnostic.baseBlocks());
            var layer=engine.sample(world,new BlockPos(x,height(world,x,z)+2,z)).layers().get(0);
            String kind=CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water(),c.ageSeconds);
            byte type=(byte)(kind.equals("cumulonimbus")?7:kind.equals("cumulus congestus")?2:
                kind.equals("cumulus")||kind.equals("cumulus humilis")?1:
                kind.equals("stratus")?3:kind.equals("stratocumulus")?4:0);
            // The same existing condensate evolves into additional cloud geometries.
            // 7 Cb/anvil, 8 Nimbostratus, 9 Altocumulus.
            if(type==2 && c.diagnostic.lift()>.26 && c.moisture.liquid()>.34 && c.state.cover()>.38)type=7;
            else if((type==3||type==4) && c.rainMmHour>3.8 && c.state.cover()>.60)type=8;
            else if(type==0 && c.humidity>.48 && c.state.cover()>.19 && c.state.cover()<.63 && c.rainMmHour<.6)type=9;
            if(SynopticRuntime.current().cloudFronts()&&SynopticRuntime.current().fronts()){
                // Existing rain clouds cannot be disguised as thin ice-cloud veils.
                type=FrontalCloudPhysics.visualType(
                    c.frontStage,type,c.moisture.liquid(),c.state.cover());
            }
            // Very wide frontal decks and low-layer clouds must clear nearby
            // loaded ridge columns, not only the cloud centre. This avoids the
            // large translucent underside slicing across mountain faces.
            int footprint=type==6?158:type==8?138:type==7?168:
                (type==4||type==9)?88:(type==3||type==5)?83:52;
            // Eight samples only for broad cloud decks; small formations
            // use four to avoid unnecessary terrain heightmap queries.
            for(int[] direction:footprint>100?LARGE_CLOUD_PROBES:SMALL_CLOUD_PROBES){
                double factor=direction[0]!=0&&direction[1]!=0?.70710678:1.0;
                double fx=c.cloudX+direction[0]*footprint*factor;
                double fz=c.cloudZ+direction[1]*footprint*factor;
                if(loaded(world,fx,fz))base=TerrainCloudFlow.clearBase(base,
                    height(world,(int)Math.floor(fx),(int)Math.floor(fz)));
            }
            result.add(new CloudSnapshotPayload.CloudCell(cx,cz,(float)c.cloudX,(float)c.cloudZ,(float)(type==9||type==5?Math.min(world.getTopY()-45,base+75):base),
                (float)c.state.cover(),(float)c.moisture.liquid(),(float)c.diagnostic.lift(),
                (float)layer.windU(),(float)layer.windV(),type,(float)(raining(c)?c.rainMmHour:0),
                (float)c.temperature,(float)c.humidity,(float)c.diagnostic.terrainLift()));
        }
        // Independent ice-cloud layer: a second formation can coexist above a
        // cumulus/stratocumulus at the same ground location. Sample elevated air.
        // Reuse existing 64-block seed identities with an ID offset; positions
        // are still WORLD-ANCHORED and the lower clouds are not replaced.
        int highCount=0;
        java.util.List<Map.Entry<String,Cell>> highCandidates=new java.util.ArrayList<>(nearby);
        highCandidates.sort(java.util.Comparator.comparingDouble((Map.Entry<String,Cell> e)->
            -(e.getValue().frontStage.advance()*.8+e.getValue().frontStage.core()*.65+
              Math.max(0,1-Math.hypot(e.getValue().cloudX-pos.getX(),e.getValue().cloudZ-pos.getZ())/1500)*.18)));
        for(var entry:highCandidates){
            if(result.size()>=348||highCount>=28)break;
            String[] pieces=entry.getKey().substring(dimension.length()).split(":");
            int cx=Integer.parseInt(pieces[0]),cz=Integer.parseInt(pieces[1]);
            // Sparse filaments: one seed in every four cells, deterministic.
            if(Math.floorMod(cx*17+cz*13,3)!=0)continue;
            Cell c=entry.getValue();
            int x=(int)Math.floor(c.cloudX),z=(int)Math.floor(c.cloudZ);
            var upper=engine.sample(world,new BlockPos(x,Math.min(280,world.getTopY()-8),z)).layers().get(1);
            double relative=upper.relativeHumidity();
            double ice=HighCloudPhysics.iceContent(relative,upper.temperatureC());
            // Leading ice-cloud formations are sampled from exactly the synoptic
            // pressure/front field that drives the radar, independent of
            // whether the lower parcel has already condensed into rain.
            var skyFront=frontStage(engine,c.cloudX,c.cloudZ,c.humidity);
            ice=Math.max(ice,FrontalCloudPhysics.highVeil(skyFront,relative));
            if(ice<.075)continue;
            float highBase=(float)HighCloudPhysics.baseY(world.getTopY(),height(world,x,z),relative);
            // Minimal layer drift is predictable and nonzero even if lower
            // cloud is almost calm; upper wind is from elevated sample.
            result.add(new CloudSnapshotPayload.CloudCell(cx+1000000,cz+1000000,
                (float)c.cloudX,(float)c.cloudZ,highBase,
                (float)HighCloudPhysics.cover(ice),(float)ice,0,
                (float)upper.windU(),(float)upper.windV(),(byte)5,0,
                (float)upper.temperatureC(),(float)relative,0));
            highCount++;
        }
        // Distant front lines are known even without generated terrain.
        // Represent them by elevated, non-precipitating ice clouds so the
        // player can see the approaching system before entering loaded chunks.
        // Actual precipitation always comes from simulated loaded cloud cells.
        if(SynopticRuntime.current().fronts()&&SynopticRuntime.current().cloudFronts()){
            double radius=1550,now=engine.simulatedSeconds();
            // Sample a fixed world grid.  The former polyline samples derived their
            // network identity from a moving position; crossing a 64-block boundary
            // therefore deleted one cloud and created another at a shifted location.
            final int FRONT_GRID=192;
            java.util.List<SynopticWeather.FrontPoint> candidates=new java.util.ArrayList<>();
            int minGx=Math.floorDiv((int)Math.floor(pos.getX()-radius),FRONT_GRID);
            int maxGx=Math.floorDiv((int)Math.floor(pos.getX()+radius),FRONT_GRID);
            int minGz=Math.floorDiv((int)Math.floor(pos.getZ()-radius),FRONT_GRID);
            int maxGz=Math.floorDiv((int)Math.floor(pos.getZ()+radius),FRONT_GRID);
            for(int gx=minGx;gx<=maxGx;gx++)for(int gz=minGz;gz<=maxGz;gz++){
                float x=gx*FRONT_GRID+FRONT_GRID*.5f,z=gz*FRONT_GRID+FRONT_GRID*.5f;
                if(Math.hypot(x-pos.getX(),z-pos.getZ())>radius)continue;
                var syn=SynopticRuntime.fieldAt(now,x,z);
                if(syn.frontIntensity()>=.16)candidates.add(new SynopticWeather.FrontPoint(x,z,syn.frontType()));
            }
            candidates.sort(java.util.Comparator.comparingDouble(pt->
                Math.hypot(pt.x()-pos.getX(),pt.z()-pos.getZ())));
            int visual=0;
            for(var pt:candidates){
                if(result.size()>=384||visual>=36)break;
                double x=pt.x(),z=pt.z();
                var syn=SynopticRuntime.fieldAt(now,x,z);
                double front=syn.frontIntensity();
                if(front<.16)continue;
                boolean near=loaded(world,x,z);
                int terrain=near?cachedHeight(world,x,z,world.getBottomY()):world.getBottomY();
                byte type=5;
                double base=near?Math.max(world.getTopY()-32,terrain+105):world.getTopY()+22;
                double cover=.34+.44*front;
                double condensate=.18+.32*front;
                // Dark frontal decks only appear where their terrain footprint
                // can be checked without force-loading chunks.
                if(near&&front>.45){
                    type=6;
                    int highest=terrain;
                    for(int[] direction:LARGE_CLOUD_PROBES){
                        double fx=x+direction[0]*110,fz=z+direction[1]*110;
                        if(loaded(world,fx,fz))highest=Math.max(highest,cachedHeight(world,fx,fz,highest));
                    }
                    base=Math.max(highest+TerrainCloudFlow.CLEARANCE,terrain+48);
                    if(base>world.getTopY()-34)continue;
                    cover=.48+.40*front;condensate=.28+.33*front;
                }
                // Both layers remain anchored to this world cell.  Their weather
                // values evolve as the synoptic front moves across the cell.
                double visualX=x,visualZ=z;
                // Upper veil and lower deck use separate stable identities.  When
                // the front matures, the veil can fade while the deck grows below
                // it instead of one mesh teleporting and changing shape.
                int cx=3000000+(type==5?0:100000)+Math.floorDiv((int)Math.floor(x),FRONT_GRID);
                int cz=3000000+Math.floorDiv((int)Math.floor(z),FRONT_GRID);
                result.add(new CloudSnapshotPayload.CloudCell(cx,cz,(float)visualX,(float)visualZ,(float)base,
                    (float)Math.min(1,cover),(float)condensate,(float)(.12+.42*front),0,0,
                    type,0,(float)(syn.temperatureOffset()+2),.8f,0));
                visual++;
            }
        }
        return new CloudSnapshotPayload(world.getTime(),java.util.List.copyOf(result));
    }

    /** Independent precipitation scan. Cloud rendering prioritizes close cells and
     * can omit wet formations; this packet does not share that limitation. */
    public static RainRadarPayload radarSnapshot(ServerWorld world,ServerPlayerEntity player){
        ensureWorld(world);
        double px=player.getX(),pz=player.getZ();
        String dimension=world.getRegistryKey().getValue()+":";
        java.util.List<RainRadarPayload.RainCell> rain=new java.util.ArrayList<>();
        for(var entry:cells.entrySet()){
            if(!entry.getKey().startsWith(dimension))continue;
            Cell c=entry.getValue();
            if(c.diagnostic==null||!Double.isFinite(c.cloudX)||!Double.isFinite(c.cloudZ)
                ||!Double.isFinite(c.rainMmHour)||!raining(c))continue;
            if(Math.abs(c.cloudX-px)>1024||Math.abs(c.cloudZ-pz)>1024)continue;
            String kind=CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water());
            byte type=(byte)(kind.equals("stratocumulus")?4:kind.equals("stratus")?3:kind.equals("cumulus congestus")?2:1);
            rain.add(new RainRadarPayload.RainCell((float)c.cloudX,(float)c.cloudZ,
                (float)c.rainMmHour,type,(byte)(PrecipitationPhase.snowFraction(c.temperature)>=.5?1:0)));
        }
        rain.sort(java.util.Comparator.comparingDouble(c->Math.hypot(c.x()-px,c.z()-pz)));
        if(rain.size()>512)rain=new java.util.ArrayList<>(rain.subList(0,512));
        return new RainRadarPayload(world.getTime(),java.util.List.copyOf(rain));
    }

    /** Server-authoritative player-local values, not birth-cell measurements. */
    public static CloudDiagnosticPayload diagnosticSnapshot(AtmosphereEngine engine,ServerWorld world,ServerPlayerEntity player){
        ensureWorld(world);
        BlockPos pos=player.getBlockPos();
        // Measure the air at the PLAYER, not at the current position of a
        // cloud that was originally seeded in the same 64-block birth cell.
        CloudPhysics.Cloud local=diagnose(engine,world,pos.getX(),pos.getZ());
        var layer=engine.sample(world,pos).layers().get(0);
        int active=0,wet=0;
        double liquid=0,cover=0,rain=0;
        String dimension=world.getRegistryKey().getValue()+":";
        for(var entry:cells.entrySet()){
            if(!entry.getKey().startsWith(dimension))continue;
            Cell c=entry.getValue();
            if(c.diagnostic==null||!Double.isFinite(c.cloudX))continue;
            double dist=Math.hypot(c.cloudX-pos.getX(),c.cloudZ-pos.getZ());
            if(dist>1150)continue;
            if(c.state.cover()>=.09&&c.moisture.liquid()>=.045)active++;
            if(raining(c)&&c.rainMmHour>.15)wet++;
            // Only actual moving nearby clouds contribute to this site's
            // simulated cloud cover / water, not the stationary seed grid.
            double weight=Math.max(0,1-dist/110.0);
            cover=Math.max(cover,c.state.cover()*weight);
            liquid=Math.max(liquid,c.moisture.liquid()*weight);
            if(raining(c))rain+=RainPhysics.localRate(c.cloudX,c.cloudZ,pos.getX(),pos.getZ(),c.rainMmHour,(byte)(CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water()).equals("stratocumulus")?4:CloudFieldPhysics.classify(c.state.cover(),c.diagnostic.lift(),c.humidity,c.solar,c.state.water()).equals("stratus")?3:1));
        }
        int ground=height(world,pos.getX(),pos.getZ());
        double base=ground+local.baseBlocks();
        return new CloudDiagnosticPayload(world.getTime(),layer.temperatureC(),layer.dewPointC(),
            layer.relativeHumidity(),layer.windU(),layer.windV(),local.lift(),
            local.terrainLift(),(float)local.baseBlocks(),(float)base,
            (float)cover,(float)liquid,(float)Math.min(35,rain),active,wet,ground);
    }

    /** Evolve new weather cells and maintain existing moving cloud identities. */
    public static void tick(AtmosphereEngine engine,ServerWorld world){
        ensureWorld(world);
        if(world.getTime()%20!=0)return;
        var players=world.getPlayers();
        for(ServerPlayerEntity player:players){
            int pcx=Math.floorDiv(player.getBlockX(),CELL),pcz=Math.floorDiv(player.getBlockZ(),CELL);
            for(int dx=-16;dx<=16;dx++)for(int dz=-16;dz<=16;dz++){
                int ring=Math.max(Math.abs(dx),Math.abs(dz));
                if((ring<=3 || Math.floorMod(dx*19+dz*31,Math.max(8,ring*4))==Math.floorMod(world.getTime()/20,Math.max(8,ring*4)))
                    && loaded(world,(pcx+dx)*CELL+CELL/2.0,(pcz+dz)*CELL+CELL/2.0))
                    update(engine,world,pcx+dx,pcz+dz);
            }
        }
        String dimension=world.getRegistryKey().getValue()+":";
        // Travelled formations must not freeze just because their original cell
        // falls outside the currently simulated seed square.
        for(var entry:new java.util.ArrayList<>(cells.entrySet())){
            if(!entry.getKey().startsWith(dimension))continue;
            Cell c=entry.getValue();
            if(!Double.isFinite(c.cloudX)||c.lastTick==world.getTime())continue;
            boolean near=false;
            for(ServerPlayerEntity player:players)
                if(CloudMotion.intersects(c.cloudX,c.cloudZ,player.getX(),player.getZ(),90,1150)){near=true;break;}
            if(near){
                String[] pieces=entry.getKey().substring(dimension.length()).split(":");
                update(engine,world,Integer.parseInt(pieces[0]),Integer.parseInt(pieces[1]));
            }
        }
    }
    /** Persist cloud identities, locations, age and condensate independently of nearby clients. */
    public static void save(java.nio.file.Path file){
        if(!storageWritable)return;
        try{
            java.nio.file.Files.createDirectories(file.getParent());
            java.nio.file.Path temp=file.resolveSibling(file.getFileName()+".tmp");
            try(var out=new java.io.DataOutputStream(new java.util.zip.GZIPOutputStream(java.nio.file.Files.newOutputStream(temp)))){
                out.writeInt(0x4d434c44);out.writeInt(1);out.writeInt(cells.size());
                for(var e:cells.entrySet()){
                    Cell c=e.getValue();out.writeUTF(e.getKey());
                    out.writeDouble(c.state.water());out.writeDouble(c.state.cover());
                    out.writeDouble(c.moisture.vapor());out.writeDouble(c.moisture.liquid());
                    out.writeDouble(c.precipitation);out.writeDouble(c.rainMmHour);out.writeDouble(c.stratiformMmHour);
                    out.writeDouble(c.cloudX);out.writeDouble(c.cloudZ);out.writeDouble(c.cloudBaseY);
                    out.writeDouble(c.humidity);out.writeDouble(c.solar);out.writeDouble(c.temperature);
                    out.writeDouble(c.deltaWater);out.writeDouble(c.condensation);out.writeDouble(c.evaporation);
                    out.writeDouble(c.transport);out.writeLong(c.updateCount);
                }
            }
            try{java.nio.file.Files.move(temp,file,java.nio.file.StandardCopyOption.REPLACE_EXISTING,java.nio.file.StandardCopyOption.ATOMIC_MOVE);}
            catch(java.nio.file.AtomicMoveNotSupportedException e){java.nio.file.Files.move(temp,file,java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
        }catch(java.io.IOException e){MeteoMod.LOGGER.error("Could not save Meteo clouds",e);}
    }
    public static void load(ServerWorld world,java.nio.file.Path file){
        reset();activeWorld=world;if(!java.nio.file.Files.isRegularFile(file))return;
        try(var in=new java.io.DataInputStream(new java.util.zip.GZIPInputStream(java.nio.file.Files.newInputStream(file)))){
            if(in.readInt()!=0x4d434c44||in.readInt()!=1)throw new java.io.IOException("Unsupported cloud format");
            int count=in.readInt();if(count<0||count>MAX_CELLS)throw new java.io.IOException("Cloud record count invalid");
            Map<String,Cell> restored=new HashMap<>();
            for(int i=0;i<count;i++){
                String key=in.readUTF();if(key.length()>120||!key.startsWith("minecraft:overworld:"))throw new java.io.IOException("Invalid cloud key");
                Cell c=new Cell();c.state=new CloudFieldPhysics.State(in.readDouble(),in.readDouble());
                c.moisture=new MoisturePhysics.Parcel(in.readDouble(),in.readDouble());
                c.precipitation=in.readDouble();c.rainMmHour=in.readDouble();c.stratiformMmHour=in.readDouble();
                c.cloudX=in.readDouble();c.cloudZ=in.readDouble();c.cloudBaseY=in.readDouble();
                c.humidity=in.readDouble();c.solar=in.readDouble();c.temperature=in.readDouble();
                c.deltaWater=in.readDouble();c.condensation=in.readDouble();c.evaporation=in.readDouble();
                c.transport=in.readDouble();c.updateCount=in.readLong();
                if(!Double.isFinite(c.state.water())||!Double.isFinite(c.moisture.vapor())||
                    !Double.isFinite(c.cloudX)||!Double.isFinite(c.cloudZ))throw new java.io.IOException("Corrupt cloud state");
                c.lastTick=world.getTime()-20;c.lastVisitedTick=world.getTime();
                restored.put(key,c);
            }
            cells.clear();cells.putAll(restored);MeteoMod.LOGGER.info("Restored {} cloud formations",cells.size());
        }catch(Exception e){MeteoMod.LOGGER.error("Could not load Meteo clouds; preserving existing file",e);reset();activeWorld=world;storageWritable=false;}
    }
}
