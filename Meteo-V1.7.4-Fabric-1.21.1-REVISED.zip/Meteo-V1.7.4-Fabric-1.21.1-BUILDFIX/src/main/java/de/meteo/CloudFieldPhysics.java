package de.meteo;

/** Pure-Java prognostic cloud water. Each spatial cell retains its own state.
 * Simplified relaxation, evaporation and upstream moisture transport; not a CFD model.
 */
public final class CloudFieldPhysics {
    private CloudFieldPhysics() {}
    public record State(double water, double cover) {}
    public static State advance(State old, double target, double lift, double humidity,
                                double upstreamWater, double transportFraction, double seconds) {
        double dt=Math.max(0,Math.min(seconds,120));
        double adv=clamp(transportFraction,0,0.65);
        double water=clamp(old.water()*(1-adv)+clamp(upstreamWater,0,1)*adv,0,1);
        double equilibrium=clamp(target,0,1);
        // Condensation is faster in ascent; evaporation in descending dry air is slower than an instant switch.
        double tau=equilibrium>water ? (lift>0.2?140:260) : (lift< -0.15?230:420);
        double response=1-Math.exp(-dt/tau);
        water=clamp(water+(equilibrium-water)*response,0,1);
        // Dry subsiding air accelerates evaporation without erasing existing clouds immediately.
        double dry=clamp((0.60-humidity)/0.60,0,1);
        water=clamp(water*Math.exp(-dt*dry*Math.max(0,-lift)/900),0,1);
        double cover=clamp(old.cover()+(water-old.cover())*(1-Math.exp(-dt/100)),0,1);
        return new State(water,cover);
    }
    public static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
    public static String classify(double cover,double lift,double humidity,double solar,double water){
        return classify(cover,lift,humidity,solar,water,1200);
    }
    public static String classify(double cover,double lift,double humidity,double solar,double water,double ageSeconds){
        if(cover<0.08)return "clear";
        var storm=ThunderstormPhysics.diagnose(cover,water,lift,humidity,solar,ageSeconds);
        if(storm.stage()==ThunderstormPhysics.Stage.MATURE)return "cumulonimbus";
        if(storm.stage()==ThunderstormPhysics.Stage.BUILDING&&storm.strength()>.34)return "cumulus congestus";
        if(lift>0.65&&water>0.40)return "cumulus congestus";
        if(lift>0.20)return "cumulus";
        if(lift>0.06&&solar>0.3)return "cumulus humilis";
        if(humidity>0.78&&cover>.33&&lift<.23)return "stratocumulus";
        if(humidity>0.83&&lift<0.08)return "stratus";
        if(cover>0.40)return "stratocumulus";
        return "orographic cloud";
    }
}
