package de.meteo;

/** Client weather visualization policy, independent of the cloud simulation. */
public final class FogPhysics {
    private FogPhysics(){}
    public static double target(double relativeHumidity,double dewPointGapC,double windMps,
                                double recentRainMmHour,boolean night){
        if(!Double.isFinite(relativeHumidity)||!Double.isFinite(dewPointGapC)
                ||!Double.isFinite(windMps)||!Double.isFinite(recentRainMmHour))return 0;
        double saturation=Math.max(0,(relativeHumidity-.78)/.20);
        double cooling=Math.max(0,1-dewPointGapC/5);
        double calm=Math.max(.18,1-Math.max(0,windMps)/12);
        double damp=Math.min(1,Math.max(0,recentRainMmHour)/5)*.24;
        return Math.min(1,Math.max(0,(saturation*.70+cooling*.30+damp)*calm*(night?1:.675)));
    }
    public static float approach(float current,double target){
        float difference=(float)(Math.max(0,Math.min(1,target))-current);
        return Math.max(0,Math.min(1,current+difference*(difference>0?.24f:.11f)));
    }
}
