package de.meteo;

/** Diagnostic rain rate for small, explicitly simulated cloud-water sinks.
 * 1 unit of normalized cloud water corresponds to ~8 mm of condensate.
 * This is a simplified convective shower model, not a radar reflectivity solver. */
public final class RainPhysics {
    private RainPhysics(){}
    public static double rainRate(double removedWater,double simulationSeconds){
        if(simulationSeconds<=0)return 0;
        return clamp(removedWater*8.0*3600.0/simulationSeconds,0,35);
    }
    /** Exponential response in simulated seconds: keeps local showers coherent. */
    public static double smoothRate(double previous,double target,double simulationSeconds){
        if(!Double.isFinite(previous)||!Double.isFinite(target))return 0;
        double tau=target>previous?180:300;
        double alpha=1-Math.exp(-Math.max(0,Math.min(120,simulationSeconds))/tau);
        return clamp(previous+(clamp(target,0,35)-previous)*alpha,0,35);
    }
    public static double localRate(double cloudX,double cloudZ,double x,double z,double intensity){
        if(intensity<=0)return 0;
        double distance=Math.hypot(x-cloudX,z-cloudZ);
        // Broad precipitating shaft; no rain outside the actual cloud footprint.
        double r=40+Math.min(12,intensity*.5);
        double w=Math.max(0,1-distance/r);
        return intensity*w*w*(3-2*w);
    }
    /** Stratiform rain follows a cloud deck; convective rain stays local. */
    public static double localRate(double cloudX,double cloudZ,double x,double z,double intensity,byte type){
        return type==3||type==4 ? StratiformRain.footprint(cloudX,cloudZ,x,z,intensity)
                                 : type==5 ? 0 : localRate(cloudX,cloudZ,x,z,intensity);
    }
    public static boolean snow(double surfaceTemperatureC){return surfaceTemperatureC<=1.5;}
    private static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
}
