package de.meteo;

import java.util.ArrayList;
import java.util.List;

/** Lightweight, independent, weather-gated 3D voxel cloud surface generator.
 * Inspired by the *concept* of layered 3D noise in Simple Clouds; independent
 * mathematics and Java rendering (no borrowed Simple Clouds shader/code).
 */
public final class CloudVoxelMesh {
    private CloudVoxelMesh() {}
    /** face side: 0 west, 1 east, 2 down, 3 up, 4 north, 5 south.
     * occlusion is the fraction of locally blocked skylight (0 exposed, 1 deep).
     */
    public record Face(float x0,float y0,float z0,float x1,float y1,float z1,
                       byte side,float variation,float occlusion) {}
    /** Outer translucent skin and an independently enclosed, smaller dense core. */
    public record Layers(List<Face> outer, List<Face> core) {}

    private static float clamp(float n,float a,float b){return Math.max(a,Math.min(b,n));}

    public static List<Face> build(int cx,int cz,float baseY,int type,
            float cover,float liquid,float lift,int quality){
        return build(cx,cz,cx*64+32,cz*64+32,baseY,type,cover,liquid,lift,quality);
    }
    /** Stable seed identity with independently advected cloud world coordinates. */
    public static List<Face> build(int cx,int cz,float worldX,float worldZ,float baseY,int type,
            float cover,float liquid,float lift,int quality){
        return buildHybrid(cx,cz,worldX,worldZ,baseY,type,cover,liquid,lift,quality).outer();
    }

    public static Layers buildHybrid(int cx,int cz,float worldX,float worldZ,float baseY,int type,
            float cover,float liquid,float lift,int quality){
        if(!Float.isFinite(worldX)||!Float.isFinite(worldZ)||
           !Float.isFinite(baseY)||!Float.isFinite(cover)||!Float.isFinite(liquid)||
           !Float.isFinite(lift)||cover<.09f||liquid<.045f)return new Layers(List.of(),List.of());
        // Adaptive mesh detail: intentionally conservative for Intel integrated GPUs.
        int n=quality<=0?11:quality==1?16:quality==2?21:27;
        int vertical=type==5?(quality<=0?5:quality==1?7:quality==2?9:11):(quality<=0?7:quality==1?12:quality==2?17:22);
        boolean sheet=type==0||type==3||type==4||type==5||type==6||type==8||type==9;
        float strength=clamp(Math.min(cover*1.65f,liquid*1.85f),.08f,1f);
        float width=(type==7?220:type==6?300:type==8?260:type==9?184:type==5?152:type==4?158:sheet?104:type==2?94:86)*(.82f+.20f*strength);
        float height=(type==7?195:type==6?65:type==8?49:type==9?28:type==5?16:type==2?94:type==1?46:sheet?type==3?21:30:36)*(.79f+.31f*strength);
        if(!sheet)height*=1+clamp(lift,0,2f)*.16f;
        height=Math.min(height,Math.max(0,310-baseY));
        if(height<=7)return new Layers(List.of(),List.of());
        float sx=width/n,sy=height/vertical,sz=width/n;
        int seed=cx*73428767^cz*912931^0x4d455445;
        float offX=(float)((CloudVolumeField.noise(cx*.37+7,2,cz*.33,seed)-.5)*11);
        float offZ=(float)((CloudVolumeField.noise(cx*.29,5,cz*.37+9,seed)-.5)*11);
        float xOrigin=worldX+offX-width/2f;
        float zOrigin=worldZ+offZ-width/2f;
        boolean[][][] inside=new boolean[n][vertical][n];
        float[][][] variations=new float[n][vertical][n];
        for(int ix=0;ix<n;ix++)for(int iy=0;iy<vertical;iy++)for(int iz=0;iz<n;iz++){
            double nx=2*(ix+.5)/(double)n-1,ny=(iy+.5)/(double)vertical,nz=2*(iz+.5)/(double)n-1;
            double density=CloudVolumeField.density(nx,ny,nz,type,seed);
            // Limited water shrinks cloud contours instead of reducing their visibility
            // to a translucent fog. No cloud forms when the simulated water is zero.
            double threshold=(type==5?.21:.34)+(1-strength)*(type==5?.10:.24);
            inside[ix][iy][iz]=density>threshold;
            variations[ix][iy][iz]=(float)(CloudVolumeField.noise(nx*8+6,ny*7+8,nz*8+2,seed+207)-.5);
        }
        List<Face> faces=new ArrayList<>();
        for(int ix=0;ix<n;ix++)for(int iy=0;iy<vertical;iy++)for(int iz=0;iz<n;iz++){
            if(!inside[ix][iy][iz])continue;
            float x0=xOrigin+ix*sx,x1=x0+sx,y0=baseY+iy*sy,y1=y0+sy,z0=zOrigin+iz*sz,z1=z0+sz;
            float variation=variations[ix][iy][iz];
            int above=0;
            // Skylight through up to six layers of condensed water. This gives a
            // naturally darker cloud base and a bright illuminated upper canopy.
            for(int dy=iy+1;dy<Math.min(vertical,iy+7);dy++)if(inside[ix][dy][iz])above++;
            float occlusion=clamp(above/5f,0,1);
            if(ix==0||!inside[ix-1][iy][iz])faces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)0,variation,occlusion));
            if(ix==n-1||!inside[ix+1][iy][iz])faces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)1,variation,occlusion));
            if(iy==0||!inside[ix][iy-1][iz])faces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)2,variation,occlusion));
            if(iy==vertical-1||!inside[ix][iy+1][iz])faces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)3,variation,occlusion));
            if(iz==0||!inside[ix][iy][iz-1])faces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)4,variation,occlusion));
            if(iz==n-1||!inside[ix][iy][iz+1])faces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)5,variation,occlusion));
        }
        // Erode the occupancy field by one voxel. The inner shell is genuinely
        // smaller than the translucent outer skin, rather than a duplicate surface.
        // The resulting opaque center gives the cloud depth without dozens of
        // incorrectly blended overlapping translucent cube faces.
        boolean[][][] core=new boolean[n][vertical][n];
        for(int ix=1;ix<n-1;ix++)for(int iy=1;iy<vertical-1;iy++)
            for(int iz=1;iz<n-1;iz++)
                core[ix][iy][iz]=inside[ix][iy][iz]
                    &&inside[ix-1][iy][iz]&&inside[ix+1][iy][iz]
                    &&inside[ix][iy-1][iz]&&inside[ix][iy+1][iz]
                    &&inside[ix][iy][iz-1]&&inside[ix][iy][iz+1];
        List<Face> coreFaces=new ArrayList<>();
        if(type==5)return new Layers(List.copyOf(faces),List.of());
        for(int ix=1;ix<n-1;ix++)for(int iy=1;iy<vertical-1;iy++)
            for(int iz=1;iz<n-1;iz++){
                if(!core[ix][iy][iz])continue;
                float x0=xOrigin+ix*sx,x1=x0+sx,y0=baseY+iy*sy,y1=y0+sy;
                float z0=zOrigin+iz*sz,z1=z0+sz;
                float variation=variations[ix][iy][iz];
                int above=0;
                for(int dy=iy+1;dy<Math.min(vertical,iy+7);dy++)if(inside[ix][dy][iz])above++;
                float occlusion=clamp(above/5f,0,1);
                if(!core[ix-1][iy][iz])coreFaces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)0,variation,occlusion));
                if(!core[ix+1][iy][iz])coreFaces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)1,variation,occlusion));
                if(!core[ix][iy-1][iz])coreFaces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)2,variation,occlusion));
                if(!core[ix][iy+1][iz])coreFaces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)3,variation,occlusion));
                if(!core[ix][iy][iz-1])coreFaces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)4,variation,occlusion));
                if(!core[ix][iy][iz+1])coreFaces.add(new Face(x0,y0,z0,x1,y1,z1,(byte)5,variation,occlusion));
            }
        return new Layers(List.copyOf(faces),List.copyOf(coreFaces));
    }
}
