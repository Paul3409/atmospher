package de.meteo;

/** Deterministic physical/visual contract tests, no Minecraft runtime required. */
public final class V173FrontMountainTest {
    private static void ok(boolean check,String description){if(!check)throw new AssertionError(description);}
    private static SynopticWeather.State weather(double front,byte type){
        return new SynopticWeather.State(990,-23,front,type,1.22,-2,1.5,1.2);
    }
    public static void main(String[] args){
        var distant=FrontalCloudPhysics.at(weather(.08,(byte)2),weather(.7,(byte)2),.7);
        var arrived=FrontalCloudPhysics.at(weather(.85,(byte)2),weather(.88,(byte)2),.7);
        var clear=FrontalCloudPhysics.at(weather(0,(byte)0),weather(0,(byte)0),.7);
        ok(distant.approaching(),"front is preceded by high clouds");
        ok(distant.core()<arrived.core(),"frontal deck thickens on arrival");
        ok(FrontalCloudPhysics.highVeil(distant,.55)>.10,"upper ice veil independent of pre-existing liquid");
        ok(FrontalCloudPhysics.highVeil(clear,.55)==0,"clear area has no frontal veil");
        ok(FrontalCloudPhysics.saturationReduction(arrived)>.20,"frontal lift condenses real vapor");
        ok(FrontalCloudPhysics.responseSeconds(arrived)<FrontalCloudPhysics.responseSeconds(clear),"front clouds evolve faster than ordinary fair-weather cloud");
        ok(FrontalCloudPhysics.visualType(arrived,(byte)1,.42,.65)==7,"mature cold front has Cb clouds");
        ok(FrontalCloudPhysics.visualType(arrived,(byte)1,.01,.02)==1,"no massive front cloud without condensate");
        double before=CloudLife.approachFrontal(0,.8,240);
        double normal=CloudLife.approach(0,.8,240);
        ok(before>normal*3,"front clouds become visible before ordinary cloud maturation");
        var over=TerrainCloudFlow.steer(0,0,4,0,100,105,112,112,.8);
        ok(over.obstructed()&&!over.stalled()&&over.minimumBase()>=119,"uplift clears the ridge");
        var around=TerrainCloudFlow.steer(0,0,4,0,100,155,75,155,0);
        ok(around.obstructed()&&!around.stalled()&&around.z()>0,"low cloud goes around passable flank");
        var blocked=TerrainCloudFlow.steer(0,0,4,0,100,155,155,155,0);
        ok(blocked.stalled()&&blocked.x()==0&&blocked.z()==0,"cloud banks at impassable ridge");
        var free=TerrainCloudFlow.steer(0,0,4,0,100,75,75,75,0);
        ok(!free.obstructed()&&free.x()==4,"cloud travels freely without mountain");
        System.out.println("V1.7.4 PASS: high front veil, mature Cb, cloud growth, mountain avoidance");
    }
}
