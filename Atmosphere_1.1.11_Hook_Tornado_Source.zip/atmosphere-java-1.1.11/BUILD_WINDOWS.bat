@echo off
cd /d "%~dp0"
echo Atmosphere 1.1.11 - Hook Echo und Tornado - Fabric 1.21.1 / Java 21
call "C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace > build-output.log 2>&1
if errorlevel 1 (
 type build-output.log
 echo BUILD FEHLGESCHLAGEN - Ausgabe steht in build-output.log.
 pause
 exit /b 1
)
echo Fertig: build\libs\atmosphere-1.1.11.jar
pause
