package dev.atmosphere;

/**
 * Deterministic mesoscale storm cells. Pure Java: no loaded chunks and no global RNG.
 * Each cell has a stable seed, an advected center and a continuous birth/growth/
 * maturity/decay cycle. This is a stylised weather simulation, not an NWP solver.
 */
public final class WeatherCells {
    public static final int NONE=0, SHOWER=1, THUNDER=2, SEVERE=3, SUPERCELL=4, SQUALL=5;
    public static final String[] NAMES = {"Kein", "Schauer", "Gewitter", "Starkes Gewitter", "Superzelle", "Squall Line"};
    public record Cell(int type, double x, double z, double radius, double intensity,
                       double growth, double anvil, double rotation, double windX, double windZ,
                       long id, double phase, double speedBlocksPerDay, double cycleDurationDays) {
        public Cell(int type,double x,double z,double radius,double intensity,double growth,
                    double anvil,double rotation,double windX,double windZ,long id) {
            this(type,x,z,radius,intensity,growth,anvil,rotation,windX,windZ,id,.48,200,1.8);
        }
        public String stage() { return StormEvolution.stage(phase); }
        public double ageDays() { return ((phase-Math.floor(phase)) * cycleDurationDays); }
    }
    public record Field(double rain, double storm, double cloud, double development, double gustFront,
                        int type, double centerX, double centerZ, double radius,
                        double anvil, double rotation, double windX, double windZ, long id) { }
    private static final double TAU = Math.PI*2;
    private static final double SPACING = 690.0;
    private WeatherCells() {}

    public static double smooth(double start, double end, double v) {
        double t = clamp((v-start)/(end-start),0,1);
        return t*t*(3-2*t);
    }
    public static double lifecycle(double phase) {
        phase -= Math.floor(phase);
        double birth = smooth(.02,.32,phase);
        double decay = 1-smooth(.65,.97,phase);
        return birth*decay;
    }
    public static Cell cell(int gx, int gz, double weatherDays) {
        double seed = hash(gx,gz,7);
        double x = (gx + .18 + .64*hash(gx,gz,11))*SPACING;
        double z = (gz + .18 + .64*hash(gx,gz,13))*SPACING;
        double direction = .7 + 1.0*hash(gx,gz,19);
        double wx = Math.cos(direction), wz = Math.sin(direction);
        // Fronts translate in physical world space; visual cloud motion shares this direction.
        double speed=170 + hash(gx,gz,17)*100;
        x += weatherDays*speed*wx;
        z += weatherDays*speed*wz;
        double shear = hash(gx,gz,31);
        double potential = hash(gx,gz,37);
        int type = potential > .95 && shear > .52 ? SQUALL :
                   potential > .84 && shear > .55 ? SUPERCELL :
                   potential > .69 ? SEVERE : potential > .43 ? THUNDER : SHOWER;
        double cycleDuration = .82 + 1.7*hash(gx,gz,41);
        double phase = weatherDays/cycleDuration + hash(gx,gz,43);
        double growth = lifecycle(phase);
        double radius = (type == SQUALL ? 240 : type == SUPERCELL ? 195 : 105)
                + 65*hash(gx,gz,47);
        double intensity = growth * (.45 + .55*hash(gx,gz,53));
        double anvil = type >= THUNDER ? smooth(.35,.80,growth) : 0;
        return new Cell(type,x,z,radius,intensity,growth,anvil,
                shear*growth,wx,wz, gx*1000003L+gz,phase, speed,cycleDuration);
    }

    /** Max of the local cells: returns a continuous 2-D storm field and a leading cell. */
    public static Field sample(double x, double z, double weatherDays) {
        // Approximate inverse advection to constrain the search to nine local cells.
        double advX=x-weatherDays*190*.4, advZ=z-weatherDays*190*.87;
        int gx=(int)Math.floor(advX/SPACING), gz=(int)Math.floor(advZ/SPACING);
        double best=0, cloud=0, gustFront=0, rain=0;
        Cell leading = null;
        for (int j=-2;j<=2;j++) for(int i=-2;i<=2;i++) {
            Cell c=cell(gx+i,gz+j,weatherDays);
            double dx=x-c.x(), dz=z-c.z();
            if(dx*dx+dz*dz>c.radius()*c.radius()*16)continue;
            double across=dx*(-c.windZ())+dz*c.windX();
            double along=dx*c.windX()+dz*c.windZ();
            // Bend the rain shield without creating frame-to-frame random noise.
            double bend = Math.sin(across / (c.radius()*.62) + hash(c.id(),0,719)*TAU)
                    * c.radius()*.24;
            along -= bend;
            double reach = c.radius()*(.55+.62*c.growth());
            double norm;
            if(c.type()==SQUALL) {
                // Elongated, slightly bowed front, not an infinitely repeated straight strip.
                double bow=27*Math.sin(across/230.0+c.id()*.01);
                norm=Math.pow((along-bow)/Math.max(30,reach*.40),2)
                     +Math.pow(across/(reach*2.3),2);
            } else if(c.type()==SUPERCELL) {
                // Oblique, rotating elliptical updraft/precipitation sector.
                double a=across + along*.34*c.rotation();
                norm=Math.pow(a/(reach*.83),2)+Math.pow(along/(reach*1.35),2);
            } else {
                norm=(dx*dx+dz*dz)/(reach*reach);
            }
            double texture=StormEvolution.precipitationStructure(along,across,c.radius(),c.id(),c.type());
            double shape=Math.exp(-norm*1.15)*(.58+.42*texture);
            double convective=shape*c.intensity();
            double localRain=StormEvolution.rainProfile(along,across,c.radius(),c.id(),c.type(),c.growth())
                    *c.intensity()*c.intensity()
                    *(c.type()==SHOWER?23:c.type()==THUNDER?48:c.type()==SEVERE?84:
                    c.type()==SUPERCELL?104:91);
            rain=Math.max(rain,localRain);
            double spread=Math.exp(-norm*.46)*c.growth();
            cloud=Math.max(cloud,spread);
            gustFront=Math.max(gustFront,StormEvolution.gustFront(along,across,c.radius(),c.growth(),c.type()));
            if(convective>best) {best=convective; leading=c;}
        }
        if (leading == null) return new Field(0,0,cloud,0,gustFront,NONE,x,z,100,0,0,1,0,0);
        double strength=smooth(.12,.93,best);
        return new Field(rain,strength,cloud,leading.growth(),gustFront,leading.type(),leading.x(),leading.z(),
                leading.radius(),leading.anvil(),leading.rotation(),leading.windX(),leading.windZ(),leading.id());
    }
    public static double clamp(double x,double low,double high) {return Math.max(low,Math.min(high,x));}
    public static double hash(long x,long z,int salt) {
        long h=x*341873128712L ^ z*132897987541L ^ salt*2177342783L;
        h^=h>>>30;h*=-4658895280553007687L;h^=h>>>27;h*=-7723592293110705685L;h^=h>>>31;
        return (h>>>11)*0x1.0p-53;
    }
}
