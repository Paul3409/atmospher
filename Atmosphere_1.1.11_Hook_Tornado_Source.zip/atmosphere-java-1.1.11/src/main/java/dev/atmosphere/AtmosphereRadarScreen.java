package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The radar samples the same deterministic weather fields as the world, not
 * decorative random textures. Updates are spread across rendered frames.
 * Doppler returns radial velocities measured from the player's radar position.
 */
public final class AtmosphereRadarScreen extends Screen {
    private static final String[] VIEWS = {"Niederschlag","Zellen","Doppler","Luftdruck","500 hPa","Wind","Jetstream 300 hPa","Temperatur"};
    private static final int[] RANGES={500,1500,3000};
    private static final int[] WIDTHS={96,144,192};
    private static final int[] HEIGHTS={96,144,192};
    private final AtmosphereSettings settings;
    private int view=0, forecastHours=0, rowsDone=0, detailDone=0, cols=0, rows=0;
    private int[] colors = new int[0];
    private double[] pressure = new double[0], heights = new double[0], jetSpeeds = new double[0];
    private WeatherModel.Weather[] samples = new WeatherModel.Weather[0];
    private double[] radial = new double[0];
    /** Kept between radar openings: changing colour layers should not re-simulate weather. */
    private static WeatherCache shared;
    public static void clearCache(){shared=null;}
    private record WeatherCache(long bucket,int cx,int cz,int range,int resolution,int weatherSpeed,
            int stormFrequency,int stormStrength,int experience,int mode,int precipitation,int temperatureOffset,
            int highPower,int lowPower,int pressureLifetime,int systemsRevision,
            WeatherModel.Weather[] samples,double[] radial,double[] pressure,double[] heights,double[] jetSpeeds) { }
    private long cacheTick=Long.MIN_VALUE, cacheTime;
    private int cacheX=Integer.MIN_VALUE,cacheZ=Integer.MIN_VALUE;
    private int cacheView=-1,cacheRange=-1,cacheRes=-1,cacheForecast=-1;
    private ButtonWidget viewButton,rangeButton,timeButton,resButton,contourButton,frontButton;
    private boolean showFronts=true;
    private final List<Marker> markers=new ArrayList<>();
    private record Marker(double x,double z,String name,String details,int tint,long id) {}
    private long trackedCell=Long.MIN_VALUE;
    private long markerKey=Long.MIN_VALUE;

    public AtmosphereRadarScreen(AtmosphereSettings s) {super(Text.literal("ATMOSPHERE | Weather Revolution Radar"));settings=s;}
    @Override protected void init() {
        int x=width/2-167, y=height-74;
        viewButton=button(x,y,111,"",()->{view=(view+1)%VIEWS.length;invalidate();});
        rangeButton=button(x+114,y,105,"",()->{settings.radarRange=(settings.radarRange+1)%3;settings.save();invalidate();});
        timeButton=button(x+222,y,111,"",()->{forecastHours=(forecastHours+3)%15;invalidate();});
        resButton=button(x,y+23,164,"",()->{settings.radarResolution=(settings.radarResolution+1)%3;settings.save();invalidate();});
        contourButton=button(x+168,y+23,165,"",()->{settings.radarIsobars=!settings.radarIsobars;settings.save();invalidate();});
        frontButton=button(x+168,y+46,165,"",()->{showFronts=!showFronts;});
        updateLabels();
    }
    private ButtonWidget button(int x,int y,int w,String label,Runnable r) {
        return addDrawableChild(ButtonWidget.builder(Text.literal(label),b->{r.run();updateLabels();}).dimensions(x,y,w,20).build());
    }
    private void updateLabels() {
        if(viewButton==null)return;
        viewButton.setMessage(Text.literal(VIEWS[view]));
        rangeButton.setMessage(Text.literal(RANGES[settings.radarRange]+" Bl."));
        timeButton.setMessage(Text.literal(forecastHours==0?"Jetzt":"+"+forecastHours+" Spielstunden"));
        resButton.setMessage(Text.literal("Radar: "+new String[]{"Schnell","Ausgewogen","Hoch"}[settings.radarResolution]));
        contourButton.setMessage(Text.literal("Isobaren: "+(settings.radarIsobars?"AN":"AUS")));
        frontButton.setMessage(Text.literal("Fronten: "+(showFronts?"AN":"AUS")));
    }
    private void invalidate(){cacheView=-1;}
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta) {
        super.render(ctx,mouseX,mouseY,delta);
        MinecraftClient client=MinecraftClient.getInstance();
        if(client.player==null || client.world==null)return;
        int mw=Math.max(46,Math.min(width-22,height-155)),mh=mw,mx=(width-mw)/2,my=24;
        ctx.drawCenteredTextWithShadow(textRenderer,title,width/2,8,0xFFE1F5FF);
        ctx.fill(mx-2,my-2,mx+mw+2,my+mh+2,0xFF71899B);
        ctx.fill(mx,my,mx+mw,my+mh,0xFF080B10);
        int cx=Math.floorDiv(client.player.getBlockX(),16)*16;
        int cz=Math.floorDiv(client.player.getBlockZ(),16)*16;
        long time=client.world.getTimeOfDay()+forecastHours*1000L;
        int range=RANGES[settings.radarRange];
        long bucket=Math.floorDiv(time,100);
        boolean same=shared!=null && shared.bucket()==bucket && shared.cx()==cx && shared.cz()==cz
            && shared.range()==range && shared.resolution()==settings.radarResolution
            && shared.weatherSpeed()==settings.weatherSpeed && shared.stormFrequency()==settings.stormFrequency
            && shared.stormStrength()==settings.stormStrength && shared.experience()==settings.weatherExperience && shared.mode()==settings.mode
            && shared.precipitation()==settings.precipitationMmH
            && shared.temperatureOffset()==settings.temperatureOffset
            && shared.highPower()==settings.highPressureStrength
            && shared.lowPower()==settings.lowPressureStrength
            && shared.pressureLifetime()==settings.pressureLifetime
            && shared.systemsRevision()==ManualPressureSystems.revision();
        if(!same){
            cols=WIDTHS[settings.radarResolution];rows=HEIGHTS[settings.radarResolution];
            WeatherModel.Weather[] w=new WeatherModel.Weather[cols*rows];
            double[] rv=new double[w.length],ps=new double[w.length],hs=new double[w.length],js=new double[w.length];
            java.util.Arrays.fill(rv,Double.NaN);java.util.Arrays.fill(hs,Double.NaN);java.util.Arrays.fill(js,Double.NaN);
            shared=new WeatherCache(bucket,cx,cz,range,settings.radarResolution,settings.weatherSpeed,
                settings.stormFrequency,settings.stormStrength,settings.weatherExperience,settings.mode,settings.precipitationMmH,
                settings.temperatureOffset,settings.highPressureStrength,settings.lowPressureStrength,
                settings.pressureLifetime,ManualPressureSystems.revision(),w,rv,ps,hs,js);
            cacheTick=bucket; cacheX=cx;cacheZ=cz;cacheRange=range;cacheRes=settings.radarResolution;
            cacheTime=bucket*100;rowsDone=0;detailDone=0;
        }else{
            cols=WIDTHS[settings.radarResolution];rows=HEIGHTS[settings.radarResolution];
            cacheTick=bucket;cacheX=cx;cacheZ=cz;cacheRange=range;cacheTime=bucket*100;
            if(rowsDone==0) {
                int n=0;for(WeatherModel.Weather w:shared.samples()){if(w==null)break;n++;}
                rowsDone=n/cols; // resume partial work if reopened
            }
        }
        samples=shared.samples();radial=shared.radial();pressure=shared.pressure();heights=shared.heights();jetSpeeds=shared.jetSpeeds();
        if(colors.length!=cols*rows)colors=new int[cols*rows];
        if(cacheView!=view || cacheForecast!=forecastHours){
            cacheView=view;cacheForecast=forecastHours;detailDone=0;
        }
        // Bounded frame-time budget: cache first, calculate only missing samples.
        // In a full cache, changing views merely re-colours existing sample values.
        int stop=Math.min(rows,rowsDone+(settings.radarResolution==2?20:24));
        double days=cacheTime/24000.0*settings.weatherSpeed;
        for(int y=rowsDone;y<stop;y++) {
            double z=cz+(2.0*(y+.5)/rows-1)*range;
            for(int x=0;x<cols;x++) {
                int idx=y*cols+x;
                if(samples[idx]!=null)continue;
                double wx=cx+(2.0*(x+.5)/cols-1)*range;
                WeatherModel.Weather w=WeatherModel.sample(wx,z,cacheTime,settings);
                samples[idx]=w;pressure[idx]=w.pressure();

            }
        }
        rowsDone=stop;
        // Doppler and upper-air measurements are lazy: rainfall radar does not
        // sample two extra fields for every pixel during initial loading.
        if(view==2 || view==4 || view==6){
            int detailStop=Math.min(rowsDone,detailDone+18);
            for(int y=detailDone;y<detailStop;y++){
                double z=cz+(2.0*(y+.5)/rows-1)*range;
                for(int x=0;x<cols;x++){
                    int idx=y*cols+x;if(samples[idx]==null)continue;
                    double wx=cx+(2.0*(x+.5)/cols-1)*range;
                    if(view==6 && Double.isNaN(jetSpeeds[idx])) {
                        double[] jet=SynopticSystems.jetstream(wx,z,days);
                        jetSpeeds[idx]=Math.hypot(jet[0],jet[1]);
                    }
                    if(view==4 && Double.isNaN(heights[idx]))
                        heights[idx]=SynopticSystems.sample(wx,z,days).height500();
                    if(view==2 && Double.isNaN(radial[idx])){
                        WeatherModel.Weather w=samples[idx];
                        WeatherCells.Field cell=WeatherCells.sample(wx,z,days);
                        double dx=wx-cell.centerX(),dz=z-cell.centerZ(),d=Math.hypot(dx,dz);
                        double a=cell.rotation()*53*Math.exp(-Math.pow(d/Math.max(32,cell.radius()*.65),2));
                        double norm=Math.max(15,d);
                        radial[idx]=SynopticSystems.radialVelocity(cx,cz,wx,z,
                            w.windX()*w.windKmh()-dz/norm*a,w.windZ()*w.windKmh()+dx/norm*a);
                    }
                }
            }
            detailDone=detailStop;
        }
        // The cached measurement grid supports all seven modes without recomputing weather.
        for(int i=0;i<colors.length;i++) {
            WeatherModel.Weather w=samples[i];
            if(w==null){colors[i]=0xFF10212D;continue;}
            colors[i]=switch(view){
                case 0 -> precipitationColor(w);
                case 1 -> scalarColor(w.storm()*100,0,100);
                case 2 -> Double.isNaN(radial[i])?0xFF10212D:velocityColor(radial[i]);
                case 3 -> pressureColor(pressure[i]);
                case 4 -> Double.isNaN(heights[i])?0xFF10212D:heightColor(heights[i]);
                case 5 -> scalarColor(w.windKmh(),0,150);
                case 6 -> Double.isNaN(jetSpeeds[i])?0xFF10212D:scalarColor(jetSpeeds[i],15,165);
                default -> temperatureColor(w.t2());
            };
        }
        long nextMarkerKey=bucket*31+cx*7L+cz*13L+view*177L+range+ (settings.radarIsobars?1:0);
        if(nextMarkerKey!=markerKey){
            markers.clear();
            if(view==0 || view==1 || view==2 || view==3 || settings.radarIsobars)
                prepareMarkers(cx,cz,range,cacheTime);
            markerKey=nextMarkerKey;
        }
        // Merge adjacent pixels of equal colour: substantially fewer GUI fill calls
        // over large dry/background areas, especially on integrated graphics.
        for(int y=0;y<rows;y++) {
            int y0=my+y*mh/rows,y1=my+(y+1)*mh/rows;
            int x=0;
            while(x<cols){
                int tint=colors[y*cols+x],end=x+1;
                while(end<cols && colors[y*cols+end]==tint)end++;
                ctx.fill(mx+x*mw/cols,y0,mx+end*mw/cols,y1,tint);
                x=end;
            }
        }
        // Crosshairs, static grid and actual pressure contours.
        for(int n=1;n<5;n++) {
            int px=mx+n*mw/5,py=my+n*mh/5;
            ctx.fill(px,my,px+1,my+mh,0x3389B4C8);
            ctx.fill(mx,py,mx+mw,py+1,0x3389B4C8);
        }
        if(settings.radarIsobars || view==3 || view==4)drawContours(ctx,mx,my,mw,mh);
        if(showFronts && view!=4 && view!=6) drawFronts(ctx,mx,my,mw,mh,cx,cz,range,days);
        if(view==1 || view==2 || view==3 || settings.radarIsobars) drawMarkers(ctx,mx,my,mw,mh,cx,cz,range,mouseX,mouseY);
        if(view==1 || view==2) for(AtmosphereAudioLightning.Strike b:AtmosphereAudioLightning.recentStrikes(client.world.getTime())) {
            int sx=mx+(int)((b.x()-cx+range)*mw/(2*range));
            int sy=my+(int)((b.z()-cz+range)*mh/(2*range));
            if(sx>mx&&sx<mx+mw&&sy>my&&sy<my+mh)
                ctx.drawTextWithShadow(textRenderer,"*",sx,sy,0xFFFFFF73);
        }
        ctx.fill(mx+mw/2-3,my+mh/2,mx+mw/2+4,my+mh/2+1,0xFFFFFFFF);
        ctx.fill(mx+mw/2,my+mh/2-3,mx+mw/2+1,my+mh/2+4,0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer,"N ^",mx+6,my+6,0xFFF0FBFF);
        // Two concise explanatory lines; cursor values show the actual model units.
        String legend=switch(view){case 0->"REGEN gruen-gelb-rot | HAGEL rosa | SCHNEE weiss-pink";
            case 1->"Gewitterzellen: Anklicken = markieren; * = Blitz";
            case 2->"DOPPLER: Gruen = auf Radar zu, Rot = vom Radar weg";
            case 3->"BODENDRUCK in hPa: T = Tief, H = Hoch";
            case 4->"500 hPa: Geopotenzialhoehe in dam (Modell)";
            case 5->"WIND: Geschwindigkeit in km/h (Bodennaehe)";
            case 6->"JETSTREAM 300 hPa: Geschwindigkeiten in km/h (Modell)";
            default->"TEMPERATUR in Grad C: Blau = kalt, Rot = warm";};
        ctx.drawCenteredTextWithShadow(textRenderer,legend,width/2,my+mh+7,0xFFCDE3F0);
        String explanation=switch(view){case 0->"Farbe = Niederschlagsart und Staerke in mm/h";
            case 1->"Helle Kerne = kraeftigere Zellen; Symbole zeigen Sturmtyp";
            case 2->"Radialgeschwindigkeit in km/h; Rot-Gruen-Paar = Rotation moeglich";
            case 3->"Duennere Linien: alle 4 hPa; kleinere Werte = tieferer Druck";
            case 4->"Hoehenlinien: alle 8 dam; Hoehentrog / Hoehenruecken";
            case 5->"Dunkel = wenig Wind; Hell/Rot = staerkerer Wind";
            case 6->"Jetstreaks: hell/rot = starker Hoehenwind";
            default->"Skala ca. -22 bis +38 Grad C; Werte per Maus anzeigen";};
        ctx.drawCenteredTextWithShadow(textRenderer,explanation,width/2,my+mh+18,0xFF9ABED1);
        if(mouseX>=mx && mouseX<mx+mw && mouseY>=my && mouseY<my+mh) {
            int ix=Math.min(cols-1,(mouseX-mx)*cols/mw),iy=Math.min(rows-1,(mouseY-my)*rows/mh);
            int idx=iy*cols+ix;
            WeatherModel.Weather w=samples[idx];
            if(w!=null){
                String reading=switch(view){
                    case 0 -> String.format(Locale.GERMANY,"Niederschlag: %.1f mm/h",w.rainMmH());
                    case 1 -> String.format(Locale.GERMANY,"Sturmintensitaet: %.0f %%",w.storm()*100);
                    case 2 -> String.format(Locale.GERMANY,"Radialwind: %.0f km/h",radial[idx]);
                    case 3 -> String.format(Locale.GERMANY,"Luftdruck: %.1f hPa",w.pressure());
                    case 4 -> String.format(Locale.GERMANY,"Geopotenzial: %.1f dam",heights[idx]);
                    case 5 -> String.format(Locale.GERMANY,"Wind: %.0f km/h",w.windKmh());
                    case 6 -> String.format(Locale.GERMANY,"Jetstream: %.0f km/h",jetSpeeds[idx]);
                    default -> String.format(Locale.GERMANY,"Temperatur: %+.1f Grad C",w.t2());
                };
                ctx.drawCenteredTextWithShadow(textRenderer,reading,width/2,my+mh+29,0xFFFFFFAE);
            }
        } else ctx.drawCenteredTextWithShadow(textRenderer,"Maus auf Karte: genaue Messwerte",width/2,my+mh+29,0xFF7FA8BC);
        if(rowsDone<rows) ctx.drawCenteredTextWithShadow(textRenderer,"Radarmessung: "+(100*rowsDone/rows)+"%",width/2,my+mh/2+10,0xFFFFFFFF);
    }
    /** Each pressure system has exactly one cold/warm/occluded line, not concentric arcs. */
    private void drawFronts(DrawContext ctx,int mx,int my,int mw,int mh,int cx,int cz,int range,double days){
        for(SynopticSystems.SystemInfo sys:SynopticSystems.systems(cx,cz,days,range+1300)){
            if(!sys.low() || sys.strength()<.35)continue;
            double maturity=Math.max(0,Math.min(1,(sys.age()-.20)/.57));
            for(int kind=0;kind<3;kind++){
                if(kind==2&&maturity<.08)continue;
                int tint=kind==0?0xFF3B8FFF:kind==1?0xFFFF6166:0xFFCE7AFF;
                double lo=kind==2?0:.07+maturity*.25;
                double hi=kind==2?maturity*.87:1;
                if(hi<=lo)continue;
                SynopticSystems.FrontPoint prev=SynopticSystems.frontPoint(sys,kind,lo);
                for(int i=1;i<=27;i++){
                    double t=lo+(hi-lo)*i/27.0;
                    SynopticSystems.FrontPoint cur=SynopticSystems.frontPoint(sys,kind,t);
                    int x0=mx+(int)((prev.x()-cx+range)*mw/(2.0*range));
                    int y0=my+(int)((prev.z()-cz+range)*mh/(2.0*range));
                    int x1=mx+(int)((cur.x()-cx+range)*mw/(2.0*range));
                    int y1=my+(int)((cur.z()-cz+range)*mh/(2.0*range));
                    drawSegment(ctx,x0,y0,x1,y1,tint,mx,my,mw,mh);
                    // Meteorological symbols only on their own single front line.
                    if(i%5==0 && x1>=mx+2 && x1<mx+mw-5 && y1>=my+2 && y1<my+mh-5){
                        if(kind==0 || kind==2 && i%2==0)ctx.drawTextWithShadow(textRenderer,"▲",x1-4,y1-5,tint);
                        else ctx.drawTextWithShadow(textRenderer,"●",x1-3,y1-5,tint);
                    }
                    prev=cur;
                }
            }
        }
    }
    private static void drawSegment(DrawContext ctx,int x0,int y0,int x1,int y1,int tint,int mx,int my,int mw,int mh){
        int steps=Math.max(1,Math.max(Math.abs(x1-x0),Math.abs(y1-y0)));
        for(int k=0;k<=steps;k++){
            int x=x0+(x1-x0)*k/steps,y=y0+(y1-y0)*k/steps;
            if(x>=mx&&x<mx+mw-1&&y>=my&&y<my+mh-1)ctx.fill(x,y,x+2,y+2,tint);
        }
    }
    private int radarValue(WeatherModel.Weather w,double x,double z,double days,double rv) {
        int color=switch(view) {
            case 0 -> precipitationColor(w);
            case 1 -> scalarColor(w.storm()*100,0,100);
            case 2 -> velocityColor(rv);
            case 3 -> pressureColor(w.pressure());
            case 4 -> heightColor(SynopticSystems.sample(x,z,days).height500());
            case 5 -> scalarColor(w.windKmh(),0,150);
            default -> temperatureColor(w.t2());
        };
        return color;
    }
    /** Continuous, thin marching-squares contour segments (1 pixel).
     * The previous algorithm rendered isolated 2x2 dots and was hard to read.
     * Each grid square intersects a contour at most twice per boundary. */
    private void drawContours(DrawContext c,int mx,int my,int w,int h) {
        if(cols<2||rowsDone<2)return;
        boolean upper=view==4;
        double[] grid=upper?heights:pressure;
        double interval=upper?8.0:4.0; // fewer isopleths: dam at 500 hPa, hPa at surface
        double[] ex=new double[4],ey=new double[4];
        // Contour detail is independent of precipitation resolution; reduce
        // repeated GUI work on the largest measurement grid.
        int stride=cols>=144?2:1;
        for(int y=stride;y<Math.min(rowsDone,rows);y+=stride) for(int x=stride;x<cols;x+=stride) {
            double a=grid[(y-stride)*cols+x-stride],b=grid[(y-stride)*cols+x];
            double d=grid[y*cols+x-stride],e=grid[y*cols+x];
            if(!Double.isFinite(a)||!Double.isFinite(b)||!Double.isFinite(d)||!Double.isFinite(e))continue;
            // Skip non-measured upper-air fields and anomalously discontinuous cells.
            if(upper&&(Double.isNaN(a)||Double.isNaN(b)||Double.isNaN(d)||Double.isNaN(e)))continue;
            double min=Math.min(Math.min(a,b),Math.min(d,e));
            double max=Math.max(Math.max(a,b),Math.max(d,e));
            if(max-min>18)continue;
            int first=(int)Math.ceil(min/interval),last=(int)Math.floor(max/interval);
            for(int iso=first;iso<=last;iso++){
                double level=iso*interval;
                int count=0;
                // Edge interpolation avoids blocky square outlines.
                if((a<level)!=(b<level)){double t=(level-a)/(b-a);ex[count]=x-stride+t*stride;ey[count++]=y-stride;}
                if((b<level)!=(e<level)){double t=(level-b)/(e-b);ex[count]=x;ey[count++]=y-stride+t*stride;}
                if((e<level)!=(d<level)){double t=(level-e)/(d-e);ex[count]=x-t*stride;ey[count++]=y;}
                if((d<level)!=(a<level)){double t=(level-d)/(a-d);ex[count]=x-stride;ey[count++]=y-t*stride;}
                for(int k=0;k+1<count;k+=2){
                    int x0=mx+(int)Math.round(ex[k]*w/cols), y0=my+(int)Math.round(ey[k]*h/rows);
                    int x1=mx+(int)Math.round(ex[k+1]*w/cols), y1=my+(int)Math.round(ey[k+1]*h/rows);
                    thinSegment(c,x0,y0,x1,y1,0xB9E8E5D5,mx,my,w,h);
                }
                // Sparse numbers, aligned with their own contour rather than a label cloud.
                if(count>=2 && x%68==0 && y%58==0){
                    int tx=mx+x*w/cols,ty=my+y*h/rows;
                    if(tx<mx+w-30&&ty<my+h-10)c.drawTextWithShadow(textRenderer,Integer.toString((int)level),tx,ty,0xFFD8E6ED);
                }
            }
        }
    }
    private static void thinSegment(DrawContext c,int x0,int y0,int x1,int y1,int tint,int mx,int my,int mw,int mh) {
        int steps=Math.max(1,Math.max(Math.abs(x1-x0),Math.abs(y1-y0)));
        for(int i=0;i<=steps;i++){
            int x=x0+(x1-x0)*i/steps,y=y0+(y1-y0)*i/steps;
            if(x>=mx&&y>=my&&x<mx+mw&&y<my+mh)c.fill(x,y,x+1,y+1,tint);
        }
    }
    private void prepareMarkers(double cx,double cz,int range,long time) {
        double days=time/24000.0*settings.weatherSpeed;
        int gx=(int)Math.floor((cx-days*80)/690.0),gz=(int)Math.floor((cz-days*170)/690.0);
        for(int j=-8;j<=8;j++)for(int i=-8;i<=8;i++) {
            WeatherCells.Cell cell=WeatherCells.cell(gx+i,gz+j,days);
            if(cell.growth()<.30 || Math.abs(cell.x()-cx)>range || Math.abs(cell.z()-cz)>range)continue;
            String kind=WeatherCells.NAMES[cell.type()];
            String info=cell.stage()+" · "+String.format(Locale.GERMANY,"%.1f Tage",cell.ageDays());
            markers.add(new Marker(cell.x(),cell.z(),kind,info,cell.type()>=4?0xFFFF88DD:0xFFFFEEAA,cell.id()));
            if(cell.type()==WeatherCells.SUPERCELL && cell.rotation()>.22
                    && StormEvolution.tornadoActivity(cell.id(),cell.growth(),settings.tornadoChance)>.88)
                addTornadoMarker(cell.x(),cell.z(),cell.radius(),cell.windX(),cell.windZ(),cell.id());
        }
        for(StormEvents.Event e:StormEvents.events()) {
            if(Math.abs(e.x()-cx)>range || Math.abs(e.z()-cz)>range)continue;
            markers.add(new Marker(e.x(),e.z(),WeatherCells.NAMES[e.type()],"Manuell · "+String.format(Locale.GERMANY,"%.1f Tage",e.ageDays(time,settings)),0xFF86F2FF,e.started()));
            if(e.type()==WeatherCells.SUPERCELL) {
                double growth=WeatherCells.lifecycle(.28+e.ageDays(time,settings)/e.lifeDays()*.72);
                long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());
                double angle=StormEvolution.manualAngle(seed);
                if(StormEvolution.tornadoActivity(seed,growth,settings.tornadoChance)>.88)
                    addTornadoMarker(e.x(),e.z(),e.radius(),Math.cos(angle),Math.sin(angle),seed);
            }
        }
        if(view==3 || settings.radarIsobars) {
            // Isobars are derived from pressure samples, not arbitrary map symbols.
            for(int j=-4;j<=4;j++)for(int i=-4;i<=4;i++) {
                double x=cx+i*range/4.0,z=cz+j*range/4.0;
                SynopticSystems.Field f=SynopticSystems.sample(x,z,days);
                if(f.cyclone()>.74)markers.add(new Marker(x,z,"T",String.format(Locale.GERMANY,"%.0f hPa",f.pressure()),0xFFFFCC77,Long.MIN_VALUE));
                else if(f.anticyclone()>.80)markers.add(new Marker(x,z,"H",String.format(Locale.GERMANY,"%.0f hPa",f.pressure()),0xFF88EEFF,Long.MIN_VALUE));
            }
        }
    }
    private void addTornadoMarker(double x,double z,double radius,double windX,double windZ,long id) {
        double along=-.10*radius,across=-.45*radius;
        markers.add(new Marker(x+along*windX-across*windZ,
                z+along*windZ+across*windX,"Tornado","Am Hook Echo",0xFFFFFFFF,id));
    }
    private void drawMarkers(DrawContext c,int mx,int my,int w,int h,double cx,double cz,int range,int mouseX,int mouseY) {
        Marker hover=null;
        for(Marker m:markers) {
            int sx=mx+(int)((m.x()-cx+range)*w/(range*2)),sy=my+(int)((m.z()-cz+range)*h/(range*2));
            if(sx<mx||sx>=mx+w||sy<my||sy>=my+h)continue;
            boolean highOrLow=m.name().equals("T")||m.name().equals("H");
            if(view!=1 && view!=2 && !(view==0 && m.name().equals("Tornado")) && !highOrLow)continue;
            String symbol=highOrLow?m.name():m.name().equals("Tornado")?"T":m.id()==trackedCell?"[+]":m.name().startsWith("Super")?"Z":m.name().startsWith("Squall")?"L":"G";
            c.drawTextWithShadow(textRenderer,symbol,sx,sy,m.tint());
            if(Math.abs(mouseX-sx)<12&&Math.abs(mouseY-sy)<12) hover=m;
        }
        if(hover!=null){
            String s=hover.name()+" | "+hover.details();
            int px=Math.max(mx+4,Math.min(mx+w-textRenderer.getWidth(s)-10,mouseX+9));
            int py=Math.max(my+3,Math.min(my+h-18,mouseY+12));
            c.fill(px-3,py-2,px+textRenderer.getWidth(s)+4,py+12,0xE90D1823);
            c.drawTextWithShadow(textRenderer,s,px,py,0xFFFDFAE7);
        }
    }
    private static int precipitationColor(WeatherModel.Weather w) {
        double v=w.rainMmH();if(v<.15)return 0xFF080B10;
        if(w.precipitationKind()==4)return v>62?0xFF94219F:v>25?0xFFC52B9C:0xFFEE6DAF;
        if(w.precipitationKind()==1||w.precipitationKind()==2)
            return v>65?0xFFFA55D4:v>30?0xFFE7B6F5:v>8?0xFFC1E7FB:0xFFF7FCFF;
        if(v<1)return 0xFF193C91; if(v<4)return 0xFF08A86E;
        if(v<10)return 0xFF49D538; if(v<20)return 0xFFE1E43A;
        if(v<35)return 0xFFFFAA29; if(v<55)return 0xFFED4B29;
        return v<90?0xFFD51B26:0xFFB511B5;
    }
    private static int velocityColor(double v){
        double f=Math.min(1,Math.abs(v)/95);
        if(Math.abs(v)<5)return 0xFF85858C;
        int mid=(int)(75+100*f), bright=(int)(75+175*f);
        return v<0?0xFF000000|(bright<<8)|(mid/3):0xFF000000|(bright<<16)|((mid/3)<<8)|(mid/3);
    }
    private static int pressureColor(double p){return scalarColor(p,976,1040);}
    private static int heightColor(double h){return scalarColor(h,495,604);}
    private static int temperatureColor(double t){return scalarColor(t,-22,38);}
    private static int scalarColor(double v,double lo,double hi) {
        double a=Math.max(0,Math.min(1,(v-lo)/(hi-lo)));
        int r=(int)(34+217*a),g=(int)(95+115*Math.sin(a*Math.PI)),b=(int)(190-148*a);
        return 0xFF000000|(r<<16)|(g<<8)|b;
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        if(button==0 && view==1 && client!=null && client.player!=null) {
            int mw=Math.max(46,Math.min(width-22,height-155)),mh=mw,mx=(width-mw)/2,my=24;
            int range=RANGES[settings.radarRange];double cx=cacheX,cz=cacheZ;
            for(Marker m:markers){
                int x=mx+(int)((m.x()-cx+range)*mw/(2*range));
                int y=my+(int)((m.z()-cz+range)*mh/(2*range));
                if(Math.abs(mouseX-x)<12 && Math.abs(mouseY-y)<12){trackedCell=m.id();return true;}
            }
        }
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override public boolean keyPressed(int key,int scan,int mod){if(key==GLFW.GLFW_KEY_R){close();return true;}return super.keyPressed(key,scan,mod);}
    @Override public void close(){MinecraftClient.getInstance().setScreen(null);}
    @Override public boolean shouldPause(){return false;}
}
