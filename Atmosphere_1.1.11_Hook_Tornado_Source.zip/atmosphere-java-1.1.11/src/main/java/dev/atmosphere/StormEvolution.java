package dev.atmosphere;

/** Pure mathematical helpers shared by the renderer, storm model and radar.
 * All curves are bounded, deterministic and independent of loaded world chunks.
 * Storms remain an artistic simulation: no destructive weather mechanics.
 */
public final class StormEvolution {
    private StormEvolution() {}

    public static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }
    public static double smooth(double a, double b, double x) {
        double u=clamp((x-a)/(b-a),0,1); return u*u*(3-2*u);
    }
    public static double localTower(double life, int index, int total, long seed) {
        double stagger = index/(double)Math.max(1,total-1);
        double jitter = .14*(WeatherCells.hash(seed,index,195)-.5);
        double wake = smooth(.08+stagger*.46+jitter,.29+stagger*.48+jitter,life);
        return wake * (.83+.17*Math.sin(index*2.71+seed*.001+life*9));
    }
    /** Higher clouds feel a different wind direction and a stronger velocity. */
    public static double[] altitudeWind(double baseX,double baseZ,double height,long seed,double days) {
        double altitude=clamp((height-100)/390,0,1);
        double angle=Math.atan2(baseZ,baseX)+altitude*(.38+.17*Math.sin(seed*.001+days*.21));
        double speed=1+altitude*.66;
        return new double[]{Math.cos(angle)*speed,Math.sin(angle)*speed};
    }
    public static String stage(double phase) {
        phase=phase-Math.floor(phase);
        if(phase<.04) return "Entstehung";
        if(phase<.32) return "Wachstum";
        if(phase<.65) return "Reife";
        if(phase<.94) return "Auflösung";
        return "Zerfall";
    }
    public static double rainCurtain(double storm,double cloud,double humidity) {
        return smooth(.20,.82,storm)*smooth(.30,.75,cloud)*smooth(.38,.78,humidity);
    }
    /** Outflow arrives ahead of the rain core during the mature part of a strong storm. */
    public static double gustFront(double along, double across, double radius, double growth, int type) {
        if (type < WeatherCells.SEVERE) return 0;
        double leading = radius * 1.15;
        double width = Math.max(25, radius * .34);
        double band = Math.exp(-Math.pow((along-leading)/width, 2));
        double lateral = Math.exp(-Math.pow(across/(radius*(type==WeatherCells.SQUALL?2.4:1.15)), 4));
        return clamp(band*lateral*smooth(.38,.78,growth),0,1);
    }
    /** Smooth, seeded bands and gaps shared by the world weather and radar. */
    public static double precipitationStructure(double along, double across, double radius, long seed, int type) {
        double scale = Math.max(40, radius);
        double phase = WeatherCells.hash(seed, 0, 733) * Math.PI * 2;
        double broad = Math.sin(along / (scale * .55) + across / (scale * .39) + phase);
        double fine = Math.sin(along / (scale * .21) - across / (scale * .34) + phase * 1.7);
        double segment = type == WeatherCells.SQUALL
                ? .58 + .42 * smooth(-.65,.55, Math.sin(across / (scale * .48) + phase))
                : 1;
        return clamp((.56 + .31 * broad + .13 * fine) * segment, .08, 1);
    }
    public static long manualSeed(long started, double x, double z) {
        return started ^ Long.rotateLeft(Double.doubleToLongBits(x),21)
                ^ Long.rotateLeft(Double.doubleToLongBits(z),43);
    }
    public static double manualAngle(long seed) {
        return .7+WeatherCells.hash(seed,0,947)*1.0;
    }
    public static double hookMaturity(double growth) {
        return smooth(.45,.76,growth);
    }
    public static double tornadoActivity(long seed,double growth,int chance) {
        if(chance<=0)return 0;
        double probability=switch(chance){case 1->.08;case 2->.25;default->1.0;};
        if(WeatherCells.hash(seed,4,28)>=probability)return 0;
        return smooth(.70,.85,growth)*(1-smooth(.93,.99,growth));
    }
    /** Rain rate envelope in storm-relative coordinates; the same field feeds radar and particles. */
    public static double rainProfile(double along, double across, double radius, long seed, int type) {
        return rainProfile(along,across,radius,seed,type,1);
    }
    public static double rainProfile(double along, double across, double radius, long seed, int type,double growth) {
        double r=Math.max(40,radius);
        double texture=precipitationStructure(along,across,r,seed,type);
        if(type==WeatherCells.SUPERCELL) {
            // An asymmetric forward-flank shield with a curved rear-flank hook.
            double u=along/r, v=across/r;
            double shield=Math.exp(-Math.pow((u+.38)/1.13,2)
                    -Math.pow((v-.55)/.68,2));
            double core=Math.exp(-Math.pow((u+.28)/.43,2)
                    -Math.pow((v-.38)/.31,2));
            // Narrow curved appendage wraps around a low-reflectivity inflow notch.
            double hookTurn=-(v+.10);
            double hookPath=-.17-1.15*hookTurn+1.05*hookTurn*hookTurn;
            double hook=Math.exp(-Math.pow((u-hookPath)/.105,2))
                    *smooth(-1.35,-1.05,v)*(1-smooth(-.05,.20,v))
                    *hookMaturity(growth);
            double notch=Math.exp(-Math.pow((u-.02)/.35,2)
                    -Math.pow((v+.30)/.36,2));
            return clamp(Math.max(shield*.75,Math.max(core,hook*.81))
                    *(.70+.30*texture)*(1-.94*notch),0,1);
        }
        if(type==WeatherCells.SQUALL) {
            double bow=.18*r*Math.sin(across/(.85*r)+WeatherCells.hash(seed,0,913)*6.28318530718);
            double band=Math.exp(-Math.pow((along-bow)/(.36*r),2)
                    -Math.pow(across/(2.20*r),4));
            return clamp(band*(.25+.75*texture),0,1);
        }
        double main=Math.exp(-Math.pow((along+.18*r)/(.82*r),2)-Math.pow(across/(.76*r),2));
        double side=Math.exp(-Math.pow((along-.36*r)/(.43*r),2)
                -Math.pow((across+.70*r)/(.46*r),2));
        return clamp(Math.max(main,side*.67)*(.35+.65*texture),0,1);
    }
    public static double virga(double storm,double cloud,double humidity) {
        return smooth(.15,.61,storm)*smooth(.35,.80,cloud)*(1-smooth(.42,.70,humidity));
    }
    public static double flashPulse(long age) {
        return switch((int)age) { case 0 -> 1.0; case 1 -> .23; case 2 -> .78;
            case 3 -> .12; case 4 -> .52; case 5 -> .18; default -> 0.0; };
    }
}
