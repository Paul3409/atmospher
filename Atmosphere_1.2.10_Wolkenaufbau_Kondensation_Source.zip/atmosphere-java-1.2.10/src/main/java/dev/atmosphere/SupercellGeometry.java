package dev.atmosphere;

/** One closed surface from lowered wall cloud to tilted updraft and anvil.
 * No independent plate, hollow tube or repeated circular cloud rings. */
public final class SupercellGeometry {
    private SupercellGeometry(){}
    public record Point(double x,double y,double z,double nx,double ny,double nz){}
    private record Position(double x,double y,double z){}
    public static double lowering(double growth){return 42*WeatherCells.smooth(.35,.85,growth);}
    private static double profile(double t,double growth){
        double maturity=WeatherCells.smooth(.35,.85,growth);
        // Restore the exact two-level lowering/base silhouette of the selected preview.
        double wall=.33*maturity*Math.exp(-Math.pow((t-.12)/.18,2));
        double base=.16*Math.exp(-Math.pow((t-.29)/.20,2));
        double anvil=1.30*maturity*Math.exp(-Math.pow((t-.83)/.21,2));
        return (.36+wall+base+anvil)
            *Math.sqrt(WeatherCells.smooth(0,.13,t))
            *Math.sqrt(1-WeatherCells.smooth(.89,1,t));
    }
    private static Position position(long seed,double t,double angle,double radius,double base,double height,
                                      double wx,double wz,double jetX,double jetZ,double growth,double ticks,double drop){
        double jet=Math.max(1e-6,Math.hypot(jetX,jetZ));
        double canopy=WeatherCells.smooth(.70,.92,t)*(1-WeatherCells.smooth(.96,1,t));
        double lean=height*.32*t*t+radius*.30*canopy*WeatherCells.smooth(.45,.85,growth);
        double rootX=(.05*wx+.35*wz)*radius,rootZ=(.05*wz-.35*wx)*radius;
        double spin=ticks*.006*(1-WeatherCells.smooth(.13,.30,t));
        double noise=CloudNoise.billow(Math.cos(angle-spin)*1.4,t*3.8,Math.sin(angle-spin)*1.4,seed);
        // Fine billows belong to the updraft; the thin anvil has broad, softer edges.
        double relief=.65;
        double lobes=.16*Math.cos(angle*5+t*17+seed%19)+.09*Math.cos(angle*8-t*23);
        double r=radius*profile(t,growth)*(1+noise*relief+lobes);
        double unevenY=radius*(.12*noise+.065*Math.cos(angle*5+t*11))*Math.sin(Math.PI*t);
        return new Position(rootX+lean*jetX/jet+Math.cos(angle)*r,
                base-drop+(height+8+drop)*t+unevenY,
                rootZ+lean*jetZ/jet+Math.sin(angle)*r);
    }
    public static Point point(long seed,double t,double angle,double radius,double base,double height,
                               double wx,double wz,double jetX,double jetZ){
        return point(seed,t,angle,radius,base,height,wx,wz,jetX,jetZ,1);
    }
    public static Point point(long seed,double t,double angle,double radius,double base,double height,
                               double wx,double wz,double jetX,double jetZ,double growth){
        return point(seed,t,angle,radius,base,height,wx,wz,jetX,jetZ,growth,0,lowering(growth));
    }
    public static Point point(long seed,double t,double angle,double radius,double base,double height,
                               double wx,double wz,double jetX,double jetZ,double growth,double ticks,double drop){
        Position v=position(seed,t,angle,radius,base,height,wx,wz,jetX,jetZ,growth,ticks,drop);
        if(t<=1e-6||t>=1-1e-6)return new Point(v.x,v.y,v.z,0,t<.5?-1:1,0);
        double e=.0001;
        Position p=position(seed,t+e,angle,radius,base,height,wx,wz,jetX,jetZ,growth,ticks,drop);
        Position a=position(seed,t,angle+e,radius,base,height,wx,wz,jetX,jetZ,growth,ticks,drop);
        double px=p.x-v.x,py=p.y-v.y,pz=p.z-v.z,ax=a.x-v.x,ay=a.y-v.y,az=a.z-v.z;
        double nx=py*az-pz*ay,ny=pz*ax-px*az,nz=px*ay-py*ax;
        double n=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));
        return new Point(v.x,v.y,v.z,nx/n,ny/n,nz/n);
    }
}
