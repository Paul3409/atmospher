from PIL import Image
import math,pathlib
im=Image.new('RGBA',(128,128))
for y in range(128):
 for x in range(128):
  u=(x-63.5)/63.5;v=(y-63.5)/63.5
  radius=math.sqrt(u*u+v*v)
  lobes=1+.10*math.sin(u*13+v*7)+.07*math.cos(v*19-u*4)
  density=max(0,1-radius/lobes)**2
  im.putpixel((x,y),(235,235,235,int(255*density)))
im.save(pathlib.Path(__file__).resolve().parents[1]/'src/main/resources/assets/atmosphere/textures/environment/condensation.png')
