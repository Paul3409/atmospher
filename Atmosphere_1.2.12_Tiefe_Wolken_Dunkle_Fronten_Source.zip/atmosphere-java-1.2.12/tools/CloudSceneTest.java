import dev.atmosphere.*;
import java.util.List;

public final class CloudSceneTest {
 static void ck(boolean ok,String text){if(!ok)throw new AssertionError(text);}
 static void winding(double[] p,double[] a,double[] b,double[] normal){
  double ax=a[0]-p[0],ay=a[1]-p[1],az=a[2]-p[2];
  double bx=b[0]-p[0],by=b[1]-p[1],bz=b[2]-p[2];
  ck((ay*bz-az*by)*normal[0]+(az*bx-ax*bz)*normal[1]+(ax*by-ay*bx)*normal[2]>0,
    "Depth-writing/culling pass has inward-facing surface");
 }
 public static void main(String[] args){
  var storm=new WeatherCells.Cell(WeatherCells.SUPERCELL,0,0,270,1,1,1,.8,1,0,42);
  ck(CloudScene.backgroundVisibility(0,0,List.of(storm))==0,"Deck still hides mature cell");
  ck(CloudScene.backgroundVisibility(1000,0,List.of(storm))==1,"Distant clouds removed");
  double previous=-1;
  for(int x=0;x<1000;x++){
   double visible=CloudScene.backgroundVisibility(x,0,List.of(storm));
   ck(visible>=0&&visible<=1&&visible>=previous,"Background transition discontinuous");previous=visible;
  }
  var young=new WeatherCells.Cell(WeatherCells.SUPERCELL,0,0,270,.1,.1,0,.1,1,0,42);
  ck(CloudScene.backgroundVisibility(0,0,List.of(young))==1,"Young cell erases background");
  for(int q=0;q<4;q++)ck(CloudScene.stormLevels(q)>=44&&CloudScene.stormSides(q)>=48,"Reference shape loses lowering on low quality");
  for(int i=0;i<=100;i++){
   double t=i/100.0;
   var p=SupercellGeometry.point(42,t,.4,270,130,355,1,0,.8,.6);
   ck(Double.isFinite(p.x()+p.y()+p.z()+p.nx()),"Template invalid");
   if(t==0)ck(p.y()==88,"Wall lowering changed");
  }
  for(int i=0;i<=100;i++){
   double v=i/100.0;
   ck(RainVeil.opacity(0,v)==0&&RainVeil.opacity(1,v)==0,"Hard rain side edge");
   ck(RainVeil.opacity(v,0)==0&&RainVeil.opacity(v,1)==0,"Hard rain top/bottom edge");
   ck(RainVeil.opacity(.5,v)>=0&&RainVeil.opacity(.5,v)<=1,"Rain opacity out of bounds");
  }
  ck(RainVeil.opacity(.5,.3)>.1,"Rain invisible");
  ck(CloudLighting.shade(0,1,0,.4)>CloudLighting.shade(0,-1,0,.4),"Lighting inverted");
  // Verify the exact vertex order used by the two game mesh writers.
  for(int j=1;j<43;j++)for(int i=0;i<80;i++){
   double t=j/44.0,a=i*Math.PI*2/80,e=.0001;
   var p=SupercellGeometry.point(42,t,a,270,130,355,1,0,.8,.6);
   var q=SupercellGeometry.point(42,t+e,a,270,130,355,1,0,.8,.6);
   var r=SupercellGeometry.point(42,t,a+e,270,130,355,1,0,.8,.6);
   winding(new double[]{p.x(),p.y(),p.z()},new double[]{q.x(),q.y(),q.z()},
      new double[]{r.x(),r.y(),r.z()},new double[]{p.nx(),p.ny(),p.nz()});
   var cp=CloudGeometry.point(42,t*Math.PI,a,120,100,95,130,.8,.6,0);
   var cq=CloudGeometry.point(42,t*Math.PI,a+e,120,100,95,130,.8,.6,0);
   var cr=CloudGeometry.point(42,t*Math.PI+e,a,120,100,95,130,.8,.6,0);
   winding(new double[]{cp.x(),cp.y(),cp.z()},new double[]{cq.x(),cq.y(),cq.z()},
      new double[]{cr.x(),cr.y(),cr.z()},new double[]{cp.nx(),cp.ny(),cp.nz()});
  }
  var guide=new CloudGeometry.Point[45][65];
  for(int j=0;j<=44;j++)for(int i=0;i<=64;i++)guide[j][i]=CloudGeometry.point(42,j*Math.PI/44,i*Math.PI*2/64,160,120,140,125,1,0,0);
  int count=0;
  for(int quality=0;quality<4;quality++){
   var volume=CloudCondensation.volume(guide,quality);
   ck(volume.size()>count&&volume.size()<=1000,"Unbounded or non-scaling condensation");count=volume.size();
   ck(volume.equals(CloudCondensation.volume(guide,quality)),"Condensation moves with camera/random frame");
   for(var puff:volume)ck(Double.isFinite(puff.x()+puff.y()+puff.z()+puff.width()+puff.height())&&puff.width()>0&&puff.height()>0,"Invalid volume puff");
  }
  for(int type=0;type<=5;type++)for(int n=0;n<=100;n++){
   double b=CloudAltitude.base(n/100.0,n/100.0,type);
   ck(b>=(type==4?170:type==5?110:100)&&b<=(type==4?190:140),"Cloud base range");
   for(double ground:new double[]{64,110,220,360}){
    double adjusted=CloudAltitude.terrain(b,ground,type);
    ck(adjusted-ground>=(type==4?106:44),"Terrain clearance lost");
   }
  }
  ck(StormShade.coverage(0,0,440,1,WeatherCells.SQUALL)>.99,"Squall interior not dark");
  ck(StormShade.coverage(2000,0,440,1,WeatherCells.SQUALL)==0,"Clear area darkened");
  ck(StormShade.coverage(0,0,440,1,WeatherCells.THUNDER)==0,"Squall mask leaked");
  ck(StormShade.light(.3,1,70,120,1)<.35,"Squall too bright");
  ck(StormShade.light(.3,1,500,120,1)==1,"Above-cloud view darkened");
  System.out.println("PASS: full-scene background suppression, reference LOD floor, rain edge mask and shared lighting");
 }
}
