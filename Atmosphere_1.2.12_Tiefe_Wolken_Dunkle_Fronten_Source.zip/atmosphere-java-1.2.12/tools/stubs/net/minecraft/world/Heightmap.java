package net.minecraft.world;
public final class Heightmap {public enum Type {MOTION_BLOCKING_NO_LEAVES}}
