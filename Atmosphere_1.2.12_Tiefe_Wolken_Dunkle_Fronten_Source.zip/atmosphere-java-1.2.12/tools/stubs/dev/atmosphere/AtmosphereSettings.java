package dev.atmosphere;
public class AtmosphereSettings {
public int rainParticles=100;
public int snowParticles=100;
public int dustParticles=100;
public int particleRadius=58;
public int rainVolume=100;
public int thunderRange=500;
public int profileStrength=100;
 public int tornadoChance=1,tornadoPercent=25;
 public int tornadoCode(){return tornadoChance==5?1000+tornadoPercent:tornadoChance;}

 public static final AtmosphereSettings INSTANCE=new AtmosphereSettings();
 public static AtmosphereSettings get(){return INSTANCE;}
 public int weatherExperience=2,weatherSpeed=1,seasonOffset=0,temperatureOffset=0,stormFrequency=100,stormStrength=100;
 public int windKmh=35,gustKmh=80,windDirectionDegrees=270,mode=0,precipitationMmH=15,precipitationType=0;
 public int highPressureStrength=100,lowPressureStrength=100,pressureLifetime=1;
 public int lightningBrightness=100,lightningSize=100,thunderVolume=100,windAmbientVolume=40;
 public boolean windGusts=true,manualWind=false;
}
