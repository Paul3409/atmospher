"""Prepare user-provided recordings. Does not run as part of a normal mod build."""
import pathlib,subprocess,json,concurrent.futures,argparse
root=pathlib.Path(__file__).resolve().parents[1]
assets=root/'src/main/resources/assets/atmosphere'
parser=argparse.ArgumentParser()
parser.add_argument("--weather-source",type=pathlib.Path,required=True)
parser.add_argument("--siren-source",type=pathlib.Path)
args=parser.parse_args()
source=args.weather_source
mapping={'rain_light':'regen_normal','rain_medium':'regen_normal','rain_roof':'regen_normal','drizzle':'regen_normal',
 'rain_heavy':'regen_stark','heavy_rain':'regen_stark','rain_extreme':'regen_stark','snow_wind':'wind_winter','wind':'wind_winter',
 'thunder_near':'donner_naheinschlag','thunder_crack':'donner_naheinschlag','thunder_deep':'donner1',
 'thunder_multi':'donner1','thunder_far':'donner_weiterentfernt','thunder_distant':'donner_weiterentfernt',
 'thunder_roll':'donner_weiterentfernt','thunder_rumble':'donner1'}
jobs=[]
for target,name in mapping.items():
 origin=source/(name+'.mp3')
 cmd=['ffmpeg','-y','-loglevel','error','-i',str(origin)]
 if not target.startswith('thunder'):
  duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(origin)],text=True))
  x=1.0
  graph=f'[0:a]asplit=3[b][h][t];[b]atrim=start={x}:end={duration-x},asetpts=PTS-STARTPTS[body];[h]atrim=end={x},asetpts=PTS-STARTPTS[head];[t]atrim=start={duration-x},asetpts=PTS-STARTPTS[tail];[tail][head]acrossfade=d={x}:c1=tri:c2=tri[blend];[body][blend]concat=n=2:v=0:a=1[out]'
  cmd+=['-filter_complex',graph,'-map','[out]']
 jobs.append(cmd+['-ac','1','-ar','44100','-c:a','libvorbis','-q:a','5',str(assets/'sounds'/(target+'.ogg'))])
originals={'probe':'Sirenenprobe','fire':'Alarmierung','warning':'Warnung','clear':'Entwarnung'}
counts={'probe':13,'fire':32,'warning':34,'clear':35}
for signal,label in (originals.items() if args.siren_source else []):
 origin=next(args.siren_source.rglob('Sirenensignal_'+label+'.mp3'))
 for muted in (False,True):
  for boost in (1,2,4):
   for i in range(counts[signal]):
    suffix=('m_' if muted else '')+('g'+str(boost)+'_' if boost>1 else '')
    filters=(['lowpass=f=900'] if muted else [])+([f'volume={boost}','alimiter=limit=0.95:level=0:latency=1'] if boost>1 else [])
    cmd=['ffmpeg','-y','-loglevel','error','-ss',str(i*2),'-i',str(origin),'-t','2.4','-ac','1','-ar','44100']
    if filters:cmd+=['-af',','.join(filters)]
    jobs.append(cmd+['-c:a','libvorbis','-q:a','3',str(assets/'sounds'/f'siren_{signal}_{suffix}{i:02d}.ogg')])
def run(cmd):subprocess.run(cmd,check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as p:list(p.map(run,jobs))
print('Prepared',len(jobs),'weather recordings and overlapping siren slices')
