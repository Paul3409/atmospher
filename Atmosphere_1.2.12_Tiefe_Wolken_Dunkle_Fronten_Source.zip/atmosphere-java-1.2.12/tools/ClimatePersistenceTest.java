import dev.atmosphere.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.nbt.*;

/** Real state classes against small NBT/world test doubles, not a Fabric runtime. */
public final class ClimatePersistenceTest {
 static void ck(boolean v,String s){if(!v)throw new AssertionError(s);}
 public static void main(String[] args){
  var server=new MinecraftServer();var world=server.world;var settings=AtmosphereSettings.get();
  settings.weatherSpeed=1;ClimateState.tick(world);
  StormEvents.spawn(server,4,100,200);ManualPressureSystems.spawn(server,true,970,0,0);
  var event=StormEvents.events().get(0);double initial=event.ageDays(world.daylight,settings);
  long eventId=event.started();double days=ClimateClock.days(world.daylight,1);
  world.daylight+=240000;ClimateState.tick(world);
  ck(ClimateClock.days(world.daylight,1)==days,"Time command advances clock");
  ck(event.ageDays(world.daylight,settings)==initial,"Time command ages manual event");
  settings.weatherSpeed=20;ClimateState.tick(world);
  ck(ClimateClock.days(world.daylight,20)==days,"Speed setting rewinds clock");
  world.age++;world.daylight++;ClimateState.tick(world);
  ck(Math.abs(ClimateClock.days(world.daylight,20)-days-20/24000.0)<1e-12,"Speed integration");
  double before=ClimateClock.days(world.daylight,20),eventAge=event.ageDays(world.daylight,settings);
  world.getPersistentStateManager().saveAndUnload();ClimateClock.reset();StormEvents.reset();ManualPressureSystems.reset();
  ClimateState.tick(world);StormEvents.sync(world);ManualPressureSystems.sync(world);
  ck(ClimateClock.days(world.daylight,20)==before,"Weather clock not restored");
  var loaded=StormEvents.events().get(0);
  ck(loaded.started()==eventId&&loaded.ageDays(world.daylight,settings)==eventAge,"Event rerolled/aged on load");
  ck(Double.isFinite(ManualPressureSystems.centres().get(0).bornDays()),"Pressure birth missing");
  // Legacy manual storm migration keeps its elapsed age, then uses weather time.
  NbtCompound legacy=new NbtCompound(),entry=new NbtCompound();NbtList list=new NbtList();
  entry.putInt("Type",4);entry.putDouble("X",10);entry.putDouble("Z",20);entry.putLong("Start",world.daylight-100);
  entry.putDouble("Radius",270);entry.putDouble("Life",1.8);list.add(entry);legacy.put("Events",list);
  world.getPersistentStateManager().live.remove("atmosphere_storms_v06");
  world.getPersistentStateManager().saved.put("atmosphere_storms_v06",legacy);
  StormEvents.sync(world);double migrated=StormEvents.events().get(0).ageDays(world.daylight,settings);
  ck(Math.abs(migrated-100/24000.0*20)<1e-12,"Legacy age changed on migration");
  world.daylight=6000;ClimateState.tick(world);StormEvents.sync(world);
  ck(Math.abs(StormEvents.events().get(0).ageDays(world.daylight,settings)-migrated)<1e-12,"Legacy event still uses daylight");
  // Expired events are removed rather than resurrecting as another loop.
  for(int i=0;i<2500;i++){world.age++;world.daylight++;ClimateState.tick(world);}
  StormEvents.sync(world);ck(StormEvents.events().isEmpty(),"Dead manual event returned");
  settings.weatherSpeed=1;StormEvents.spawnTest(server,50,60);
  var test=StormEvents.current();
  ck(test.testTornado(),"Test flag not set");
  long testSeed=StormEvolution.manualSeed(test.started(),test.x(),test.z());
  ck(StormEvents.chanceFor(testSeed,0)==4,"Test overridden by normal chance");
  ck(test.phase(world.daylight,settings)<.25,"Test skips initial development");
  world.getPersistentStateManager().saveAndUnload();StormEvents.reset();
  StormEvents.sync(world);
  ck(StormEvents.current().testTornado(),"Test flag not persisted");
  ck(StormEvents.chanceFor(testSeed,0)==4,"Reloaded test loses guarantee");
  ClimateClock.reset();System.out.println("PASS: actual climate/event NBT round-trip, time/speed changes, legacy migration and expiry (test doubles)");
 }
}
