"""Read-only asset consistency check; requires ffprobe."""
import concurrent.futures,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1])/"src/main/resources"
for path in root.rglob("*.json"):json.loads(path.read_text(encoding="utf-8"))
sounds=json.loads((root/"assets/atmosphere/sounds.json").read_text(encoding="utf-8"))
expected={"probe":13,"fire":32,"warning":34,"clear":35}
paths=[]
for signal,count in expected.items():
    for muffled in ("","m_","g2_","g4_","m_g2_","m_g4_"):
        for i in range(count):
            key=f"siren_{signal}_{muffled}{i:02d}"
            assert key in sounds,key
            path=root/"assets/atmosphere/sounds"/(key+".ogg");assert path.is_file(),path
            paths.append(path)
def verify(path):
    data=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_entries","stream=channels:format=duration","-of","json",str(path)],text=True))
    assert data["streams"][0]["channels"]==1,path
    assert 0<float(data["format"]["duration"])<=2.41,path
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(verify,paths))
for block in ("e57_siren","siren_control"):
    for relative in (f"assets/atmosphere/models/block/{block}.json",f"assets/atmosphere/models/item/{block}.json",f"assets/atmosphere/blockstates/{block}.json",f"data/atmosphere/recipe/{block}.json",f"data/atmosphere/loot_table/blocks/{block}.json"):
        assert (root/relative).is_file(),relative
print(f"PASS: {len(paths)} mono alarm slices, sound IDs, block models, recipes, loot tables and JSON")
