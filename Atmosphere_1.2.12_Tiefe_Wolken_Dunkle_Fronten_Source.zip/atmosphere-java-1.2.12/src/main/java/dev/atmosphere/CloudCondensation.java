package dev.atmosphere;

import java.util.ArrayList;
import java.util.List;

/** Bounded interior and outer condensation, independent of camera and frame rate. */
public final class CloudCondensation {
 private CloudCondensation(){}
 public record Puff(double x,double y,double z,double width,double height,double shade){}
 public static List<Puff> volume(CloudGeometry.Point[][] mesh,int quality){
  int rows=mesh.length-1,cols=mesh[0].length-1;
  int layers=new int[]{8,12,18,24}[Math.max(0,Math.min(3,quality))];
  int spokes=new int[]{8,12,16,20}[Math.max(0,Math.min(3,quality))];
  double low=Double.POSITIVE_INFINITY,high=Double.NEGATIVE_INFINITY;
  for(var row:mesh)for(var p:row){low=Math.min(low,p.y());high=Math.max(high,p.y());}
  double span=Math.max(1,high-low),spacing=span/layers;
  var out=new ArrayList<Puff>();
  for(int j=0;j<layers;j++){
   double level=Math.max(.001,Math.min(rows-.001,(j+.5)*rows/layers));
   double cx=0,cy=0,cz=0;
   for(int i=0;i<cols;i++){var p=interpolate(mesh,level,i);cx+=p.x();cy+=p.y();cz+=p.z();}
   cx/=cols;cy/=cols;cz/=cols;
   double radius=0;for(int i=0;i<cols;i++)radius+=Math.hypot(interpolate(mesh,level,i).x()-cx,interpolate(mesh,level,i).z()-cz)/cols;
   double width=Math.max(3,radius*.38),height=Math.max(3,Math.min(Math.max(spacing*.95,width*.60),span*.16));
   double shade=.48+.42*Math.max(0,Math.min(1,(cy-low)/span));
   out.add(new Puff(cx,cy,cz,width,height,shade));
   for(int band=0;band<2;band++)for(int i=0;i<spokes;i++){
    int col=(int)((i+(band==0?.5:0))*cols/spokes)%cols;var p=interpolate(mesh,level,col);
    double fraction=band==0?.42:.84;
    out.add(new Puff(cx+(p.x()-cx)*fraction,p.y()+spacing*.20*Math.sin(i*2.399+j),cz+(p.z()-cz)*fraction,width*(.94+.10*Math.sin(i*3.1+j)),height*(.95+.10*Math.cos(i+j)),
      shade*(.94+.06*Math.cos(i*2.399+j))));
   }
  }
  return List.copyOf(out);
 }
 private static CloudGeometry.Point interpolate(CloudGeometry.Point[][] mesh,double row,int col){
  int lo=(int)row,hi=Math.min(mesh.length-1,lo+1);double t=row-lo;var a=mesh[lo][col];var b=mesh[hi][col];
  return new CloudGeometry.Point(a.x()+(b.x()-a.x())*t,a.y()+(b.y()-a.y())*t,a.z()+(b.z()-a.z())*t,0,1,0);
 }
}
