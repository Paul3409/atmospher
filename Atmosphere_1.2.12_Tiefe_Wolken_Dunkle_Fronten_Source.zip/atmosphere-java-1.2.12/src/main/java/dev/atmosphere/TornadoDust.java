package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.block.Blocks;

/** Small, bounded near-ground particle budget around active hook tornadoes. */
public final class TornadoDust {
    private TornadoDust() {}
    private static int budget;
    public static int material(ClientWorld world,BlockPos pos) {
        var block=world.getBlockState(pos);
        if(block.isOf(Blocks.SAND)||block.isOf(Blocks.SANDSTONE))return 1;
        if(block.isOf(Blocks.RED_SAND)||block.isOf(Blocks.RED_SANDSTONE))return 2;
        if(block.isOf(Blocks.SNOW)||block.isOf(Blocks.SNOW_BLOCK)||block.isOf(Blocks.ICE))return 3;
        return 0;
    }
    public static int red(int material){return switch(material){case 1->204;case 2->174;case 3->224;default->126;};}
    public static int green(int material){return switch(material){case 1->188;case 2->112;case 3->232;default->114;};}
    public static int blue(int material){return switch(material){case 1->139;case 2->74;case 3->238;default->96;};}
    public static void tick(MinecraftClient client,AtmosphereSettings s) {
        if(!s.customClouds||client.world==null||client.player==null
                ||client.world.getRegistryKey()!=World.OVERWORLD||client.world.getTime()%2!=0)return;
        long time=client.world.getTimeOfDay();
        budget=(s.quality==0?6:12)*s.dustParticles/100;
        double days=ClimateClock.days(time,s.weatherSpeed);
        for(var c:WeatherCells.nearby(client.player.getX(),client.player.getZ(),days,180)) {
            if(c.type()==WeatherCells.SUPERCELL&&c.rotation()>.22)
                emit(client,s,c.x(),c.z(),c.radius(),c.growth(),c.phase(),c.id(),c.windX(),c.windZ());
        }
        for(var e:StormEvents.events())if(e.type()==WeatherCells.SUPERCELL) {
            double phase=e.phase(time,s);
            long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());
            double angle=StormEvolution.manualAngle(seed);
            emit(client,s,e.x(),e.z(),e.radius(),WeatherCells.lifecycle(phase),phase,seed,Math.cos(angle),Math.sin(angle));
        }
    }
    private static void emit(MinecraftClient client,AtmosphereSettings s,double x,double z,double radius,
                             double growth,double phase,long seed,double wx,double wz) {
        if(StormEvolution.tornadoActivity(seed,growth,phase,StormEvents.chanceFor(seed,s.tornadoCode()))<.65)return;
        double cx=x+.05*radius*wx+.35*radius*wz;
        double cz=z+.05*radius*wz-.35*radius*wx;
        if(Math.hypot(cx-client.player.getX(),cz-client.player.getZ())>180)return;
        long tick=client.world.getTime();
        for(int i=0;i<Math.max(1,6*s.dustParticles/100)&&budget>0;i++) {
            double angle=WeatherCells.hash(seed,tick*6+i,943)*Math.PI*2;
            double r=radius*(.05+.07*WeatherCells.hash(seed,tick*6+i,947));
            double px=cx+Math.cos(angle)*r,pz=cz+Math.sin(angle)*r;
            BlockPos pos=BlockPos.ofFloored(px,client.player.getY(),pz);
            if(!client.world.isChunkLoaded(pos))continue;
            double y=client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,pos.getX(),pos.getZ())+.25;
            int material=material(client.world,BlockPos.ofFloored(px,y-1,pz));
            client.world.addParticle(AtmosphereMod.VORTEX_DUST,px,y,pz,cx,material,cz);
            budget--;
        }
    }
}
