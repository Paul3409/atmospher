package dev.atmosphere.siren;

import dev.atmosphere.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

final class SirenWeather {
    private SirenWeather(){}
    static boolean danger(ServerWorld world,BlockPos pos,int range,int mask){
        if(world.getRegistryKey()!=World.OVERWORLD)return false;
        var s=AtmosphereSettings.get();long time=world.getTimeOfDay();
        int step=range/2;
        for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){
            var w=WeatherModel.sample(pos.getX()+i*step,pos.getZ()+j*step,time,s);
            if(((mask&1)!=0&&w.windKmh()>=65)||((mask&2)!=0&&w.precipitationKind()==4&&w.rainMmH()>5))return true;
        }
        if((mask&4)==0||!s.customClouds)return false;
        double days=ClimateClock.days(time,s.weatherSpeed);
        for(var c:WeatherCells.nearby(pos.getX(),pos.getZ(),days,range)){
            if(c.type()==WeatherCells.SUPERCELL&&c.rotation()>.22&&Math.hypot(c.x()-pos.getX(),c.z()-pos.getZ())<range
                    &&StormEvolution.tornadoActivity(c.id(),c.growth(),c.phase(),s.tornadoCode())>.65)return true;
        }
        for(var e:StormEvents.events())if(e.type()==WeatherCells.SUPERCELL&&e.ageDays(time,s)<e.lifeDays()){
            double phase=e.phase(time,s);
            long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());
            if(Math.hypot(e.x()-pos.getX(),e.z()-pos.getZ())<range&&StormEvolution.tornadoActivity(seed,
                    WeatherCells.lifecycle(phase),phase,StormEvents.chanceFor(seed,s.tornadoCode()))>.65)return true;
        }return false;
    }
}
