package dev.atmosphere.siren;

import com.google.gson.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.*;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.*;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import java.util.*;

public final class SirenClient {
    private static final Map<Long,Playback> active=new HashMap<>();
    private static final List<Voice> voices=new ArrayList<>();
    private static long lastClock;
    private static boolean wasPaused;
    private static ClientWorld world; private static long receivedAt,serverNow;
    private static final class Playback {
        long realStart;long pos,start;int signal,radius,volume,level=100,lastSegment=-1;boolean muffled;float gain;
    }
    private record Voice(long pos,long born,SegmentSound sound){}
    private SirenClient(){}
    public static void register(){
        ClientPlayNetworking.registerGlobalReceiver(SirenPayloads.Status.ID,(payload,context)->context.client().execute(()->{
            try{
                var b=JsonParser.parseString(payload.json()).getAsJsonObject();var client=context.client();
                if(b.get("type").getAsString().equals("screen")){
                    if(b.get("open").getAsBoolean())client.setScreen(new SirenScreen(b));
                    else if(client.currentScreen instanceof SirenScreen screen)screen.accept(b);
                }else audio(client,b);
            }catch(RuntimeException ex){System.err.println("[Atmosphere] Ungültige Sirenenstatusdaten: "+ex.getMessage());}
        }));
        ClientTickEvents.END_CLIENT_TICK.register(SirenClient::tick);
    }
    public static void request(JsonObject b){if(ClientPlayNetworking.canSend(SirenPayloads.Request.ID))ClientPlayNetworking.send(new SirenPayloads.Request(b.toString()));}
    private static void audio(MinecraftClient client,JsonObject b){
        if(client.world==null)return;
        if(world!=client.world)reset(client);
        world=client.world;receivedAt=world.getTime();serverNow=b.get("now").getAsLong();
        var seen=new HashSet<Long>();
        for(var value:b.getAsJsonArray("nodes")){
            var a=value.getAsJsonObject();long pos=a.get("pos").getAsLong(),start=a.get("start").getAsLong();
            int signal=SirenProgram.of(a.get("signal").getAsInt()).ordinal();
            var p=active.get(pos);if(p==null||p.start!=start||p.signal!=signal){
                stop(pos);p=new Playback();p.pos=pos;p.start=start;p.signal=signal;p.realStart=System.nanoTime()-Math.max(0,serverNow-start)*50_000_000L;active.put(pos,p);
            }p.radius=Math.max(64,Math.min(1024,a.get("radius").getAsInt()));p.volume=SirenGain.bound(a.get("volume").getAsInt());p.level=a.has("level")?SirenGain.bound(a.get("level").getAsInt()):100;seen.add(pos);
        }
        active.keySet().removeIf(pos->{if(seen.contains(pos))return false;stop(pos);return true;});
    }
    private static void reset(MinecraftClient client){for(var v:voices)client.getSoundManager().stop(v.sound);voices.clear();active.clear();lastClock=0;wasPaused=false;world=client.world;}
    private static void stop(long pos){for(var v:voices)if(v.pos==pos)v.sound.stopping=true;}
    private static void tick(MinecraftClient client){
        if(client.world==null||client.player==null||world!=client.world){reset(client);return;}
        long clock=System.nanoTime();boolean paused=client.isPaused();
        if(lastClock!=0&&(paused||wasPaused)){
            long delta=Math.max(0,clock-lastClock);
            for(var p:active.values())p.realStart+=delta;
            for(var v:voices)v.sound.born+=delta;
        }
        lastClock=clock;wasPaused=paused;if(paused)return;
        long now=world.getTime();if(now-receivedAt>60){for(var p:active.values())stop(p.pos);active.clear();}
        var selected=active.values().stream().sorted(Comparator.comparingDouble(p->distance(client,p))).limit(16).toList();
        for(var p:active.values())if(!selected.contains(p))stop(p.pos);
        for(var p:selected){
            var pos=BlockPos.fromLong(p.pos);double distance=distance(client,p);
            long elapsed=(System.nanoTime()-p.realStart)/50_000_000L-(long)(distance/343.0*20);
            if(elapsed<0||elapsed>=SirenProgram.of(p.signal).ticks){if(elapsed>=0)stop(p.pos);continue;}
            if(now%10==0||p.lastSegment<0){
                var from=client.player.getEyePos();var source=new Vec3d(pos.getX()+.5,pos.getY()+1.1,pos.getZ()+.5);
                var delta=source.subtract(from);var to=from.add(delta.normalize().multiply(Math.min(64,delta.length())));
                p.muffled=!world.isSkyVisible(client.player.getBlockPos().up())||world.raycast(new RaycastContext(from,to,
                        RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,client.player)).getType()==HitResult.Type.BLOCK;
            }
            p.gain=(float)(Math.pow(Math.max(0,1-distance/p.radius),1.3)*SirenGain.effective(p.volume,p.level)*(p.muffled?.50:1));
            int segment=SirenProgram.segment(elapsed);
            if(p.gain<=0){
                p.lastSegment=Math.max(p.lastSegment,segment);
                for(var voice:voices)if(voice.pos==p.pos)voice.sound.target=0;
                continue;
            }
            // If the listener arrives mid-segment, wait for the next aligned slice (at most two seconds).
            if(segment>p.lastSegment&&(elapsed%40<5||p.lastSegment>=0)){
                p.lastSegment=segment;
                var sound=new SegmentSound(p,segment,pos,p.muffled);voices.add(new Voice(p.pos,now,sound));client.getSoundManager().play(sound);
            }
            for(var voice:voices)if(voice.pos==p.pos&&!voice.sound.stopping)voice.sound.target=Math.min(1,p.gain/voice.sound.boost);
        }
        voices.removeIf(v->{if(now-v.born>55||v.sound.isDone()){client.getSoundManager().stop(v.sound);return true;}return false;});
    }
    private static double distance(MinecraftClient client,Playback p){var pos=BlockPos.fromLong(p.pos);return Math.sqrt(client.player.squaredDistanceTo(pos.getX()+.5,pos.getY()+1,pos.getZ()+.5));}
    private static final class SegmentSound extends MovingSoundInstance {
        float target;boolean stopping;int age;final int boost;long born=System.nanoTime();
        SegmentSound(Playback p,int segment,BlockPos pos,boolean muffled){
            super(SirenSounds.EVENTS[p.signal][muffled?1:0][SirenGain.variant(SirenGain.effective(p.volume,p.level))][segment],SoundCategory.WEATHER,Random.create());
            boost=SirenGain.boost(SirenGain.variant(SirenGain.effective(p.volume,p.level)));
            x=pos.getX()+.5;y=pos.getY()+1.1;z=pos.getZ()+.5;volume=.001f;pitch=1;
            target=Math.min(1,p.gain/boost);attenuationType=SoundInstance.AttenuationType.NONE;relative=false;repeat=false;
        }
        @Override public void tick(){
            age++;if(stopping){volume*=.25f;if(volume<.001f)setDone();return;}
            double seconds=(System.nanoTime()-born)/1e9;
            volume=(float)(target*Math.min(1,seconds/.4)*Math.min(1,Math.max(0,(2.4-seconds)/.4)));if(seconds>=2.4)setDone();
        }
    }
}
