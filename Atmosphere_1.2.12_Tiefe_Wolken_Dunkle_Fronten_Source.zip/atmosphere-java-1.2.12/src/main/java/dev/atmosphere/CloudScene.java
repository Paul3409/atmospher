package dev.atmosphere;

import java.util.List;

/** Shared scene composition, independent of camera orientation and selected detail. */
public final class CloudScene {
    private CloudScene(){}
    public static double backgroundVisibility(double x,double z,List<WeatherCells.Cell> storms){
        double visible=1;
        for(var c:storms){
            if(c.type()<WeatherCells.THUNDER)continue;
            double mature=WeatherCells.smooth(.22,.72,c.growth());
            double distance=Math.hypot(x-c.x(),z-c.z());
            double clear=1-WeatherCells.smooth(c.radius()*1.25,c.radius()*2.45,distance);
            visible=Math.min(visible,1-mature*clear);
        }
        return visible;
    }
    public static int stormSides(int quality){return switch(quality){case 0->56;case 2->112;case 3->144;default->80;};}
    public static int stormLevels(int quality){return switch(quality){case 0->44;case 2->72;case 3->96;default->56; };}
}
