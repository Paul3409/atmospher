package dev.atmosphere;

import java.util.ArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.random.Random;

/** Persistent weather loops with gain envelopes rather than periodic one-shot restarts. */
public final class WeatherAmbience {
 private static final ArrayList<Loop> sounds=new ArrayList<>();
 private static net.minecraft.client.world.ClientWorld world;
 private WeatherAmbience(){}
 public static void clear(MinecraftClient c){for(var l:sounds)c.getSoundManager().stop(l);sounds.clear();world=null;}
 public static void tick(MinecraftClient c,WeatherModel.Weather w,AtmosphereSettings s,boolean sheltered){
  if(world!=c.world){clear(c);world=c.world;}
  for(var l:sounds)l.target=0;
  if(s.weatherSounds){
   if(w.rainMmH()>.1){
    SoundEvent rain=w.precipitationKind()==1?AtmosphereMod.SNOW_WIND:w.precipitationKind()==4?AtmosphereMod.HAIL_SOUND:
      w.rainMmH()>35?AtmosphereMod.RAIN_HEAVY:AtmosphereMod.RAIN_LIGHT;
    select(c,rain,(float)(Math.min(.9,.15+Math.sqrt(w.rainMmH()/120)*.65)*s.rainVolume/100.0*(sheltered?.45:1)));
   }
   if(w.windKmh()>2)select(c,w.precipitationKind()==1?AtmosphereMod.SNOW_WIND:AtmosphereMod.WIND_SOUND,
      (float)(Math.min(.75,w.windKmh()/100)*s.windAmbientVolume/100.0*(sheltered?.4:1)));
  }
  sounds.removeIf(Loop::isDone);
 }
 private static void select(MinecraftClient c,SoundEvent event,float gain){
  for(var l:sounds)if(l.event==event&&!l.isDone()){l.target=Math.max(l.target,gain);return;}
  var l=new Loop(event);l.target=gain;sounds.add(l);c.getSoundManager().play(l);
 }
 private static final class Loop extends MovingSoundInstance{
  final SoundEvent event;float target;int age;
  Loop(SoundEvent event){super(event,SoundCategory.WEATHER,Random.create());this.event=event;
   repeat=true;repeatDelay=0;relative=true;attenuationType=SoundInstance.AttenuationType.NONE;volume=.001f;pitch=1;}
  @Override public void tick(){age++;volume+=(target-volume)*.06f;if(age>40&&target==0&&volume<.0005f)setDone();}
 }
}
