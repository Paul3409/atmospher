package dev.atmosphere;

/** Own analytic squall coverage, independent of any external renderer. */
public final class StormShade {
 private StormShade(){}
 public static double coverage(double along,double across,double radius,double growth,int type){
  if(type!=WeatherCells.SQUALL||radius<=0)return 0;
  double side=1-StormEvolution.smooth(.72,1,Math.abs(across)/GustFront.span(radius,type));
  double lead=GustFront.leading(across,radius,type);
  double rear=StormEvolution.smooth(lead-radius*2.2,lead-radius*1.5,along);
  double front=1-StormEvolution.smooth(lead-radius*.12,lead+radius*.45,along);
  return side*rear*front*GustFront.maturity(growth,type);
 }
 public static double light(double generic,double squall,double cameraY,double base,double contrast){
  double below=1-StormEvolution.smooth(base+15,base+120,cameraY);
  return WeatherCells.clamp(1-below*Math.max(generic, .82*squall)*contrast,.12,1);
 }
}
