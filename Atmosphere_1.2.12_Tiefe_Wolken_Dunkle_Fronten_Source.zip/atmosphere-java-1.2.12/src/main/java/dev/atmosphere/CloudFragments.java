package dev.atmosphere;

/** Small ragged scud masses: closed on all sides, without a flat cumulus floor. */
public final class CloudFragments {
    private CloudFragments(){}
    private record Key(long seed,int sides,int rows){}
    private static final java.util.Map<Key,CloudGeometry.Point[][]> CACHE=new java.util.LinkedHashMap<>(256,.75f,true){
        @Override protected boolean removeEldestEntry(java.util.Map.Entry<Key,CloudGeometry.Point[][]> e){return size()>256;}
    };
    private static double[] pos(long seed,double p,double a){
        double x=Math.sin(p)*Math.cos(a),y=Math.cos(p),z=Math.sin(p)*Math.sin(a);
        double n=CloudNoise.billow(x*1.5,y*1.5,z*1.5,seed);
        double r=1+n*.65;
        double taper=.20+.80*WeatherCells.smooth(-.85,.45,y);
        double bend=.18*(1-y)*Math.sin(y*2+(seed%19));
        return new double[]{x*r*taper+bend+.09*Math.sin(p*7+a*3)*Math.sin(p),.5+.5*y*r,z*r*taper*(.85+.15*Math.sin(p*5+a*2))};
    }
    public static synchronized CloudGeometry.Point[][] unitMesh(long seed,int sides,int rows){
        Key key=new Key(seed,sides,rows);var mesh=CACHE.get(key);if(mesh!=null)return mesh;
        mesh=new CloudGeometry.Point[rows+1][sides+1];
        for(int j=0;j<=rows;j++)for(int i=0;i<=sides;i++){
            double p=j*Math.PI/rows,a=i*Math.PI*2/sides;
            var v=pos(seed,p,a);double nx=0,ny=j==0?1:-1,nz=0;
            if(j!=0&&j!=rows){
                var q=pos(seed,p+.0001,a);var r=pos(seed,p,a+.0001);
                double x=q[0]-v[0],y=q[1]-v[1],z=q[2]-v[2],u=r[0]-v[0],w=r[1]-v[1],t=r[2]-v[2];
                nx=z*w-y*t;ny=x*t-z*u;nz=y*u-x*w;
                double norm=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));nx/=norm;ny/=norm;nz/=norm;
            }
            mesh[j][i]=new CloudGeometry.Point(v[0],v[1],v[2],nx,ny,nz);
        }
        CACHE.put(key,mesh);return mesh;
    }
}
