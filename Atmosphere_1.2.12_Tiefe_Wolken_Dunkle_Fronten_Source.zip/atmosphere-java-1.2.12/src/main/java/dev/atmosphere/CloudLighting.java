package dev.atmosphere;

/** Same single light evaluation in the game and mathematical preview. */
public final class CloudLighting {
    private CloudLighting(){}
    public static double shade(double nx,double ny,double nz,double sun){
        double facing=nx*Math.cos(sun)*.72+ny*.62+nz*Math.sin(sun)*.72;
        return .57+.36*(.5+.5*facing/Math.sqrt(facing*facing+.22));
    }
}
