package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;

/** Cached local sky attenuation; artificial block light remains unaffected. */
public final class StormLighting {
    private static ClientWorld lastWorld;
    private static long lastTick=Long.MIN_VALUE;
    private static double factor=1;
    private StormLighting() {}
    public static double factor() {
        MinecraftClient client=MinecraftClient.getInstance();
        if(client.world==null||client.player==null||client.world.getRegistryKey()!=World.OVERWORLD)return 1;
        if(lastWorld!=client.world) {lastWorld=client.world;lastTick=Long.MIN_VALUE;factor=1;}
        long tick=client.world.getTime();
        if(tick!=lastTick) {
            lastTick=tick;
            var p=client.gameRenderer.getCamera().getPos();
            var w=WeatherModel.sample(client.world,p.x,p.y,p.z,client.world.getTimeOfDay(),AtmosphereSettings.get());
            double below=1-StormEvolution.smooth(w.cloudBase(),w.cloudBase()+45,p.y);
            double strength=StormEvolution.smooth(.20,.85,w.storm());
            var settings=AtmosphereSettings.get();
            double profile=new double[]{.85,.95,1,1.20,1.35}[Math.max(0,Math.min(4,settings.weatherExperience))];
            double contrast=1+(profile-1)*settings.profileStrength/100.0;
            double squall=0,days=ClimateClock.days(client.world.getTimeOfDay(),settings.weatherSpeed);
            for(var c:WeatherCells.nearby(p.x,p.z,days,2200)){
                double dx=p.x-c.x(),dz=p.z-c.z();
                squall=Math.max(squall,StormShade.coverage(dx*c.windX()+dz*c.windZ(),-dx*c.windZ()+dz*c.windX(),c.radius(),c.growth(),c.type()));
            }
            squall*=WeatherCells.clamp(settings.stormFrequency/100.0,0,1);
            for(var event:StormEvents.events())if(event.type()==WeatherCells.SQUALL){
                long seed=StormEvolution.manualSeed(event.started(),event.x(),event.z());double angle=StormEvolution.manualAngle(seed);
                double dx=p.x-event.x(),dz=p.z-event.z();
                squall=Math.max(squall,StormShade.coverage(dx*Math.cos(angle)+dz*Math.sin(angle),-dx*Math.sin(angle)+dz*Math.cos(angle),
                    event.radius(),WeatherCells.lifecycle(event.phase(client.world.getTimeOfDay(),settings)),event.type()));
            }
            double target=StormShade.light(strength*(.23+.27*w.cloudiness()),squall,p.y,w.cloudBase(),contrast);
            factor+=(target-factor)*.10;
        }
        return factor;
    }
}
