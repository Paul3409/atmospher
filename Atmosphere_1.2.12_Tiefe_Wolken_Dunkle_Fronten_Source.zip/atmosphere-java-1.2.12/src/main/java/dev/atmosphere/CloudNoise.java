package dev.atmosphere;

/** Continuous 3-D value noise: seam/pole-safe, world/camera independent. */
public final class CloudNoise {
    private CloudNoise(){}
    private static double h(int x,int y,int z,long seed){return WeatherCells.hash(x^seed,z^((long)y*1000003),1501)*2-1;}
    private static double fade(double t){return t*t*t*(t*(t*6-15)+10);}
    public static double sample(double x,double y,double z,long seed){
        int ix=(int)Math.floor(x),iy=(int)Math.floor(y),iz=(int)Math.floor(z);
        double u=fade(x-ix),v=fade(y-iy),w=fade(z-iz);
        double a=h(ix,iy,iz,seed)*(1-u)+h(ix+1,iy,iz,seed)*u;
        double b=h(ix,iy+1,iz,seed)*(1-u)+h(ix+1,iy+1,iz,seed)*u;
        double c=h(ix,iy,iz+1,seed)*(1-u)+h(ix+1,iy,iz+1,seed)*u;
        double d=h(ix,iy+1,iz+1,seed)*(1-u)+h(ix+1,iy+1,iz+1,seed)*u;
        return (a*(1-v)+b*v)*(1-w)+(c*(1-v)+d*v)*w;
    }
    public static double billow(double x,double y,double z,long seed){
        double broad=sample(x*2,y*2,z*2,seed), tufts=sample(x*4.2,y*4.2,z*4.2,seed^37);
        return .23*broad+.10*(Math.exp(tufts*1.7)-1)/1.7
                +.018*sample(x*7.2,y*7.2,z*7.2,seed^73);
    }
}
