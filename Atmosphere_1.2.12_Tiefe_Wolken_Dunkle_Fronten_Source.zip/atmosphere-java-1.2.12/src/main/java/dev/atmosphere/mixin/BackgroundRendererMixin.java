package dev.atmosphere.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.atmosphere.AtmosphereSettings;
import dev.atmosphere.CloudField;
import dev.atmosphere.WeatherModel;
import dev.atmosphere.WeatherFog;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Shallow dawn/valley fog. Modify existing vanilla world fog, never underwater/other realms. */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    /** Exact Yarn 1.21.1 render signature; color is adjusted once after vanilla recomputes it. */
    @Inject(method="render(Lnet/minecraft/client/render/Camera;FLnet/minecraft/client/world/ClientWorld;IF)V",at=@At("TAIL"))
    private static void atmosphere$stormColor(Camera camera,float tickDelta,net.minecraft.client.world.ClientWorld world,int distance,float darkness,CallbackInfo ci){
        if(world.getRegistryKey()!=World.OVERWORLD||camera.getSubmersionType()!=CameraSubmersionType.NONE)return;
        float factor=(float)(.40+.60*dev.atmosphere.StormLighting.factor());
        float[] color=RenderSystem.getShaderFogColor();
        RenderSystem.setShaderFogColor(color[0]*factor,color[1]*factor,color[2]*factor,color[3]);
    }

    @Inject(method = "applyFog(Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/BackgroundRenderer$FogType;FZF)V",
            at = @At("TAIL"))
    private static void atmosphere$valleyFog(Camera camera, BackgroundRenderer.FogType fogType,
                                             float viewDistance, boolean thickFog, float tickDelta,
                                             CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        AtmosphereSettings s = AtmosphereSettings.get();
        if ((!s.atmosphericFog && !s.customClouds) || client.world == null || client.player == null ||
                client.world.getRegistryKey() != World.OVERWORLD || camera.getFocusedEntity() != client.player ||
                thickFog || camera.getSubmersionType()!=CameraSubmersionType.NONE
                || client.player.hasStatusEffect(StatusEffects.BLINDNESS)
                || client.player.hasStatusEffect(StatusEffects.DARKNESS)) return;
        var pos = camera.getPos();
        var w = WeatherModel.sample(client.world, pos.x, pos.y, pos.z, client.world.getTimeOfDay(), s);
        // Flying into a cloud is volumetric: apply a bounded near-white mist
        // based on the same world-anchored lower deck used by the cloud geometry.
        double cloud = s.customClouds ? CloudField.immersion(pos.x,pos.y,pos.z,client.world.getTimeOfDay(),s) : 0;
        double rainMist = s.atmosphericFog ? Math.min(.92, Math.max(0,(w.rainMmH()-25)/130.0)) : 0;
        double combined = Math.max(WeatherFog.density(w.fog(),rainMist,s.atmosphericFog,s.fogStrength),cloud);
        if (combined < .12) return;
        float originalEnd = RenderSystem.getShaderFogEnd();
        // 1.1.5: 195-166x collapsed the view to ~60 blocks in ordinary rain. A wider
        // floor keeps the horizon readable while heavy downpours still close in.
        float visibility = (float) WeatherFog.visibility(combined);
        float end = Math.min(originalEnd, visibility);
        if (end < 48) return;
        RenderSystem.setShaderFogStart(Math.min(RenderSystem.getShaderFogStart(), end * .08f));
        RenderSystem.setShaderFogEnd(end);
    }
}
