package dev.atmosphere;

/** Shared soft edge mask; no solid rectangular rain walls. */
public final class RainVeil {
    private RainVeil(){}
    public static double opacity(double u,double v){
        if(u<=0||u>=1||v<=0||v>=1)return 0;
        double edge=Math.pow(Math.sin(Math.PI*u),2);
        double top=WeatherCells.smooth(0,.04,v),bottom=1-WeatherCells.smooth(.90,1,v);
        double texture=.62+.20*Math.sin(u*37+v*11)+.18*Math.cos(u*83-v*9);
        return WeatherCells.clamp(edge*top*bottom*texture*.65,0,1);
    }
}
