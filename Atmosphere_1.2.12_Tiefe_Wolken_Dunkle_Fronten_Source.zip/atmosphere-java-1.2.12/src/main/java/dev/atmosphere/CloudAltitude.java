package dev.atmosphere;

/** Absolute base Y; terrain adjustment only uses already loaded heightmaps. */
public final class CloudAltitude {
 private CloudAltitude(){}
 public static double base(double humidity,double storm,int type){
  double ordinary=WeatherCells.clamp(105+(1-humidity)*35-storm*12,100,140);
  if(type==WeatherCells.SUPERCELL)return WeatherCells.clamp(170+(1-humidity)*22,170,190);
  return type==WeatherCells.SQUALL?WeatherCells.clamp(ordinary+10,110,140):ordinary;
 }
 public static double terrain(double base,double ground,int type){
  return Math.max(base,ground+(type==WeatherCells.SUPERCELL?106:44));
 }
}
