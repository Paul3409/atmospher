# Atmosphere 1.2.12 – Tiefere Wolken und dunkle Squall Lines

Minecraft/Fabric genau 1.21.1, Yarn 1.21.1+build.3, Fabric API 0.115.6+1.21.1, Java 21. Eigene Umsetzung; kein Simple-Clouds-Code uebernommen.

- Wolkenbasis im Tiefland: normale Bewoelkung Y=100–140, Squall Lines Y=110–140, Superzellen Y=170–190 statt Mindest-Y=260.
- Bei bereits geladenem Gelaende mindestens 44 Bloecke Abstand zur Basis; Superzellen mindestens 106 Bloecke, davon bis zu 42 fuer die Wall Cloud. Renderer prueft zusaetzlich den Hook-Standort. Keine Chunks werden dafuer nachgeladen. Unbekanntes Gelaende behaelt den prozeduralen Basiswert; hoeheres, entferntes Gelaende kann daher erst beim Laden beruecksichtigt werden.
- Basis und vertikale Ausdehnung getrennt: reife normale Superzelle reicht grob bis Y=530–550, seltene grosse Zellen hoeher. Cirrusband auf etwa Y=305–343 abgesenkt. Partikelraender koennen ueber das Formgeruest hinausragen.
- Vertikal aufgebautes dunkles gebogenes Kondensationsband an der gemeinsamen GustFront-Grenze. Vor-/Rueckseite und seitliche Raender laufen aus.
- Lokale Squall-Verdunklung von Himmel/Tageslicht mit Hoehenuebergang und zeitlicher Glaettung; oberhalb der Wolken entfällt sie. Kuenstliches Blocklicht wird nicht eigens reduziert. Nebelfarbe wird nach ihrer Vanilla-Neuberechnung abgedunkelt, nicht wiederholt pro Nebelpass.
- Kondensationswolken, Tornado-Chance/Entwicklung, Radar, Audio und Sirenen bleiben erhalten. Keine Server-Gelaendeveraenderungen.

BUILD_WINDOWS.bat erzeugt build/libs/atmosphere-1.2.12.jar. Testhilfe nur mit -PvisualTest. Mathematische Vorschau ist kein Spielbild; echter Clienttest prueft zusaetzlich die lokale Helligkeit unter/ueber einer Squall Line.

## Sicherheitsstatus

Die fruehere Chrome-Downloadwarnung ist weiterhin ungeklärt. Build-, Modell- und Clienttests ersetzen keine unabhaengige Malware-Pruefung. Dieses Update ist keine Sicherheitsfreigabe; keine Schutzfunktion umgehen.

## Test

Nach geklaerter Downloadwarnung Welt sichern und alte JAR aufbewahren. Neue Superzelle in Tiefland und auf geladenem Berggelaende testen: niedrigere Basis, sichtbarer Abstand zum Boden und vollstaendige Funnelentwicklung. Squall Line von vorne ansehen, darunter fliegen und wieder hinaus bzw. darueber: Verdunklung soll weich kommen und gehen. Fackelraum gegen dunklen Aussenbereich vergleichen; Partikeldichte/FPS auf eigener Hardware pruefen.

## Archivierte Dokumentation
# Atmosphere 1.2.11 – Dichte Kondensationswolken

Nur Minecraft/Fabric 1.21.1, Yarn 1.21.1+build.3, Fabric API 0.115.6+1.21.1, Java 21.

Wolkenkoerper, Superzelle, Tail und Scud verwenden dicht ueberlappende Kondensations-Sprites anstelle sichtbarer geschlossener Mesh-Aussenhaeute. Bestehende Formfunktionen liefern das raeumliche Geruest; Innenringe und Mittelpunkte fuellen das Volumen. Helle Oberseite und dunklere Unterseite sind eine angenaeherte Dichte-/Lichtdarstellung, kein physikalischer Volumenshader.
CloudCondensation begrenzt die Anzahl je Koerper auf 136/300/594/984 fuer Leicht/Ausgewogen/Hoch/Ultra. Gemeinsame Tiefensortierung der Wolkensprites, feste Gesamtbudgets getrennt fuer Hintergrund und Superzellen. Bei erschoepftem Budget werden weitere Sprites ausgelassen; auf eigener Hardware auf Luecken und FPS pruefen. Keine Leistungsgarantie fuer schwache Geraete.
Tornado und Wetter-/Radar-/Sirenen-/Audiologik unveraendert. Spezielle Front-/Shelf-Darstellungen bleiben im bisherigen Renderer.
Mathematische Projektion: previews/Kondensation_Modellvorschau.png; keine Spielaufnahme. Echter Clienttest und Bilder im GitHub-Workflow-Artefakt. BUILD_WINDOWS.bat baut build/libs/atmosphere-1.2.11.jar.

## Sicherheitsstatus des Downloads

Die Chrome-Warnung der vorherigen Mod-Testfassung ist NICHT aufgeklaert. Dieses Update, erfolgreiche Builds und Spieltests sind keine Sicherheitsfreigabe und kein Nachweis eines Fehlalarms. Keine Empfehlung, Schutzfunktionen zu umgehen. Kein unabhaengiger Malware-Scan der fertigen JAR erfolgt.

## Test

Welt sichern, alte Version aufbewahren. Erst nach geklaerter Downloadwarnung installieren.
Normale trockene Wolke und Superzelle von unten/seitlich/oben pruefen. Wolkeninneres und Raender duerfen nicht bloss aus einer hohlen Partikelhuelle bestehen. Leicht/Hoch sowie FPS vergleichen. Tailstroemung und unveraenderten Tornado beobachten. Der optionale Client-Test ist nicht Teil der produktiven JAR.
# Atmosphere 1.2.10 – Wolkenaufbau und weiche Kondensation

Nur Fabric/Minecraft 1.21.1, Yarn 1.21.1+build.3, Fabric API 0.115.6+1.21.1, Java 21.

- Breitere vertikale Amboss-/Basisprofile statt schmaler Tellerringe. Räumlich versetzte Ausbuchtungen, gewölbte normale Wolkenunterseiten.
- Tail aus 24 dicht überlappenden, einströmenden Wolkenkörpern statt einer zugespitzten Röhrenoberfläche. Einströmbewegung bleibt erhalten.
- Zusätzliche weich ausblendende Kondensationsfetzen an Superzelle und Tornado. Schlanke Trichterform und Absenkung bleiben die Positionsgrundlage; sichtbarer Tornado besteht aus überlappender weicher Kondensation ohne harte äußere Mesh-Hülle. Vorhandener 1.21.1-Core-Shader mit separatem Alpha-Pass, Tiefentest ohne Tiefenschreiben für Fetzen.
- Tornado nutzt dieselbe Wetternebelbehandlung wie Wolken statt des zu früh aufhellenden Vanilla-Entity-Nebels.
- Qualitätsabhängig begrenzte Fetzenzahl. Keine Messung oder FPS-Garantie für schwache Laptops; Transparenz kostet Füllrate. Kein echter volumetrischer Raymarcher.
- Wettermodell, Audio, Sirenen unverändert.

Welt sichern und alte Mod-JAR ersetzen. BUILD_WINDOWS.bat baut build/libs/atmosphere-1.2.10.jar.
Test: neue Tornado-Testzelle, Tempo 1; seitlich und von unten ansehen. Leicht/Hoch vergleichen, 20 Sekunden Rotation und Funnelentwicklung beobachten. Insbesondere Tailende und Unterseite prüfen.
Mathematische Vorschau zeigt nur feste Oberflächen, nicht die Alpha-Fetzen. Echte Clientbilder liegen im GitHub-Workflow-Artefakt. Testhilfe nur mit -PvisualTest, nicht Bestandteil der produktiven Mod-JAR.

## Archivierte Dokumentation
# Atmosphere 1.2.9 – Wollige Wolken und strukturierte Tornados

Nur Minecraft/Fabric 1.21.1, Java 21, Yarn 1.21.1+build.3, Fabric API 0.115.6+1.21.1.

Bestehende Wolkenformen und schlanker Trichter bleiben Grundlage. Mehrskalige weich interpolierte Quellungen, geglättete Normalen und sanfte Schattierung ersetzen scharfe Detailfalten. Details skalieren über Leicht bis Ultra; keine Garantie bestimmter FPS auf unbekannter Hardware. Tornados erhalten bewegte unregelmäßige Kondensationskonturen und räumlich variierende Schattierung, ohne zusätzliche Spiralringe. Es bleibt ein Mesh-Renderer, keine volumetrische Simulation oder exakte Kopie der Referenz.

Keine Änderungen an Wettermodell, Audio oder Sirenen gegenüber 1.2.8. Welt sichern und alte JAR ersetzen. BUILD_WINDOWS.bat erzeugt build/libs/atmosphere-1.2.9.jar.

Test: dieselbe Zelle seitlich und von unten bei Leicht/Ausgewogen/Hoch vergleichen; Form soll erhalten bleiben. Tornado-Testzelle: Entstehung, Kontur, Rotation und Bodenkontakt beobachten. FPS auf eigener Hardware vergleichen; Ultra ist bewusst anspruchsvoller.

previews enthält mathematische Projektionen, keine Spielbilder. GitHub Actions erstellt separat echte Minecraft-1.21.1-Aufnahmen. Der optionale Test-Quellensatz gehört nicht zur produktiven JAR.

## Vorheriger Stand

# Atmosphere 1.2.8 – Wettereffekte, Wolken und Audio

Ausschließlich Minecraft/Fabric 1.21.1, Yarn 1.21.1+build.3, Fabric API 0.115.6+1.21.1, Java 21. Die Metadaten erlauben nur Minecraft 1.21.1.

## Änderungen

- Der Tornado verwendet wieder den stark verjüngten, leicht geneigten Trichter des alten Geometrietyps. Die Superzellen-Hauptform bleibt erhalten, die Basis liegt mindestens auf Y=260. Funnel entsteht und senkt sich bis zum geladenen Boden. Keine Garantie auf pixelgleiche Darstellung zur alten Version: Wolkenbeleuchtung und Renderer haben sich verändert.
- Breitere, längere Tail Cloud: durchgehendes Mesh mit in der Wall Cloud verborgenem Ansatz und nach innen laufenden Formdetails. Das ist eine künstlerische Strömungsdarstellung, keine Strömungssimulation.
- Größere, unregelmäßige, nach unten verjüngte Scud-Fetzen mit begrenzter Anzahl und bestehendem Lebenszyklus.
- Zusätzliche entfernte Niederschlagsvorhänge sind abgeschaltet. Normale lokale Regen-/Schnee-/Hagelpartikel und das Wetter-/Radar-Modell bleiben bestehen.
- Menü → Effekte: Regen, Schnee/Hagel und Tornadostaub separat 0–300 %, Partikelradius 0–128 Blöcke, Regenlautstärke 0–200 %, Donnerreichweite 0–800 Blöcke (Standard 500), Profilstärke 0–200 %. Der globale Partikelschalter bleibt übergeordnet; adaptive Grafik reduziert weiterhin Last.
- Natur/Ruhig/Balance/Dramatisch/Kino verändern jetzt tatsächlich den Wolkenkontrast und die lokale Gewitter-Himmelsabdunklung. Sie verändern nicht länger die Gewitterhäufigkeit; dafür gibt es den separaten Häufigkeitsregler. Kein vollständiger Welt-Shader und kein Ersatz für Iris/Shaderpacks.
- Neue vom Nutzer bereitgestellte Regen-, Winterwind- und Donneraufnahmen. Regen/Wind laufen als persistente Sounds mit gleitender Lautstärke; die importierten Atmosphärenspuren haben überblendete Loop-Enden. Wechsel zwischen Regenstärken blendet statt hart zu starten. Unter Dächern wird gedämpft.
- Donner wird außerhalb der gewählten Entfernung nicht eingeplant bzw. abgespielt; der Pegel fällt zum Rand auf null. Nahe, mittlere und entfernte Donner verwenden unterschiedliche Aufnahmen.
- Sirenen: 2,4 Sekunden lange Abschnitte im 2-Sekunden-Takt mit 400 ms Überblendung statt nur 100 ms Reserve. Zeitbasis unabhängig von schwankenden Spielticks, mit Pausenkompensation. Signale, Gruppen, individuelle Pegel und Probepläne bleiben erhalten.

## Installation / Build

Welt und Konfiguration sichern. Alte Atmosphere-JAR außerhalb von mods aufbewahren; nur eine Atmosphere-Version installieren. Java 21 und Fabric API für 1.21.1 verwenden.
BUILD_WINDOWS.bat erzeugt build/libs/atmosphere-1.2.8.jar. Alternativ: gradle build.
Die Quell-ZIP enthält keine Gradle-Caches und keine Spielwelt.

## Testen

1. Menüversion 1.2.8 prüfen. Druck → Tornado-Testzelle, Tempo 1: aus 150–350 Blöcken Entfernung Funnel und Bodenkontakt beobachten. Immer gilt für geeignete reife Superzellen, nicht für jeden Schauer; Testzelle hat eigene Garantie.
2. Seitliche Ansicht: Tail-Ansatz soll breit in die Wall Cloud greifen. Mindestens 15 Sekunden beobachten: Formdetails laufen hinein. Scud-Fetzen aus normaler Spielentfernung ansehen.
3. Effekte: 0/100/300 % je Partikelart vergleichen; Radius 0 schaltet Niederschlagspartikel aus. Sehr hohe Werte kosten FPS. Speichern und neu laden.
4. Natur/Kino bei gleicher Zelle und Profilstärke 100 % vergleichen; 0 % neutralisiert den Profileffekt.
5. Regen mehrere Minuten innen/außen und beim Stärkewechsel hören. Nahe/ferne Donner vergleichen; über 500 Blöcken bei Standardreichweite kein neuer Mod-Donner.
6. Alle vier Sirenensignale ohne Unterbrechung hören, währenddessen bewegen, pausieren/fortsetzen und vorzeitig stoppen. Audioqualität muss zusätzlich auf echter Hardware geprüft werden; der automatische Clienttest verwendet einen Null-Audiotreiber.
7. Radar dBZ/mm/h, Wetteruhr, Nebel und Sirenen-Gruppen als Regression gegenprüfen.

## Vorschauen und Prüfungen

previews/Wolken_Modellvorschau.png ist ausdrücklich eine mathematische Projektion derselben Geometriefunktionen, KEIN Ingame-Bild. Textur, Transparenz und Perspektive können im Spiel anders wirken.
Der GitHub-Workflow baut die Mod gegen echte 1.21.1-Abhängigkeiten und startet separat einen echten Minecraft-Client mit Software-OpenGL. Seine Aufnahmen liegen im separaten Client-Artefakt.
Die Entwicklungs-Test-Mod tools/visual-test wird nur mit -PvisualTest erzeugt und gehört nicht in die produktive JAR.

bash tools/test-model.sh: 16 Testprogramme für Modell, Geometrie, Persistenz, Einstellungen und Sirenen.
python tools/check_render_assets.py: Shader-/Textur-Schnittstellen (Pillow benötigt).
python tools/verify_siren_assets.py .: 684 Mono-Sirenenabschnitte (ffprobe benötigt).
tools/import_weather_audio.py --weather-source ORDNER [--siren-source ORDNER] bereitet bereitgestellte Originalaufnahmen mit ffmpeg auf; kein normaler Build-Schritt. Die Originaldateien und deren Nutzungsrechte werden dadurch nicht mitgeliefert oder als frei lizenziert erklärt.
