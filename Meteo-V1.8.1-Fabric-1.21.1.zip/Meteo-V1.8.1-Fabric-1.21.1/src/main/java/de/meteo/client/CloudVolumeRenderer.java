package de.meteo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import de.meteo.CloudLife;
import de.meteo.CloudStability;
import de.meteo.CloudMotion;
import de.meteo.CloudSnapshotPayload;
import de.meteo.CloudVoxelMesh;
import de.meteo.CloudOptimization;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Weather-authoritative, client-interpolated mobile cloud volumes.
 * One stable mesh per formation/type/LOD, translated and scaled smoothly.
 * The server continues to own rain, water and cloud position; this is visualization only.
 */
public final class CloudVolumeRenderer {
    private CloudVolumeRenderer() {}
    public enum Quality { SCHNELL, AUSGEWOGEN, HOCH, ULTRA }
    private static final class Volume {
        final long key;
        CloudSnapshotPayload.CloudCell weather;
        List<CloudVoxelMesh.Face> faces=List.of();
        List<CloudVoxelMesh.Face> coreFaces=List.of();
        List<CloudVoxelMesh.Face> previousFaces=List.of();
        List<CloudVoxelMesh.Face> previousCoreFaces=List.of();
        int meshType=-1, meshDetail=-1;
        float meshBaseY,previousMeshBaseY;
        double x,z,baseY,growth,heightPhase,shapeBlend=1,fieldScale=1,fieldTarget=1,visibility=1,visibilityTarget=1;
        long fieldLeader;
        long lastSeenTick;
        Volume(long key,CloudSnapshotPayload.CloudCell w,long tick){
            this.key=key; fieldLeader=key; weather=w; x=w.x(); z=w.z(); baseY=w.baseY(); lastSeenTick=tick;
            growth=0; // first visible seed starts small and grows smoothly
            heightPhase=w.type()==1?.52:1;
        }
    }
    private static final Map<Long,Volume> volumes=new LinkedHashMap<>();
    private static CloudSnapshotPayload lastPacket;
    private static long clientTicks;
    private static long receiveClientTick=-1;
    private static boolean enabled=true,preview=false;
    private static Quality quality=Quality.AUSGEWOGEN;
    /** Cloud CPU budget: 0 legacy, 1 balanced, 2 strong. Meshes and cloud physics unchanged. */
    private static int optimization=1;
    public static String optimizationName(){return new String[]{"Aus","Ausgewogen","Stark"}[optimization];}
    public static void cycleOptimization(){optimization=(optimization+1)%3;saveSettings();}

    private static List<CloudVoxelMesh.Face> previewFaces=List.of();
    private record SkinFace(CloudVoxelMesh.Face face, Matrix4f pose, double distanceSq, int alpha, double storm) {}
    private static final double[] RANGES={256,512,768,1024,1408,1792};
    private static int rangeSetting=2;
    private static double maxDistance(){return RANGES[rangeSetting];}
    public static int rangeBlocks(){return (int)maxDistance();}
    public static void cycleRange(){rangeSetting=(rangeSetting+1)%RANGES.length;rebuild();saveSettings();}
    private static long id(int cx,int cz){return (((long)cx)<<32)^(cz&0xffffffffL);}
    /** Client-only display settings, preserved across game restarts. */
    public static void loadSettings(){
        try {
            java.nio.file.Path path=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meteo-clouds.properties");
            if(!java.nio.file.Files.exists(path))return;
            java.util.Properties props=new java.util.Properties();
            try(var in=java.nio.file.Files.newInputStream(path)){props.load(in);}
            enabled=Boolean.parseBoolean(props.getProperty("enabled","true"));
            try{optimization=Math.max(0,Math.min(2,Integer.parseInt(props.getProperty("optimization","1"))));}
            catch(NumberFormatException ignored){optimization=1;}

            String q=props.getProperty("quality","AUSGEWOGEN");
            try{quality=Quality.valueOf(q);}catch(IllegalArgumentException ignored){quality=Quality.AUSGEWOGEN;}
            try{rangeSetting=Math.max(0,Math.min(RANGES.length-1,Integer.parseInt(props.getProperty("range","2"))));}
            catch(NumberFormatException ignored){rangeSetting=2;}
        }catch(java.io.IOException ex){System.err.println("Meteo cloud settings: "+ex.getMessage());}
    }
    private static void saveSettings(){
        try{
            java.nio.file.Path path=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meteo-clouds.properties");
            java.util.Properties props=new java.util.Properties();
            props.setProperty("enabled",Boolean.toString(enabled));
            props.setProperty("optimization",Integer.toString(optimization));
            props.setProperty("quality",quality.name());
            props.setProperty("range",Integer.toString(rangeSetting));
            try(var out=java.nio.file.Files.newOutputStream(path)){props.store(out,"Meteo cloud display settings");}
        }catch(java.io.IOException ex){System.err.println("Meteo cloud settings: "+ex.getMessage());}
    }

    public static boolean enabled(){return enabled;}
    public static Quality quality(){return quality;}
    public static boolean preview(){return preview;}
    public static void setEnabled(boolean value){enabled=value;saveSettings();}
    public static void setQuality(Quality value){quality=value;rebuild();if(preview)createPreview();saveSettings();}
    public static void togglePreview(){preview=!preview;if(preview)createPreview();else previewFaces=List.of();}
    public static void clear(){volumes.clear();lastPacket=null;receiveClientTick=-1;clientTicks=0;preview=false;previewFaces=List.of();}

    public static String localReport(){
        var c=MinecraftClient.getInstance();
        if(c.player==null||lastPacket==null)return "Wetterdaten: Noch kein Serverpaket empfangen";
        int cx=Math.floorDiv(c.player.getBlockX(),64),cz=Math.floorDiv(c.player.getBlockZ(),64);
        for(var w:lastPacket.cells())if(w.cx()==cx&&w.cz()==cz)
            return String.format(java.util.Locale.ROOT,"Wolken %.0f%% | Wasser %.3f | Hebung %+.2f m/s",w.cover()*100,w.liquid(),w.lift());
        return "Wetterdaten: Zelle nicht empfangen";
    }
    public static String windReport(){
        var c=MinecraftClient.getInstance();
        if(c.player==null||lastPacket==null)return "Winddaten werden geladen";
        int cx=Math.floorDiv(c.player.getBlockX(),64),cz=Math.floorDiv(c.player.getBlockZ(),64);
        for(var w:lastPacket.cells())if(w.cx()==cx&&w.cz()==cz){
            double speed=Math.hypot(w.windU(),w.windV());
            double from=(Math.toDegrees(Math.atan2(-w.windU(),w.windV()))+360)%360;
            return String.format(java.util.Locale.ROOT,"Wind aus %.0f Grad | %.1f m/s",from,speed);
        }
        return "Winddaten: Zelle nicht empfangen";
    }
    public static String info(){return "Wolken: "+volumes.size()+" | Quads: "+volumes.values().stream().mapToInt(v->v.faces.size()+v.coreFaces.size()).sum();}
    public static String debugReport(){
        int fading=0,merging=0,stale=0;
        for(Volume v:volumes.values()){
            if(v.visibility<.95)merging++;
            if(v.growth<.8)fading++;
            if(clientTicks-v.lastSeenTick>400)stale++;
        }
        return "Formationen: "+volumes.size()+" | Übergänge: "+merging+" | Entwicklung: "+fading+" | Alt: "+stale;
    }
    public static CloudSnapshotPayload lastSnapshot(){return lastPacket;}
    public static double rainHere(){
        var client=MinecraftClient.getInstance();
        if(client.player==null||lastPacket==null)return 0;
        double total=0;
        for(var w:lastPacket.cells())
            total+=de.meteo.RainPhysics.localRate(w.x(),w.z(),client.player.getX(),client.player.getZ(),w.rainMmHour(),w.type());
        return Math.min(35,total);
    }
    public static String rainReport(){
        double rain=rainHere();
        return String.format(java.util.Locale.ROOT,"Niederschlag: %.1f mm/h | Radar: Schauer",rain);
    }
    public static void accept(CloudSnapshotPayload p){
        var client=MinecraftClient.getInstance();
        if(client.world==null)return;
        lastPacket=p;
        long now=clientTicks;
        receiveClientTick=now;
        for(var c:p.cells()){
            long key=id(c.cx(),c.cz());
            Volume v=volumes.get(key);
            if(v==null){
                v=new Volume(key,c,now);
                volumes.put(key,v);
            }
            v.weather=c;
            v.lastSeenTick=now;
        }
        // A new packet must not invalidate otherwise unchanged meshes.
    }

    /** Called every actual game tick (NOT accelerated meteorological seconds). */
    public static void tick(MinecraftClient client){
        if(client.world==null){clear();return;}
        long now=++clientTicks;
        // Stable leaders are selected by identity (not packet or render order).
        // Crossfade followers instead of removing their meshes in one frame.
        java.util.List<Volume> candidates=new java.util.ArrayList<>(volumes.values());
        candidates.sort(java.util.Comparator.comparingLong(a->a.key));
        // Keep the previous leader when groups merge or split. Choosing the lowest
        // numeric key every tick used to swap an entire field's visible geometry.
        // Reject old ghosts during grouping, but let them fade separately below.
        // Group formation membership changes slowly compared to 20 client ticks/s.
        // Recalculate at a bounded cadence, but continue positions, fading and
        // growth every tick. The old every-tick algorithm remains available (Aus).
        if(now%CloudOptimization.groupingInterval(optimization)==0 || now==1){
        java.util.Map<Long,java.util.List<Volume>> buckets=new java.util.HashMap<>();
        if(optimization>0){
            for(Volume v:candidates)
                buckets.computeIfAbsent(CloudOptimization.bucket(v.x,v.z),ignored->new java.util.ArrayList<>()).add(v);
        }
        java.util.Set<Long> assigned=new java.util.HashSet<>();
        for(Volume seed:candidates){
            if(assigned.contains(seed.key))continue;
            java.util.List<Volume> group=new java.util.ArrayList<>();
            group.add(seed);assigned.add(seed.key);
            for(int gi=0;gi<group.size();gi++){
                Volume a=group.get(gi);
                // In optimized modes, compare only nearby 160-block bins.
                // Connected() never accepts points 125 blocks apart, so this
                // spatial lookup keeps exactly the same possible neighbours.
                java.util.List<Volume> neighbours;
                if(optimization==0)neighbours=candidates;
                else{
                    neighbours=new java.util.ArrayList<>();
                    long bx=(long)Math.floor(a.x/160.0),bz=(long)Math.floor(a.z/160.0);
                    for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
                        var list=buckets.get(((bx+dx)<<32)^((bz+dz)&0xffffffffL));
                        if(list!=null)neighbours.addAll(list);
                    }
                }
                for(Volume b:neighbours){
                    if(assigned.contains(b.key))continue;
                    if(now-a.lastSeenTick>1800||now-b.lastSeenTick>1800)continue;
                    boolean previouslyJoined=a.fieldLeader==b.fieldLeader;
                    if(de.meteo.CloudFieldContinuity.connected(a.x,a.z,b.x,b.z,
                        a.weather.liquid(),b.weather.liquid(),a.weather.cover(),b.weather.cover(),previouslyJoined)){
                        assigned.add(b.key);group.add(b);
                    }
                }
            }
            Volume leader=null;
            // Retain the previous representative while it remains in this connected
            // group.  Picking whichever member is currently most visible allowed
            // the centre of a large cloud field to hop between neighbouring cells.
            for(Volume member:group)for(Volume candidate:group)
                if(candidate.key==member.fieldLeader &&
                    (leader==null||candidate.visibility>leader.visibility))leader=candidate;
            if(leader==null)leader=group.get(0);
            double radius=0;
            for(Volume member:group){
                radius=Math.max(radius,Math.hypot(member.x-leader.x,member.z-leader.z));
                member.visibilityTarget=member==leader?1:0;
                member.fieldTarget=1;
                member.fieldLeader=leader.key;
            }
            // A connected deck may widen a little, but never magnify one voxel
            // mesh into the enormous geometric ceiling seen in V1.8.0.
            leader.fieldTarget=Math.max(1,Math.min(1.55,(radius+90)/90));
        }
        } // end slower grouping pass
        var it=volumes.values().iterator();
        while(it.hasNext()){
            Volume v=it.next();
            // Snapshot quotas and temporary chunk availability may omit a healthy
            // cloud.  One missing packet must not start dissolving it.
            boolean current=now-v.lastSeenTick<=1200;
            double target=current?CloudLife.target(v.weather.cover(),v.weather.liquid()):0;
            v.growth=(v.weather.type()==5||v.weather.type()==6||v.weather.type()==7||v.weather.type()==8)
                ?CloudLife.approachFrontal(v.growth,target,1)
                :CloudLife.approach(v.growth,target,1);
            v.fieldScale=CloudStability.approach(v.fieldScale,v.fieldTarget,1,900);
            v.visibility=CloudStability.approach(v.visibility,v.visibilityTarget,1,1800);
            v.baseY=CloudStability.approach(v.baseY,v.weather.baseY(),1,900);
            v.shapeBlend=CloudStability.approach(v.shapeBlend,1,1,600);
            if(v.shapeBlend>.95&&!v.previousFaces.isEmpty()){
                v.previousFaces=List.of();v.previousCoreFaces=List.of();
            }
            if(v.fieldScale<1)v.fieldScale=1;
            // Convective clouds share a stable full-height mesh: continuous
            // vertical scaling carries cumulus into congestus without a hard
            // topology switch or an instant doubling of the cloud tower.
            double targetHeight=v.weather.type()==1?.52:1.0;
            v.heightPhase=CloudLife.approach(v.heightPhase,targetHeight,1);
            // Predict motion from the last *server* position using the SAME
            // slowed CloudMotion formula. Smooth corrections rather than snapping.
            // A server-steered cloud must never fly through a mountain because
            // the client predicted a full minute of straight-line movement.
            // Predict at most one packet interval; the server owns terrain routing.
            double elapsed=Math.max(0,Math.min(12,now-v.lastSeenTick));
            CloudMotion.Position predicted=CloudMotion.advance(
                new CloudMotion.Position(v.weather.x(),v.weather.z()),
                v.weather.windU(),v.weather.windV(),elapsed*3.6);
            double easing=1-Math.exp(-1.0/7.0);
            v.x+=(predicted.x()-v.x)*easing;
            v.z+=(predicted.z()-v.z)*easing;
            if(!current&&v.growth<.008&&now-v.lastSeenTick>7200)it.remove();
        }
    }
    /** Invalidates detail without resetting visible cloud life or positions. */
    private static void rebuild(){
        for(Volume v:volumes.values())v.meshDetail=-1;
    }
    private static void ensureMesh(Volume v,int detail){
        byte type=v.weather.type();
        int shapeType=(type==1||type==2)?2:type;
        if(v.meshDetail==detail&&v.meshType==shapeType)return;
        // Geometry is generated in LOCAL formation coordinates at full maturity.
        // Growth only scales it, therefore each incoming packet does not abruptly
        // create a different voxel surface. The server still controls whether
        // the formation has enough real condensate to be visible.
        boolean shapeChanged=v.meshType>=0&&v.meshType!=shapeType;
        if(shapeChanged){
            v.previousFaces=v.faces;v.previousCoreFaces=v.coreFaces;
            v.previousMeshBaseY=v.meshBaseY;v.shapeBlend=0;
        }else if(v.meshDetail!=detail){
            // LOD changes represent the same shape and do not need two meshes.
            v.previousFaces=List.of();v.previousCoreFaces=List.of();v.shapeBlend=1;
        }
        float lift=shapeType==2?1.1f:.12f;
        v.meshBaseY=v.weather.baseY();
        CloudVoxelMesh.Layers layers=CloudVoxelMesh.buildHybrid(v.weather.cx(),v.weather.cz(),
            0f,0f,v.meshBaseY,shapeType,1f,.95f,lift,detail);
        v.faces=layers.outer();
        v.coreFaces=layers.core();
        v.meshDetail=detail;
        v.meshType=shapeType;
    }
    private static void createPreview(){
        var client=MinecraftClient.getInstance();
        if(client.world==null||client.player==null){previewFaces=List.of();return;}
        Vec3d look=client.player.getRotationVec(1.0f);
        double x=client.player.getX()+look.x*105,z=client.player.getZ()+look.z*105;
        int cx=Math.floorDiv((int)Math.floor(x),64),cz=Math.floorDiv((int)Math.floor(z),64);
        int ground=client.world.getTopY(net.minecraft.world.Heightmap.Type.WORLD_SURFACE,cx*64+32,cz*64+32);
        float base=(float)Math.max(client.player.getY()+42,ground+76);
        base=Math.min(220,base);
        previewFaces=CloudVoxelMesh.build(cx,cz,base,2,.96f,.88f,1.65f,quality.ordinal());
    }

    private static void vertex(BufferBuilder b,Matrix4f pose,float x,float y,float z,int r,int g,int blue,int alpha){
        b.vertex(pose,x,y,z).color(r,g,blue,alpha);
    }
    private static void face(BufferBuilder b,Matrix4f pose,CloudVoxelMesh.Face f,double solar,double storm,int alpha){
        float x0=f.x0(),y0=f.y0(),z0=f.z0(),x1=f.x1(),y1=f.y1(),z1=f.z1();
        int side=f.side();
        // Bright voxel tops, gently shaded undersides and a translucent skin.
        // An eroded, opaque inner shell provides real depth to thicker clouds.
        double sideLight=side==3?1.10:side==2?.81:side==0?.92:side==1?.97:side==4?.94:1.02;
        double ambient=.34+.66*solar;
        double shadow=1.0 - f.occlusion()*(side==2?.31:.24);
        // Strong moist congestus can develop a darker rain-ready lower deck.
        double underside=side==2?(1.0-storm*.21):1.0;
        double variation=1.0+f.variation()*.20;
        double total=Math.max(.14,sideLight*ambient*shadow*underside*variation*(1.0-.22*Math.max(0,storm-1.0)));
        // Sunlit tops are slightly warm; optically deep bases retain a muted
        // blue-grey cast. This uses the existing vertices and costs no extra mesh.
        double depthTone=Math.max(0,Math.min(.20,f.occlusion()*.14+Math.max(0,storm)*.025));
        double topWarm=side==3?solar*.035:0;
        int r=(int)Math.max(0,Math.min(255,Math.round(252*total*(1+topWarm-depthTone*.18))));
        int g=(int)Math.max(0,Math.min(255,Math.round(253*total*(1+topWarm*.45-depthTone*.08))));
        int blue=(int)Math.max(0,Math.min(255,Math.round(255*total*(1-depthTone*.02))));
        switch(side){
            case 0 -> {vertex(b,pose,x0,y0,z0,r,g,blue,alpha);vertex(b,pose,x0,y0,z1,r,g,blue,alpha);vertex(b,pose,x0,y1,z1,r,g,blue,alpha);vertex(b,pose,x0,y1,z0,r,g,blue,alpha);}
            case 1 -> {vertex(b,pose,x1,y0,z1,r,g,blue,alpha);vertex(b,pose,x1,y0,z0,r,g,blue,alpha);vertex(b,pose,x1,y1,z0,r,g,blue,alpha);vertex(b,pose,x1,y1,z1,r,g,blue,alpha);}
            case 2 -> {vertex(b,pose,x0,y0,z1,r,g,blue,alpha);vertex(b,pose,x0,y0,z0,r,g,blue,alpha);vertex(b,pose,x1,y0,z0,r,g,blue,alpha);vertex(b,pose,x1,y0,z1,r,g,blue,alpha);}
            case 3 -> {vertex(b,pose,x0,y1,z0,r,g,blue,alpha);vertex(b,pose,x0,y1,z1,r,g,blue,alpha);vertex(b,pose,x1,y1,z1,r,g,blue,alpha);vertex(b,pose,x1,y1,z0,r,g,blue,alpha);}
            case 4 -> {vertex(b,pose,x1,y0,z0,r,g,blue,alpha);vertex(b,pose,x0,y0,z0,r,g,blue,alpha);vertex(b,pose,x0,y1,z0,r,g,blue,alpha);vertex(b,pose,x1,y1,z0,r,g,blue,alpha);}
            case 5 -> {vertex(b,pose,x0,y0,z1,r,g,blue,alpha);vertex(b,pose,x1,y0,z1,r,g,blue,alpha);vertex(b,pose,x1,y1,z1,r,g,blue,alpha);vertex(b,pose,x0,y1,z1,r,g,blue,alpha);}
            default -> throw new IllegalArgumentException("Invalid cloud face "+side);
        }
    }
    public static void render(WorldRenderContext context){
        var client=MinecraftClient.getInstance();
        if(!enabled||context.world()==null||context.matrixStack()==null||client.world==null||client.player==null)return;
        if(client.world!=context.world()||client.world.getRegistryKey()!=net.minecraft.world.World.OVERWORLD)return;
        if(volumes.isEmpty()&&(!preview||previewFaces.isEmpty()))return;
        // Never switch OFF the whole sky when one network packet arrives late.
        // Individual clouds fade on their own if their snapshots stop arriving.
        Vec3d eye=context.camera().getPos();
        double time=Math.floorMod(client.world.getTimeOfDay(),24000);
        double solar=Math.max(0,Math.sin(Math.PI*time/12000));
        // Daylight responds to the actual sky cycle, while night has some skylight.
        List<Volume> active=new ArrayList<>();
        Vec3d view=client.player.getRotationVec(1.0f);
        for(Volume v:volumes.values()){
            if(v.growth<.008||v.visibility<.008)continue;
            boolean synopticHorizon=v.weather.cx()>=3000000 && v.weather.type()==5;
            double visibilityRange=synopticHorizon?Math.max(maxDistance(),1450):maxDistance();
            if(!CloudMotion.intersects(v.x,v.z,eye.x,eye.z,125,visibilityRange+65))continue;
            double distance=Math.hypot(v.x-eye.x,v.z-eye.z);
            double vy=v.baseY-eye.y;
            double threeD=Math.sqrt(distance*distance+vy*vy);
            double dot=(v.x-eye.x)*view.x+vy*view.y+(v.z-eye.z)*view.z;
            if(CloudOptimization.hiddenBehind(threeD,dot,optimization))continue;
            // Keep large storm/deck silhouettes; subsample tiny ordinary distant cells
            // deterministically to avoid flooding Intel HD 520 with far-away geometry.
            if(distance>850 && v.weather.type()!=6 && v.weather.type()!=7 && v.weather.type()!=8
                && Math.floorMod(v.key,3)!=0)continue;
            active.add(v);
        }
        if(active.isEmpty()&&(!preview||previewFaces.isEmpty()))return;
        MatrixStack matrices=context.matrixStack();
        matrices.push();
        matrices.translate(-eye.x,-eye.y,-eye.z);
        try{
            RenderSystem.enableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            // Pass 1: smaller opaque inner cores, depth-writing and terrain occlusion.
            // Pass 2: a translucent, back-to-front outer voxel skin. Do NOT write
            // depth for translucent surfaces, or their own far sides disappear.
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            BufferBuilder coreBuffer=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            List<SkinFace> skin=new ArrayList<>();
            int coreCount=0;
            Matrix4f rootPose=matrices.peek().getPositionMatrix();
            // Field membership is calculated in tick(), never on the render thread.
            // Every original volume survives a merge/split and crossfades gradually.
            // No group leader can delete another cloud's mesh in one frame.
            for(Volume v:active){
                double centerX=v.x,centerZ=v.z;
                double fieldScale=v.fieldScale;
                double d=Math.hypot(centerX-eye.x,centerZ-eye.z);
                // 80-block range fade avoids a hard on/off when approaching a
                // cloud field; opaque cores crossfade as translucent geometry.
                // High-level synoptic veils are visible on the distant horizon
                // even when ordinary volumetric clouds use a shorter setting.
                double cloudRange=v.weather.cx()>=3000000 && v.weather.type()==5
                    ?Math.max(maxDistance(),1450):maxDistance();
                double distanceFade=de.meteo.CloudFieldContinuity.rangeFade(d,cloudRange,80);
                if(distanceFade<=.001)continue;
                double effectiveVisibility=v.visibility*distanceFade;
                int detail=CloudOptimization.detail(quality.ordinal(),d,optimization);
                ensureMesh(v,detail);
                if(v.faces.isEmpty())continue;
                double life=CloudLife.clamp(v.growth);
                double h=CloudLife.horizontalScale(life)*fieldScale;
                double y=CloudLife.verticalScale(life)*v.heightPhase;
                double storm=Math.max(0,Math.min(1,(v.weather.liquid()-.35f)*1.65));
                if(v.weather.type()==6||v.weather.type()==8)storm+=1.35; // frontal and nimbostratus decks darken
                if(v.weather.type()==7)storm+=1.65; // cumulonimbus shadows
                // When meteorology changes category, retain the old mesh while the
                // new silhouette fades in. Both variants follow the same smoothly
                // interpolated position, altitude and life cycle.
                boolean transitioning=!v.previousFaces.isEmpty()&&v.shapeBlend<=.95;
                for(int variant=transitioning?0:1;variant<2;variant++){
                    boolean previous=variant==0;
                    List<CloudVoxelMesh.Face> renderFaces=previous?v.previousFaces:v.faces;
                    List<CloudVoxelMesh.Face> renderCore=previous?v.previousCoreFaces:v.coreFaces;
                    float renderBase=previous?v.previousMeshBaseY:v.meshBaseY;
                    double formVisibility=effectiveVisibility*(previous?1-v.shapeBlend:(transitioning?v.shapeBlend:1));
                    if(formVisibility<=.002||renderFaces.isEmpty())continue;
                    matrices.push();
                    matrices.translate(centerX,v.baseY-renderBase,centerZ);
                    matrices.translate(0,renderBase,0);
                    matrices.scale((float)h,(float)y,(float)h);
                    matrices.translate(0,-renderBase,0);
                    Matrix4f pose=new Matrix4f(matrices.peek().getPositionMatrix());
                    for(CloudVoxelMesh.Face f:renderCore){
                        // Crossfading cores use the translucent pass. Only a fully
                        // settled formation writes an opaque inner depth shell.
                        if(formVisibility>.998){face(coreBuffer,pose,f,solar,storm,255);coreCount++;}
                        else if(formVisibility>.008){
                            double fx=(f.x0()+f.x1())*.5,fy=(f.y0()+f.y1())*.5,fz=(f.z0()+f.z1())*.5;
                            double wx=centerX+fx*h,wy=v.baseY+(fy-renderBase)*y,wz=centerZ+fz*h;
                            double ds=(wx-eye.x)*(wx-eye.x)+(wy-eye.y)*(wy-eye.y)+(wz-eye.z)*(wz-eye.z);
                            skin.add(new SkinFace(f,pose,ds,(int)Math.round(255*formVisibility),storm));
                        }
                    }
                    for(CloudVoxelMesh.Face f:renderFaces){
                        double fx=(f.x0()+f.x1())*.5,fy=(f.y0()+f.y1())*.5,fz=(f.z0()+f.z1())*.5;
                        double wx=centerX+fx*h,wy=v.baseY+(fy-renderBase)*y,wz=centerZ+fz*h;
                        double distanceSq=(wx-eye.x)*(wx-eye.x)+(wy-eye.y)*(wy-eye.y)+(wz-eye.z)*(wz-eye.z);
                        // Soft edge, denser inner flanks, lighter thin high-level cloud sheets.
                        double radial=Math.min(1,Math.hypot(fx,fz)/55.0);
                        double edge=1.0-radial;
                        double opacity=.25+.29*edge+.13*f.occlusion()+.08*f.variation();
                        if(v.weather.type()==3||v.weather.type()==4||v.weather.type()==9)opacity*=.72;
                        if(v.weather.type()==5)opacity*=.31;
                        int alpha=(int)Math.round(Math.max(.0,Math.min(.69,opacity))*formVisibility*255);
                        if(alpha>1)skin.add(new SkinFace(f,pose,distanceSq,alpha,storm));
                    }
                    matrices.pop();
                }
            }
            if(coreCount>0)BufferRenderer.drawWithGlobalProgram(coreBuffer.end());
            if(preview){
                for(CloudVoxelMesh.Face f:previewFaces){
                    double fx=(f.x0()+f.x1())*.5,fy=(f.y0()+f.y1())*.5,fz=(f.z0()+f.z1())*.5;
                    double distanceSq=(fx-eye.x)*(fx-eye.x)+(fy-eye.y)*(fy-eye.y)+(fz-eye.z)*(fz-eye.z);
                    skin.add(new SkinFace(f,new Matrix4f(rootPose),distanceSq,118,.12));
                }
            }
            if(!skin.isEmpty()){
                skin.sort(Comparator.comparingDouble(SkinFace::distanceSq).reversed());
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.depthMask(false);
                BufferBuilder skinBuffer=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
                for(SkinFace f:skin)
                    face(skinBuffer,f.pose(),f.face(),solar,f.storm(),f.alpha());
                BufferRenderer.drawWithGlobalProgram(skinBuffer.end());
            }
        }finally{
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            RenderSystem.depthMask(true);
            matrices.pop();
        }
    }
}
