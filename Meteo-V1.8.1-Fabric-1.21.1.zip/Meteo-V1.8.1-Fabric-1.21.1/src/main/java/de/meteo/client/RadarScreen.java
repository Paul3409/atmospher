package de.meteo.client;

import de.meteo.RainPhysics;
import de.meteo.RainRadarPayload;
import de.meteo.SynopticMapPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.Locale;

/** Classic Minecraft synoptic weather map. Pressure lines and front symbols come from a
 * server-authoritative evolving pressure field; radar rain comes from actual local clouds.
 */
public final class RadarScreen extends Screen {
    private static final int[] RANGES={512,768,1152,1536};
    private static int quality=1;
    private static final String[] QUALITY={"Niedrig","Normal","Hoch"};
    public static String qualityName(){return QUALITY[quality];}
    public static void cycleQuality(){quality=(quality+1)%QUALITY.length;saveQuality();}
    public static void loadQuality(){try{
        var path=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meteo-radar.properties");
        if(!java.nio.file.Files.isRegularFile(path))return;
        var properties=new java.util.Properties();try(var in=java.nio.file.Files.newInputStream(path)){properties.load(in);}
        quality=Math.max(0,Math.min(2,Integer.parseInt(properties.getProperty("quality","1"))));
    }catch(Exception e){System.err.println("Meteo radar settings: "+e.getMessage());}}
    private static void saveQuality(){try{
        var path=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("meteo-radar.properties");
        java.nio.file.Files.createDirectories(path.getParent());var properties=new java.util.Properties();
        properties.setProperty("quality",Integer.toString(quality));
        try(var out=java.nio.file.Files.newOutputStream(path)){properties.store(out,"Meteo radar graphics");}
    }catch(Exception e){System.err.println("Meteo radar settings: "+e.getMessage());}}
    private static final int[] COLORS={0xff268c9f,0xff48c878,0xffe3e95c,0xffffae49,0xfff05d57};
    private static final int OCEAN=0xff17485c, GRID=0x995e93a4,WHITE=0xfff8f3e6;
    private int zoom=1,mode=2,hours=0;
    private int[][] rainPixels=new int[0][0];
    private RainRadarPayload cachedRain;
    private int cachedZoom=-1,cachedW=-1,cachedH=-1,cachedQuality=-1;
    private double cachedX=Double.NaN,cachedZ=Double.NaN;
    private static int rainTile(){return new int[]{7,4,2}[quality];}
    private void rebuildRain(int mw,int mh,double px,double pz,RainRadarPayload rain){
        int tile=rainTile();int cols=(mw+tile-1)/tile,rows=(mh+tile-1)/tile;
        rainPixels=new int[rows][cols];
        double span=RANGES[zoom]*2.0,minX=px-span/2,minZ=pz-span/2;
        // Spatial binning: high-quality radar does not scan all 512 sources for every pixel.
        java.util.Map<Long,java.util.List<RainRadarPayload.RainCell>> bins=new java.util.HashMap<>();
        for(var source:rain.cells()){
            int bx=(int)Math.floor(source.x()/256.0),bz=(int)Math.floor(source.z()/256.0);
            long key=(((long)bx)<<32)^(bz&0xffffffffL);
            bins.computeIfAbsent(key,k->new java.util.ArrayList<>()).add(source);
        }
        for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){
            double wx=minX+(x*tile+tile*.5)*span/mw;
            double wz=minZ+(y*tile+tile*.5)*span/mh;
            double amount=0,snow=0;
            int bx=(int)Math.floor(wx/256.0),bz=(int)Math.floor(wz/256.0);
            for(int dz=-1;dz<=1;dz++)for(int dx=-1;dx<=1;dx++){
                long key=(((long)(bx+dx))<<32)^((bz+dz)&0xffffffffL);
                var nearby=bins.get(key);if(nearby==null)continue;
                for(var c:nearby){
                    if(Math.abs(wx-c.x())>130||Math.abs(wz-c.z())>130)continue;
                    double value=RainPhysics.localRate(c.x(),c.z(),wx,wz,c.mmHour(),c.type());
                    if(c.precipitationKind()==1)snow+=value;else amount+=value;
                }
            }
            rainPixels[y][x]=snow>.08?(snow>5?0xffe5b6ec:0xfff4f4fa):rainColor(amount);
        }
        cachedRain=rain;cachedZoom=zoom;cachedW=mw;cachedH=mh;cachedQuality=quality;cachedX=px;cachedZ=pz;
    }
    private ButtonWidget zoomButton,modeButton;
    public RadarScreen(){super(Text.literal("Meteo Wetterradar"));}
    private static Text t(String text){return Text.literal(text);}
    @Override protected void init(){
        int gap=4,cw=Math.min(770,width-16),w=(cw-4*gap)/5,x=(width-cw)/2,y=height-25;
        modeButton=addDrawableChild(ButtonWidget.builder(t("Alles"),b->{mode=(mode+1)%3;modeButton.setMessage(t(
            (width<550?new String[]{"Regen","Druck","Alles"}:new String[]{"Niederschlag","Druck / Fronten","Alles"})[mode]));}).dimensions(x,y,w,20).build());
        zoomButton=addDrawableChild(ButtonWidget.builder(t(RANGES[zoom]+" Bl."),b->{zoom=(zoom+1)%RANGES.length;
            zoomButton.setMessage(t(RANGES[zoom]+" Bl."));}).dimensions(x+w+gap,y,w,20).build());
        addDrawableChild(ButtonWidget.builder(t((width<550?"Qual.: ":"Grafik: ")+qualityName()),b->{cycleQuality();cachedQuality=-1;
            b.setMessage(t((width<550?"Qual.: ":"Grafik: ")+qualityName()));}).dimensions(x+2*(w+gap),y,w,20).build());
        addDrawableChild(ButtonWidget.builder(t(width<550?"+0h":"Vorhersage +0h"),b->{hours=(hours+3)%12;
            b.setMessage(t(width<550?"+"+hours+"h":"Vorhersage +"+hours+"h"));
            if(hours>0&&ClientPlayNetworking.canSend(de.meteo.RadarForecastRequestPayload.ID))
                ClientPlayNetworking.send(new de.meteo.RadarForecastRequestPayload(hours));
        }).dimensions(x+3*(w+gap),y,w,20).build());
        addDrawableChild(ButtonWidget.builder(t("Fertig"),b->MinecraftClient.getInstance().setScreen(null))
            .dimensions(x+4*(w+gap),y,cw-4*(w+gap),20).build());
    }
    @Override public void renderBackground(DrawContext g,int mx,int my,float dt){g.fill(0,0,width,height,0xb0192734);}
    private static void stroke(DrawContext g,int x0,int y0,int x1,int y1,int color){
        int dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,err=dx+dy;
        for(;;){g.fill(x0,y0,x0+1,y0+1,color);if(x0==x1&&y0==y1)break;
            int e=2*err;if(e>=dy){err+=dy;x0+=sx;}if(e<=dx){err+=dx;y0+=sy;}}
    }
    private static int rainColor(double r){if(r<.08)return 0;if(r<1)return COLORS[0];if(r<3)return COLORS[1];
        if(r<8)return COLORS[2];if(r<18)return COLORS[3];return COLORS[4];}
    /** Keep one ridge of each frontal band, not the entire wide 2D intensity area. */
    private static boolean ridge(SynopticMapPayload map,int r,int c){
        if(r<1||c<1||r>=SynopticMapPayload.ROWS-1||c>=SynopticMapPayload.COLS-1)return false;
        int nx=SynopticMapPayload.COLS;var cells=map.grid();float v=cells.get(r*nx+c).front();
        if(v<.36f)return false;
        float left=cells.get(r*nx+c-1).front(),right=cells.get(r*nx+c+1).front();
        float up=cells.get((r-1)*nx+c).front(),down=cells.get((r+1)*nx+c).front();
        return (v>=left&&v>=right&&(v>left+.035||v>right+.035))||
            (v>=up&&v>=down&&(v>up+.035||v>down+.035));
    }
    private static int frontColor(byte type){return switch(type){case 1->0xffff655f;case 2->0xff66c6ff;case 3->0xffe49bdf;default->0;};}
    private static void symbol(DrawContext g,int x,int y,byte type){
        int c=frontColor(type);if(c==0)return;
        if(type==2){g.fill(x-2,y-4,x+3,y-2,c);g.fill(x-1,y-6,x+2,y-3,c);}
        else if(type==1){g.fill(x-3,y-3,x+4,y,c);}
        else{g.fill(x-3,y-4,x+3,y-2,c);g.fill(x-2,y-6,x+2,y-3,c);}
    }
    private void contours(DrawContext g,SynopticMapPayload map,int l,int top,int mw,int mh){
        int nx=SynopticMapPayload.COLS,ny=SynopticMapPayload.ROWS;
        // Marching squares, levels from 980 to 1040 hPa every 4 hPa.
        for(int row=0;row<ny-1;row++)for(int col=0;col<nx-1;col++){
            float a=map.grid().get(row*nx+col).pressure(),b=map.grid().get(row*nx+col+1).pressure(),
                c=map.grid().get((row+1)*nx+col+1).pressure(),d=map.grid().get((row+1)*nx+col).pressure();
            double x0=l+col*(double)mw/(nx-1),x1=l+(col+1)*(double)mw/(nx-1);
            double y0=top+row*(double)mh/(ny-1),y1=top+(row+1)*(double)mh/(ny-1);
            for(int level=976;level<=1048;level+=4){
                int[] xx=new int[4],yy=new int[4];int k=0;
                if((a<level)!=(b<level)){double f=(level-a)/(b-a);xx[k]=(int)(x0+(x1-x0)*f);yy[k++]=(int)y0;}
                if((b<level)!=(c<level)){double f=(level-b)/(c-b);xx[k]=(int)x1;yy[k++]=(int)(y0+(y1-y0)*f);}
                if((c<level)!=(d<level)){double f=(level-c)/(d-c);xx[k]=(int)(x1+(x0-x1)*f);yy[k++]=(int)y1;}
                if((d<level)!=(a<level)){double f=(level-d)/(a-d);xx[k]=(int)x0;yy[k++]=(int)(y1+(y0-y1)*f);}
                if(k>=2)stroke(g,xx[0],yy[0],xx[1],yy[1],0xfff9f7ef);
                if(k==4)stroke(g,xx[2],yy[2],xx[3],yy[3],0xfff9f7ef);
            }
        }
        // Label coherent local pressure extrema rather than placing random H/L markers.
        for(int row=3;row<ny-3;row+=2)for(int col=3;col<nx-3;col+=2){
            int i=row*nx+col;float p=map.grid().get(i).pressure();boolean min=true,max=true;
            for(int dz=-3;dz<=3;dz++)for(int dx=-3;dx<=3;dx++){
                float q=map.grid().get((row+dz)*nx+col+dx).pressure();if(q<p)max=false;if(q>p)min=false;
            }
            if(min||max){int px=l+col*mw/(nx-1),py=top+row*mh/(ny-1);
                String label=min?"T":"H";
                g.drawCenteredTextWithShadow(textRenderer,t(label),px,py,min?0xffff9a76:0xffc7e3ff);
                g.drawCenteredTextWithShadow(textRenderer,t(""+Math.round(p)),px,py+10,WHITE);
            }
        }
    }
    @Override public void render(DrawContext g,int mx,int my,float dt){
        renderBackground(g,mx,my,dt);
        int mw=Math.min(785,width-28),mh=Math.max(70,Math.min(height-123,(int)(mw*.53)));
        int left=(width-mw)/2,top=25;
        g.drawCenteredTextWithShadow(textRenderer,t("METEO V1.8.1 | Synoptisches Radar"),width/2,12,WHITE);
        g.fill(left-3,top-3,left+mw+3,top+mh+3,0xffb9c5ce);
        g.fill(left,top,left+mw,top+mh,OCEAN);
        var forecast=SynopticControls.forecast();
        var map=hours>0?(forecast!=null&&forecast.hours()==hours?forecast.map():null):SynopticControls.map();
        var rain=RadarData.latest();var client=MinecraftClient.getInstance();
        if(map!=null&&client.player!=null){
            double px=client.player.getX(),pz=client.player.getZ();
            double span=RANGES[zoom]*2.0;
            double minX=px-span/2,minZ=pz-span/2;
            // Cache intensity tiles until data, player position or map zoom changes.
            if(hours==0&&mode!=1&&SynopticControls.current().precip()&&rain!=null){
                if(rain!=cachedRain||zoom!=cachedZoom||mw!=cachedW||mh!=cachedH||quality!=cachedQuality||
                    Math.hypot(px-cachedX,pz-cachedZ)>12)rebuildRain(mw,mh,px,pz,rain);
                for(int y=0;y<rainPixels.length;y++)for(int x=0;x<rainPixels[y].length;x++){
                    int color=rainPixels[y][x];if(color==0)continue;
                    int tile=rainTile(),xx=left+x*tile,yy=top+y*tile;
                    g.fill(xx,yy,Math.min(left+mw,xx+tile),Math.min(top+mh,yy+tile),color);
                }
            }
            // Forecast has no future cloud-water integration. Display a distinct
            // *potential* field computed from the same synoptic pressure/fronts,
            // never misrepresent it as observed radar or as an exact rain rate.
            if(hours>0&&mode!=1&&SynopticControls.current().precip()){
                int nx=SynopticMapPayload.COLS,ny=SynopticMapPayload.ROWS;
                int tileX=Math.max(2,(int)Math.ceil(SynopticMapPayload.STEP*mw/span));
                int tileY=Math.max(2,(int)Math.ceil(SynopticMapPayload.STEP*mh/span));
                for(int r=0;r<ny;r++)for(int c=0;c<nx;c++){
                    var point=map.grid().get(r*nx+c);
                    if(point.rainPotential()<.5)continue;
                    double wx=map.originX()+(c-nx/2)*SynopticMapPayload.STEP;
                    double wz=map.originZ()+(r-ny/2)*SynopticMapPayload.STEP;
                    int sx=left+(int)((wx-minX)*mw/span),sy=top+(int)((wz-minZ)*mh/span);
                    if(inside(sx,sy,left,top,mw,mh)){
                        int color=point.rainPotential()>8?0x9994a64b:point.rainPotential()>3?0x9951a976:0x99317896;
                        g.fill(Math.max(left,sx-tileX/2),Math.max(top,sy-tileY/2),
                            Math.min(left+mw,sx+tileX/2+1),Math.min(top+mh,sy+tileY/2+1),color);
                    }
                }
            }
            // Plot pressure and fronts using the server's world-coordinate grid.
            if(mode!=0){
                if(SynopticControls.current().fronts()){
                    // Draw exact continuous paths provided by the server.
                    // Pixel ridges computed from independent samples broke
                    // diagonals and produced disconnected crossing scribbles.
                    for(var line:map.frontLines()){
                        var points=line.points();int color=frontColor(line.type());
                        for(int i=1;i<points.size();i++){
                            var a=points.get(i-1);var b=points.get(i);
                            int ax=left+(int)((a.x()-minX)*mw/span),ay=top+(int)((a.z()-minZ)*mh/span);
                            int bx=left+(int)((b.x()-minX)*mw/span),by=top+(int)((b.z()-minZ)*mh/span);
                            if(inside(ax,ay,left,top,mw,mh)&&inside(bx,by,left,top,mw,mh)){
                                stroke(g,ax,ay,bx,by,color);
                                if(i%5==0)symbol(g,bx,by,line.type());
                            }
                        }
                    }
                }
                if(SynopticControls.current().isobars()){
                    drawPressureContours(g,map,left,top,mw,mh,minX,minZ,span);
                    drawPressureCentres(g,map,left,top,mw,mh,minX,minZ,span);
                }
            }
            int crossX=left+mw/2,crossY=top+mh/2;
            var local=WeatherDiagnostics.latest();
            if(hours==0&&mode!=1&&local!=null&&local.rainMmHour()>.08){
                // The independent player-local server measurement is a point,
                // never a fabricated radar field.
                double shown=0;
                if(rain!=null)for(var c:rain.cells())shown+=RainPhysics.localRate(c.x(),c.z(),px,pz,c.mmHour(),c.type());
                if(shown<.08){
                    int color=local.temperatureC()<=1.0?0xfff4f4fa:rainColor(local.rainMmHour());
                    g.fill(crossX-5,crossY-5,crossX+6,crossY+6,color);
                    g.drawTextWithShadow(textRenderer,t("Lokale Messung - keine Radarquelle"),left+6,top+mh-16,0xffffe1a0);
                }
            }
            g.fill(crossX-6,crossY,crossX+7,crossY+1,WHITE);g.fill(crossX,crossY-6,crossX+1,crossY+7,WHITE);
            g.drawTextWithShadow(textRenderer,t("N ^"),left+6,top+5,WHITE);
        }else g.drawCenteredTextWithShadow(textRenderer,t(hours>0?"Vorhersage wird vom Server geladen ...":"Warte auf Wetterdaten vom Server"),width/2,top+mh/2,WHITE);
        // Fine grid lines like the original Atmosphere radar.
        for(int i=1;i<4;i++){
            int x=left+i*mw/4,y=top+i*mh/4;
            g.fill(x,top,x+1,top+mh,GRID);g.fill(left,y,left+mw,y+1,GRID);
        }
        String legend=hours>0?"Prognose: Druck, Fronten & Niederschlagspotenzial (keine Messung)":
            width<700?"Regen gruen-rot | Schnee weiss-pink | Fronten farbig":
            "Regen gruen-rot | Schnee weiss-pink | Warm rot | Kalt blau | Okklusion lila";
        g.drawCenteredTextWithShadow(textRenderer,t(legend),width/2,top+mh+6,WHITE);
        var d=WeatherDiagnostics.latest();
        g.drawCenteredTextWithShadow(textRenderer,t(String.format(Locale.GERMANY,"Hier: %.1f mm/h  |  Quellen: %d  |  %d Bl.",
            d==null?0:d.rainMmHour(),rain==null?0:rain.cells().size(),RANGES[zoom])),width/2,top+mh+18,WHITE);
        super.render(g,mx,my,dt);
    }
    /** Pressure-centre labels are located by extrema of the same server pressure grid. */
    private void drawPressureCentres(DrawContext g,SynopticMapPayload map,int left,int top,int mw,int mh,double minX,double minZ,double span){
        int nx=SynopticMapPayload.COLS,ny=SynopticMapPayload.ROWS;
        for(int row=3;row<ny-3;row++)for(int col=3;col<nx-3;col++){
            float p=map.grid().get(row*nx+col).pressure();boolean min=true,max=true;
            for(int dz=-3;dz<=3;dz++)for(int dx=-3;dx<=3;dx++){
                if(dx==0&&dz==0)continue;
                float q=map.grid().get((row+dz)*nx+col+dx).pressure();
                if(q<=p)min=false;if(q>=p)max=false;
            }
            if(!min&&!max)continue;
            double wx=map.originX()+(col-nx/2)*SynopticMapPayload.STEP;
            double wz=map.originZ()+(row-ny/2)*SynopticMapPayload.STEP;
            int x=left+(int)((wx-minX)*mw/span),y=top+(int)((wz-minZ)*mh/span);
            if(x<left+22||x>left+mw-22||y<top+18||y>top+mh-22)continue;
            g.drawCenteredTextWithShadow(textRenderer,t(min?"T":"H"),x,y,min?0xffff9999:0xffddedff);
            g.drawCenteredTextWithShadow(textRenderer,t(""+Math.round(p)),x,y+10,WHITE);
        }
    }
    /** Full world-coordinate contour interpolation for zoom levels 768 and 1152. */
    private void drawPressureContours(DrawContext g,SynopticMapPayload map,int left,int top,int mw,int mh,double minX,double minZ,double span){
        int nx=SynopticMapPayload.COLS,ny=SynopticMapPayload.ROWS;
        for(int row=0;row<ny-1;row++)for(int col=0;col<nx-1;col++){
            float[] p={map.grid().get(row*nx+col).pressure(),map.grid().get(row*nx+col+1).pressure(),
                map.grid().get((row+1)*nx+col+1).pressure(),map.grid().get((row+1)*nx+col).pressure()};
            double wx=map.originX()+(col-nx/2)*SynopticMapPayload.STEP;
            double wz=map.originZ()+(row-ny/2)*SynopticMapPayload.STEP;
            double x0=left+(wx-minX)*mw/span,x1=x0+SynopticMapPayload.STEP*mw/span;
            double y0=top+(wz-minZ)*mh/span,y1=y0+SynopticMapPayload.STEP*mh/span;
            if(x1<left||x0>left+mw||y1<top||y0>top+mh)continue;
            for(int level=976;level<=1048;level+=4){
                int[] xx=new int[4],yy=new int[4];int k=0;
                if((p[0]<level)!=(p[1]<level)){double f=(level-p[0])/(p[1]-p[0]);xx[k]=(int)(x0+(x1-x0)*f);yy[k++]=(int)y0;}
                if((p[1]<level)!=(p[2]<level)){double f=(level-p[1])/(p[2]-p[1]);xx[k]=(int)x1;yy[k++]=(int)(y0+(y1-y0)*f);}
                if((p[2]<level)!=(p[3]<level)){double f=(level-p[2])/(p[3]-p[2]);xx[k]=(int)(x1+(x0-x1)*f);yy[k++]=(int)y1;}
                if((p[3]<level)!=(p[0]<level)){double f=(level-p[3])/(p[0]-p[3]);xx[k]=(int)x0;yy[k++]=(int)(y1+(y0-y1)*f);}
                if(k>=2&&inside(xx[0],yy[0],left,top,mw,mh)&&inside(xx[1],yy[1],left,top,mw,mh)){
                    stroke(g,xx[0],yy[0],xx[1],yy[1],WHITE);
                    // Sparse actual pressure labels directly on measured isobars.
                    if((row*7+col*11+level)%127==0 && xx[0]>left+22 && xx[0]<left+mw-38
                        && yy[0]>top+9 && yy[0]<top+mh-11)
                        g.drawTextWithShadow(textRenderer,t(level+""),xx[0]+2,yy[0]-4,WHITE);
                }
                if(k==4&&inside(xx[2],yy[2],left,top,mw,mh)&&inside(xx[3],yy[3],left,top,mw,mh))stroke(g,xx[2],yy[2],xx[3],yy[3],WHITE);
            }
        }
    }
    private static boolean inside(int x,int y,int left,int top,int w,int h){return x>=left&&x<left+w&&y>=top&&y<top+h;}
    @Override public void close(){MinecraftClient.getInstance().setScreen(new MeteoScreen());}
    @Override public boolean shouldPause(){return false;}
}
