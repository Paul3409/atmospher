package dev.atmosphere;

/** Continuous storm-relative geometry. No world access and no cloud height clamp. */
public final class TornadoGeometry {
    private TornadoGeometry() {}
    public record Point(double x,double y,double z,double nx,double nz) {}
    public static int type(long seed) { return (int)(WeatherCells.hash(seed,0,821)*3); }
    /** t=0 at the wall cloud, t=1 at the descending tip. */
    public static Point point(long seed,double t,double azimuth,double ticks,
                              double top,double bottom,double scale,int type) {
        return point(seed,t,azimuth,ticks,top,bottom,scale,type,.55);
    }
    public static double radiusProfile(int type,double t,double phase) {
        double age=phase-Math.floor(phase);
        double cone=.12+.88*Math.pow(1-t,.85);
        double mature=switch(type){case 0->.10+.90*Math.pow(1-t,2.5);
            case 2->.64+.36*(1-t);default->cone;};
        double growth=StormEvolution.smooth(.32,.48,age);
        double rope=StormEvolution.smooth(.70,.89,age);
        double radius=cone+(mature-cone)*growth;
        double thin=.045+.955*Math.pow(1-t,3.0);
        return radius+(thin-radius)*rope;
    }
    public static double band(double azimuth,double height,long seed) {
        return .76+.17*Math.sin(azimuth*4+height*13+seed*.001)
                +.07*Math.sin(azimuth*9-height*8);
    }
    public static double soundGain(double distance,double width,double activity,boolean sheltered) {
        double range=StormEvolution.clamp(1-distance/1200,0,1);
        return range*range*StormEvolution.clamp(.35+width/80,.35,1)*activity*(sheltered?.42:1);
    }
    public static Point point(long seed,double t,double azimuth,double ticks,
                              double top,double bottom,double scale,int type,double phase) {
        double age=phase-Math.floor(phase);
        double spin=ticks*.045*(1+.10*t);
        double angle=azimuth+spin;
        double profile=radiusProfile(type,t,phase);
        double ripple=1+.09*Math.sin(azimuth*5+t*10+seed*.001)
                +.035*Math.sin(azimuth*9-t*6+ticks*.003);
        double radius=scale*profile*ripple;
        double lean=scale*(.08+(type==0?.27:0)+.65*StormEvolution.smooth(.70,.90,age));
        return new Point(Math.cos(angle)*radius+lean*t*t,
                top+(bottom-top)*t,Math.sin(angle)*radius,
                Math.cos(angle),Math.sin(angle));
    }
}
