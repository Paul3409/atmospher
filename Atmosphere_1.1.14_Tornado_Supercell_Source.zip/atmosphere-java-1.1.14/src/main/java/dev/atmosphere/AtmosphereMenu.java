package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Singleplayer, keyboard-accessible graphical controls. Numeric inputs require Apply. */
public final class AtmosphereMenu extends Screen {
    private final AtmosphereSettings settings;
    private final List<ButtonWidget> weatherButtons = new ArrayList<>();
    private final List<ButtonWidget> graphicsButtons = new ArrayList<>();
    private final List<ButtonWidget> extrasButtons = new ArrayList<>();
    private final List<ButtonWidget> climateButtons = new ArrayList<>();
    private final List<ButtonWidget> snowButtons = new ArrayList<>();
    private final List<ButtonWidget> pressureButtons = new ArrayList<>();
    private final List<TextFieldWidget> weatherFields = new ArrayList<>();
    private final List<TextFieldWidget> climateFields = new ArrayList<>();
    private int page = 0;
    private ButtonWidget mode, season, type, quality, rain, particles, snow, color,
            speed, sounds, lightning, gusts, cloudDetail, stormType,
            hud, clouds, fog, sunset, shadows;
    private TextFieldWidget amount, temperature, windInput, gustInput, directionInput;
    private ButtonWidget manualWind, frequency, strength, adapt, lightningRate, experience;
    private ButtonWidget snowArea, snowDeposit, snowThaw;
    private ButtonWidget highPower, lowPower, pressureLife, pressureSelect, lightningPower, lightningSizeControl,
            thunderVolumeControl, windVolumeControl, rainbowButton, tornadoChanceControl, tornadoVolumeControl;
    private String feedback = "";
    private int selectedStorm = WeatherCells.SHOWER;
    private int pressureChoice=985;
    private int lastOffset;
    private boolean lastColors;

    public AtmosphereMenu(AtmosphereSettings settings) {
        super(Text.literal("Atmosphere 1.1.14 | Tornado & Superzelle"));
        this.settings = settings;
    }

    @Override protected void init() {
        weatherButtons.clear(); graphicsButtons.clear(); extrasButtons.clear(); climateButtons.clear(); snowButtons.clear(); pressureButtons.clear(); weatherFields.clear(); climateFields.clear();
        int x = width / 2 - 162;
        int y = Math.max(1, (height - 250) / 2);
        lastOffset = settings.seasonOffset;
        lastColors = settings.seasonalColors;
        button(x, y, 51, "Wetter", b -> { page = 0; updateVisibility(); });
        button(x + 55, y, 51, "Grafik", b -> { page = 1; updateVisibility(); });
        button(x + 110, y, 51, "Sound", b -> { page = 2; updateVisibility(); });
        button(x + 165, y, 51, "Wind", b -> { page = 3; updateVisibility(); });
        button(x + 220, y, 51, "Schnee", b -> { page = 4; updateVisibility(); });
        button(x + 275, y, 49, "Druck", b -> { page = 5; updateVisibility(); });
        int top = y + 26;
        mode = weather(x, top, 324, "", b -> { settings.mode = (settings.mode + 1) % 3; changed(); });
        type = weather(x, top + 23, 324, "", b -> {
            settings.precipitationType = (settings.precipitationType + 1) % WeatherModel.PRECIPITATION.length;
            settings.mode = 2; changed();
        });
        season = weather(x, top + 46, 324, "", b -> { settings.seasonOffset = (settings.seasonOffset + 1) % 4; changed(); });
        amount = new TextFieldWidget(textRenderer, x + 163, top + 73, 96, 19, Text.literal("Niederschlag mm/h"));
        amount.setMaxLength(6);
        amount.setText(Integer.toString(settings.precipitationMmH));
        addDrawableChild(amount);
        weatherFields.add(amount);
        weather(x + 265, top + 73, 59, "Setzen", b -> applyAmount());
        temperature = new TextFieldWidget(textRenderer, x + 163, top + 98, 96, 19, Text.literal("Temperatur Offset"));
        temperature.setMaxLength(4);
        temperature.setText(Integer.toString(settings.temperatureOffset));
        addDrawableChild(temperature);
        weatherFields.add(temperature);
        weather(x + 265, top + 98, 59, "Setzen", b -> applyTemperature());
        weather(x, top + 133, 157, "14-Tage-Trend", b ->
                MinecraftClient.getInstance().setScreen(new AtmosphereForecastScreen(settings)));
        weather(x + 167, top + 133, 157, "Wetterradar (R)", b ->
                MinecraftClient.getInstance().setScreen(new AtmosphereRadarScreen(settings)));

        quality = graphics(x, top, 158, "", b -> { settings.quality = (settings.quality + 1) % 4; changed(); });
        clouds = graphics(x + 166, top, 158, "", b -> { settings.customClouds = !settings.customClouds; changed(); });
        shadows = graphics(x, top + 23, 158, "", b -> { settings.cloudShadows = !settings.cloudShadows; changed(); });
        rain = graphics(x + 166, top + 23, 158, "", b -> { settings.replaceVanillaRain = !settings.replaceVanillaRain; changed(); });
        particles = graphics(x, top + 46, 158, "", b -> { settings.particles = !settings.particles; changed(); });
        snow = graphics(x + 166, top + 46, 158, "", b -> { settings.snowAccumulation = !settings.snowAccumulation; changed(); });
        color = graphics(x, top + 69, 158, "", b -> { settings.seasonalColors = !settings.seasonalColors; changed(); });
        experience = graphics(x + 166, top + 69, 158, "", b -> { settings.weatherExperience = (settings.weatherExperience + 1) % 5; changed(); });
        fog = graphics(x, top + 92, 158, "", b -> { settings.atmosphericFog = !settings.atmosphericFog; changed(); });
        sunset = graphics(x + 166, top + 92, 158, "", b -> { settings.sunsetLighting = !settings.sunsetLighting; changed(); });
        rainbowButton = graphics(x, top + 115, 158, "", b -> { settings.rainbow = !settings.rainbow; changed(); });
        hud = graphics(x + 166, top + 115, 158, "", b -> { settings.hud = !settings.hud; changed(); });
        cloudDetail = graphics(x, top + 138, 324, "", b -> {
            settings.cloudDetail = settings.cloudDetail >= 3 ? -1 : settings.cloudDetail + 1;
            changed();
        });
        speed = extras(x, top, 324, "", b -> {
            settings.weatherSpeed = switch (settings.weatherSpeed) { case 1 -> 2; case 2 -> 5; case 5 -> 10; case 10 -> 20; default -> 1; };
            changed();
        });
        sounds = extras(x, top + 24, 158, "", b -> { settings.weatherSounds = !settings.weatherSounds; changed(); });
        lightning = extras(x + 166, top + 24, 158, "", b -> { settings.visualLightning = !settings.visualLightning; changed(); });
        gusts = extras(x, top + 48, 324, "", b -> { settings.windGusts = !settings.windGusts; changed(); });
        lightningRate = extras(x, top + 72, 324, "", b -> {
            settings.lightningFrequency=(settings.lightningFrequency+1)%4;changed();
        });
        lightningPower = extras(x, top + 96, 324, "", b -> {
            settings.lightningBrightness = stepPercent(settings.lightningBrightness,25,200,25); changed();
        });
        lightningSizeControl = extras(x, top + 120, 324, "", b -> {
            settings.lightningSize = stepPercent(settings.lightningSize,25,200,25); changed();
        });
        thunderVolumeControl = extras(x, top + 144, 158, "", b -> {
            settings.thunderVolume = stepPercent(settings.thunderVolume,0,200,25); changed();
        });
        windVolumeControl = extras(x+166, top + 144, 158, "", b -> {
            settings.windAmbientVolume = stepPercent(settings.windAmbientVolume,0,100,10); changed();
        });
        tornadoVolumeControl=extras(x,top+168,324,"",b->{settings.tornadoVolume=stepPercent(settings.tornadoVolume,0,100,10);changed();});
        // Existing manual pressure tools move to their own dedicated page.
        highPower = pressure(x,top,324,"",b->{settings.highPressureStrength=stepPercent(settings.highPressureStrength,0,200,25);changed();});
        lowPower = pressure(x,top+24,324,"",b->{settings.lowPressureStrength=stepPercent(settings.lowPressureStrength,0,200,25);changed();});
        pressureLife = pressure(x,top+48,324,"",b->{settings.pressureLifetime=(settings.pressureLifetime+1)%3;changed();});
        stormType = pressure(x,top+72,324,"",b->{selectedStorm=selectedStorm>=WeatherCells.SQUALL?WeatherCells.SHOWER:selectedStorm+1;updateLabels();});
        pressure(x,top+96,158,"Gewitter erzeugen",b->{
            MinecraftClient client=MinecraftClient.getInstance();
            if(client.player!=null && client.getServer()!=null){
                StormEvents.spawn(client.getServer(),selectedStorm,client.player.getX()+210,client.player.getZ()+80);
                settings.mode=0;changed();feedback="Gewitter erzeugt";
            } else feedback="Nur Einzelspieler";
        });
        pressure(x+166,top+96,158,"Gewitter entfernen",b->{
            StormEvents.clear(MinecraftClient.getInstance().getServer());feedback="Gewitter entfernt";
        });
        pressure(x,top+120,158,"Tief erzeugen",b->generatePressure(true));
        pressure(x+166,top+120,158,"Hoch erzeugen",b->generatePressure(false));
        pressureSelect = pressure(x,top+144,158,"",b->{
            pressureChoice=pressureChoice==985?970:pressureChoice==970?1000:pressureChoice==1000?1025:pressureChoice==1025?1040:985;
            updateLabels();
        });
        pressure(x+166,top+144,158,"Druckgebiete loeschen",b->{
            ManualPressureSystems.clear(MinecraftClient.getInstance().getServer());feedback="Druckgebiete geloescht";
        });
        frequency = pressure(x,top+168,158,"",b->{settings.stormFrequency=settings.stormFrequency>=200?0:settings.stormFrequency+25;changed();});
        strength = pressure(x+166,top+168,158,"",b->{settings.stormStrength=settings.stormStrength>=200?0:settings.stormStrength+25;changed();});
        tornadoChanceControl = graphics(x,top+161,324,"",b->{settings.tornadoChance=(settings.tornadoChance+1)%4;changed();});
        manualWind = climate(x,top,324,"", b->{settings.manualWind=!settings.manualWind;changed();});
        windInput = climateInput(x+164,top+29,96,settings.windKmh,"Grundwind km/h");
        climate(x+263,top+29,61,"Setzen",b->applyWind());
        gustInput = climateInput(x+164,top+54,96,settings.gustKmh,"Windböen km/h");
        climate(x+263,top+54,61,"Setzen",b->applyWind());
        directionInput = climateInput(x+164,top+79,96,settings.windDirectionDegrees,"Richtung in Grad");
        climate(x+263,top+79,61,"Setzen",b->applyWind());
        adapt = climate(x,top+107,324,"",b->{settings.adaptiveGraphics=!settings.adaptiveGraphics;changed();});
        climate(x,top+132,324,"Radar / Druckkarten",b->MinecraftClient.getInstance().setScreen(new AtmosphereRadarScreen(settings)));
        snowArea = snowControl(x,top,324,"",b->{settings.snowRadius = settings.snowRadius>=224?64:settings.snowRadius+32;changed();});
        snowDeposit = snowControl(x,top+25,324,"",b->{settings.snowGrowth=settings.snowGrowth>=5?1:settings.snowGrowth+1;changed();});
        snowThaw = snowControl(x,top+50,324,"",b->{settings.snowMelt=settings.snowMelt>=5?1:settings.snowMelt+1;changed();});
        button(x, top + 188, 324, "Fertig", b -> close());
        updateLabels(); updateVisibility();
    }

    private void generatePressure(boolean low){
        MinecraftClient client=MinecraftClient.getInstance();
        if(client.player==null||client.getServer()==null){feedback="Nur Einzelspieler";return;}
        int p=low ? (pressureChoice>1012?985:pressureChoice) : (pressureChoice<1018?1030:pressureChoice);
        // Spawn west of observer: synoptic westerlies carry it towards the village.
        ManualPressureSystems.spawn(client.getServer(),low,p,client.player.getX()-950,client.player.getZ()+200);
        AtmosphereRadarScreen.clearCache();
        feedback=(low?"Tief ":"Hoch ")+p+" hPa erzeugt";
    }
    private TextFieldWidget climateInput(int x,int y,int width,int value,String hint) {
        TextFieldWidget f=new TextFieldWidget(textRenderer,x,y,width,19,Text.literal(hint));
        f.setText(Integer.toString(value));f.setMaxLength(4);
        addDrawableChild(f);climateFields.add(f);return f;
    }
    private void applyWind() {
        try {
            int wind=Integer.parseInt(windInput.getText().trim());
            int gust=Integer.parseInt(gustInput.getText().trim());
            int direction=Integer.parseInt(directionInput.getText().trim());
            if(wind<0||wind>150||gust<wind||gust>200||direction<0||direction>359)throw new NumberFormatException();
            settings.windKmh=wind;settings.gustKmh=gust;settings.windDirectionDegrees=direction;
            feedback="Windwerte gespeichert";changed();
        }catch(NumberFormatException ex){feedback="Wind 0–150, Böe >= Wind bis 200, Richtung 0–359";}
    }
    private void applyAmount() {
        try {
            double input = Double.parseDouble(amount.getText().trim().replace(',', '.'));
            if (!Double.isFinite(input) || input < 0 || input > 150) throw new NumberFormatException();
            settings.precipitationMmH = (int) Math.round(input);
            settings.mode = 2;
            feedback = "Niederschlag gespeichert: " + settings.precipitationMmH + " mm/h";
            changed();
        } catch (NumberFormatException ex) { feedback = "Bitte Zahl von 0 bis 150 eingeben."; }
    }
    private void applyTemperature() {
        try {
            int input = Integer.parseInt(temperature.getText().trim());
            if (input < -40 || input > 40) throw new NumberFormatException();
            settings.temperatureOffset = input;
            feedback = "Temperaturkorrektur gespeichert: " + input + " °C";
            changed();
        } catch (NumberFormatException ex) { feedback = "Bitte ganze Zahl von -40 bis +40 eingeben."; }
    }
    private ButtonWidget button(int x, int y, int width, String message, ButtonWidget.PressAction action) {
        return addDrawableChild(ButtonWidget.builder(Text.literal(message), action).dimensions(x, y, width, 20).build());
    }
    private ButtonWidget weather(int x, int y, int width, String message, ButtonWidget.PressAction action) {
        ButtonWidget b = button(x, y, width, message, action);
        weatherButtons.add(b); return b;
    }
    private ButtonWidget graphics(int x, int y, int width, String message, ButtonWidget.PressAction action) {
        ButtonWidget b = button(x, y, width, message, action);
        graphicsButtons.add(b); return b;
    }
    private ButtonWidget extras(int x, int y, int width, String message, ButtonWidget.PressAction action) {
        ButtonWidget b = button(x, y, width, message, action);
        extrasButtons.add(b); return b;
    }
    private ButtonWidget snowControl(int x,int y,int width,String message,ButtonWidget.PressAction action) {
        ButtonWidget b=button(x,y,width,message,action);snowButtons.add(b);return b;
    }
    private ButtonWidget pressure(int x,int y,int width,String message,ButtonWidget.PressAction action) {
        ButtonWidget b=button(x,y,width,message,action);pressureButtons.add(b);return b;
    }
    private static int stepPercent(int current,int min,int max,int step){
        return current>=max?min:Math.min(max,current+step);
    }
    private ButtonWidget climate(int x,int y,int width,String message,ButtonWidget.PressAction action) {
        ButtonWidget b=button(x,y,width,message,action);climateButtons.add(b);return b;
    }
    private void updateVisibility() {
        for (ButtonWidget b : weatherButtons) b.visible = page == 0;
        for (ButtonWidget b : graphicsButtons) b.visible = page == 1;
        for (ButtonWidget b : extrasButtons) b.visible = page == 2;
        for (ButtonWidget b : climateButtons) b.visible = page == 3;
        for (ButtonWidget b : snowButtons) b.visible = page == 4;
        for (ButtonWidget b : pressureButtons) b.visible = page == 5;
        for (TextFieldWidget b : climateFields) {b.visible=page==3;b.setFocused(false);}
        for (TextFieldWidget b : weatherFields) { b.visible = page == 0; b.setFocused(false); }
    }
    private void changed() {
        settings.save();
        if (settings.seasonOffset != lastOffset || settings.seasonalColors != lastColors) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world != null) client.worldRenderer.scheduleTerrainUpdate();
            lastOffset = settings.seasonOffset;
            lastColors = settings.seasonalColors;
        }
        updateLabels();
    }
    private void updateLabels() {
        mode.setMessage(Text.literal("Wetter: " + WeatherModel.MODES[settings.mode]));
        type.setMessage(Text.literal("Niederschlagsart: " + WeatherModel.PRECIPITATION[settings.precipitationType]));
        MinecraftClient client = MinecraftClient.getInstance();
        long time = client.world == null ? 0 : client.world.getTimeOfDay();
        int seasonNo = WeatherModel.sample(0, 0, time, settings).season();
        season.setMessage(Text.literal("Jahreszeit: " + WeatherModel.SEASONS[seasonNo]));
        quality.setMessage(Text.literal("Grafik: " + WeatherModel.QUALITY[settings.quality]));
        cloudDetail.setMessage(Text.literal("Wolkendetails: " + (settings.cloudDetail < 0 ? "Automatisch" : WeatherModel.QUALITY[settings.cloudDetail])));
        stormType.setMessage(Text.literal("Gewitter wählen: " + WeatherCells.NAMES[selectedStorm]));
        clouds.setMessage(Text.literal("Wolken: " + on(settings.customClouds)));
        shadows.setMessage(Text.literal("Wolkenschatten: " + on(settings.cloudShadows)));
        rain.setMessage(Text.literal("Vanilla-Regen: " + (settings.replaceVanillaRain ? "AUS" : "AN")));
        particles.setMessage(Text.literal("Eigene Partikel: " + on(settings.particles)));
        snow.setMessage(Text.literal("Schneedecke: " + on(settings.snowAccumulation)));
        color.setMessage(Text.literal("Jahreszeitenfarben: " + on(settings.seasonalColors)));
        experience.setMessage(Text.literal("Wetterstil: " + new String[]{"Natur", "Ruhig", "Balance", "Dramatisch", "Kino"}[settings.weatherExperience]));
        fog.setMessage(Text.literal("Talnebel: " + on(settings.atmosphericFog)));
        sunset.setMessage(Text.literal("Wolkenlicht: " + on(settings.sunsetLighting)));
        rainbowButton.setMessage(Text.literal("Regenbogen: " + on(settings.rainbow)));
        hud.setMessage(Text.literal("Wetteranzeige (H): " + on(settings.hud)));
        speed.setMessage(Text.literal("Wetter-Zeitskalierung: " + settings.weatherSpeed + "x"));
        sounds.setMessage(Text.literal("Wettersounds: " + on(settings.weatherSounds)));
        lightning.setMessage(Text.literal("Visuelle Blitze: " + on(settings.visualLightning)));
        lightningRate.setMessage(Text.literal("Blitzhaeufigkeit: "+new String[]{"Selten","Normal","Haeufig","Extrem"}[settings.lightningFrequency]));
        lightningPower.setMessage(Text.literal("Blitzhelligkeit: "+settings.lightningBrightness+"%"));
        lightningSizeControl.setMessage(Text.literal("Blitzgroesse: "+settings.lightningSize+"%"));
        thunderVolumeControl.setMessage(Text.literal("Donner: "+settings.thunderVolume+"%"));
        windVolumeControl.setMessage(Text.literal("Windton: "+settings.windAmbientVolume+"%"));
        tornadoVolumeControl.setMessage(Text.literal("Tornadodroehnen: "+settings.tornadoVolume+"%"));
        highPower.setMessage(Text.literal("Hochdruckstaerke: "+settings.highPressureStrength+"%"));
        lowPower.setMessage(Text.literal("Tiefdruckstaerke: "+settings.lowPressureStrength+"%"));
        pressureLife.setMessage(Text.literal("Wetterlagen-Dauer: "+new String[]{"Kurz","Normal","Lang"}[settings.pressureLifetime]));
        pressureSelect.setMessage(Text.literal("Kerndruck: "+pressureChoice+" hPa"));
        gusts.setMessage(Text.literal("Windböen: " + on(settings.windGusts)));
        manualWind.setMessage(Text.literal("Windmodus: "+(settings.manualWind?"Manuell":"Automatisch")));
        frequency.setMessage(Text.literal("Gewitterhäufigkeit: "+settings.stormFrequency+"%"));
        strength.setMessage(Text.literal("Gewitterstärke: "+settings.stormStrength+"%"));
        tornadoChanceControl.setMessage(Text.literal("Tornadochance: "+new String[]{"Aus","Selten","Normal","Häufig"}[settings.tornadoChance]));
        adapt.setMessage(Text.literal("Automatische Grafikleistung: "+on(settings.adaptiveGraphics)));
        snowArea.setMessage(Text.literal("Schnee-Radius: "+settings.snowRadius+" Bloecke"));
        snowDeposit.setMessage(Text.literal("Schnee-Ansammlung: "+settings.snowGrowth+" / 5"));
        snowThaw.setMessage(Text.literal("Schnee-Schmelze: "+settings.snowMelt+" / 5"));
    }
    private static String on(boolean v) { return v ? "AN" : "AUS"; }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int x = width / 2 - 162;
        int y = Math.max(1, (height - 250) / 2);
        int top = y + 26;
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, y - 12, 0xFFD8F1FF);
        if (page == 0) {
            context.drawTextWithShadow(textRenderer, "Niederschlag (mm/h):", x, top + 78, 0xFFDBF0FF);
            context.drawTextWithShadow(textRenderer, "Temperatur +/- °C:", x, top + 103, 0xFFDBF0FF);
            context.drawCenteredTextWithShadow(textRenderer, feedback.isEmpty() ? "M / O: Menü  |  R: Radar  |  H: HUD" : feedback,
                    width / 2, top + 158, feedback.isEmpty() ? 0xFFB4CDD9 : 0xFFFFE7A3);
        } else if (page == 1) {
            context.drawCenteredTextWithShadow(textRenderer, "Soft Clouds: 3D-Meshes, kein Raymarching-Shader",
                    width / 2, top + 163, 0xFFB4CDD9);
            context.drawCenteredTextWithShadow(textRenderer, "Schatten sind optische Bodenprojektionen",
                    width / 2, top + 175, 0xFFB4CDD9);
        } else if (page == 2) {
            context.drawCenteredTextWithShadow(textRenderer, "Blitze verursachen weiterhin keine Schaeden",
                    width / 2, top + 174, 0xFFFFE7A3);
        } else if (page == 3) {
            context.drawTextWithShadow(textRenderer,"Grundwind (km/h)",x,top+34,0xFFDBF0FF);
            context.drawTextWithShadow(textRenderer,"Windböen max.",x,top+59,0xFFDBF0FF);
            context.drawTextWithShadow(textRenderer,"Windrichtung (0–359°)",x,top+84,0xFFDBF0FF);
            if(!feedback.isEmpty())context.drawCenteredTextWithShadow(textRenderer,feedback,width/2,top+180,0xFFFFD49A);
        } else if (page == 5) {
            // All available space is assigned to the pressure controls.
        } else if (page == 4) {
            context.drawCenteredTextWithShadow(textRenderer,"Schnee-Engine 1.0: groessere Schneefelder",
                width/2,top+94,0xFFDBF0FF);
            context.drawCenteredTextWithShadow(textRenderer,"Schneller bei Starkschnee und Plusgraden",
                width/2,top+109,0xFFC2DAE8);
            context.drawCenteredTextWithShadow(textRenderer,"Nur geladene Chunks; Natur-/Bauschnee bleibt",
                width/2,top+124,0xFFC2DAE8);
            context.drawCenteredTextWithShadow(textRenderer,"Groesserer Radius benoetigt mehr Leistung",
                width/2,top+143,0xFFFFDEA8);
        }
    }
    @Override public void close() { MinecraftClient.getInstance().setScreen(null); }
}
