import dev.atmosphere.TornadoGeometry;
import dev.atmosphere.StormEvolution;
import dev.atmosphere.WeatherCells;

public final class TornadoGeometryTest {
    public static void main(String[] args) {
        for(int type=0;type<3;type++)for(int level=0;level<=20;level++) {
            double t=level/20.0;
            var p=TornadoGeometry.point(42,t,0,0,125,63.5,25,type);
            var seam=TornadoGeometry.point(42,t,Math.PI*2,0,125,63.5,25,type);
            var rotated=TornadoGeometry.point(42,t,0,20,125,63.5,25,type);
            require(Math.abs(p.x()-seam.x())<1e-8&&Math.abs(p.z()-seam.z())<1e-8,"Mesh seam open");
            require(p.y()==rotated.y(),"Rotation moves points vertically");
            require(Math.hypot(p.x()-rotated.x(),p.z()-rotated.z())>.1,"No visible rotation");
            require(Double.isFinite(p.x())&&Double.isFinite(p.y())&&Double.isFinite(p.z()),"Invalid geometry");
            if(level==20)require(Math.abs(p.y()-63.5)<1e-8,"Cloud height clamp still affects ground contact");
        }
        double notch=StormEvolution.rainProfile(5,-35,100,42,WeatherCells.SUPERCELL);
        double arc=StormEvolution.rainProfile(-50,-35,100,42,WeatherCells.SUPERCELL);
        require(arc>notch*3,"Hook does not surround a dry notch");
        require(TornadoGeometry.radiusProfile(2,.9,.55)>TornadoGeometry.radiusProfile(2,.9,.28)*2,
                "Wedge never develops from a narrow funnel");
        require(TornadoGeometry.radiusProfile(2,.9,.87)<TornadoGeometry.radiusProfile(2,.9,.55)*.3,
                "Dissipating wedge does not rope out");
        require(TornadoGeometry.soundGain(100,70,1,false)>TornadoGeometry.soundGain(800,70,1,false),
                "Sound does not weaken with distance");
        require(TornadoGeometry.soundGain(100,70,1,true)<TornadoGeometry.soundGain(100,70,1,false),
                "Shelter does not muffle the roar");
        require(TornadoGeometry.soundGain(1300,70,1,false)==0,"Distant roar unbounded");
        require(Math.abs(TornadoGeometry.band(0,.3,42)-TornadoGeometry.band(Math.PI*2,.3,42))<1e-8,
                "Condensation bands have an open seam");
        System.out.println("PASS: mesh continuity, ground contact, rotation, evolving shapes, hook notch and sound falloff");
    }
    private static void require(boolean v,String message){if(!v)throw new AssertionError(message);}
}
