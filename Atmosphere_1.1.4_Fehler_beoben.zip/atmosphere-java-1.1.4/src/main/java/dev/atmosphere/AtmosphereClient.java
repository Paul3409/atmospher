package dev.atmosphere;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.particle.ParticleTypes;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;
import java.util.Random;

/** Render-only local precipitation system. Server-side world modifications are separate. */
public final class AtmosphereClient implements ClientModInitializer {
    private static final Random RANDOM = new Random();
    private static KeyBinding menuKey, hudKey, radarKey;
    private static int cachedSeason = -1;
    private static boolean cachedColors = true;
    private static long lastTick = Long.MIN_VALUE;

    @Override public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(literal("atmosphere").executes(ctx -> {
                    MinecraftClient.getInstance().execute(() ->
                            MinecraftClient.getInstance().setScreen(new AtmosphereMenu(AtmosphereSettings.get())));
                    return 1;
                })));
        SeasonalColors.register();
        AtmosphereParticles.register();
        AtmosphereClouds.register();
        AtmosphereAudioLightning.register();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.atmosphere.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.atmosphere"));
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.atmosphere.hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.atmosphere"));
        radarKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.atmosphere.radar", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.atmosphere"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) { cachedSeason = -1; return; }
            AtmosphereSettings settings = AtmosphereSettings.get();
            while (menuKey.wasPressed()) client.setScreen(new AtmosphereMenu(settings));
            while (radarKey.wasPressed()) client.setScreen(new AtmosphereRadarScreen(settings));
            while (hudKey.wasPressed()) { settings.hud = !settings.hud; settings.save(); }
            int season = WeatherModel.sample(client.world, client.player.getX(), client.player.getY(), client.player.getZ(),
                    client.world.getTimeOfDay(), settings).season();
            if (season != cachedSeason || cachedColors != settings.seasonalColors) {
                if (cachedSeason != -1) client.worldRenderer.scheduleTerrainUpdate();
                cachedSeason = season;
                cachedColors = settings.seasonalColors;
            }
            long tick = client.world.getTime();
            if (settings.particles && !client.isPaused() && tick != lastTick)
                spawnWeatherParticles(client, settings);
            // Ground drifting snow/dust is not part of the selected 1.1.3 scope.
            // spawnWindEffects intentionally not scheduled.
            lastTick = tick;
        });
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            AtmosphereSettings s = AtmosphereSettings.get();
            if (!s.hud || client.world == null || client.player == null || client.options.hudHidden) return;
            var w = WeatherModel.sample(client.world, client.player.getX(), client.player.getY(), client.player.getZ(),
                    client.world.getTimeOfDay(), s);
            String a = "ATMOSPHERE  1.1.3  |  " + WeatherModel.SEASONS[w.season()] + "  " + w.dayInSeason() + "/12";
            String b = String.format(Locale.GERMANY, "T2: %.1f °C   |   %s: %.1f mm/h", w.t2(), w.phase(), w.rainMmH());
            String c = String.format(Locale.GERMANY, "Wind: %.0f km/h %s   |   Wolken: %.0f%%", w.windKmh(), w.windDirection(), w.cloudiness() * 100);
            String d = String.format(Locale.GERMANY, "Luftdruck %.0f hPa  |  Nebel %.0f%%  |  R: Radar", w.pressure(), w.fog() * 100);
            int width = Math.max(Math.max(client.textRenderer.getWidth(a), client.textRenderer.getWidth(b)),
                    Math.max(client.textRenderer.getWidth(c), client.textRenderer.getWidth(d)));
            context.fill(6, 6, width + 22, 66, 0xBE081421);
            context.drawTextWithShadow(client.textRenderer, a, 13, 11, 0xFFFFFF);
            context.drawTextWithShadow(client.textRenderer, b, 13, 23, 0xD2EBFF);
            context.drawTextWithShadow(client.textRenderer, c, 13, 35, 0xD6E4CD);
            context.drawTextWithShadow(client.textRenderer, d, 13, 47, 0xF7DDAB);
        });
    }

    private static void spawnWeatherParticles(MinecraftClient client, AtmosphereSettings settings) {
        // Within up to 58 blocks of the player, simulate nearby and distant precipitation.
        // Number of attempts rises strongly with rainfall, with a quality-dependent FPS cap.
        double px = client.player.getX(), py = client.player.getY(), pz = client.player.getZ();
        long time = client.world.getTimeOfDay();
        WeatherModel.Weather center = WeatherModel.sample(client.world, px, py, pz, time, settings);
        int max = switch (settings.quality) { case 0 -> 65; case 2 -> 195; case 3 -> 270; default -> 125; };
        int min = switch (settings.quality) { case 0 -> 8; case 2 -> 24; case 3 -> 30; default -> 15; };
        double intensity = Math.sqrt(Math.min(1.0, center.rainMmH() / 95.0));
        // Keep some attempts even if player is dry: rain cells may be visible nearby.
        int budget = (int) Math.max(4,(min + max * (.15 + .85 * intensity))
                * SoftCloudMath.particleScale(client.getCurrentFps(),settings.adaptiveGraphics));
        double radius = settings.quality == 0 ? 44 : 58;
        for (int i = 0; i < budget; i++) {
            double a = RANDOM.nextDouble() * Math.PI * 2;
            double distance = Math.sqrt(RANDOM.nextDouble()) * radius;
            double x = px + Math.cos(a) * distance, z = pz + Math.sin(a) * distance;
            BlockPos loaded = BlockPos.ofFloored(x, py, z);
            if (!client.world.isChunkLoaded(loaded)) continue;
            var w = WeatherModel.sample(client.world, x, py, z, time, settings);
            if (w.rainMmH() < .1) continue;
            // More precipitation means more particles, no arbitrary identical rainfall at all rates.
            double chance = Math.min(.99, .07 + .91 * Math.sqrt(w.rainMmH() / 100.0));
            if (RANDOM.nextDouble() > chance) continue;
            // Distribute particles through a shallow fall column close to visible surface.
            int ground = client.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, (int)x, (int)z);
            double y = Math.max(ground + 1.5, py - 10 + RANDOM.nextDouble() * 27);
            y = Math.min(y, client.world.getTopY() - 2);
            BlockPos block = BlockPos.ofFloored(x, y, z);
            if (!client.world.getBlockState(block).isAir()) continue;
            if (!client.world.isSkyVisible(block)) continue;
            double gust = w.windKmh() * .006;
            double vx = w.windX() * gust + (RANDOM.nextDouble() - .5) * .035;
            double vz = w.windZ() * gust + (RANDOM.nextDouble() - .5) * .035;
            double r = RANDOM.nextDouble();
            switch (w.precipitationKind()) {
                case 1 -> client.world.addParticle(AtmosphereMod.SNOW_FLAKE, x, y, z,
                        vx * (1.1 + r), -.046 - r * .07, vz * (1.1 + r));
                case 2 -> client.world.addParticle(r < .65 ? AtmosphereMod.SNOW_FLAKE : AtmosphereMod.RAIN_STREAK,
                        x, y, z, vx, r < .65 ? -.11 : -.67, vz);
                case 3 -> client.world.addParticle(AtmosphereMod.GRAUPEL, x, y, z,
                        vx * .8, -.24 - r * .16, vz * .8);
                case 4 -> client.world.addParticle(AtmosphereMod.HAIL, x, y, z,
                        vx * .7, -.5 - r * .27, vz * .7);
                default -> {
                    // Drizzle falls more slowly, heavy showers form faster streaks.
                    double fall=w.rainMmH()<2.5?(-.22-r*.16):
                            w.rainMmH()>55?(-.85-r*.38):(-.48-r*.38);
                    client.world.addParticle(AtmosphereMod.RAIN_STREAK, x, y, z,
                            vx * .6, fall, vz * .6);
                }
            }
        }
    }
    /** Very sparse wind-blown dust or drifting snow. Never changes blocks. */
    private static void spawnWindEffects(MinecraftClient client, AtmosphereSettings s) {
        var player=client.player;
        if(player==null) return;
        long t=client.world.getTimeOfDay();
        var weather=WeatherModel.sample(client.world,player.getX(),player.getY(),player.getZ(),t,s);
        if(weather.windKmh()<26) return;
        boolean driftSnow=weather.precipitationKind()==1 && weather.rainMmH()>2;
        boolean dryDust=weather.rainMmH()<.2 && weather.humidity()<.48 && weather.windKmh()>36;
        boolean downburst=weather.storm()>.77 && weather.windKmh()>40;
        if(!driftSnow && !dryDust && !downburst) return;
        int count = (int)Math.min(5,1+weather.windKmh()/23);
        for(int i=0;i<count;i++) {
            double x=player.getX()+(RANDOM.nextDouble()-.5)*40;
            double z=player.getZ()+(RANDOM.nextDouble()-.5)*40;
            var pos=BlockPos.ofFloored(x,player.getY(),z);
            if(!client.world.isChunkLoaded(pos)) continue;
            double surface=client.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,(int)x,(int)z);
            if(Math.abs(surface-player.getY())>18) continue;
            double y=surface+.25+RANDOM.nextDouble()*.8;
            double velocity=Math.min(.52,weather.windKmh()*.007);
            client.world.addParticle(driftSnow?AtmosphereMod.SNOW_FLAKE:
                            dryDust?ParticleTypes.POOF:ParticleTypes.CLOUD,
                    x,y,z,velocity*weather.windX(),.025+RANDOM.nextDouble()*.02,
                    velocity*weather.windZ());
        }
    }

}
