package dev.atmosphere;

import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Only Atmosphere-owned snow is melted. Original leaf block IDs are persisted for spring restoration. */
public final class AtmosphereWorldState extends PersistentState {
    public static final int MAX_SNOW = 65000;
    public static final int MAX_LEAVES = 500;
    public final Set<Long> snow = new HashSet<>();
    public final Map<Long, String> removedLeaves = new HashMap<>();

    public static final Type<AtmosphereWorldState> TYPE = new Type<>(
            AtmosphereWorldState::new, AtmosphereWorldState::fromNbt, DataFixTypes.SAVED_DATA_MAP_DATA);

    public static AtmosphereWorldState of(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE, "atmosphere_weather_blocks");
    }

    public static AtmosphereWorldState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        AtmosphereWorldState state = new AtmosphereWorldState();
        for (long pos : nbt.getLongArray("Snow")) {
            if (state.snow.size() >= MAX_SNOW) break;
            state.snow.add(pos);
        }
        NbtList list = nbt.getList("Leaves", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < list.size() && state.removedLeaves.size() < MAX_LEAVES; i++) {
            NbtCompound entry = list.getCompound(i);
            state.removedLeaves.put(entry.getLong("Pos"), entry.getString("Id"));
        }
        return state;
    }

    @Override public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        nbt.putLongArray("Snow", snow.stream().mapToLong(Long::longValue).toArray());
        NbtList list = new NbtList();
        removedLeaves.forEach((pos, id) -> {
            NbtCompound entry = new NbtCompound();
            entry.putLong("Pos", pos);
            entry.putString("Id", id);
            list.add(entry);
        });
        nbt.put("Leaves", list);
        return nbt;
    }
}
