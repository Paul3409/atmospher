package dev.atmosphere.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.atmosphere.AtmosphereSettings;
import dev.atmosphere.CloudField;
import dev.atmosphere.WeatherModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Shallow dawn/valley fog. Modify existing vanilla world fog, never underwater/other realms. */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "applyFog(Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/BackgroundRenderer$FogType;FZF)V",
            at = @At("TAIL"))
    private static void atmosphere$valleyFog(Camera camera, BackgroundRenderer.FogType fogType,
                                             float viewDistance, boolean thickFog, float tickDelta,
                                             CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        AtmosphereSettings s = AtmosphereSettings.get();
        if ((!s.atmosphericFog && !s.customClouds) || client.world == null || client.player == null ||
                client.world.getRegistryKey() != World.OVERWORLD || camera.getFocusedEntity() != client.player ||
                thickFog || client.player.isSubmergedInWater() || client.player.isInLava()) return;
        var pos = camera.getPos();
        var w = WeatherModel.sample(client.world, pos.x, pos.y, pos.z, client.world.getTimeOfDay(), s);
        // Flying into a cloud is volumetric: apply a bounded near-white mist
        // based on the same world-anchored lower deck used by the cloud geometry.
        double cloud = s.customClouds ? CloudField.immersion(pos.x,pos.y,pos.z,client.world.getTimeOfDay(),s) : 0;
        double rainMist = s.atmosphericFog ? Math.min(.92, Math.max(0,(w.rainMmH()-12)/110.0)) : 0;
        double combined = Math.max(s.atmosphericFog ? w.fog() : 0, Math.max(rainMist,cloud));
        if (combined < .12) return;
        float originalEnd = RenderSystem.getShaderFogEnd();
        float visibility = (float) (195 - 166 * combined);
        float end = Math.min(originalEnd, visibility);
        if (end < 12) return;
        RenderSystem.setShaderFogStart(Math.min(RenderSystem.getShaderFogStart(), end * .08f));
        RenderSystem.setShaderFogEnd(end);
    }
}
