package dev.atmosphere.mixin;

import dev.atmosphere.AtmosphereSettings;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Suppress vanilla rain strips AND vanilla rain splash particles / associated sounds.
 *  The physical vanilla weather still exists until the future weather engine replaces it.
 */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method = "renderClouds(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;FDDD)V",
            at = @At("HEAD"), cancellable = true)
    private void atmosphere$replaceClouds(MatrixStack matrices, Matrix4f matrix4f, Matrix4f matrix4f2,
                                         float tickDelta, double cameraX, double cameraY, double cameraZ,
                                         CallbackInfo ci) {
        if (AtmosphereSettings.get().customClouds) ci.cancel();
    }

    @Inject(method = "renderWeather(Lnet/minecraft/client/render/LightmapTextureManager;FDDD)V", at = @At("HEAD"), cancellable = true)
    private void atmosphere$replacePrecipitation(LightmapTextureManager lightmap, float tickDelta,
                                                double cameraX, double cameraY, double cameraZ,
                                                CallbackInfo ci) {
        if (AtmosphereSettings.get().replaceVanillaRain) ci.cancel();
    }

    @Inject(method = "tickRainSplashing(Lnet/minecraft/client/render/Camera;)V", at = @At("HEAD"), cancellable = true)
    private void atmosphere$replaceSplashing(Camera camera, CallbackInfo ci) {
        if (AtmosphereSettings.get().replaceVanillaRain) ci.cancel();
    }
}
