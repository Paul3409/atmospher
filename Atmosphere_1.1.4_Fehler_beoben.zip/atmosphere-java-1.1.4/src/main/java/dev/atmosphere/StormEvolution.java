package dev.atmosphere;

/** Pure mathematical helpers shared by the renderer, storm model and radar.
 * All curves are bounded, deterministic and independent of loaded world chunks.
 * Storms remain an artistic simulation: no destructive weather mechanics.
 */
public final class StormEvolution {
    private StormEvolution() {}

    public static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }
    public static double smooth(double a, double b, double x) {
        double u=clamp((x-a)/(b-a),0,1); return u*u*(3-2*u);
    }
    public static double localTower(double life, int index, int total, long seed) {
        double stagger = index/(double)Math.max(1,total-1);
        double jitter = .14*(WeatherCells.hash(seed,index,195)-.5);
        double wake = smooth(.08+stagger*.46+jitter,.29+stagger*.48+jitter,life);
        return wake * (.83+.17*Math.sin(index*2.71+seed*.001+life*9));
    }
    /** Higher clouds feel a different wind direction and a stronger velocity. */
    public static double[] altitudeWind(double baseX,double baseZ,double height,long seed,double days) {
        double altitude=clamp((height-100)/390,0,1);
        double angle=Math.atan2(baseZ,baseX)+altitude*(.38+.17*Math.sin(seed*.001+days*.21));
        double speed=1+altitude*.66;
        return new double[]{Math.cos(angle)*speed,Math.sin(angle)*speed};
    }
    public static String stage(double phase) {
        phase=phase-Math.floor(phase);
        if(phase<.04) return "Entstehung";
        if(phase<.32) return "Wachstum";
        if(phase<.65) return "Reife";
        if(phase<.94) return "Auflösung";
        return "Zerfall";
    }
    public static double rainCurtain(double storm,double cloud,double humidity) {
        return smooth(.20,.82,storm)*smooth(.30,.75,cloud)*smooth(.38,.78,humidity);
    }
    public static double virga(double storm,double cloud,double humidity) {
        return smooth(.15,.61,storm)*smooth(.35,.80,cloud)*(1-smooth(.42,.70,humidity));
    }
    public static double flashPulse(long age) {
        return switch((int)age) { case 0 -> 1.0; case 1 -> .23; case 2 -> .78;
            case 3 -> .12; case 4 -> .52; case 5 -> .18; default -> 0.0; };
    }
}
