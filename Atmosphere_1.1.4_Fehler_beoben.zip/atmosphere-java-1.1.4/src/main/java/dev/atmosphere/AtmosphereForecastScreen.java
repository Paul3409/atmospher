package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.Locale;

/** 14 simulated days, sampled from the exact same deterministic weather field as gameplay. */
public final class AtmosphereForecastScreen extends Screen {
    private final AtmosphereSettings settings;
    private int page = 0;

    public AtmosphereForecastScreen(AtmosphereSettings settings) {
        super(Text.literal("Atmosphere – 14-Tage-Trend"));
        this.settings = settings;
    }
    @Override protected void init() {
        int y = height / 2 + 102;
        addDrawableChild(ButtonWidget.builder(Text.literal("◀ 7 Tage"), b -> { page = 0; })
                .dimensions(width / 2 - 154, y, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("7 Tage ▶"), b -> { page = 1; })
                .dimensions(width / 2 - 50, y, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Zurück"), b -> close())
                .dimensions(width / 2 + 54, y, 100, 20).build());
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;
        double x = client.player.getX(), z = client.player.getZ();
        long now = client.world.getTimeOfDay();
        long dayStart = Math.floorDiv(now, 24000L) * 24000L;
        int startY = height / 2 - 104;
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, startY - 24, 0xDBECF7);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Tag  |   Minimum    Maximum    Max. Niederschlag    Wetter"),
                width / 2, startY - 7, 0xA7C8D7);
        for (int row = 0; row < 7; row++) {
            int offset = row + page * 7;
            double min = Double.POSITIVE_INFINITY;
            double max = Double.NEGATIVE_INFINITY;
            double peak = 0;
            for (int step = 0; step < 6; step++) {
                long sampleTime = dayStart + offset * 24000L + step * 4000L;
                var sample = WeatherModel.sample(client.world, x, client.player.getY(), z, sampleTime, settings);
                min = Math.min(min, sample.t2());
                max = Math.max(max, sample.t2());
                peak = Math.max(peak, sample.rainMmH());
            }
            var afternoon = WeatherModel.sample(client.world, x, client.player.getY(), z, dayStart + offset * 24000L + 6000, settings);
            String line = String.format(Locale.GERMANY, "%02d    |    %5.1f °C       %5.1f °C         %5.1f mm/h       %s",
                    offset + 1, min, max, peak, afternoon.phase());
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(line), width / 2,
                    startY + 18 + row * 21, row % 2 == 0 ? 0xF0F5FA : 0xBFCFDE);
        }
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Simulations-Trend – keine echte Wettervorhersage, keine Fehlerwahrscheinlichkeit"),
                width / 2, startY + 177, 0x93A8B9);
    }
    @Override public void close() {
        MinecraftClient.getInstance().setScreen(new AtmosphereMenu(settings));
    }
}
