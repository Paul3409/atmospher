package dev.atmosphere;

import java.util.ArrayList;
import java.util.List;

/**
 * Atmosphere 1.1.1: deterministic, continuous GAME-SCALE synoptic fields.
 * This is not a numerical forecast: a sparsely populated track catalogue supplies
 * developing highs and lows; long-wave background pressure/geopotential and an
 * independent wavy upper-air jet prevent the old moving checkerboard pattern.
 * Radar contours, fronts, clouds and precipitation all sample these same fields.
 */
public final class SynopticSystems {
    private SynopticSystems() {}
    public record Field(double pressure,double height500,double vx,double vz,
            double frontalLift,double moisture,double cyclone,double anticyclone,
            double shear,double lowX,double lowZ,double cold,double warm,double occluded,
            double postFront,double inversion) {
        public double speed(){return Math.hypot(vx,vz);}
    }
    public record SystemInfo(boolean low,double x,double z,double corePressure,double strength,double age,long id) {}
    public record FrontPoint(double x,double z) {}
    private static final double TAU=2*Math.PI;
    private static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    private static double hash(int x,int z,int salt){return WeatherCells.hash(x,z,salt);}

    /** Smoothly flowing jet axis with meanders, jet streaks and meridional motion. */
    public static double[] jetstream(double x,double z,double days) {
        double longitude=x/2850.0-days*.16;
        double axis=980*Math.sin(longitude*.76+.4*Math.sin(days*.085))
                + 365*Math.sin(longitude*1.81+days*.091);
        // Jet bands repeat only over planetary distances, not on a 3 km grid.
        double distance=(z-axis)/5500.0;
        double band=Math.exp(-Math.pow(Math.sin(distance*Math.PI),2)/.105);
        double streak=.75+.25*Math.sin(longitude*1.4-days*.23+1.3);
        double intensity=20+132*band*streak;
        double slope=(980*.76/2850*Math.cos(longitude*.76+.4*Math.sin(days*.085))
                +365*1.81/2850*Math.cos(longitude*1.81+days*.091));
        double scale=1/Math.sqrt(1+slope*slope);
        return new double[]{intensity*scale,intensity*slope*scale};
    }

    /** Sparse, asynchronously born tracks. IDs remain stable while each low matures. */
    public static List<SystemInfo> systems(double x,double z,double days,int range) {
        ArrayList<SystemInfo> out=new ArrayList<>();
        final double tile=4300, period=6.5;
        int gx=(int)Math.floor(x/tile),gz=(int)Math.floor(z/tile);
        int r=Math.max(1,(int)Math.ceil((range+2500.0)/tile));
        int epoch=(int)Math.floor(days/period);
        AtmosphereSettings tuning=AtmosphereSettings.get();
        int history=tuning.pressureLifetime==2?3:2;
        for(int ep=epoch-history;ep<=epoch;ep++) for(int j=-r;j<=r;j++) for(int i=-r;i<=r;i++) {
            int ix=gx+i,iz=gz+j;
            double occur=hash(ix+ep*97,iz-ep*53,914);
            if(occur>.59)continue; // empty areas, no one-to-one high/low tiling
            double born=ep*period-1.1+2.9*hash(ix,iz,ep*37+917);
            boolean fastRunner=hash(ix,iz,ep*37+927)<.035
                    && Math.hypot(jetstream(ix*tile,iz*tile,ep*period)[0],
                                  jetstream(ix*tile,iz*tile,ep*period)[1])>62;
            double life=fastRunner?(.95+1.0*hash(ix,iz,ep*37+928)):
                    (2.1+5.7*hash(ix,iz,ep*37+918));
            life *= WeatherTuning.lifetime(tuning.pressureLifetime);
            double age=(days-born)/life;
            if(age<=0||age>=1)continue;
            double maturity=Math.pow(Math.sin(age*Math.PI),.73);
            boolean low=hash(ix,iz,ep*37+919)<.54;
            double direction=.24*(hash(ix,iz,ep*37+920)-.5);
            double travel=(fastRunner?590:165)+400*hash(ix,iz,ep*37+921);
            double pathDays=days-born;
            double sx=(ix+.12+.76*hash(ix,iz,ep*37+922))*tile
                    +travel*pathDays + 160*Math.sin(pathDays*.54+direction*9);
            double sz=(iz+.12+.76*hash(ix,iz,ep*37+923))*tile
                    +travel*direction*pathDays+280*Math.sin(pathDays*.36+ix*.8+ep);
            if(Math.abs(sx-x)>range+2250||Math.abs(sz-z)>range+2250)continue;
            double pressure=low ? 1007-(12+(fastRunner?38:30)*hash(ix,iz,ep*37+924))*maturity
                                  :1019+(12+23*hash(ix,iz,ep*37+925))*maturity;
            long id=(((long)ix&0x1fffffL)<<42)^(((long)iz&0x1fffffL)<<21)^(ep&0x1fffffL);
            out.add(new SystemInfo(low,sx,sz,pressure,maturity,age,id));
        }
        for(ManualPressureSystems.Centre c:ManualPressureSystems.centres()) {
            double elapsed=Math.max(0,days-c.started()/24000.0*AtmosphereSettings.get().weatherSpeed);
            double sx=c.x()+elapsed*195,sz=c.z()+90*Math.sin(elapsed*.24+c.id()%17);
            if(Math.abs(sx-x)<range+2250&&Math.abs(sz-z)<range+2250)
                out.add(new SystemInfo(c.low(),sx,sz,c.coreHpa(),1,.42,c.id()));
        }
        return out;
    }
    /** Exactly ONE curved arc of each kind, with an occlusion replacing the inner section. */
    public static FrontPoint frontPoint(SystemInfo s,int kind,double t) {
        double ang=kind==0?2.16:kind==1?.30:-.52;
        double bend=.23*Math.sin(t*2.2+s.id()*.000013)+.32*t*t;
        double length=(kind==0?1280:kind==1?1450:640)*t;
        return new FrontPoint(s.x()+Math.cos(ang+bend)*length,
                s.z()+Math.sin(ang+bend)*length);
    }
    private static double distance(double x,double z,FrontPoint a,FrontPoint b) {
        double dx=b.x()-a.x(),dz=b.z()-a.z();
        double t=clamp(((x-a.x())*dx+(z-a.z())*dz)/Math.max(1,dx*dx+dz*dz),0,1);
        return Math.hypot(x-a.x()-dx*t,z-a.z()-dz*t);
    }
    private static double frontDistance(SystemInfo s,int k,double x,double z) {
        double d=Double.POSITIVE_INFINITY;
        FrontPoint a=frontPoint(s,k,0);
        for(int i=1;i<=7;i++) {FrontPoint b=frontPoint(s,k,i/7.0);d=Math.min(d,distance(x,z,a,b));a=b;}
        return d;
    }
    public static Field sample(double x,double z,double days) {
        // Smooth long waves superimposed on pressure anomalies, never rendered as separate circles.
        double phase=x/4300.0-days*.11;
        double p=1015.0+3.8*Math.sin(phase+.42*Math.sin(z/5100.0))
                +2.6*Math.cos(z/3900.0+phase*.53);
        double h=560+14*Math.sin(phase*.79+z/5100.0)+8*Math.cos(z/3400.0-days*.14);
        double[] jet=jetstream(x,z,days);
        double vx=9+jet[0]*.17,vz=jet[1]*.17;
        double front=0,humid=0,cyclone=0,high=0,shear=0,cold=0,warm=0,occ=0,post=0,inv=0;
        double nearest=0,bx=x,bz=z;
        for(SystemInfo sys:systems(x,z,days,2350)) {
            double dx=x-sys.x(),dz=z-sys.z(),d=Math.hypot(dx,dz);
            if(d>2750)continue;
            double radius=sys.low()?990:1240;
            double influence=Math.exp(-.5*(d/radius)*(d/radius))*sys.strength();
            // Independent pressure-system intensity, not a random rain multiplier.
            // The field is shared by radar, clouds, wind and local precipitation.
            double power=WeatherTuning.pressureStrength(sys.low()
                    ? AtmosphereSettings.get().lowPressureStrength
                    : AtmosphereSettings.get().highPressureStrength);
            if (power <= 0) continue;
            double anomaly=sys.corePressure()-(sys.low()?1007:1019);
            // Wide, coherent pressure perturbations; system central pressure is approximate
            // because neighbouring systems and planetary waves also contribute.
            p+=((sys.low()?-10:10)+anomaly)*influence*power;
            h+=((sys.low()?-12:13)+anomaly*.70)*influence*power;
            double swirl=(sys.low()?1:-.55)*(12+44*influence)*power
                    *Math.exp(-(d/1550)*(d/1550))/Math.max(210,d);
            vx+=-dz*swirl;vz+=dx*swirl;
            double effective=clamp(influence*power,0,1);
            if(sys.low()) {
                cyclone=Math.max(cyclone,effective);
                if(effective>nearest){nearest=effective;bx=sys.x();bz=sys.z();}
                if(d>1650)continue;
                double maturity=clamp((sys.age()-.35)/.42,0,1);
                double cd=frontDistance(sys,0,x,z),wd=frontDistance(sys,1,x,z),od=frontDistance(sys,2,x,z);
                double inner=clamp((d-140)/330,0,1);
                double ca=Math.exp(-Math.pow(cd/125,2))*(1-maturity*(1-inner));
                double wa=Math.exp(-Math.pow(wd/245,2))*(1-maturity*(1-inner));
                double oa=Math.exp(-Math.pow(od/175,2))*maturity;
                cold=Math.max(cold,ca*effective);
                warm=Math.max(warm,wa*effective);
                occ=Math.max(occ,oa*effective);
                front=Math.max(front,Math.max(ca,Math.max(wa*.70,oa*.9))*effective);
                double rear=clamp((-dx*.62-dz*.23)/780,0,1);
                post=Math.max(post,rear*Math.exp(-Math.pow((d-850)/980,2))*effective);
                humid=Math.max(humid,Math.max(effective*.43,front*.95));
                shear=Math.max(shear,effective*.28+front*.63);
            }else {high=Math.max(high,effective);inv=Math.max(inv,effective);}
        }
        double jetShear=clamp((Math.hypot(jet[0],jet[1])-60)/100,0,1);
        shear=Math.max(shear,jetShear*.33);
        return new Field(clamp(p,947,1052),clamp(h,490,612),vx,vz,
            clamp(front,0,1),clamp(humid,0,1),clamp(cyclone,0,1),clamp(high,0,1),
            clamp(shear,0,1),bx,bz,clamp(cold,0,1),clamp(warm,0,1),
            clamp(occ,0,1),clamp(post,0,1),clamp(inv,0,1));
    }
    public static double[] upperWind(double x,double z,double days,double altitude) {
        Field f=sample(x,z,days);
        double a=clamp(altitude,0,1);
        double[] jet=jetstream(x,z,days);
        return new double[]{f.vx()*(1-a)+jet[0]*a,f.vz()*(1-a)+jet[1]*a};
    }
    public static double radialVelocity(double rx,double rz,double x,double z,double vx,double vz) {
        double dx=x-rx,dz=z-rz,d=Math.hypot(dx,dz);
        return d<.000001?0:(vx*dx+vz*dz)/d;
    }
    public static double[] rotationalVelocity(double x,double z,WeatherCells.Cell cell) {
        if(cell==null||cell.type()<WeatherCells.SUPERCELL)return new double[]{0,0};
        double dx=x-cell.x(),dz=z-cell.z(),dist=Math.hypot(dx,dz),r=Math.max(55,cell.radius()*.52);
        double amount=cell.rotation()*55*Math.exp(-Math.pow((dist-r*.56)/r,2));
        double n=Math.max(18,dist);return new double[]{-dz/n*amount,dx/n*amount};
    }
    public static int pressureContour(double p){return (int)Math.floor(p/4.0);}
}
