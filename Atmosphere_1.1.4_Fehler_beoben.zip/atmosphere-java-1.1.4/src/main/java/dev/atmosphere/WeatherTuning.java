package dev.atmosphere;

/** Side-effect-free control curves. Defaults retain 1.1.3 synoptic strength. */
public final class WeatherTuning {
    private WeatherTuning() {}
    public static double pressureStrength(int percent) {
        return Math.max(0, Math.min(200, percent)) / 100.0;
    }
    public static double lifetime(int profile) {
        return switch (profile) { case 0 -> .70; case 2 -> 1.55; default -> 1.0; };
    }
    /** A barely perceptible breeze rises progressively into full wind; 0=muted. */
    public static double breezeGain(double windKmh, int baseVolume) {
        if (baseVolume <= 0 || windKmh < 1.5) return 0;
        double speed = Math.min(1, Math.max(0, (windKmh - 1.5) / 50.0));
        double gain = (.012 + .26 * Math.pow(speed, .85)) * Math.min(100, baseVolume) / 40.0;
        return Math.min(.55, gain);
    }
    public static double lightGain(int intensity) {
        return Math.max(.25, Math.min(2.0, intensity / 100.0));
    }
}
