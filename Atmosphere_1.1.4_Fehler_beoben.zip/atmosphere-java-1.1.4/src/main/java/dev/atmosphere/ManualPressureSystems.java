package dev.atmosphere;

import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;
import java.util.ArrayList;
import java.util.List;

/** World-persistent, user-placed synoptic centres; no entity/block side effects. */
public final class ManualPressureSystems extends PersistentState {
    public static final int MAX=8;
    public record Centre(boolean low,double x,double z,int coreHpa,long started,long id) { }
    private final List<Centre> stored=new ArrayList<>();
    private static volatile List<Centre> snapshot=List.of();
    private static volatile int revision=0;
    public static int revision(){return revision;}
    private static final Type<ManualPressureSystems> TYPE=new Type<>(ManualPressureSystems::new,
            ManualPressureSystems::fromNbt,DataFixTypes.SAVED_DATA_MAP_DATA);
    private ManualPressureSystems() {}
    public static ManualPressureSystems of(ServerWorld world){return world.getPersistentStateManager().getOrCreate(TYPE,"atmosphere_pressure_v091");}
    private static ManualPressureSystems fromNbt(NbtCompound data, RegistryWrapper.WrapperLookup registry){
        ManualPressureSystems state=new ManualPressureSystems();
        if(data.contains("Systems",NbtElement.LIST_TYPE)){
            NbtList list=data.getList("Systems",NbtElement.COMPOUND_TYPE);
            for(int i=0;i<list.size() && state.stored.size()<MAX;i++){
                NbtCompound c=list.getCompound(i);
                double x=c.getDouble("X"),z=c.getDouble("Z");int p=c.getInt("Pressure");
                boolean low=c.getBoolean("Low");
                if(Double.isFinite(x)&&Double.isFinite(z)&&p>=950&&p<=1050)
                    state.stored.add(new Centre(low,x,z,p,c.getLong("Started"),c.getLong("Id")));
            }
        }
        return state;
    }
    @Override public NbtCompound writeNbt(NbtCompound out,RegistryWrapper.WrapperLookup registry){
        NbtList list=new NbtList();
        for(Centre c:stored){NbtCompound n=new NbtCompound();n.putBoolean("Low",c.low());
            n.putDouble("X",c.x());n.putDouble("Z",c.z());n.putInt("Pressure",c.coreHpa());
            n.putLong("Started",c.started());n.putLong("Id",c.id());list.add(n);}
        out.put("Systems",list);return out;
    }
    public static List<Centre> centres(){return snapshot;}
    public static void sync(ServerWorld world){
        List<Centre> next=List.copyOf(of(world).stored);
        if(!next.equals(snapshot)){snapshot=next;revision++;}
    }
    public static void reset(){snapshot=List.of();revision++;}
    public static void spawn(MinecraftServer server,boolean low,int coreHpa,double x,double z){
        if(server==null)return;
        server.execute(()->{ServerWorld world=server.getOverworld();if(world==null)return;
            ManualPressureSystems state=of(world);
            if(state.stored.size()>=MAX)state.stored.remove(0);
            int p=low?Math.max(950,Math.min(1012,coreHpa)):Math.max(1018,Math.min(1050,coreHpa));
            long id=world.getTime() ^ Double.doubleToLongBits(x);
            state.stored.add(new Centre(low,x,z,p,world.getTimeOfDay(),id));
            state.markDirty();snapshot=List.copyOf(state.stored);revision++;
        });
    }
    public static void clear(MinecraftServer server){if(server==null)return;
        server.execute(()->{ServerWorld world=server.getOverworld();if(world==null)return;
            ManualPressureSystems state=of(world);state.stored.clear();state.markDirty();snapshot=List.of();revision++;
        });
    }
}
