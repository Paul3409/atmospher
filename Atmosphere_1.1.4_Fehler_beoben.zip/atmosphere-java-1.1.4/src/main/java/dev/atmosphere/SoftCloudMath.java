package dev.atmosphere;

/** Pure, camera-stable shape, lighting and visibility math for soft cloud shells. */
public final class SoftCloudMath {
    private SoftCloudMath() { }

    /** Normalized displacement: continuous even at the polar seam; deterministic per cell. */
    public static double billow(double polar, double azimuth, double seed) {
        double waist = Math.pow(Math.max(0, Math.sin(polar)), .55);
        double large = Math.sin(azimuth * 3 + polar * 2.3 + seed);
        double medium = Math.sin(azimuth * 7 - polar * 4.6 + seed * 1.6);
        double small = Math.sin(azimuth * 13 + polar * 9 + seed * 2.3);
        double fine = Math.sin(azimuth * 19 - polar * 15 + seed * 3.1);
        return 1 + waist * (.095 * large + .046 * medium + .017 * small + .008 * fine);
    }

    /** Suppresses hard polygon silhouettes without erasing the visible middle of a cloud. */
    public static double rim(double normalX, double normalY, double normalZ,
                             double pointX, double pointY, double pointZ) {
        double length = Math.sqrt(pointX * pointX + pointY * pointY + pointZ * pointZ);
        if(length < .00001) return 1;
        double facing = Math.abs((normalX * pointX + normalY * pointY + normalZ * pointZ) / length);
        return .34 + .66 * Math.sqrt(Math.max(0, Math.min(1, facing)));
    }

    public static double sunlight(double dayPhase, boolean enabled) {
        if(!enabled) return 0;
        double sunrise=Math.exp(-Math.pow(dayPhase/.075,2));
        double sunset=Math.exp(-Math.pow((dayPhase-.5)/.075,2));
        return Math.min(1,Math.max(sunrise,sunset));
    }

    /** FPS sensitive scaling never exceeds the selected graphics preset's particle budget. */
    public static double particleScale(int fps, boolean adaptive) {
        if (!adaptive || fps <= 0) return 1;
        if(fps < 22) return .34;
        if(fps < 32) return .52;
        if(fps < 45) return .76;
        return 1;
    }

    public static double experienceScale(int mode) {
        return switch(Math.max(0,Math.min(4,mode))) {
            case 0 -> .65; case 1 -> .82; case 3 -> 1.12; case 4 -> 1.25;
            default -> 1;
        };
    }
}
