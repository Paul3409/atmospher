package dev.atmosphere;

/** Unit-testable rate curves for snowfall and melt in the 1.0 snow engine.
 * Higher intensities must never reduce deposition, and temperatures above
 * freezing must never reduce thaw probability. */
public final class SnowRates {
    private SnowRates() {}
    public static double depositChance(double mmPerHour,int growth) {
        double intensity=Math.min(1.0,Math.max(0,mmPerHour)/32.0);
        return Math.min(.99,(.16+.78*Math.sqrt(intensity))*(.52+.13*growth));
    }
    public static double growChance(double mmPerHour,int growth) {
        return Math.min(.94,(.12+Math.max(0,mmPerHour)/73.0)*(.50+growth*.14));
    }
    public static double meltChance(double celsius,int melt) {
        if(celsius<=.2)return 0;
        return Math.min(.97,(.10+Math.max(0,celsius-.2)*.105)*(.46+melt*.17));
    }
}
