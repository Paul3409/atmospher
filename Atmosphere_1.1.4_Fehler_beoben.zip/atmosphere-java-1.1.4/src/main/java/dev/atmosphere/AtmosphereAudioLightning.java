package dev.atmosphere;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;

/** Singleplayer client-only acoustic weather and non-destructive optical lightning.
 * No lightning entities, fire, explosions, block changes, damage or server events.
 */
public final class AtmosphereAudioLightning {
    private static final Identifier WHITE = Identifier.of("atmosphere", "textures/environment/lightning.png");
    private static final Random RANDOM = new Random();
    private static final Deque<DelayedThunder> QUEUE = new ArrayDeque<>();
    public record Strike(double x,double z,long time,boolean ground) { }
    private static final Deque<Strike> STRIKES = new ArrayDeque<>();
    public static List<Strike> recentStrikes(long currentTime) {
        List<Strike> result=new ArrayList<>();
        for(Strike strike:STRIKES)
            if(currentTime-strike.time()>=0 && currentTime-strike.time()<2400) result.add(strike);
        return result;
    }
    private static Bolt current;
    private static long lastWorldTick = Long.MIN_VALUE;
    private static int ambienceTimer = 0;
    private static int windTimer = 0;
    private static float rainFade=0, windFade=0;
    private AtmosphereAudioLightning() {}

    private record DelayedThunder(long time, double distance, boolean ground, boolean echo) {}
    private record Bolt(long born, double x, double z, double bottom, double top,
                        double drift, boolean ground, boolean anvil, long shape) {}

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(AtmosphereAudioLightning::tick);
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (current == null || client.world == null || !AtmosphereSettings.get().visualLightning
                    || ctx.consumers() == null || ctx.matrixStack() == null) return;
            long age = client.world.getTime() - current.born;
            if (age < 0 || age > 6) return;
            VertexConsumer v = ctx.consumers().getBuffer(RenderLayer.getEntityTranslucent(WHITE));
            MatrixStack matrices = ctx.matrixStack();
            Vec3d cam = ctx.camera().getPos();
            // Each lightning channel is several connected, irregular segments.
            double prevX = current.x;
            double prevZ = current.z;
            double startY = current.top;
            double lowY = current.bottom;
            int segments = 12;
            double boltScale=Math.max(.25,Math.min(2.0,AtmosphereSettings.get().lightningSize/100.0));
            double lightScale=WeatherTuning.lightGain(AtmosphereSettings.get().lightningBrightness);
            float alpha = (float)Math.min(1,StormEvolution.flashPulse(age)*lightScale);
            if(alpha<=0)return;
            for (int i = 1; i <= segments; i++) {
                double t = i / (double)segments;
                double nextY = current.anvil
                        ? startY + Math.sin(t*6.4+current.shape*.1)*6.0
                        : startY + (lowY - startY) * t;
                double nextX = current.x + (current.anvil ? 150*t : 0)
                        + Math.sin(t * 8.7 + current.shape) * (3 + 9 * t)*boltScale
                        + Math.sin(t * 22.0 + current.shape * .17) * 2.8*boltScale;
                double nextZ = current.z + (current.anvil ? 64*t : 0)
                        + Math.cos(t * 12.5 + current.shape) * (3 + 7 * t)*boltScale;
                double prevY=current.anvil
                        ? startY + Math.sin(((i-1)/(double)segments)*6.4+current.shape*.1)*6.0
                        : startY+(lowY-startY)*(i-1)/(double)segments;
                for (int plane = 0; plane < 2; plane++) {
                    double dx = plane == 0 ? 0.32*boltScale : 0;
                    double dz = plane == 0 ? 0 : 0.32*boltScale;
                    quad(v,matrices,cam,prevX-dx,prevY,prevZ-dz,
                            nextX-dx,nextY,nextZ-dz, nextX+dx,nextY,nextZ+dz,
                            prevX+dx,prevY,prevZ+dz,
                            (int)(alpha*230));
                }
                if (i == 4 || i == 8) {
                    double h = prevY;
                    double branchX=nextX+(i==4?15:-18)*boltScale, branchZ=nextZ+9*boltScale;
                    quad(v,matrices,cam,prevX-.17,h,prevZ,
                            branchX-.17,nextY+8,branchZ,
                            branchX+.17,nextY+8,branchZ,
                            prevX+.17,h,prevZ,(int)(alpha*142));
                }
                prevX = nextX; prevZ = nextZ;
            }
        });
    }

    private static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null || client.world.getRegistryKey() != World.OVERWORLD) {
            current = null; QUEUE.clear(); STRIKES.clear(); ambienceTimer = windTimer = 0; rainFade=windFade=0; lastWorldTick = Long.MIN_VALUE; StormEvents.reset(); ManualPressureSystems.reset(); AtmosphereRadarScreen.clearCache(); return;
        }
        long tick = client.world.getTime();
        if (tick == lastWorldTick || client.isPaused()) return;
        lastWorldTick = tick;
        AtmosphereSettings s = AtmosphereSettings.get();
        double px = client.player.getX(), pz = client.player.getZ();
        WeatherModel.Weather w = WeatherModel.sample(client.world, px, client.player.getY(), pz,
                client.world.getTimeOfDay(), s);
        // Original Alpha 0.8 audio clips are six seconds long. Playback at 104
        // ticks gives a gentle overlap, not the harsh repeated 3-second bleeps.
        boolean sheltered = !client.world.isSkyVisible(client.player.getBlockPos().up());
        // Dense low fog swallows high frequencies slightly; don't mute storm alerts.
        float fogMuffle=(float)(1-.28*Math.max(0,Math.min(1,w.fog())));
        // Gently ease ambience amplitude between changing weather intensities.
        float rainTarget=s.weatherSounds ? (float)Math.min(1,w.rainMmH()/22.0):0;
        float windTarget=s.weatherSounds ? (float)Math.min(1,Math.max(0,w.windKmh()-1.5)/16.0):0;
        rainFade+=(rainTarget-rainFade)*.055f;
        windFade+=(windTarget-windFade)*.045f;
        if (--ambienceTimer <= 0) {
            ambienceTimer = 104 + RANDOM.nextInt(12);
            if (s.weatherSounds && w.rainMmH() > .7) {
                SoundEvent sound = switch (w.precipitationKind()) {
                    case 1 -> w.windKmh()>55 ? AtmosphereMod.BLIZZARD : w.windKmh()>25 ? AtmosphereMod.SNOW_GUST : AtmosphereMod.SNOW_LIGHT;
                    case 3 -> AtmosphereMod.GRAUPEL_SOUND;
                    case 4 -> w.rainMmH()>50 ? AtmosphereMod.HAIL_HEAVY :
                            w.rainMmH()>14 ? AtmosphereMod.HAIL_SOUND : AtmosphereMod.HAIL_LIGHT;
                    default -> sheltered ? AtmosphereMod.RAIN_ROOF :
                            w.rainMmH() > 110 ? AtmosphereMod.RAIN_EXTREME :
                            w.rainMmH() > 64 ? AtmosphereMod.HEAVY_RAIN_CLASSIC :
                            w.rainMmH() > 48 ? AtmosphereMod.RAIN_HEAVY :
                            w.rainMmH() > 14 ? AtmosphereMod.RAIN_MEDIUM :
                            w.rainMmH() < 2 ? AtmosphereMod.DRIZZLE : AtmosphereMod.RAIN_LIGHT;
                };
                float volume=(float)Math.min(.58,.09+Math.sqrt(w.rainMmH()/150.0)*.45);
                if (sheltered) volume *= .60f;
                client.player.playSound(sound,volume*rainFade*fogMuffle,1.0f);
            }
        }
        if (--windTimer <= 0) {
            windTimer=106+RANDOM.nextInt(20);
            if(s.weatherSounds && w.windKmh()>1.5 && s.windAmbientVolume>0) {
                SoundEvent wind=w.storm()>.72 && w.windKmh()>50 && RANDOM.nextInt(5)==0 ? AtmosphereMod.WIND_SWIRL :
                        w.front()>.65 ? AtmosphereMod.WIND_FRONT :
                        w.front()>.28 && w.rainMmH()<2 ? AtmosphereMod.STORM_APPROACH :
                        w.storm()>.80 && w.windKmh()>75 ? AtmosphereMod.WIND_DOWNBURST :
                        sheltered && w.windKmh()>20 ? AtmosphereMod.WIND_ROOF :
                        w.precipitationKind()==1 && w.windKmh()>32 ? AtmosphereMod.SNOW_WIND :
                        w.windKmh()>75 ? AtmosphereMod.WIND_STRONG :
                        w.windKmh()>48 ? AtmosphereMod.WIND_GUST :
                        w.windKmh()>30 ? AtmosphereMod.WIND_FOREST :
                        w.windKmh()>22 ? AtmosphereMod.WIND_BASE_CLASSIC :
                        w.windKmh()>10 ? AtmosphereMod.WIND_LIGHT : AtmosphereMod.WIND_SOUND;
                float volume=(float)WeatherTuning.breezeGain(w.windKmh(),s.windAmbientVolume);
                client.player.playSound(wind,volume*windFade*fogMuffle*(sheltered?.42f:1.0f),1.0f);
            }
        }
        while(!STRIKES.isEmpty() && tick-STRIKES.peekFirst().time()>2400)
            STRIKES.removeFirst();
        while (!QUEUE.isEmpty() && QUEUE.peekFirst().time <= tick) {
            DelayedThunder due = QUEUE.removeFirst();
            if (!s.weatherSounds) continue;
            float volume = (float)Math.max(.025, Math.min(.85, 1.0 - due.distance / 1550.0));
            if(due.echo())volume*=.29f;
            if(sheltered)volume*=.68f;
            volume=Math.min(1.0f,volume*fogMuffle*Math.max(0.0f,Math.min(2.0f,s.thunderVolume/100.0f)));
            if (volume < .001f) continue;
            SoundEvent chosen=due.echo()?(RANDOM.nextBoolean()?AtmosphereMod.THUNDER_RUMBLE:AtmosphereMod.THUNDER_ROLL):
                    due.distance < 170 ? (RANDOM.nextInt(3)==0?AtmosphereMod.THUNDER_NEAR:
                            RANDOM.nextBoolean()?AtmosphereMod.THUNDER_CRACK:AtmosphereMod.THUNDER_DEEP) :
                    due.distance < 420 ? AtmosphereMod.THUNDER_MULTI :
                    due.distance < 700 ? AtmosphereMod.THUNDER_DISTANT : AtmosphereMod.THUNDER_FAR;
            client.player.playSound(chosen,volume,
                    (due.echo()?.79f:(due.ground()?.90f:1.0f))*(.94f+RANDOM.nextFloat()*.12f));
        }
        if (current != null && tick - current.born > 7) current = null;
        if (!s.visualLightning || current != null) return;
        // Nearby thunderstorm cells may flash even while the player is in sunshine.
        // Limit sampling to occasional attempts for integrated GPUs.
        double[] rates={.25,.62,1.35,2.6};
        if (RANDOM.nextDouble() > .045*rates[Math.max(0,Math.min(3,s.lightningFrequency))]) return;
        // Find a nearby active weather cell so lightning happens in a rain-bearing cloud.
        double angle = RANDOM.nextDouble() * Math.PI * 2;
        double distance = 70 + RANDOM.nextDouble() * 1180;
        double x = px + Math.cos(angle)*distance, z = pz + Math.sin(angle)*distance;
        WeatherModel.Weather at = WeatherModel.sample(x,z,client.world.getTimeOfDay(),s);
        if (at.storm() < .38 || at.rainMmH() < 4) return;
        // More intense convective cells flash more often than light showers.
        if(RANDOM.nextDouble() > Math.min(1,.21+at.storm()*.85))return;
        boolean ground = RANDOM.nextDouble() < .12;
        boolean anvil = !ground && RANDOM.nextDouble()<.42;
        double top = Math.max(170, at.cloudBase() + 65 + RANDOM.nextInt(160));
        double bottom = ground ? 67 : Math.max(103,at.cloudBase() + 8);
        if (ground) {
            var pos = net.minecraft.util.math.BlockPos.ofFloored(x, client.player.getY(), z);
            if (client.world.isChunkLoaded(pos))
                bottom = client.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, (int)x,(int)z);
            // If the distant chunk isn't loaded, keep a non-ground-reaching strike.
            else bottom = at.cloudBase() + 8;
        }
        current = new Bolt(tick,x,z,bottom,top,0,ground,anvil,RANDOM.nextLong());
        STRIKES.addLast(new Strike(x,z,tick,ground));
        // Distant lightning sometimes has no clearly audible thunder.
        if(distance<950 || RANDOM.nextDouble()<.35) {
            long arrival=tick+Math.max(1,Math.round(distance/17.0));
            QUEUE.addLast(new DelayedThunder(arrival,distance,ground,false));
            if(distance<730 && RANDOM.nextDouble()<.72)
                QUEUE.addLast(new DelayedThunder(arrival+24+RANDOM.nextInt(19),distance,ground,true));
        }
    }

    /** For a brief internal cloud illumination at the lightning location. */
    public static double flashNear(double x, double z, long ignoredWorldTime) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (current == null || client.world == null) return 0;
        long age = client.world.getTime() - current.born;
        if (age < 0 || age > 5) return 0;
        double radius = Math.hypot(current.x-x,current.z-z);
        return Math.min(1,Math.max(0, 1-radius/370) * StormEvolution.flashPulse(age)
                * WeatherTuning.lightGain(AtmosphereSettings.get().lightningBrightness));
    }

    private static void quad(VertexConsumer v, MatrixStack m, Vec3d cam,
                             double ax,double ay,double az, double bx,double by,double bz,
                             double cx,double cy,double cz, double dx,double dy,double dz,int alpha) {
        vertex(v,m,cam,ax,ay,az,0,0,alpha);
        vertex(v,m,cam,bx,by,bz,0,1,alpha);
        vertex(v,m,cam,cx,cy,cz,1,1,alpha);
        vertex(v,m,cam,dx,dy,dz,1,0,alpha);
    }
    private static void vertex(VertexConsumer v, MatrixStack m, Vec3d cam,
                               double x,double y,double z,float u,float t,int a) {
        v.vertex(m.peek().getPositionMatrix(),(float)(x-cam.x),(float)(y-cam.y),(float)(z-cam.z))
                .color(226,239,255,a).texture(u,t).overlay(OverlayTexture.DEFAULT_UV)
                .light(0xF000F0).normal(0,1,0);
    }
}
