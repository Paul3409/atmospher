package dev.atmosphere;

import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.color.block.BlockColorProvider;
import net.minecraft.client.MinecraftClient;

/** Seasonal tints keep underlying biome colours as a starting point. */
public final class SeasonalColors {
    private SeasonalColors() {}

    public static void register() {
        registerGrass(Blocks.GRASS_BLOCK, Blocks.SHORT_GRASS, Blocks.TALL_GRASS, Blocks.FERN,
                Blocks.LARGE_FERN, Blocks.POTTED_FERN);
        // Spruce and mangrove are evergreen and deliberately do not turn golden.
        registerLeaves(Blocks.OAK_LEAVES, Blocks.BIRCH_LEAVES, Blocks.DARK_OAK_LEAVES,
                Blocks.JUNGLE_LEAVES, Blocks.ACACIA_LEAVES);
    }

    private static void registerGrass(Block... blocks) { register(false, blocks); }
    private static void registerLeaves(Block... blocks) { register(true, blocks); }

    private static void register(boolean leaves, Block... blocks) {
        for (Block block : blocks) {
            BlockColorProvider original = ColorProviderRegistry.BLOCK.get(block);
            if (original == null) continue; // never paint a formerly untinted model
            ColorProviderRegistry.BLOCK.register((state, view, pos, tintIndex) -> {
                int base = original.getColor(state, view, pos, tintIndex);
                if (base == -1 || !AtmosphereSettings.get().seasonalColors) return base;
                MinecraftClient client = MinecraftClient.getInstance();
                if (client == null || client.world == null) return base;
                int season = WeatherModel.sample(0, 0, client.world.getTimeOfDay(),
                        AtmosphereSettings.get()).season();
                return switch (season) {
                    case 0 -> mix(base, leaves ? 0x70B85A : 0x77D16B, .17);
                    case 1 -> mix(base, leaves ? 0x458C36 : 0x75A840, .11);
                    case 2 -> mix(base, leaves ? 0xD68B36 : 0xB5A16A, leaves ? .78 : .37);
                    default -> mix(base, leaves ? 0x84734B : 0xB4B0A3, leaves ? .49 : .55);
                };
            }, block);
        }
    }

    private static int mix(int a, int b, double ratio) {
        int r = channel(a >> 16, b >> 16, ratio);
        int g = channel(a >> 8, b >> 8, ratio);
        int bl = channel(a, b, ratio);
        return (r << 16) | (g << 8) | bl;
    }
    private static int channel(int a, int b, double k) {
        return (int) Math.max(0, Math.min(255, (a & 255) * (1 - k) + (b & 255) * k));
    }
}
