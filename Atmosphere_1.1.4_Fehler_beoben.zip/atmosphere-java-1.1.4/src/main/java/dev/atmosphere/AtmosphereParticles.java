package dev.atmosphere;

import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.particle.ParticleTypes;

/** Distinct textures, fall velocities and sizes for rain, snow, graupel and hail. */
public final class AtmosphereParticles {
    private AtmosphereParticles() {}

    public static void register() {
        ParticleFactoryRegistry.getInstance().register(AtmosphereMod.RAIN_STREAK, provider -> new Factory(provider, 0));
        ParticleFactoryRegistry.getInstance().register(AtmosphereMod.SNOW_FLAKE, provider -> new Factory(provider, 1));
        ParticleFactoryRegistry.getInstance().register(AtmosphereMod.GRAUPEL, provider -> new Factory(provider, 2));
        ParticleFactoryRegistry.getInstance().register(AtmosphereMod.HAIL, provider -> new Factory(provider, 3));
    }

    private static final class WeatherParticle extends SpriteBillboardParticle {
        private final int kind;
        private final double flutterPhase;
        private int bounces = 0;
        WeatherParticle(ClientWorld world, double x, double y, double z,
                        double dx, double dy, double dz, SpriteProvider sprites, int kind) {
            super(world, x, y, z, dx, dy, dz);
            this.kind = kind;
            this.setSprite(sprites);
            this.maxAge = switch (kind) { case 0 -> 30; case 1 -> 115; case 2 -> 46; default -> 35; };
            // Each precipitation category spans a range of independently sized particles.
            float size = world.random.nextFloat();
            this.scale = switch (kind) {
                case 0 -> .14f + size * .25f;
                case 1 -> .18f + size * .35f;
                case 2 -> .12f + size * .17f;
                default -> .16f + size * .30f;
            };
            this.gravityStrength = switch(kind) { case 0 -> 0.55f; case 1 -> 0.07f; case 2 -> 1.35f; default -> 1.85f; };
            this.velocityMultiplier = kind == 1 ? .985f : .998f;
            this.collidesWithWorld = true;
            this.setAlpha(kind == 0 ? .87f : 1f);
            if (kind == 0) this.setColor(.71f, .83f, 1f);
            else if (kind == 1) this.setColor(.96f, .97f, 1f);
            else if (kind == 2) this.setColor(.94f, .94f, .94f);
            else this.setColor(.88f, .92f, .95f);
            this.flutterPhase = world.random.nextDouble() * 6.283;
        }
        @Override public ParticleTextureSheet getType() {
            return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
        }
        @Override public void tick() {
            if (kind == 1) {
                this.velocityX += Math.sin(this.age * .18 + flutterPhase) * .004;
                this.velocityZ += Math.cos(this.age * .13 + flutterPhase) * .003;
            }
            // Graupel and hail must always move downward (no hovering). Cap
            // their terminal velocity to avoid crossing the ground in one frame.
            if (kind == 2 && this.velocityY <= 0 && bounces == 0)
                this.velocityY = Math.max(-.95, Math.min(this.velocityY, -.24));
            if (kind == 3 && this.velocityY <= 0 && bounces == 0)
                this.velocityY = Math.max(-1.50, Math.min(this.velocityY, -.48));
            super.tick();
            if (this.onGround) {
                if ((kind == 2 || kind == 3) && bounces < (kind == 2 ? 2 : 1)) {
                    // Small elastic impacts, then friction. No blocks/entities are touched.
                    bounces++;
                    this.velocityY = kind == 2 ? (.09 / bounces) : .16;
                    this.velocityX *= .50; this.velocityZ *= .50;
                    this.onGround = false;
                } else {
                    if (kind == 0 && world.random.nextInt(12) == 0)
                        world.addParticle(ParticleTypes.SPLASH, x, y+.03, z, 0, .01, 0);
                    this.markDead();
                }
            }
        }
    }
    private static final class Factory implements ParticleFactory<SimpleParticleType> {
        private final SpriteProvider sprites;
        private final int kind;
        Factory(SpriteProvider sprites, int kind) { this.sprites = sprites; this.kind = kind; }
        @Override public Particle createParticle(SimpleParticleType params, ClientWorld world, double x, double y,
                                                  double z, double dx, double dy, double dz) {
            return new WeatherParticle(world, x, y, z, dx, dy, dz, sprites, kind);
        }
    }
}
