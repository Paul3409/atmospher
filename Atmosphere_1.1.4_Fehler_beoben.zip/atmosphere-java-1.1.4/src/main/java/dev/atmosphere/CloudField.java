package dev.atmosphere;

/**
 * View-independent advection and continuous coverage for the lower cloud deck.
 * All methods are pure and stable with respect to camera movement and render FPS.
 */
public final class CloudField {
    public static final double SPACING = 176.0;
    private CloudField() { }

    public static double driftX(double days) {
        return days * 140.0 + 36.0 * Math.sin(days * .32);
    }
    public static double driftZ(double days) {
        return days * 92.0 + 28.0 * Math.sin(days * .25 + .7);
    }
    public static double centerX(int gx, int gz, double days) {
        return (gx + .20 + .58 * WeatherCells.hash(gx,gz,7)) * SPACING + driftX(days);
    }
    public static double centerZ(int gx, int gz, double days) {
        return (gz + .20 + .58 * WeatherCells.hash(gx,gz,11)) * SPACING + driftZ(days);
    }
    public static double coverage(int gx, int gz, double cloudiness) {
        // Fractional fade prevents sudden switching on cell/wind/weather boundaries.
        double threshold = WeatherCells.hash(gx,gz,21);
        return WeatherCells.smooth(-.10,.12,cloudiness*.94-threshold);
    }
    public static double viewFade(double distance, double limit) {
        return 1.0 - WeatherCells.smooth(Math.max(0,limit-210),limit,distance);
    }

    /** Approximate the SAME cell bases as the geometry, for flying into clouds. */
    public static double immersion(double x,double y,double z,long time,AtmosphereSettings s) {
        if(y<95 || y>630) return 0;
        double days=time/24000.0*s.weatherSpeed;
        int gx=(int)Math.floor((x-driftX(days))/SPACING);
        int gz=(int)Math.floor((z-driftZ(days))/SPACING);
        double density=0;
        for(int dz=-2;dz<=2;dz++) for(int dx=-2;dx<=2;dx++) {
            int cx=gx+dx,cz=gz+dz;
            double px=centerX(cx,cz,days),pz=centerZ(cx,cz,days);
            if(Math.abs(px-x)>205 || Math.abs(pz-z)>205)continue;
            WeatherModel.Weather w=WeatherModel.sample(px,pz,time,s);
            double cover=coverage(cx,cz,w.cloudiness());
            if(cover<.025)continue;
            double development=WeatherCells.lifecycle(days/(.85+WeatherCells.hash(cx,cz,81)*1.45)
                    +WeatherCells.hash(cx,cz,83));
            double width=(84+44*WeatherCells.hash(cx,cz,31)+w.storm()*75)*(.50+development*.70);
            double depth=width*(.84+WeatherCells.hash(cx,cz,34)*.43);
            double base=Math.max(101,w.cloudBase()+(WeatherCells.hash(cx,cz,35)-.5)*25);
            double thick=10+12*development+8*w.storm();
            double nx=(x-px)/(width*.86),nz=(z-pz)/(depth*.88);
            double ny=(y-(base+thick))/(thick*1.65);
            double d=nx*nx+nz*nz+ny*ny;
            double inside=1-WeatherCells.smooth(.55,1.22,d);
            density=Math.max(density,cover*inside);
        }
        // Convective columns from the shared precipitation/radar storm field.
        WeatherCells.Field storm=WeatherCells.sample(x,z,days);
        if(storm.cloud()>.12) {
            WeatherModel.Weather w=WeatherModel.sample(x,z,time,s);
            double height=90+storm.development()*320;
            double low=Math.max(104,w.cloudBase());
            double vertical=WeatherCells.smooth(low-12,low+17,y)
                    *(1-WeatherCells.smooth(low+height*.8,low+height+28,y));
            density=Math.max(density,storm.cloud()*.82*vertical);
        }
        return WeatherCells.clamp(density,0,1);
    }
}
