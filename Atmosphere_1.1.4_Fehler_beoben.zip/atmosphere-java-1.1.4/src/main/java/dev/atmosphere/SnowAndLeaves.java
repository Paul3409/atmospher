package dev.atmosphere;

import net.minecraft.block.*;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Bounded, server-thread-only world edits in integrated singleplayer worlds. */
public final class SnowAndLeaves {
    private static final Random RANDOM = new Random();
    private SnowAndLeaves() {}

    public static void tick(ServerWorld world, AtmosphereSettings settings) {
        if (world.getTime() % 20 != 0 || world.getPlayers().isEmpty()) return;
        AtmosphereWorldState state = AtmosphereWorldState.of(world);
        // Constant work per second, independent of loaded chunk count.
        ServerPlayerEntity player = world.getPlayers().get(RANDOM.nextInt(world.getPlayers().size()));
        if (settings.snowAccumulation) {
            // Broad, player-centred coverage, but only edits already loaded chunks.
            // A stable bounded budget prevents costly all-at-once chunk scans.
            int growth = settings.snowGrowth;
            int placementBudget = 110 + growth * 90;
            for (int i = 0; i < placementBudget; i++) placeOrGrow(world, player, state, settings);
            growTracked(world, player, state, settings, 40 + growth * 33);
            meltTracked(world, player, state, settings, 55 + settings.snowMelt * 60);
        } else {
            // Disabling accumulation disables *new* changes, not existing snow.
        }
        // Leaf loss has its own explicit opt-in. Existing tracked removals always recover in spring.
        int season = WeatherModel.sample(world, player.getX(), player.getY(), player.getZ(), world.getTimeOfDay(), settings).season();
        // Strict no-damage policy: never remove natural or player leaves.
        // Restore any removals saved by older Atmosphere versions.
        restoreLeaves(world, state, 5);
    }

    private static void placeOrGrow(ServerWorld world, ServerPlayerEntity player, AtmosphereWorldState state,
                                    AtmosphereSettings settings) {
        int radius = settings.snowRadius;
        // Uniformly sample a disc, not a square: no sharp snowy corners.
        double angle = RANDOM.nextDouble() * Math.PI * 2;
        double distance = radius * Math.sqrt(RANDOM.nextDouble());
        int x = player.getBlockX() + (int)Math.round(Math.cos(angle) * distance);
        int z = player.getBlockZ() + (int)Math.round(Math.sin(angle) * distance);
        // Never trigger chunk generation for atmospheric decorations.
        BlockPos column = new BlockPos(x, player.getBlockY(), z);
        if (!world.isChunkLoaded(column)) return;
        // getTopY returns first available block *above* the surface.
        int surface = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
        int beneathLeaves = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        // Heavy long-lasting snowfall sometimes deposits snow under a canopy.
        if (surface - beneathLeaves > 3 && RANDOM.nextDouble() < .08) surface = beneathLeaves;
        if (surface < world.getBottomY() + 1 || surface >= world.getTopY()) return;
        BlockPos target = new BlockPos(x, surface, z);
        if (!world.isChunkLoaded(target)) return;
        // Heightmaps return the block *above* short plants and existing snow.
        BlockState highest = world.getBlockState(target.down());
        if (highest.isOf(Blocks.SNOW) || highest.isOf(Blocks.SHORT_GRASS) ||
                highest.isOf(Blocks.FERN)) {
            target = target.down();
        } else if (highest.isOf(Blocks.TALL_GRASS) || highest.isOf(Blocks.LARGE_FERN)) {
            // The upper half is at top-1, the lower half at top-2.
            target = target.down(2);
        }
        WeatherModel.Weather weather = WeatherModel.sample(world, x, target.getY(), z, world.getTimeOfDay(), settings);
        if (weather.rainMmH() < .1 || weather.t2() > 1.5
                || (weather.precipitationKind() != 1 && weather.precipitationKind() != 3)) return;
        // Convective snow cores deposit much faster than light flurries.
        double chance = SnowRates.depositChance(weather.rainMmH(),settings.snowGrowth);
        if (RANDOM.nextDouble() > chance) return;
        BlockState topState = world.getBlockState(target);
        BlockPos supportPos = target.down();
        BlockState support = world.getBlockState(supportPos);
        // Short plants may be displaced by snow. Flowers, crops, tall plant decorations remain untouched.
        if (topState.isOf(Blocks.SHORT_GRASS) || topState.isOf(Blocks.FERN)
                || topState.isOf(Blocks.TALL_GRASS) || topState.isOf(Blocks.LARGE_FERN)) {
            if (allowedSupport(world, supportPos, support)) {
                boolean isTall = topState.isOf(Blocks.TALL_GRASS) || topState.isOf(Blocks.LARGE_FERN);
                if (isTall) world.setBlockState(target.up(), Blocks.AIR.getDefaultState(), 3);
                world.setBlockState(target, Blocks.AIR.getDefaultState(), 3);
                topState = world.getBlockState(target);
            }
        }
        if (topState.isOf(Blocks.SNOW)) {
            if (!state.snow.contains(target.asLong())) return; // never grow naturally occurring snow
            int layers = topState.get(SnowBlock.LAYERS);
            if (layers < 8) world.setBlockState(target, topState.with(SnowBlock.LAYERS, layers + 1), 3);
            return;
        }
        if (!topState.isAir() || state.snow.size() >= AtmosphereWorldState.MAX_SNOW) return;
        if (!allowedSupport(world, supportPos, support)) return;
        if (!Blocks.SNOW.getDefaultState().canPlaceAt(world, target)) return;
        if (world.setBlockState(target, Blocks.SNOW.getDefaultState(), 3)) {
            state.snow.add(target.asLong());
            state.markDirty();
        }
    }

    /** Explicitly grow existing Atmosphere-owned snow, rather than relying on
     * randomly selecting the exact same x/z again from a 57-block radius. */
    private static void growTracked(ServerWorld world, ServerPlayerEntity player, AtmosphereWorldState state,
                                    AtmosphereSettings settings, int attempts) {
        if (state.snow.isEmpty()) return;
        List<Long> tracked = new ArrayList<>(state.snow);
        for (int i = 0; i < Math.min(attempts, tracked.size()); i++) {
            BlockPos pos = BlockPos.fromLong(tracked.get(RANDOM.nextInt(tracked.size())));
            if (pos.getSquaredDistance(player.getBlockPos()) > (double)settings.snowRadius * settings.snowRadius || !world.isChunkLoaded(pos)) continue;
            BlockState block = world.getBlockState(pos);
            if (!block.isOf(Blocks.SNOW)) { state.snow.remove(pos.asLong()); state.markDirty(); continue; }
            WeatherModel.Weather w = WeatherModel.sample(world, pos.getX(), pos.getY(), pos.getZ(), world.getTimeOfDay(), settings);
            if (w.t2() > .8 || (w.precipitationKind() != 1 && w.precipitationKind() != 3) || w.rainMmH() < 1) continue;
            double chance = SnowRates.growChance(w.rainMmH(),settings.snowGrowth);
            if (RANDOM.nextDouble() < chance && block.get(SnowBlock.LAYERS) < 8)
                world.setBlockState(pos, block.with(SnowBlock.LAYERS, block.get(SnowBlock.LAYERS) + 1), 3);
        }
    }

    private static boolean allowedSupport(ServerWorld world, BlockPos pos, BlockState state) {
        Block block = state.getBlock();
        if (state.isAir() || state.getFluidState().isEmpty() == false) return false;
        if (block instanceof StairsBlock || block instanceof SlabBlock || block instanceof FenceBlock ||
            block instanceof WallBlock || block instanceof PaneBlock || block instanceof DoorBlock ||
            block instanceof TrapdoorBlock || block instanceof SnowBlock) return false;
        // Leaf blocks can hold snow; an intact canopy naturally intercepts it.
        return Block.isFaceFullSquare(state.getCollisionShape(world, pos), Direction.UP);
    }

    private static void meltTracked(ServerWorld world, ServerPlayerEntity player, AtmosphereWorldState state,
                                    AtmosphereSettings settings, int maxChecks) {
        if (state.snow.isEmpty()) return;
        // Gradual thaw over all loaded nearby Atmosphere snow; no natural/player snow removed.
        List<Long> candidates = new ArrayList<>(state.snow);
        for (int i = 0; i < maxChecks && !candidates.isEmpty(); i++) {
            long key = candidates.remove(RANDOM.nextInt(candidates.size()));
            BlockPos pos = BlockPos.fromLong(key);
            if (pos.getSquaredDistance(player.getBlockPos()) > (double)settings.snowRadius * settings.snowRadius || !world.isChunkLoaded(pos)) continue;
            BlockState current = world.getBlockState(pos);
            if (!current.isOf(Blocks.SNOW)) {
                state.snow.remove(key);
                state.markDirty();
                continue;
            }
            double temp = WeatherModel.sample(world, pos.getX(), pos.getY(), pos.getZ(), world.getTimeOfDay(), settings).t2();
            // Even +1°C thaws layers slowly; mild +5°C thaws visibly faster.
            double thaw = SnowRates.meltChance(temp,settings.snowMelt);
            if (thaw == 0) continue;
            if (RANDOM.nextDouble() > thaw) continue;
            int layer = current.get(SnowBlock.LAYERS);
            world.setBlockState(pos, layer <= 1 ? Blocks.AIR.getDefaultState()
                    : current.with(SnowBlock.LAYERS, layer - 1), 3);
            if (layer <= 1) {
                state.snow.remove(key);
                state.markDirty();
            }
        }
    }

    private static void removeLeaves(ServerWorld world, ServerPlayerEntity player,
                                     AtmosphereWorldState state, int attempts) {
        if (state.removedLeaves.size() >= AtmosphereWorldState.MAX_LEAVES) return;
        for (int a = 0; a < attempts; a++) {
            int x = player.getBlockX() + RANDOM.nextInt(37) - 18;
            int z = player.getBlockZ() + RANDOM.nextInt(37) - 18;
            int top = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
            for (int y = top; y >= top - 4; y--) {
                BlockPos pos = new BlockPos(x, y, z);
                if (!world.isChunkLoaded(pos)) break;
                BlockState blockState = world.getBlockState(pos);
                if (!(blockState.getBlock() instanceof LeavesBlock)) continue;
                // Evergreen trees, cherry and decorative azalea leaves keep their canopy.
                if (!(blockState.isOf(Blocks.OAK_LEAVES) || blockState.isOf(Blocks.BIRCH_LEAVES)
                        || blockState.isOf(Blocks.DARK_OAK_LEAVES) || blockState.isOf(Blocks.JUNGLE_LEAVES)
                        || blockState.isOf(Blocks.ACACIA_LEAVES))) continue;
                // Only eligible naturally generated leaves. Persistent / player-placed leaves are protected.
                if (blockState.contains(Properties.PERSISTENT) && blockState.get(Properties.PERSISTENT)) break;
                String id = Registries.BLOCK.getId(blockState.getBlock()).toString();
                if (state.removedLeaves.containsKey(pos.asLong())) break;
                if (RANDOM.nextDouble() < .24 && world.setBlockState(pos, Blocks.AIR.getDefaultState(), 3)) {
                    state.removedLeaves.put(pos.asLong(), id);
                    state.markDirty();
                }
                break;
            }
        }
    }

    private static void restoreLeaves(ServerWorld world, AtmosphereWorldState state, int budget) {
        if (state.removedLeaves.isEmpty()) return;
        int restored = 0;
        var iterator = state.removedLeaves.entrySet().iterator();
        while (iterator.hasNext() && restored < budget) {
            Map.Entry<Long, String> entry = iterator.next();
            BlockPos pos = BlockPos.fromLong(entry.getKey());
            if (!world.isChunkLoaded(pos)) continue;
            // If a player rebuilt at this location, do not overwrite the new block.
            if (world.getBlockState(pos).isAir()) {
                Identifier id = Identifier.tryParse(entry.getValue());
                if (id != null && Registries.BLOCK.get(id) instanceof LeavesBlock leaf) {
                    world.setBlockState(pos, leaf.getDefaultState().with(LeavesBlock.PERSISTENT, false), 3);
                }
            }
            iterator.remove();
            state.markDirty();
            restored++;
        }
    }
}
