import dev.atmosphere.SynopticSystems;
import dev.atmosphere.WeatherCells;
import dev.atmosphere.StormEvolution;

public class WeatherRevolutionSmokeTest {
    static void check(boolean good,String reason) {if(!good)throw new AssertionError(reason);}
    public static void main(String[] args) {
        long checked=0;
        for(int x=-8400;x<=8400;x+=400)for(int z=-8400;z<=8400;z+=400)
            for(int step=0;step<4;step++) {
                double days=step*2.5;
                SynopticSystems.Field f=SynopticSystems.sample(x,z,days);
                check(Double.isFinite(f.pressure())&&f.pressure()>=947&&f.pressure()<=1052,"pressure");
                check(Double.isFinite(f.height500())&&f.height500()>=489&&f.height500()<=612,"upper height");
                check(Double.isFinite(f.speed())&&f.speed()<200,"wind speed");
                check(f.frontalLift()>=0&&f.frontalLift()<=1,"frontal lifting");
                check(f.moisture()>=0&&f.moisture()<=1,"moisture");
                SynopticSystems.Field same=SynopticSystems.sample(x,z,days);
                check(f.equals(same),"determinism");
                double[] wind=SynopticSystems.upperWind(x,z,days,.7);
                check(Double.isFinite(wind[0])&&Double.isFinite(wind[1]),"jet");
                WeatherCells.Field c=WeatherCells.sample(x,z,days);
                check(Double.isFinite(c.cloud())&&c.cloud()>=0,"cloud map");
                check(Double.isFinite(c.rain())&&c.rain()>=0,"precip core");
                checked++;
            }
        check(Math.abs(SynopticSystems.radialVelocity(0,0,100,0,75,0)-75)<1e-9,"outbound radial");
        check(Math.abs(SynopticSystems.radialVelocity(0,0,100,0,-30,0)+30)<1e-9,"inbound radial");
        check(Math.abs(SynopticSystems.radialVelocity(0,0,0,0,50,0))<1e-9,"zero range");
        for(int t=0;t<100;t++) {
            double v=StormEvolution.localTower(t/100.,t%8,8,3);
            check(Double.isFinite(v)&&v>=0,"cloud tower");
        }
        System.out.println("OK: "+checked+" synoptic/cell samples + Doppler and tower checks");
    }
}
