import dev.atmosphere.SnowRates;
public final class SnowRatesTest {
    public static void main(String[] args) {
        long checks=0;
        for(int setting=1;setting<=5;setting++) {
            double prev=0;
            for(int precipitation=0;precipitation<=150;precipitation++) {
                double c=SnowRates.depositChance(precipitation,setting);
                require(c>=prev-1e-9 && c>=0 && c<=1,"snow deposition monotone");prev=c;checks++;
            }
            prev=0;
            for(int temp=-20;temp<=40;temp++) {
                double c=SnowRates.meltChance(temp,setting);
                require(c>=prev-1e-9 && c>=0 && c<=1,"melt monotone");prev=c;checks++;
            }
        }
        require(SnowRates.depositChance(80,4)>SnowRates.depositChance(1,4),"storm snowfall faster");
        require(SnowRates.meltChance(8,4)>SnowRates.meltChance(1,4),"warm snow melts faster");
        System.out.println("SnowRates: "+checks+" checks OK");
    }
    private static void require(boolean okay,String description){if(!okay)throw new AssertionError(description);}
}
