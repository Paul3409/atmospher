package dev.atmosphere;
import java.util.List;
/** Standalone weather-model test stub only, NOT included in the main mod build. */
public final class ManualPressureSystems {
    public record Centre(boolean low,double x,double z,int coreHpa,long started,long id) {}
    public static List<Centre> centres(){return List.of();}
}
