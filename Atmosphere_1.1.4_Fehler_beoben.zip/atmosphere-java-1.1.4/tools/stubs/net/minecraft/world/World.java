package net.minecraft.world;
import net.minecraft.util.math.BlockPos;
public class World {
    public BiomeHolder getBiome(BlockPos pos){return new BiomeHolder();}
    public static class BiomeHolder {public Biome value(){return new Biome();}}
    public static class Biome {public float getTemperature(){return 0.8f;}}
}
