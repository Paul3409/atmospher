package net.minecraft.util.math;
public class BlockPos {
    public static BlockPos ofFloored(double x,double y,double z){return new BlockPos();}
}
