import dev.atmosphere.*;
public class WeatherModelRevolutionTest {
 static void ck(boolean pass,String msg){if(!pass)throw new AssertionError(msg);}
 public static void main(String[] args) {
  AtmosphereSettings s=new AtmosphereSettings();int count=0;int snow=0;
  for(int time=0;time<240000;time+=24000)
   for(int x=-5500;x<5500;x+=275)for(int z=-5500;z<5500;z+=275){
    var w=WeatherModel.sample(x,z,time,s);
    ck(Double.isFinite(w.pressure())&&w.pressure()>=947 && w.pressure()<=1052,"pressure");
    ck(Double.isFinite(w.windKmh())&&w.windKmh()<=190,"bounded automatic wind");
    ck(w.cloudiness()>=0&&w.cloudiness()<=1,"clouds");
    ck(w.cloudBase()>=100,"cloud lower bound");
    ck(w.rainMmH()>=0&&w.rainMmH()<=150,"precipitation range");
    if(w.precipitationKind()==1)snow++;
    count++;
   }
  s.manualWind=true;s.windKmh=42;s.gustKmh=42;s.windDirectionDegrees=270;
  var w=WeatherModel.sample(100,100,4000L,s);
  ck(Math.abs(w.windKmh()-42)<1e-6,"manual wind speed");
  ck(w.windDirection().equals("W"),"west wind from west");
  s.mode=2;s.precipitationType=2;s.precipitationMmH=70;
  var storm=WeatherModel.sample(100,100,4000L,s);
  ck(storm.precipitationKind()==1,"forced snow");
  ck(Math.abs(storm.rainMmH()-70)<1e-6,"forced precip intensity");
  System.out.println("OK: "+count+" WeatherModel samples; manual wind, direction, override and snow verified");
 }
}
