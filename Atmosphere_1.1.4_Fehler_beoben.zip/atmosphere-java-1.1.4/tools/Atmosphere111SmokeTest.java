import dev.atmosphere.*;
import java.util.*;

/** No Fabric dependencies; compile alongside tools/stubs. */
public final class Atmosphere111SmokeTest {
    static void check(boolean condition,String label) {
        if(!condition)throw new AssertionError(label);
    }
    public static void main(String[] args) {
        long n=0;double low=Double.POSITIVE_INFINITY, high=Double.NEGATIVE_INFINITY;
        boolean fronts=false, blocking=false, cyclone=false, jetStreak=false;
        HashSet<Long> ids=new HashSet<>();
        long start=System.nanoTime();
        for(double day=0;day<=12;day+=2.0) {
            for(int x=-6000;x<=6000;x+=375)for(int z=-6000;z<=6000;z+=375) {
                SynopticSystems.Field f=SynopticSystems.sample(x,z,day);
                check(Double.isFinite(f.pressure())&&f.pressure()>=947&&f.pressure()<=1052,"pressure");
                check(Double.isFinite(f.height500())&&f.height500()>=489&&f.height500()<=612,"500 hPa height");
                check(Double.isFinite(f.speed())&&f.speed()<=210,"surface wind");
                check(f.equals(SynopticSystems.sample(x,z,day)),"deterministic synoptic field");
                check(f.frontalLift()>=0&&f.frontalLift()<=1,"front range");
                check(f.cold()>=0&&f.warm()>=0&&f.occluded()>=0,"front types");
                low=Math.min(low,f.pressure());high=Math.max(high,f.pressure());
                fronts|=f.frontalLift()>.09;
                blocking|=f.anticyclone()>.4;
                cyclone|=f.cyclone()>.4;
                double[] jet=SynopticSystems.jetstream(x,z,day);
                check(Double.isFinite(jet[0])&&Double.isFinite(jet[1]),"finite jet");
                jetStreak|=Math.hypot(jet[0],jet[1])>105;
                n++;
            }
            for(var s:SynopticSystems.systems(0,0,day,6800)) {
                ids.add(s.id());
                check(s.strength()>=0&&s.strength()<=1,"system lifecycle");
                for(int k=0;k<3;k++)for(int q=0;q<=10;q++){
                    var pt=SynopticSystems.frontPoint(s,k,q/10.0);
                    check(Double.isFinite(pt.x())&&Double.isFinite(pt.z()),"front polyline");
                }
            }
        }
        check(low<1002&&high>1024,"pressure diversity");
        check(fronts&&blocking&&cyclone,"different synoptic weather regimes");
        check(jetStreak,"jetstreaks");
        check(ids.size()>4,"multiple independently developing systems");
        check(Math.abs(SynopticSystems.radialVelocity(0,0,120,0,40,2)-40)<1e-6,"Doppler radial");
        System.out.printf(Locale.ROOT,"PASS Atmosphere 1.1.1: %d samples, %d systems, %.1f-%.1f hPa, %.2f s%n",
                n,ids.size(),low,high,(System.nanoTime()-start)/1e9);
    }
}
