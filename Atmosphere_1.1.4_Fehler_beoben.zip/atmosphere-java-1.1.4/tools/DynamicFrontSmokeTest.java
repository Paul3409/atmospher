import dev.atmosphere.SynopticSystems;
import dev.atmosphere.WeatherModel;
import dev.atmosphere.AtmosphereSettings;
import java.util.List;

public final class DynamicFrontSmokeTest {
    static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args){
        AtmosphereSettings s=new AtmosphereSettings();
        var before=SynopticSystems.systems(0,0,0,7000);
        require(!before.isEmpty(),"systems exist");
        long checks=0;boolean low=false,high=false,front=false;
        for(var sys:before){
            if(sys.low())low=true;else high=true;
            // Lifetimes vary, including very short fast runners. Only check
            // direction when a system is still alive the following day.
            var shifted=SynopticSystems.systems(sys.x()+450,sys.z(),1,1800).stream().filter(n->n.id()==sys.id()).findFirst();
            if(shifted.isPresent())require(shifted.get().x()>sys.x()+100,"net westerly tracks");
            if(!sys.low())continue;
            for(int kind=0;kind<3;kind++){
                var first=SynopticSystems.frontPoint(sys,kind,0);
                require(Double.isFinite(first.x()) && Double.isFinite(first.z()),"front start");
                for(int i=1;i<=80;i++){
                    var pt=SynopticSystems.frontPoint(sys,kind,i/80.0);
                    require(Double.isFinite(pt.x())&&Double.isFinite(pt.z()),"front point");
                    checks++;
                }
            }
        }
        require(low&&high,"both synoptic types");
        for(int x=-6000;x<=6000;x+=300)for(int z=-6000;z<=6000;z+=300){
            var f=SynopticSystems.sample(x,z,2.5);
            require(Double.isFinite(f.pressure()) && f.pressure()>=947 && f.pressure()<=1052,"pressure bounded");
            require(f.cold()>=0&&f.warm()>=0&&f.occluded()>=0&&f.postFront()>=0,"front bounds");
            if(f.frontalLift()>.15)front=true;
            var wx=WeatherModel.sample(x,z,30000,s);
            require(Double.isFinite(wx.rainMmH())&&Double.isFinite(wx.t2()),"weather valid");
            checks++;
        }
        require(front,"frontal weather sampled");
        System.out.println("PASS dynamic fronts: "+checks+" checks, lows/highs, eastward drift, precipitation");
    }
}
