import dev.atmosphere.*;

/** Pure Java quality, determinism and safety checks for the 1.1.3 visual upgrade. */
public final class SoftCloudMathTest {
    static void check(boolean x,String s){if(!x)throw new AssertionError(s);}
    public static void main(String[] args) {
        int count=0;
        for(double seed=-8;seed<=8;seed+=1.25)
            for(int i=0;i<=36;i++) for(int j=0;j<=72;j++){
                double p=Math.PI*i/36.0, az=Math.PI*2*j/72.0;
                double v=SoftCloudMath.billow(p,az,seed);
                check(Double.isFinite(v)&&v>.7&&v<1.3,"cloud displacement range");
                check(v==SoftCloudMath.billow(p,az,seed),"cloud stable");
                // Texture seam at 0 and 2*pi cannot open a gap.
                if(j==72)check(Math.abs(v-SoftCloudMath.billow(p,0,seed))<1e-10,"seam");
                count++;
            }
        check(SoftCloudMath.rim(1,0,0,1,0,0)>.99,"opaque center");
        check(SoftCloudMath.rim(1,0,0,0,1,0)<.35,"feathered edge");
        check(SoftCloudMath.particleScale(17,true)<SoftCloudMath.particleScale(50,true),"adaptive cap");
        check(SoftCloudMath.particleScale(17,false)==1,"adaptive off");
        check(SoftCloudMath.experienceScale(2)==1,"baseline unchanged");
        check(SoftCloudMath.experienceScale(0)<1&&SoftCloudMath.experienceScale(4)>1,"cinematic adjustable");
        System.out.println("PASS SoftCloudMathTest: "+count+" stable billows, seams, edge alpha and budgets");
    }
}
