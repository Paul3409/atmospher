import dev.atmosphere.*;

public class PressureAndAudioTuningTest {
    private static void check(boolean x,String msg){if(!x)throw new AssertionError(msg);}
    public static void main(String[] args) {
        AtmosphereSettings s=AtmosphereSettings.get();
        check(WeatherTuning.pressureStrength(100)==1,"default pressure 1.1.3");
        check(WeatherTuning.lifetime(1)==1,"default lifetime 1.1.3");
        check(WeatherTuning.lifetime(2)>1 && WeatherTuning.lifetime(0)<1,"different lifetimes");
        check(WeatherTuning.breezeGain(0,40)==0,"calm silence");
        check(WeatherTuning.breezeGain(7,40)>0,"gentle wind audible");
        check(WeatherTuning.breezeGain(25,40)>WeatherTuning.breezeGain(7,40),"wind volume grows");
        check(WeatherTuning.breezeGain(25,0)==0,"zero wind setting means muted");
        check(WeatherTuning.lightGain(200)>WeatherTuning.lightGain(100),"brightening");
        double x=0,z=0,days=1.8;
        var systems=SynopticSystems.systems(x,z,days,9000);
        check(!systems.isEmpty(),"synoptic systems present");
        // Sample at each system center, measure whether a low/high field changes in correct direction.
        s.highPressureStrength=100;s.lowPressureStrength=100;
        double baseLow=0,baseHigh=0;boolean testedLow=false,testedHigh=false;
        for(var sys:systems) {
            if(sys.low() && !testedLow) {
                double base=SynopticSystems.sample(sys.x(),sys.z(),days).pressure();
                s.lowPressureStrength=175;
                double strong=SynopticSystems.sample(sys.x(),sys.z(),days).pressure();
                check(strong<base,"stronger low depresses pressure");
                s.lowPressureStrength=100; testedLow=true;baseLow=strong;
            }
            if(!sys.low() && !testedHigh) {
                double base=SynopticSystems.sample(sys.x(),sys.z(),days).pressure();
                s.highPressureStrength=175;
                double strong=SynopticSystems.sample(sys.x(),sys.z(),days).pressure();
                check(strong>base,"stronger high raises pressure");
                s.highPressureStrength=100;testedHigh=true;baseHigh=strong;
            }
        }
        check(testedLow&&testedHigh,"tested both pressure systems");
        s.pressureLifetime=0;var shortSystems=SynopticSystems.systems(0,0,4.5,10000);
        s.pressureLifetime=2;var longSystems=SynopticSystems.systems(0,0,4.5,10000);
        check(!longSystems.isEmpty() && !shortSystems.isEmpty(),"lifetime change stable");
        s.pressureLifetime=1;
        System.out.printf("PASS pressure control + light/wind sound; high %.1f low %.1f; tracked systems %d -> %d%n",baseHigh,baseLow,shortSystems.size(),longSystems.size());
    }
}
