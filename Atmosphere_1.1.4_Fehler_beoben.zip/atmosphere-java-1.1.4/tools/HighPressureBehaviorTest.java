import dev.atmosphere.*;
public class HighPressureBehaviorTest {
 public static void main(String[] args){
  AtmosphereSettings s=new AtmosphereSettings();
  double worstRain=0,worstCloud=0;int count=0;
  for(var sys:SynopticSystems.systems(0,0,0,8000)){
   if(sys.low())continue;
   var syn=SynopticSystems.sample(sys.x(),sys.z(),0);
   if(syn.anticyclone()<.60 || syn.cyclone()>.30)continue;
   var w=WeatherModel.sample(sys.x(),sys.z(),0,s);
   worstRain=Math.max(worstRain,w.rainMmH());worstCloud=Math.max(worstCloud,w.cloudiness());count++;
   System.out.printf("HIGH: p=%.1f cloud=%.2f rain=%.2f dry=%.2f%n",w.pressure(),w.cloudiness(),w.rainMmH(),syn.anticyclone());
  }
  if(count==0)throw new AssertionError("no clear high observed");
  if(worstRain>2)throw new AssertionError("high rain peak "+worstRain);
  if(worstCloud>.40)throw new AssertionError("high cloudiness peak "+worstCloud);
 }
}
