import dev.atmosphere.*;

/** Run without Minecraft: verifies world-anchored positioning and continuous fades. */
public final class CloudStabilityTest {
    private static void check(boolean ok,String message) {
        if(!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        for(double d=0;d<20;d+=.13) {
            for(int x=-7;x<=7;x++) for(int z=-7;z<=7;z++) {
                double px=CloudField.centerX(x,z,d),pz=CloudField.centerZ(x,z,d);
                check(Double.isFinite(px)&&Double.isFinite(pz),"finite center");
                // Camera position must not occur anywhere in world anchoring functions.
                check(px==CloudField.centerX(x,z,d)&&pz==CloudField.centerZ(x,z,d),"stable repeat");
                double delta=Math.hypot(CloudField.centerX(x,z,d+1e-5)-px,
                        CloudField.centerZ(x,z,d+1e-5)-pz);
                check(delta<.005,"no movement discontinuity");
                for(double cover=0;cover<=1.001;cover+=.05) {
                    double v=CloudField.coverage(x,z,cover);
                    check(v>=0&&v<=1,"coverage bounds");
                    check(CloudField.coverage(x,z,Math.min(1,cover+.001))+1e-9>=v,"coverage continuity direction");
                }
            }
        }
        double limit=750;
        check(CloudField.viewFade(0,limit)==1,"near full visibility");
        check(CloudField.viewFade(limit,limit)==0,"fade to zero");
        check(CloudField.viewFade(limit-1,limit)>0,"no sudden pop");
        check(CloudField.viewFade(limit-220,limit)==1,"flat near plateau");
        System.out.println("PASS CloudStabilityTest: deterministic cells, continuous drift, coverage and view fades");
    }
}
