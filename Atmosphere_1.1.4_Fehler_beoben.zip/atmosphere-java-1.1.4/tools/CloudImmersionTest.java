import dev.atmosphere.*;
public final class CloudImmersionTest {
    public static void main(String[] args) {
        var s = new AtmosphereSettings();
        int count=0, within=0;
        double maximum=0;
        long start=System.nanoTime();
        for(long day=0;day<=24000*3;day+=12000) {
            for(int x=-440;x<=440;x+=44) for(int z=-440;z<=440;z+=44) {
                double y=WeatherModel.sample(x,z,day,s).cloudBase()+17;
                double fog=CloudField.immersion(x,y,z,day,s);
                if(!Double.isFinite(fog)||fog<0||fog>1)throw new AssertionError("bad density " + fog);
                if(fog>.22)within++;
                maximum=Math.max(fog,maximum);
                count++;
            }
        }
        if(within<3 || maximum<.40)throw new AssertionError("No dense clouds to fly into: "+within+" / "+maximum);
        System.out.printf("PASS CloudImmersionTest: %d samples, %d cloudy, peak %.3f, %.2f sec%n",
                count,within,maximum,(System.nanoTime()-start)/1e9);
    }
}
