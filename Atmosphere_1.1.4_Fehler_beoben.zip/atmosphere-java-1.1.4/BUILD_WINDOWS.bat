@echo off
cd /d "%~dp0"
echo Atmosphere 1.1.4 - Dynamic Pressure and Wind - Fabric 1.21.1 / Java 21
"C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build
if errorlevel 1 (
 echo BUILD FEHLGESCHLAGEN - erste Fehlermeldung senden.
 pause
 exit /b 1
)
echo Fertig: build\libs\atmosphere-1.1.4.jar
pause
