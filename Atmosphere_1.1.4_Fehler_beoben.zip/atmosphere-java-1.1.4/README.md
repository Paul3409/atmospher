# Atmosphere 1.1.4 – Dynamic Pressure & Wind

**Fabric 1.21.1 · Minecraft 1.21.1 · Java 21 · Quellcode aus Atmosphere 1.1.3**

## Was in 1.1.4 geändert wurde

- **Hochdruck 0–200 % und Tiefdruck 0–200 % separat:** Die Stärke wirkt auf das gemeinsame synoptische Druckfeld sowie Hoch-/Tief-Einfluss, Fronten und rotierenden Wind. Dadurch wirken die Einstellungen auf Niederschlag, Wolken und Radar, statt nur die Regenwahrscheinlichkeit zu verändern. **100 % ist das alte Verhalten aus 1.1.3.**
- **Lebensdauer Kurz / Normal / Lang:** Natürlich erzeugte Druckgebiete halten ungefähr 70 %, 100 % oder 155 % der bisherigen Dauer. Nicht die Minecraft-Tageslänge oder die bereits manuell gesetzten Hochs und Tiefs werden verändert.
- **Blitzhelligkeit 25–200 % / Blitzgröße 25–200 %:** Getrennt von der bestehenden Blitzhäufigkeit. Optische Lichtimpulse sind begrenzt; keine echten Feuer-/Schadensblitze.
- **Donnerlautstärke 0–200 %** unabhängig von der Blitzhäufigkeit; Ausgabewerte begrenzt.
- **Windton 0–100 % (Standard 40 %):** Eine sanfte Brise ist bereits ab etwa 2 km/h hörbar; Lautstärke blendet weich ein und wächst mit der Windgeschwindigkeit. Es werden bestehende Audio-Clips einschließlich `wind.ogg`, `wind_light.ogg`, `wind_base.ogg`, `snow_wind.ogg` und der stärkeren Böen-Clips situationsabhängig genutzt. Die vorhandenen 34 Audioclips bleiben erhalten, werden **nicht** gleichzeitig abgespielt.
- **Menü:** Neue Seite **Druck** mit Hoch/Tief-Stärke, Lebensdauer und bisherigen Druck-/Gewittersteuerungen. Auf **Sound**: Blitz-Helligkeit, Blitz-Größe, Donner- und Wind-Lautstärke. Wetterradar verwirft zwischengespeicherte Druckfelder, wenn diese Einstellungen verändert werden.
- **Vorhandenes unverändert:** Watteartige Cloud Engine 7.0, stabile Wolken, Radar, Fronten, Schneeakkumulation, Sounddateien, Gewitter-Soundkulisse, sichere Funnel Clouds, Grafikprofile, manuelle Wetterfunktionen.

### Bedienung und Werte

Alle neuen Regler sind zyklische Schaltflächen im Atmosphere-Menü. Ein Klick erhöht den Wert (je 25 Prozentpunkte bei Druck, Blitz und Donner; Wind je 10); am Höchstwert beginnt die Einstellung wieder beim Mindestwert. Die Werte werden unter `config/atmosphere.properties` gespeichert, ältere Dateien bleiben kompatibel. **Standardwerte:** Hoch 100 %, Tief 100 %, Dauer Normal, Blitz-Helligkeit 100 %, Blitzgröße 100 %, Donner 100 %, Windton 40 %.

**Tipp:** Für kräftige, aber plausible Wetterlagen: Hoch 125 %, Tief 150 %, Dauer Lang; Blitzhelligkeit 125 %, Größe 125 %, Windton 50 %. Extreme Einstellungen wie 200 % können deutlich mehr Niederschlag/kräftigere Winde erzeugen. Änderungen betreffen clientseitige Einzelspieler-Wetterberechnungen, nicht Server mit synchronisiertem globalem Wetter.

## Bauen unter Windows

1. ZIP entpacken und Eingabeaufforderung im Ordner `atmosphere-java-1.1.4` öffnen.
2. Java 21 installieren und Fabric/Minecraft-Gradle-Abhängigkeiten verfügbar halten.
3. Bauen:

   ```bat
   "C:\Gradle\gradle-8.8\bin\gradle.bat" clean build
   ```

4. Die fertige Mod liegt bei erfolgreichem Build unter `build\libs\atmosphere-1.1.4.jar`. Lege nur **eine** Atmosphere-JAR in `mods/`, zusammen mit Fabric API. Erstelle vor dem ersten Spielstart ein Backup deiner Welt.

## Entwicklungsprüfung und Einschränkungen

Die mitgelieferten `tools/` sind eigenständige Java-Tests für die Wettermodelle; die Minecraft-/Fabric-API und das tatsächliche Audio-Rendering können nur mit vollständigem Fabric-Build bzw. im Spiel getestet werden. Ein regulärer Minecraft-Start kann in dieser Umgebung nicht garantiert werden. Die neuen Schalter wurden so angelegt, dass die bisherigen 1.1.3-Standardeinstellungen (bis auf den bereits bei wenig Wind hörbaren Windton) erhalten bleiben.

**Empfohlener Funktionstest:** Erst mit normalen Druckeinstellungen starten, dann ein Hoch und Tief mit 150 % vergleichen, Radar schließen und neu öffnen, Windton bei 5–15 km/h mit manuellem Wind testen, Blitzgröße/Helligkeit und Donner getrennt einstellen. Bei Fehlern die erste `error:`-Meldung aus dem Build oder die `latest.log` mitschicken.
