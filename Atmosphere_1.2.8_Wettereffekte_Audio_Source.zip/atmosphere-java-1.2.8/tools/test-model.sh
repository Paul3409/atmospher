#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/model-test build/persistence-test
java com.sun.tools.javac.Main -d build/model-test \
  tools/stubs/dev/atmosphere/{AtmosphereSettings,ManualPressureSystems,StormEvents}.java \
  tools/stubs/net/minecraft/{util/math/BlockPos,world/World}.java \
  src/main/java/dev/atmosphere/{ClimateClock,WeatherRegimes,WeatherCells,StormEvolution,HookEcho,GustFront,ShelfCloudGeometry,TornadoGeometry,WeatherModel,WeatherTuning,SoftCloudMath,CloudNoise,CloudGeometry,CloudScene,CloudLighting,ConvectiveCloudGeometry,CloudFragments,TailCloudGeometry,StormAttachments,RainVeil,CloudField,WeatherFog,RadarReflectivity,SynopticSystems,SupercellGeometry,SettingsStorage}.java \
  src/main/java/dev/atmosphere/siren/{SirenProgram,SirenEngine,SirenGain}.java \
  tools/{StormStructuresTest,CloudSceneTest,RadarReflectivityTest,CloudsFogTest,WeatherEvolutionSmokeTest,WeatherVarietyTest,TornadoGeometryTest,GustFrontTest,ManualGustFrontTest,WeatherModelRevolutionTest,SupercellGeometryTest,SettingsStorageTest,SirenEngineTest,SirenScheduleTest}.java
for test in StormStructuresTest CloudSceneTest RadarReflectivityTest CloudsFogTest WeatherEvolutionSmokeTest WeatherVarietyTest TornadoGeometryTest GustFrontTest ManualGustFrontTest WeatherModelRevolutionTest SupercellGeometryTest SettingsStorageTest SirenEngineTest SirenScheduleTest; do
  java -cp build/model-test "$test"
done
java com.sun.tools.javac.Main -d build/persistence-test \
  $(find tools/persistence-stubs -name '*.java' -print) tools/stubs/dev/atmosphere/AtmosphereSettings.java \
  src/main/java/dev/atmosphere/{ClimateClock,ClimateState,WeatherRegimes,WeatherCells,StormEvents,ManualPressureSystems,StormEvolution,HookEcho,GustFront}.java \
  tools/ClimatePersistenceTest.java
java -cp build/persistence-test ClimatePersistenceTest
mkdir -p build/settings-test
java com.sun.tools.javac.Main -cp build/model-test -d build/settings-test \
  tools/settings-stubs/net/fabricmc/loader/api/FabricLoader.java \
  src/main/java/dev/atmosphere/AtmosphereSettings.java tools/FogSettingsTest.java
java -cp build/settings-test:build/model-test FogSettingsTest
