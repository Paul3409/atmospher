import dev.atmosphere.*;

public final class StormStructuresTest {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[]args){
  for(int seed=0;seed<300;seed++){
   ck(StormEvolution.tornadoActivity(seed,1,.5,4)>.99,"Always did not guarantee mature tornado");
   ck(StormEvolution.tornadoActivity(seed,1,.5,1000)==0,"0 percent did not disable");
   ck(StormEvolution.tornadoActivity(seed,1,.5,1100)>.99,"100 percent lost tornado");
   ck(StormEvolution.tornadoActivity(seed,.1,.05,4)==0,"Always skipped funnel development");
   double last=0;for(int i=0;i<=100;i++){
    double activity=StormEvolution.tornadoActivity(seed,1,.25+i*.0015,4);
    ck(activity>=last,"Formation is not continuous");last=activity;
   }
  }
  double previous=.04;
  for(int i=0;i<=100;i++){
   double phase=StormEvolution.manualPhase(i*.0002,1.8);
   ck(phase>=previous,"Manual phase reversed");previous=phase;
  }
  ck(StormEvolution.manualPhase(.02,1.8)>.40,"Test formation takes too long");
  var fragment=CloudFragments.unitMesh(42,20,12);
  for(int j=0;j<=12;j++)for(int i=0;i<=20;i++){
   var p=fragment[j][i];ck(Double.isFinite(p.x()+p.y()+p.z()+p.ny()),"Invalid scud fragment");
   var seam=fragment[j][0];if(i==20)ck(Math.abs(p.x()-seam.x())+Math.abs(p.y()-seam.y())+Math.abs(p.z()-seam.z())<1e-8,"Scud seam open");
  }
  var first=StormAttachments.tail(42,270,1,50);var next=StormAttachments.tail(42,270,1,51);
  ck(first.size()==24,"Unbounded tail");
  int advected=0;for(int i=0;i<first.size();i++){
   if(first.get(i).alpha()>50&&next.get(i).alpha()>50){
    ck(next.get(i).across()<first.get(i).across(),"Tail drifts away from wall cloud");advected++;
   }
  }
  ck(advected>10,"Tail has no material stream");
  ck(StormAttachments.scud(42,270,1,30).size()==12,"Unbounded scud");
  ck(!StormAttachments.scud(42,270,1,30).equals(StormAttachments.scud(42,270,1,31)),"Static scud");
  ck(StormAttachments.underside(-1)<StormAttachments.underside(1),"Underside not darker");
  for(int type=1;type<=3;type++)for(int seed=0;seed<5;seed++)for(int j=0;j<=36;j++)for(int i=0;i<=56;i++){
   var p=ConvectiveCloudGeometry.point(seed,j/36.0,i*Math.PI*2/56,205,125,230,1,0,1,.5,type);
   ck(Double.isFinite(p.x()+p.y()+p.z()+p.nx()+p.ny()+p.nz()),"Invalid convective surface");
   ck(p.y()>=124&&p.y()<=356,"Cloud leaves vertical bounds");
   if(j==0||j==36)ck(Math.abs(p.x()- (j==0?0:230*(.08+.14*WeatherCells.hash(seed,0,1801))+205*.25*(type==1?0:1)))<100,
      "Cap has unexpected offset");
  }
  var a=ConvectiveCloudGeometry.point(1,.5,1,200,125,230,1,0,1,.5,2);
  var b=ConvectiveCloudGeometry.point(2,.5,1,200,125,230,1,0,1,.5,2);
  ck(!a.equals(b),"All clouds have same shape");
  System.out.println("PASS: Always/custom tornado chance, continuous formation, inward tail advection, bounded evolving scud and connected varied convection");
 }
}
