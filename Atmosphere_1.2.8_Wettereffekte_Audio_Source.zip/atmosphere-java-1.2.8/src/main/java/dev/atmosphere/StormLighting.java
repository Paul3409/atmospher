package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;

/** Cached local sky attenuation; artificial block light remains unaffected. */
public final class StormLighting {
    private static ClientWorld lastWorld;
    private static long lastTick=Long.MIN_VALUE;
    private static double factor=1;
    private StormLighting() {}
    public static double factor() {
        MinecraftClient client=MinecraftClient.getInstance();
        if(client.world==null||client.player==null||client.world.getRegistryKey()!=World.OVERWORLD)return 1;
        if(lastWorld!=client.world) {lastWorld=client.world;lastTick=Long.MIN_VALUE;factor=1;}
        long tick=client.world.getTime();
        if(tick!=lastTick) {
            lastTick=tick;
            var p=client.gameRenderer.getCamera().getPos();
            var w=WeatherModel.sample(p.x,p.z,client.world.getTimeOfDay(),AtmosphereSettings.get());
            double below=1-StormEvolution.smooth(w.cloudBase(),w.cloudBase()+45,p.y);
            double strength=StormEvolution.smooth(.20,.85,w.storm());
            var settings=AtmosphereSettings.get();
            double profile=new double[]{.85,.95,1,1.20,1.35}[Math.max(0,Math.min(4,settings.weatherExperience))];
            double contrast=1+(profile-1)*settings.profileStrength/100.0;
            double target=Math.max(.25,1-below*strength*(.23+.27*w.cloudiness())*contrast);
            factor+=(target-factor)*.10;
        }
        return factor;
    }
}
