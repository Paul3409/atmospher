# Atmosphere 1.2.8 – Wettereffekte, Wolken und Audio

Ausschließlich Minecraft/Fabric 1.21.1, Yarn 1.21.1+build.3, Fabric API 0.115.6+1.21.1, Java 21. Die Metadaten erlauben nur Minecraft 1.21.1.

## Änderungen

- Der Tornado verwendet wieder den stark verjüngten, leicht geneigten Trichter des alten Geometrietyps. Die Superzellen-Hauptform bleibt erhalten, die Basis liegt mindestens auf Y=260. Funnel entsteht und senkt sich bis zum geladenen Boden. Keine Garantie auf pixelgleiche Darstellung zur alten Version: Wolkenbeleuchtung und Renderer haben sich verändert.
- Breitere, längere Tail Cloud: durchgehendes Mesh mit in der Wall Cloud verborgenem Ansatz und nach innen laufenden Formdetails. Das ist eine künstlerische Strömungsdarstellung, keine Strömungssimulation.
- Größere, unregelmäßige, nach unten verjüngte Scud-Fetzen mit begrenzter Anzahl und bestehendem Lebenszyklus.
- Zusätzliche entfernte Niederschlagsvorhänge sind abgeschaltet. Normale lokale Regen-/Schnee-/Hagelpartikel und das Wetter-/Radar-Modell bleiben bestehen.
- Menü → Effekte: Regen, Schnee/Hagel und Tornadostaub separat 0–300 %, Partikelradius 0–128 Blöcke, Regenlautstärke 0–200 %, Donnerreichweite 0–800 Blöcke (Standard 500), Profilstärke 0–200 %. Der globale Partikelschalter bleibt übergeordnet; adaptive Grafik reduziert weiterhin Last.
- Natur/Ruhig/Balance/Dramatisch/Kino verändern jetzt tatsächlich den Wolkenkontrast und die lokale Gewitter-Himmelsabdunklung. Sie verändern nicht länger die Gewitterhäufigkeit; dafür gibt es den separaten Häufigkeitsregler. Kein vollständiger Welt-Shader und kein Ersatz für Iris/Shaderpacks.
- Neue vom Nutzer bereitgestellte Regen-, Winterwind- und Donneraufnahmen. Regen/Wind laufen als persistente Sounds mit gleitender Lautstärke; die importierten Atmosphärenspuren haben überblendete Loop-Enden. Wechsel zwischen Regenstärken blendet statt hart zu starten. Unter Dächern wird gedämpft.
- Donner wird außerhalb der gewählten Entfernung nicht eingeplant bzw. abgespielt; der Pegel fällt zum Rand auf null. Nahe, mittlere und entfernte Donner verwenden unterschiedliche Aufnahmen.
- Sirenen: 2,4 Sekunden lange Abschnitte im 2-Sekunden-Takt mit 400 ms Überblendung statt nur 100 ms Reserve. Zeitbasis unabhängig von schwankenden Spielticks, mit Pausenkompensation. Signale, Gruppen, individuelle Pegel und Probepläne bleiben erhalten.

## Installation / Build

Welt und Konfiguration sichern. Alte Atmosphere-JAR außerhalb von mods aufbewahren; nur eine Atmosphere-Version installieren. Java 21 und Fabric API für 1.21.1 verwenden.
BUILD_WINDOWS.bat erzeugt build/libs/atmosphere-1.2.8.jar. Alternativ: gradle build.
Die Quell-ZIP enthält keine Gradle-Caches und keine Spielwelt.

## Testen

1. Menüversion 1.2.8 prüfen. Druck → Tornado-Testzelle, Tempo 1: aus 150–350 Blöcken Entfernung Funnel und Bodenkontakt beobachten. Immer gilt für geeignete reife Superzellen, nicht für jeden Schauer; Testzelle hat eigene Garantie.
2. Seitliche Ansicht: Tail-Ansatz soll breit in die Wall Cloud greifen. Mindestens 15 Sekunden beobachten: Formdetails laufen hinein. Scud-Fetzen aus normaler Spielentfernung ansehen.
3. Effekte: 0/100/300 % je Partikelart vergleichen; Radius 0 schaltet Niederschlagspartikel aus. Sehr hohe Werte kosten FPS. Speichern und neu laden.
4. Natur/Kino bei gleicher Zelle und Profilstärke 100 % vergleichen; 0 % neutralisiert den Profileffekt.
5. Regen mehrere Minuten innen/außen und beim Stärkewechsel hören. Nahe/ferne Donner vergleichen; über 500 Blöcken bei Standardreichweite kein neuer Mod-Donner.
6. Alle vier Sirenensignale ohne Unterbrechung hören, währenddessen bewegen, pausieren/fortsetzen und vorzeitig stoppen. Audioqualität muss zusätzlich auf echter Hardware geprüft werden; der automatische Clienttest verwendet einen Null-Audiotreiber.
7. Radar dBZ/mm/h, Wetteruhr, Nebel und Sirenen-Gruppen als Regression gegenprüfen.

## Vorschauen und Prüfungen

previews/Wolken_Modellvorschau.png ist ausdrücklich eine mathematische Projektion derselben Geometriefunktionen, KEIN Ingame-Bild. Textur, Transparenz und Perspektive können im Spiel anders wirken.
Der GitHub-Workflow baut die Mod gegen echte 1.21.1-Abhängigkeiten und startet separat einen echten Minecraft-Client mit Software-OpenGL. Seine Aufnahmen liegen im separaten Client-Artefakt.
Die Entwicklungs-Test-Mod tools/visual-test wird nur mit -PvisualTest erzeugt und gehört nicht in die produktive JAR.

bash tools/test-model.sh: 16 Testprogramme für Modell, Geometrie, Persistenz, Einstellungen und Sirenen.
python tools/check_render_assets.py: Shader-/Textur-Schnittstellen (Pillow benötigt).
python tools/verify_siren_assets.py .: 684 Mono-Sirenenabschnitte (ffprobe benötigt).
tools/import_weather_audio.py --weather-source ORDNER [--siren-source ORDNER] bereitet bereitgestellte Originalaufnahmen mit ffmpeg auf; kein normaler Build-Schritt. Die Originaldateien und deren Nutzungsrechte werden dadurch nicht mitgeliefert oder als frei lizenziert erklärt.
