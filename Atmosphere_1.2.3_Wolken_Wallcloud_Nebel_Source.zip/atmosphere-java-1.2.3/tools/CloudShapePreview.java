import dev.atmosphere.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import javax.imageio.ImageIO;
import java.io.File;

/** Diagnostic projection of the exact math surfaces; NOT a Minecraft screenshot. */
public final class CloudShapePreview {
 record Face(int[] x,int[] y,double depth,int shade){}
 interface Surface {CloudGeometry.Point point(int j,int i);}
 static void mesh(ArrayList<Face> faces,Surface s,int rows,int cols,double ox,double oy,double scale,
                  double shiftX,double shiftZ){
  var p=new CloudGeometry.Point[rows+1][cols+1];
  for(int j=0;j<=rows;j++)for(int i=0;i<=cols;i++)p[j][i]=s.point(j,i);
  for(int j=0;j<rows;j++)for(int i=0;i<cols;i++){
   int[] xx=new int[4],yy=new int[4];double depth=0,shade=0;
   for(int k=0;k<4;k++){
    var v=p[j+(k>=2?1:0)][i+(k==1||k==2?1:0)];
    double x=v.x()+shiftX,z=v.z()+shiftZ,d=-x*.6+z*.8;
    xx[k]=(int)(ox+(x*.8+z*.6)*scale);yy[k]=(int)(oy-v.y()*scale+d*scale*.18);
    depth+=d;shade+=.54+.37*Math.max(0,v.nx()*.5+v.ny()*.7-v.nz()*.5);
   }
   faces.add(new Face(xx,yy,depth,(int)(205*shade/4)));
  }
 }
 public static void main(String[] args)throws Exception{
  var image=new BufferedImage(1100,520,BufferedImage.TYPE_INT_RGB);var g=image.createGraphics();
  g.setColor(new Color(136,177,220));g.fillRect(0,0,1100,520);
  var faces=new ArrayList<Face>();int rows=44,cols=80;
  mesh(faces,(j,i)->CloudGeometry.point(42,j*Math.PI/rows,i*Math.PI*2/cols,120,100,95,130,.8,.6,0),
    rows,cols,175,430,1,0,0);
  mesh(faces,(j,i)->CloudGeometry.point(42,j*Math.PI/rows,i*Math.PI*2/cols,150,120,25,240,.8,.6,1),
    rows,cols,175,430,1,0,0);
  mesh(faces,(j,i)->{
   var p=SupercellGeometry.point(42,j/(double)rows,i*Math.PI*2/cols,270,130,355,1,0,.8,.6);
   return new CloudGeometry.Point(p.x(),p.y(),p.z(),p.nx(),p.ny(),p.nz());
  },rows,cols,710,465,.70,0,0);
  mesh(faces,(j,i)->WallCloudGeometry.point(42,j*Math.PI/rows,i*Math.PI*2/cols,40,124,158,106),
    rows,cols,710,465,.70,13.5,-94.5);
  faces.sort(Comparator.comparingDouble(Face::depth).reversed());
  for(var f:faces){int shade=Math.max(0,Math.min(255,f.shade));g.setColor(new Color(shade,shade,Math.min(255,shade+5)));g.fillPolygon(f.x,f.y,4);}
  g.setColor(Color.BLACK);g.drawString("1.2.3 mathematical mesh preview - NOT in-game / no Minecraft textures or transparency",15,20);
  g.drawString("Dry cumulus / shallow stratus",65,490);g.drawString("Connected updraft, anvil and broad closed wall cloud",550,490);
  g.dispose();ImageIO.write(image,"png",new File(args[0]));
 }
}
