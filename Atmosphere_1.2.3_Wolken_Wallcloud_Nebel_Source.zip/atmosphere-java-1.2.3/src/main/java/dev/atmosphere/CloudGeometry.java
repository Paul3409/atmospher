package dev.atmosphere;

/** Closed cloud surface: flat underside, coherent multi-scale upper billows.
 * Shape is independent of quality/camera; quality changes only tessellation. */
public final class CloudGeometry {
    private CloudGeometry(){}
    public record Point(double x,double y,double z,double nx,double ny,double nz){}
    private record Position(double x,double y,double z){}
    private static Position position(long seed,double p,double a,double width,double depth,
                                     double height,double base,double wx,double wz,double layered){
        double c=Math.cos(p),s=Math.sin(p),phase=WeatherCells.hash(seed,0,1321)*Math.PI*2;
        double top=WeatherCells.smooth(-.18,.55,c);
        double broad=.09*Math.sin(3*a+phase)+.05*Math.cos(5*a-phase);
        double detail=.035*Math.sin(8*a+p*5+phase)+.018*Math.cos(13*a-p*7);
        double billow=1+Math.pow(s,.8)*(broad+detail*(1-layered*.65))*(.65+.35*top);
        double r=s*billow;
        double vertical=c>=0?.25+.75*c:.25*Math.pow(1+c,3);
        double lobes=(.12*Math.sin(a*3+p*4+phase)+.06*Math.cos(a*5-p*3-phase))
                *s*s*top*(1-.75*layered);
        vertical=WeatherCells.clamp(vertical*(1+lobes),0,1);
        double y=base+height*vertical;
        double lean=height*.16*vertical*vertical;
        return new Position(width*r*Math.cos(a)+wx*lean,y,depth*r*Math.sin(a)+wz*lean);
    }
    public static Point point(long seed,double polar,double angle,double width,double depth,
                               double height,double base,double wx,double wz,double layered){
        Position v=position(seed,polar,angle,width,depth,height,base,wx,wz,layered);
        if(polar<1e-6||polar>Math.PI-1e-6)
            return new Point(v.x,v.y,v.z,0,polar<1?1:-1,0);
        double e=.0001;
        Position p=position(seed,polar+e,angle,width,depth,height,base,wx,wz,layered);
        Position a=position(seed,polar,angle+e,width,depth,height,base,wx,wz,layered);
        double px=p.x-v.x,py=p.y-v.y,pz=p.z-v.z;
        double ax=a.x-v.x,ay=a.y-v.y,az=a.z-v.z;
        double nx=pz*ay-py*az,ny=px*az-pz*ax,nz=py*ax-px*ay;
        double n=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));
        return new Point(v.x,v.y,v.z,nx/n,ny/n,nz/n);
    }
}
