package dev.atmosphere;

import java.util.LinkedHashMap;
import java.util.Map;

/** Rain-bearing rear flank, following a tapering, irregular curved centreline. */
public final class HookEcho {
    private HookEcho(){}
    private record Curve(double[] x,double[] z,double phase){}
    private static final Map<Long,Curve> CACHE=new LinkedHashMap<>(128,.75f,true){
        @Override protected boolean removeEldestEntry(Map.Entry<Long,Curve> e){return size()>128;}
    };
    private static synchronized Curve curve(long seed){
        Curve found=CACHE.get(seed);if(found!=null)return found;
        double[] px={-.49,-.65,-.66,-.49,-.14,.18,.24};
        double[] pz={.37,.03,-.32,-.62,-.75,-.65,-.47};
        for(int i=1;i<px.length-1;i++){
            px[i]+=(WeatherCells.hash(seed,i,1401)-.5)*.13;
            pz[i]+=(WeatherCells.hash(seed,i,1403)-.5)*.11;
        }
        int steps=24;double[] x=new double[steps+1],z=new double[steps+1];
        for(int j=0;j<=steps;j++){
            double t=j/(double)steps*(px.length-1);int i=Math.min(px.length-2,(int)t);double u=t-i;
            x[j]=spline(px,i,u);z[j]=spline(pz,i,u);
        }
        found=new Curve(x,z,WeatherCells.hash(seed,0,1407)*Math.PI*2);CACHE.put(seed,found);return found;
    }
    private static double spline(double[] p,int i,double t){
        double a=p[Math.max(0,i-1)],b=p[i],c=p[i+1],d=p[Math.min(p.length-1,i+2)];
        return .5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
    }
    public static double rain(double u,double v,long seed){
        Curve c=curve(seed);double best=0;
        for(int i=0;i<c.x.length-1;i++){
            double dx=c.x[i+1]-c.x[i],dz=c.z[i+1]-c.z[i];
            double t=WeatherCells.clamp(((u-c.x[i])*dx+(v-c.z[i])*dz)/Math.max(1e-9,dx*dx+dz*dz),0,1);
            double life=(i+t)/(c.x.length-1);
            double width=(.28-.22*life)*(.84+.16*Math.sin(life*12+c.phase));
            double d=Math.hypot(u-c.x[i]-dx*t,v-c.z[i]-dz*t);
            double rain=Math.exp(-Math.pow(d/width,2))*(.60+.15*Math.sin(life*9+c.phase))
                    *(1-WeatherCells.smooth(.94,1,life)*.40);
            best=Math.max(best,rain);
        }
        return best;
    }
    /** Smooth world-anchored perturbations, never independent radar-only pixel noise. */
    public static double noise(double x,double z,long seed){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);
        double tx=WeatherCells.smooth(0,1,x-ix),tz=WeatherCells.smooth(0,1,z-iz);
        double a=WeatherCells.hash(ix^seed,iz,1421),b=WeatherCells.hash((ix+1)^seed,iz,1421);
        double c=WeatherCells.hash(ix^seed,iz+1,1421),d=WeatherCells.hash((ix+1)^seed,iz+1,1421);
        return (a+(b-a)*tx)*(1-tz)+(c+(d-c)*tx)*tz;
    }
}
