package dev.atmosphere;

/** Broad, closed lowering. Differential cloud drift, never a hollow vortex tube. */
public final class WallCloudGeometry {
    private WallCloudGeometry(){}
    public static CloudGeometry.Point point(long seed,double polar,double angle,double ticks,
                                             double radius,double top,double bottom){
        // All levels drift in the same direction; no helical displacement bands.
        double spin=ticks*.006;
        var p=CloudGeometry.point(seed,polar,angle-spin,radius,radius*.86,
                Math.max(1,top-bottom),bottom,0,0,.6);
        // Gentle asymmetry orbits inside a fixed, broad envelope.
        double co=Math.cos(spin),si=Math.sin(spin);
        return new CloudGeometry.Point(p.x()*co-p.z()*si,p.y(),p.x()*si+p.z()*co,
                p.nx()*co-p.nz()*si,p.ny(),p.nx()*si+p.nz()*co);
    }
}
