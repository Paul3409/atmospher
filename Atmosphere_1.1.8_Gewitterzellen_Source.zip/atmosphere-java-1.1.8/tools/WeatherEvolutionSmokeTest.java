import dev.atmosphere.StormEvolution;
import dev.atmosphere.WeatherCells;

/** Run without Fabric: javac -d build/model-test src/main/java/dev/atmosphere/{WeatherCells,StormEvolution}.java tools/WeatherEvolutionSmokeTest.java
 * java -cp build/model-test WeatherEvolutionSmokeTest
 */
public final class WeatherEvolutionSmokeTest {
    public static void main(String[] args) {
        int seen=0;
        for(int gx=-12;gx<=12;gx++) for(int gz=-12;gz<=12;gz++) {
            for(double days : new double[]{0,.1,.5,1,4,12}) {
                WeatherCells.Cell c=WeatherCells.cell(gx,gz,days);
                WeatherCells.Cell again=WeatherCells.cell(gx,gz,days);
                require(c.equals(again),"Not deterministic");
                require(c.type()>=1 && c.type()<=5,"Invalid weather type");
                require(c.growth()>=0 && c.growth()<=1,"Invalid storm lifecycle");
                require(c.speedBlocksPerDay()>=170 && c.speedBlocksPerDay()<=270,"Invalid advection");
                require(Double.isFinite(c.x()) && Double.isFinite(c.z()),"Invalid cell position");
                for(int i=0;i<6;i++) {
                    double part=StormEvolution.localTower(c.growth(),i,6,c.id());
                    require(Double.isFinite(part) && part>=0 && part<=1,"Invalid local cloud growth");
                }
                double[] wind=StormEvolution.altitudeWind(c.windX(),c.windZ(),400,c.id(),days);
                require(Double.isFinite(wind[0]) && Double.isFinite(wind[1]),"Invalid shear");
                WeatherCells.Field field=WeatherCells.sample(c.x(),c.z(),days);
                require(Double.isFinite(field.rain()) && field.rain()>=0,"Invalid rain");
                require(field.gustFront()>=0 && field.gustFront()<=1,"Invalid gust front");
                seen++;
            }
        }
        for(int age=0;age<8;age++)
            require(StormEvolution.flashPulse(age)>=0 && StormEvolution.flashPulse(age)<=1,"Invalid lightning flash");
        require(StormEvolution.virga(.9,.9,.3)>StormEvolution.virga(.9,.9,.85),"Virga humidity inversion");
        require(StormEvolution.rainCurtain(.9,.9,.9)>StormEvolution.rainCurtain(.9,.9,.2),"Rain humidity inversion");
        require(StormEvolution.gustFront(115,0,100,1,WeatherCells.SEVERE)>.8,"Strong leading gust missing");
        require(StormEvolution.gustFront(115,0,100,1,WeatherCells.SHOWER)==0,"Shower has severe gust front");
        System.out.println("PASS: "+seen+" deterministic storm snapshots; growth, shear, rain, virga, flashes");
    }
    private static void require(boolean value,String message) {if(!value)throw new AssertionError(message);}
}
