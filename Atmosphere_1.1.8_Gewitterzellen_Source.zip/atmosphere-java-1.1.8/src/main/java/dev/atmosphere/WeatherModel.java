package dev.atmosphere;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Continuous, deterministic regional weather. This is a game-scale procedural model,
 * not real numerical weather prediction. No unbounded state or random tick updates.
 * World-aware samples use the actual biome and height for local T2.
 */
public final class WeatherModel {
    public static final String[] SEASONS = {"Frühling", "Sommer", "Herbst", "Winter"};
    public static final String[] MODES = {"Automatisch", "Trocken", "Niederschlag"};
    public static final String[] QUALITY = {"Leicht", "Ausgewogen", "Hoch", "Ultra"};
    public static final int[] RATES = {0, 1, 3, 8, 15, 25, 40, 60, 100}; // migration only
    public static final String[] PRECIPITATION = {"Automatisch", "Regen", "Schnee", "Graupel", "Hagel"};
    private static final double TAU = Math.PI * 2;
    private WeatherModel() {}

    public record Weather(double t2, double windX, double windZ, double windKmh,
                          double rainMmH, double cloudiness, boolean snow, int season,
                          int dayInSeason, double fog, double storm, double front,
                          double humidity, double pressure, double cloudBase, int precipitationKind) {
        public String phase() {
            if (rainMmH < .1) return "Trocken";
            return switch (precipitationKind) {
                case 1 -> "Schnee"; case 2 -> "Schneeregen";
                case 3 -> "Graupel"; case 4 -> "Hagel"; default -> "Regen";
            };
        }
        public String windDirection() {
            double degrees = (Math.toDegrees(Math.atan2(-windX, windZ)) + 360) % 360;
            String[] dirs = {"N", "NO", "O", "SO", "S", "SW", "W", "NW"};
            return dirs[((int) Math.round(degrees / 45)) % 8];
        }
    }

    /** Radar and forecasts use the procedural climate map, without loading world chunks. */
    public static Weather sample(double x, double z, long time, AtmosphereSettings s) {
        return sample(x, 70, z, .8, time, s);
    }

    /** For actual precipitation and HUD temperature. Only call for loaded locations. */
    public static Weather sample(World world, double x, double y, double z, long time, AtmosphereSettings s) {
        BlockPos pos = BlockPos.ofFloored(x, y, z);
        double biome = world.getBiome(pos).value().getTemperature();
        return sample(x, y, z, biome, time, s);
    }

    /** Biome temperature 0.8 is approximately temperate Plains. */
    public static Weather sample(double x, double y, double z, double biomeTemp, long time, AtmosphereSettings s) {
        long day = Math.floorDiv(time, 24000L);
        double days = (time / 24000.0) * s.weatherSpeed;
        double dayCycle = Math.floorMod(time, 24000L) / 24000.0;
        // +.15 aligns day 0 with spring instead of deep winter.
        double annual = (Math.floorMod(day, 48L) + dayCycle) / 48.0 + .15;
        // Season label follows the same +.15 phase as the temperature curve below,
        // otherwise summer would be displayed while the air is still spring-cool.
        int season = (int) ((Math.floor(annual * 4.0) + s.seasonOffset) % 4);
        int dayInSeason = (int) Math.floorMod(day, 12L) + 1;

        // Spring mild, summer warm, autumn cool, winter cold.
        double seasonal = 11.0 + 13.0 * Math.sin(TAU * (annual - .10 + s.seasonOffset * .25));
        double dayNight = 5.0 * Math.cos(TAU * (dayCycle - .34));
        double geographic = 1.6 * Math.sin(x / 570.0) - 1.9 * Math.cos(z / 670.0);
        double variability = 2.8 * Math.sin(days * .68 + x / 1100.0 + z / 2400.0);
        double biomeAdjustment = clamp((biomeTemp - .8) * 13.0, -16, 20);
        // Approximate environmental lapse rate: 0.65 degrees per 100 vertical blocks.
        double altitude = clamp((y - 70.0) * -.0065, -2.0, 7.0);
        double t2 = seasonal + dayNight + geographic + variability + biomeAdjustment + altitude + s.temperatureOffset;

        // Shared synoptic weather: lows/highs, curved warm/cold fronts and
        // horizontally rotating wind. Same field is sampled on all map layers.
        SynopticSystems.Field syn = SynopticSystems.sample(x,z,days);
        double front = syn.frontalLift();
        double envelope = Math.max(syn.moisture()*.74, syn.cyclone()*.23);
        // Pressure systems are actual weather drivers. Calm dry air descends in highs.
        double highDry = clamp((syn.anticyclone()-.16)/.72,0,1);
        boolean winterHigh = season == 3 && syn.inversion() > .50;
        if (winterHigh) t2 -= 3.8*syn.inversion();
        else t2 += 3.1*syn.anticyclone();
        double instability = clamp(.36 + .26 * Math.sin(days * .22 + x / 1600.0)
                + .16 * Math.cos(z / 1300.0 + days * .37)
                + syn.shear()*.18 - syn.anticyclone()*.3, 0, 1);
        double direction = Math.atan2(syn.vz(),syn.vx());
        double wx = Math.cos(direction), wz = Math.sin(direction);
        // Shared storm cells drive weather, the cloud structures and the radar.
        WeatherCells.Field cells = WeatherCells.sample(x, z, days);
        envelope = Math.max(envelope, cells.cloud() * .62);
        // Strong anticyclones suppress random background convective cells.
        double suppression = 1.0 - .98*highDry;
        // Exception: winter inversions can trap fog and low stratus under a high.
        double stratus = winterHigh ? .57*syn.inversion():0;
        double frequency = s.stormFrequency / 100.0 * SoftCloudMath.experienceScale(s.weatherExperience);
        double strength = s.stormStrength / 100.0;
        double storm = clamp(Math.max(cells.storm()*frequency*suppression, front * (.36 + instability * .28) * Math.sqrt(frequency)) * strength, 0, 1);
        // Discrete convective cores and broad stratiform shields share pressure fronts.
        double postShowers = syn.postFront()*(.3+.7*Math.pow(Math.sin(x/135.0+days*4)*Math.cos(z/190.0-days*3),2));
        double mmh = clamp((cells.rain() * suppression * (.42 + instability * .58) * frequency
                + Math.pow(front, 1.45) * (16+17*syn.moisture())
                + syn.cyclone()*syn.moisture()*5 + syn.warm()*15 + postShowers*20 - .4) * strength * suppression, 0, 150);
        double cloud = clamp(.12 + .70 * Math.max(envelope, front)
                + .26 * cells.cloud()*suppression + .15 * storm + stratus + postShowers*.35
                + .09 * Math.sin(days * .51 + x / 900.0), .03, 1);
        if (highDry > .05 && !winterHigh) cloud=clamp(cloud*(1-.95*highDry),.015,1);
        // A slowly evolving gust field, coherent across nearby world positions;
        // the higher-frequency term makes squalls breathe rather than stay constant.
        double gustPulse = s.windGusts ? (.73 + .23 * Math.sin(days * 13.0 + x / 220.0 + z / 330.0)
                + .13 * Math.sin(days * 38.0 + x / 110.0)
                + .12 * Math.sin(days * 240.0 + x / 190.0 - z / 170.0)) : 1.0;
        double gust = s.windGusts ? clamp((storm*39 + front*19 + cells.gustFront()*32) * gustPulse,0,85) : 0;
        double windKmh = Math.hypot(syn.vx(),syn.vz()) + gust;
        if(s.manualWind) {
            // Meteorological direction: heading FROM a bearing clockwise from north.
            double bearing=Math.toRadians(s.windDirectionDegrees);
            wx=-Math.sin(bearing);wz=Math.cos(bearing);
            windKmh=s.windKmh+gust;
        }
        windKmh=clamp(windKmh,0,s.manualWind?s.gustKmh:190);
        if(windKmh < .01) {wx=0;wz=0;}
        double humidity = clamp(.36 + .29 * cloud + .29*syn.moisture()
                + .15 * Math.sin(days * .27 + z / 800.0) - .2*syn.anticyclone(), .12, 1);
        double pressure = syn.pressure();

        // Morning radiation fog and shallow temperature inversions in calmer low valleys.
        double dawnDistance = Math.min(dayCycle, 1.0 - dayCycle);
        double dawn = Math.exp(-Math.pow(dawnDistance / .145, 2));
        double lowAltitude = clamp((122 - y) / 72.0, 0, 1);
        double calm = clamp((23 - windKmh) / 19, 0, 1);
        double fog = clamp((dawn * .84 + Math.max(0, humidity - .67) * .9 + (winterHigh ? syn.inversion()*.55:0)) *
                lowAltitude * calm * (1 - storm * .75), 0, 1);
        // Cloud geometry must remain above Y=100; bases adapt to storm/humidity.
        double cloudBase = Math.max(105, 129 + (1 - humidity) * 35 - storm * 20);

        StormEvents.Event forced = StormEvents.activeAt(x, z, time, s);
        if (forced != null) {
            double radius = forced.radius();
            double d = Math.hypot(x - forced.x(), z - forced.z());
            double field = Math.exp(-Math.pow(d / radius, 2) * 1.35);
            double stage = WeatherCells.lifecycle(.28 + forced.ageDays(time,s) / forced.lifeDays()*.72);
            double force = stage * field;
            storm = Math.max(storm, force);
            cloud = Math.max(cloud, Math.min(1,.2 + force * .82));
            mmh = Math.max(mmh, force * force * (forced.type() == WeatherCells.SHOWER ? 34 : 105));
        }
        if (s.mode == 1) mmh = 0;
        if (s.mode == 2) {
            mmh = s.precipitationMmH;
            cloud = Math.max(cloud, mmh > 0 ? .75 : .2);
            storm = Math.max(storm, mmh >= 40 ? mmh / 110.0 : 0);
        }
        int kind;
        if (s.mode == 2 && s.precipitationType != 0) kind = switch (s.precipitationType) {
            case 2 -> 1; case 3 -> 3; case 4 -> 4; default -> 0;
        };
        else if (t2 < -.5) kind = 1;
        else if (t2 < 1.8) kind = storm > .48 ? 3 : 2;
        else if (storm > .85 && mmh > 28 && instability > .65) kind = 4;
        else kind = 0;
        return new Weather(t2, wx, wz, windKmh, mmh, cloud, kind == 1,
                season, dayInSeason, fog, storm, front, humidity, pressure, cloudBase, kind);
    }

    private static double hash(long x, long z, int salt) {
        long h = x * 341873128712L ^ z * 132897987541L ^ salt * 2177342783L;
        h ^= h >>> 30; h *= -4658895280553007687L;
        h ^= h >>> 27; h *= -7723592293110705685L;
        h ^= h >>> 31;
        return (h >>> 11) * 0x1.0p-53;
    }
    public static double wrap(double x, double period) { return x - Math.floor(x / period + .5) * period; }
    public static double clamp(double x, double lo, double hi) { return Math.max(lo, Math.min(hi, x)); }
}
