# Atmosphere 1.1.8 – Gewitterzellen

**Fabric 1.21.1 · Minecraft 1.21.1 · Java 21 · Quellcode aus Atmosphere 1.1.7**

## Was in 1.1.8 geändert wurde

- Starke Gewitterzellen haben jetzt eine räumlich begrenzte Böenfront vor dem Kern. Sie wächst erst während der Reifephase und nutzt die vorhandene Windböen-Einstellung.
- Der Niederschlagskern liegt leicht hinter dem Aufwind. Wolken, Regen und Wind treffen deshalb nicht mehr exakt am selben Ort zusammen.
- Das Regenfeld bleibt Teil des gemeinsamen Modells und erscheint dadurch auch auf dem Radar.
- Zellen erhalten gebogene, ungleichmäßige Regenbänder mit Lücken und Nebenbereichen; Squall Lines sind abschnittsweise unterbrochen. Die Muster sind räumlich glatt und pro Zelle stabil.
- Der eigenständige Gewitter-Smoke-Test prüft nun die Grenzen des neuen Böenfelds.

Diese Version verändert keine Blöcke und erzeugt keine schädigenden Blitz-Entities. Ein echter Fabric-Build und Test im Spiel bleiben erforderlich.

## Was in 1.1.7 geändert wurde

### Regenbogen sichtbar gemacht (Fehler aus 1.1.6)

Der Bogen wurde in 1.1.6 berechnet, aber nie gezeichnet. Drei Ursachen:

1. **Falsche Matrix:** `renderSky` baut seine eigenen Matrizen aus der Projektionsmatrix. Ein frisches `new MatrixStack()` erzeugte Vertices weit außerhalb des Frustums – der Bogen wurde emittiert und dann weggecullt. Jetzt wird die Identitätsmatrix benutzt, weil `RenderLayer.getEntityTranslucent` die View-Rotation ohnehin selbst anwendet.
2. **Puffer nie geflusht:** `VertexConsumerProvider.Immediate.draw()` fehlte – der Batch verfiel am Frameende.
3. **Schwellen zu streng:** Regen unter 1,2 mm/h ergab 0, und 75 % Bewölkung (normal bei Regen!) drückte die Sichtbarkeit auf 0,45. Jetzt: Regen ab 0,5 mm/h, Bewölkung dämpft statt auszuschalten, Mindestklarheit 0,22.

Zusätzlich: Bänder **heller** (Alpha 0,88 statt 0,62), **breiter** (2,6° statt 1,9°) und der Bogen weiter weg (340 statt 220 Blöcke), damit er nicht hinter Gelände verschwindet.

### Wolken: Variante 1 + 2

- **Variante 1 – Flächennormale:** Helligkeit wird jetzt **pro Quad** aus der tatsächlichen Flächennormale der drei verschobenen Eckpunkte berechnet, nicht mehr pro Vertex aus der glatten Kugelnormale. Das beseitigt die harten, kastenförmigen Facetten aus 1.1.6.
- **Variante 2 – Selbstschattierung:** Ein Beer-Lambert-artiger Test läuft in drei Schritten von jedem Quad in Richtung Sonne durch das Ellipsoid. Punkte, deren Pfad im Inneren bleibt, werden verdunkelt (`occlusion`, gedeckelt auf 0,85). Ergebnis: echte Unterseite statt flacher Fläche.
- Helligkeitsbereich gemessen: **0,20 bis 0,96** über 126 Test-Quads – sichtbarer Verlauf, keine Ausreißer.
- Die Sonnenrichtung folgt jetzt dem Tageszyklus (`RENDER_SUN_AZIMUTH`), nicht mehr einer festen Konstante.

### Test-Infrastruktur

- `tools/stubs` enthält jetzt `VertexConsumer`, `OverlayTexture`, `MatrixStack` und `Vec3d`, damit `Rainbow.java` (Mathematik **und** Geometrie) ohne Fabric kompiliert und getestet werden kann. Der Fehler aus 1.1.6 wäre damit sofort aufgefallen.
- `RainbowMathTest` um zwei Fälle erweitert: leichter Regen unter normaler Bewölkung muss sichtbar sein, und stärkerer Regen darf den Bogen nicht schwächen.

## Was in 1.1.6 geändert wurde

- **Nebel zähmen:** Die Sichtweite war bei normalem Regen auf ~60 Blöcke zusammengefallen (`195 − 166·combined`), bei Starkregen auf 29. Neue Kurve `320 − 190·combined`: bei mittlerem Regen **~206 Blöcke**, der Horizont bleibt lesbar. Regennebel setzt erst ab 25 mm/h ein (vorher 12) und die Mindest-Sichtweite liegt bei 48 statt 12 Blöcken.
- **Wolkenschatten dunkeln jetzt ab:** Die Bodenschatten erschienen als helle Rechtecke, weil eine weiße Textur mit dunklem Tint über helles Gras geblendet wurde. `cloud_shadow.png` ist jetzt eine **schwarze Alpha-Maske** mit weichem Wolkenrand, gerendert über `getEntityTranslucentCull` – Blending kann damit nur abdunkeln. Weniger Schatten (12 statt 18), dafür sichtbar.
- **Regen fällt sichtbar:** Lebensdauer 30 → 22 Ticks, Schwerkraft 0,55 → 1,15, Fallgeschwindigkeit −0,48 → −0,85 (−1,25 bei Starkregen), Streifen länger (0,17–0,36 statt 0,10–0,26). Tropfen schweben nicht mehr.
- **Regenbogen (neu):** Prozeduraler Bogen aus farbigen Vertices, kein Asset, keine Weltinteraktion. Primärbogen bei 42°, sekundärer bei 51° mit umgekehrter Farbfolge. Erscheint nur bei Sonnenhöhe 3–52°, Regen über 1,2 mm/h und nicht vollständig bedecktem Himmel. Schalter im Menü unter **Grafik → Regenbogen**.
- **Neuer Test:** `tools/RainbowMathTest.java` prüft Sonnenhöhe, Sichtbarkeitsfenster (Nacht/Hohersonne/Trockenheit/Bedeckung), Monotonie im Regen, Farbtabellen und Alpha-Grenzen.

### Technische Notiz zum Regenbogen

Der Bogen wird in `mixin/RainbowRendererMixin.java` am Ende von `WorldRenderer.renderSky` gezeichnet, also im **eigenen** Vertex-Buffer des Renderers. Das ist bewusst so: ein RenderLayer aus einem fremden Event-Handler anzufordern kann außerhalb des Render-Threads werfen.

## Was in 1.1.5 geändert wurde

- **Nasse Fläche statt Dauer-Trockenheit:** Über 20.000 × 20.000 Blöcke waren in 1.1.4 nur **7,3 %** der Fläche nass, an einzelnen Tagen unter 5 %. Frontregen greift jetzt früher (`pow(front, 1.45)` statt `1.65`) und die Regenuntergrenze liegt bei −0,4 statt −1,6 mm/h. Ergebnis: **11–17 % nasse Fläche**, Spitzenregen unverändert begrenzt (Messung: max. 72 mm/h, Modellgrenze 150).
- **Jahreszeiten stimmen jetzt mit der Temperatur überein:** Tag 0 war vorher mitten im Winter (−1,2 °C), obwohl „Frühling" angezeigt wurde. Die Jahreskurve ist um +0,15 verschoben, das Saison-Label folgt derselben Phase. Tag 0 ist jetzt mild (18,2 °C), Sommer nie unter 18,9 °C, Winter nie über 7,4 °C.
- **Wolkenschatten sehen wie Wolken aus:** `cloud_shadow.png` war eine vollflächig weiße Kachel – die Bodenschatten erschienen als Rechtecke. Neu: 128×128-Textur mit 4 Oktaven Wertrauschen und weichem Alpha-Rand. Zusätzlich ein Quad pro Wolke statt eines 4×4-Rasters, max. 12 statt 18 Schatten, dunklerer Blaugrau-Tint (12/18/28).
- **Regenpartikel neu:** `rain_streak.png` war eine 2-Pixel-Linie. Neu: 16×32-Streifen mit transparentem Kopf, Tropfenkopf unten und weichem Alpha-Rand. Partikel schlanker (0,10–0,26 statt 0,14–0,39), Alpha 0,74 statt 0,87, kühlere Farbe. Spritzer häufiger (jeder 7. statt 12. Treffer).
- **Sound-Streaming korrigiert:** Alle 34 Clips waren mit `stream: true` markiert, obwohl sie nur 6 Sekunden lang sind. Streaming kostet dort nur I/O und Thread-Zeit; jetzt `stream: false`.
- **HUD zeigt die richtige Version:** Die Wetteranzeige behauptete weiterhin „ATMOSPHERE 1.1.3".
- **Neuer Regressionstest:** `tools/WetAreaAndSeasonTest.java` prüft nasse Fläche (9–30 %), Regenobergrenze, Saison-Label gegen Temperatur und den Tag-0-Start.

## Was in 1.1.4 geändert wurde

- **Hochdruck 0–200 % und Tiefdruck 0–200 % separat:** Die Stärke wirkt auf das gemeinsame synoptische Druckfeld sowie Hoch-/Tief-Einfluss, Fronten und rotierenden Wind. Dadurch wirken die Einstellungen auf Niederschlag, Wolken und Radar, statt nur die Regenwahrscheinlichkeit zu verändern. **100 % ist das alte Verhalten aus 1.1.3.**
- **Lebensdauer Kurz / Normal / Lang:** Natürlich erzeugte Druckgebiete halten ungefähr 70 %, 100 % oder 155 % der bisherigen Dauer. Nicht die Minecraft-Tageslänge oder die bereits manuell gesetzten Hochs und Tiefs werden verändert.
- **Blitzhelligkeit 25–200 % / Blitzgröße 25–200 %:** Getrennt von der bestehenden Blitzhäufigkeit. Optische Lichtimpulse sind begrenzt; keine echten Feuer-/Schadensblitze.
- **Donnerlautstärke 0–200 %** unabhängig von der Blitzhäufigkeit; Ausgabewerte begrenzt.
- **Windton 0–100 % (Standard 40 %):** Eine sanfte Brise ist bereits ab etwa 2 km/h hörbar; Lautstärke blendet weich ein und wächst mit der Windgeschwindigkeit. Es werden bestehende Audio-Clips einschließlich `wind.ogg`, `wind_light.ogg`, `wind_base.ogg`, `snow_wind.ogg` und der stärkeren Böen-Clips situationsabhängig genutzt. Die vorhandenen 34 Audioclips bleiben erhalten, werden **nicht** gleichzeitig abgespielt.
- **Menü:** Neue Seite **Druck** mit Hoch/Tief-Stärke, Lebensdauer und bisherigen Druck-/Gewittersteuerungen. Auf **Sound**: Blitz-Helligkeit, Blitz-Größe, Donner- und Wind-Lautstärke. Wetterradar verwirft zwischengespeicherte Druckfelder, wenn diese Einstellungen verändert werden.
- **Vorhandenes unverändert:** Watteartige Cloud Engine 7.0, stabile Wolken, Radar, Fronten, Schneeakkumulation, Sounddateien, Gewitter-Soundkulisse, sichere Funnel Clouds, Grafikprofile, manuelle Wetterfunktionen.

### Bedienung und Werte

Alle neuen Regler sind zyklische Schaltflächen im Atmosphere-Menü. Ein Klick erhöht den Wert (je 25 Prozentpunkte bei Druck, Blitz und Donner; Wind je 10); am Höchstwert beginnt die Einstellung wieder beim Mindestwert. Die Werte werden unter `config/atmosphere.properties` gespeichert, ältere Dateien bleiben kompatibel. **Standardwerte:** Hoch 100 %, Tief 100 %, Dauer Normal, Blitz-Helligkeit 100 %, Blitzgröße 100 %, Donner 100 %, Windton 40 %.

**Tipp:** Für kräftige, aber plausible Wetterlagen: Hoch 125 %, Tief 150 %, Dauer Lang; Blitzhelligkeit 125 %, Größe 125 %, Windton 50 %. Extreme Einstellungen wie 200 % können deutlich mehr Niederschlag/kräftigere Winde erzeugen. Änderungen betreffen clientseitige Einzelspieler-Wetterberechnungen, nicht Server mit synchronisiertem globalem Wetter.

## Bauen unter Windows

1. ZIP entpacken und Eingabeaufforderung im Ordner `atmosphere-java-1.1.8` öffnen.
2. Java 21 installieren (die Fabric-/Minecraft-Abhängigkeiten lädt Gradle beim ersten Build selbst).
3. Bauen – entweder per Doppelklick auf `BUILD_WINDOWS.bat` oder im Terminal:

   ```bat
   gradle clean build
   ```

   Der Pfad in `BUILD_WINDOWS.bat` muss auf die eigene Gradle-Installation zeigen.

4. Die fertige Mod liegt bei erfolgreichem Build unter `build\libs\atmosphere-1.1.8.jar`. Lege nur **eine** Atmosphere-JAR in `mods/`, zusammen mit Fabric API. Erstelle vor dem ersten Spielstart ein Backup deiner Welt.

## Entwicklungsprüfung und Einschränkungen

Die mitgelieferten `tools/` sind eigenständige Java-Tests für die Wettermodelle; die Minecraft-/Fabric-API und das tatsächliche Audio-Rendering können nur mit vollständigem Fabric-Build bzw. im Spiel getestet werden. Ein regulärer Minecraft-Start kann in dieser Umgebung nicht garantiert werden. Die neuen Schalter wurden so angelegt, dass die bisherigen 1.1.3-Standardeinstellungen (bis auf den bereits bei wenig Wind hörbaren Windton) erhalten bleiben.

Alle Tests laufen ohne Minecraft. Kurzbefehl (Java 21, aus dem Projektordner):

```bat
javac -d build-test -encoding UTF-8 tools/stubs/**/*.java src/main/java/dev/atmosphere/{WeatherModel,WeatherTuning,WeatherCells,SoftCloudMath,StormEvolution,CloudField,SynopticSystems,SnowRates}.java
javac -cp build-test -d build-test -encoding UTF-8 tools/*.java
java -cp build-test WetAreaAndSeasonTest
java -cp build-test RainbowMathTest
```

**Empfohlener Funktionstest:** Erst mit normalen Druckeinstellungen starten, dann ein Hoch und Tief mit 150 % vergleichen, Radar schließen und neu öffnen, Windton bei 5–15 km/h mit manuellem Wind testen, Blitzgröße/Helligkeit und Donner getrennt einstellen. Bei Fehlern die erste `error:`-Meldung aus dem Build oder die `latest.log` mitschicken.
