import dev.atmosphere.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import javax.imageio.ImageIO;
import java.io.File;

/** Diagnostic projection of the exact math surfaces; NOT a Minecraft screenshot. */
public final class CloudShapePreview {
 record Face(int[] x,int[] y,double[] depth,double[] shade){}
 interface Surface {CloudGeometry.Point point(int j,int i);}
 static void mesh(ArrayList<Face> faces,Surface s,int rows,int cols,double ox,double oy,double scale,
                  double shiftX,double shiftZ){
  var p=new CloudGeometry.Point[rows+1][cols+1];
  for(int j=0;j<=rows;j++)for(int i=0;i<=cols;i++)p[j][i]=s.point(j,i);
  for(int j=0;j<rows;j++)for(int i=0;i<cols;i++){
   int[] xx=new int[4],yy=new int[4];double[] depth=new double[4],shade=new double[4];
   for(int k=0;k<4;k++){
    var v=p[j+(k>=2?1:0)][i+(k==1||k==2?1:0)];
    double x=v.x()+shiftX,z=v.z()+shiftZ,d=-x*.6+z*.8;
    xx[k]=(int)(ox+(x*.8+z*.6)*scale);yy[k]=(int)(oy-v.y()*scale+d*scale*.18);
    depth[k]=d;shade[k]=.58+.35*Math.max(0,v.nx()*.5+v.ny()*.7-v.nz()*.5);
   }
   faces.add(new Face(xx,yy,depth,shade));
  }
 }
 static double cross(double x,double y,double ax,double ay,double bx,double by){return (x-bx)*(ay-by)-(ax-bx)*(y-by);}
 static void triangle(BufferedImage image,double[] buffer,Face f,int a,int b,int c){
  double area=cross(f.x[a],f.y[a],f.x[b],f.y[b],f.x[c],f.y[c]);if(Math.abs(area)<1e-9)return;
  int minX=Math.max(0,Math.min(f.x[a],Math.min(f.x[b],f.x[c]))),maxX=Math.min(image.getWidth()-1,Math.max(f.x[a],Math.max(f.x[b],f.x[c])));
  int minY=Math.max(0,Math.min(f.y[a],Math.min(f.y[b],f.y[c]))),maxY=Math.min(image.getHeight()-1,Math.max(f.y[a],Math.max(f.y[b],f.y[c])));
  for(int y=minY;y<=maxY;y++)for(int x=minX;x<=maxX;x++){
   double u=cross(x+.5,y+.5,f.x[b],f.y[b],f.x[c],f.y[c])/area;
   double v=cross(x+.5,y+.5,f.x[c],f.y[c],f.x[a],f.y[a])/area,w=1-u-v;
   if(u<0||v<0||w<0)continue;
   double d=u*f.depth[a]+v*f.depth[b]+w*f.depth[c];int at=y*image.getWidth()+x;
   if(d>=buffer[at])continue;buffer[at]=d;
   int shade=Math.max(0,Math.min(250,(int)(205*(u*f.shade[a]+v*f.shade[b]+w*f.shade[c]))));
   image.setRGB(x,y,new Color(shade,shade,shade+5).getRGB());
  }
 }
 public static void main(String[] args)throws Exception{
  var image=new BufferedImage(1100,520,BufferedImage.TYPE_INT_RGB);var g=image.createGraphics();
  g.setColor(new Color(136,177,220));g.fillRect(0,0,1100,520);
  var faces=new ArrayList<Face>();int rows=44,cols=80;
  mesh(faces,(j,i)->CloudGeometry.point(42,j*Math.PI/rows,i*Math.PI*2/cols,120,100,95,130,.8,.6,0),
    rows,cols,175,430,1,0,0);
  mesh(faces,(j,i)->CloudGeometry.point(42,j*Math.PI/rows,i*Math.PI*2/cols,150,120,25,240,.8,.6,1),
    rows,cols,175,430,1,0,0);
  mesh(faces,(j,i)->{
   var p=SupercellGeometry.point(42,j/(double)rows,i*Math.PI*2/cols,270,130,355,1,0,.8,.6);
   return new CloudGeometry.Point(p.x(),p.y(),p.z(),p.nx(),p.ny(),p.nz());
  },rows,cols,710,465,.58,0,0);
  double[] buffer=new double[1100*520];java.util.Arrays.fill(buffer,Double.POSITIVE_INFINITY);
  for(var f:faces){triangle(image,buffer,f,0,1,2);triangle(image,buffer,f,0,2,3);}
  g.setColor(Color.BLACK);g.drawString("1.2.4 mathematische Formvorschau - KEIN Ingame-Bild / ohne Spieltextur und Transparenz",15,20);
  g.drawString("Trockene Quellwolke / Schichtwolke",50,490);g.drawString("Wall Cloud, Basis, Aufwind und Amboss: EINE Oberflaeche",485,490);
  g.dispose();ImageIO.write(image,"png",new File(args[0]));
 }
}
