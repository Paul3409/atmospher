package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import java.util.ArrayList;
import java.util.List;

/** Bounded snapshot for sound and other near-player tornado effects. */
public final class TornadoTracker {
    public record Active(long id,double x,double z,double width,double activity) {}
    private static ClientWorld world;
    private static long lastTick=Long.MIN_VALUE;
    private static int chance=-1,speed=-1;
    private static final List<Active> active=new ArrayList<>();
    private TornadoTracker() {}
    public static List<Active> nearby(MinecraftClient client,AtmosphereSettings s) {
        if(client.world==null||client.player==null||client.world.getRegistryKey()!=World.OVERWORLD) {
            active.clear();world=null;return active;
        }
        long tick=client.world.getTime();
        if(world==client.world&&chance==s.tornadoChance&&speed==s.weatherSpeed
                &&tick>=lastTick&&tick-lastTick<4)return active;
        world=client.world;lastTick=tick;chance=s.tornadoChance;speed=s.weatherSpeed;active.clear();
        if(chance==0||!s.customClouds)return active;
        long time=world.getTimeOfDay();double days=time/24000.0*s.weatherSpeed;
        int gx=(int)Math.floor((client.player.getX()-days*80)/690);
        int gz=(int)Math.floor((client.player.getZ()-days*170)/690);
        for(int j=-3;j<=3;j++)for(int i=-3;i<=3;i++) {
            var c=WeatherCells.cell(gx+i,gz+j,days);
            if(c.type()==WeatherCells.SUPERCELL&&c.rotation()>.22)
                add(c.id(),c.x(),c.z(),c.radius(),c.growth(),c.phase(),c.windX(),c.windZ(),s);
        }
        for(var e:StormEvents.events())if(e.type()==WeatherCells.SUPERCELL&&e.ageDays(time,s)<e.lifeDays()) {
            double phase=.28+Math.min(.999,e.ageDays(time,s)/e.lifeDays())*.72;
            long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());double angle=StormEvolution.manualAngle(seed);
            add(seed,e.x(),e.z(),e.radius(),WeatherCells.lifecycle(phase),phase,Math.cos(angle),Math.sin(angle),s);
        }
        return active;
    }
    private static void add(long seed,double x,double z,double radius,double growth,double phase,
                             double wx,double wz,AtmosphereSettings s) {
        double activity=StormEvolution.tornadoActivity(seed,growth,phase,s.tornadoChance);
        if(activity<.02)return;
        double scale=radius*(.22+.36*growth)*.36*growth*.50;
        double width=2*scale*TornadoGeometry.radiusProfile(TornadoGeometry.type(seed),1,phase);
        active.add(new Active(seed,x+.05*radius*wx+.35*radius*wz,
                z+.05*radius*wz-.35*radius*wx,width,activity));
    }
}
