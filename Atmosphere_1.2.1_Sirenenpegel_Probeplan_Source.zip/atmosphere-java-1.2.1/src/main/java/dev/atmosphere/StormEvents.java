package dev.atmosphere;

import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

import java.util.ArrayList;
import java.util.List;

/** Save multiple manual weather cells in the existing v0.6 singleplayer save key.
 * Legacy one-storm saves are imported, new saves store a bounded list. Weather
 * simulation is deterministic; persistent state never creates damaging entities.
 */
public final class StormEvents extends PersistentState {
    public static final int MAX_EVENTS = 12;
    public record Event(int type,double x,double z,long started,double radius,double lifeDays) {
        public double ageDays(long worldTime, AtmosphereSettings s) {
            return Math.max(0,(worldTime-started)/24000.0*s.weatherSpeed);
        }
        public double phase(long worldTime, AtmosphereSettings s) {
            return .04+.90*Math.min(1,ageDays(worldTime,s)/Math.max(.1,lifeDays));
        }
    }
    private final List<Event> saved=new ArrayList<>();
    private static volatile List<Event> snapshot=List.of();
    private static final Type<StormEvents> TYPE=new Type<>(
            StormEvents::new,StormEvents::fromNbt,DataFixTypes.SAVED_DATA_MAP_DATA);
    private StormEvents() { }
    public static StormEvents of(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE,"atmosphere_storms_v06");
    }
    private static Event parse(NbtCompound nbt) {
        int type=nbt.getInt("Type");
        if(type<WeatherCells.SHOWER || type>WeatherCells.SQUALL) return null;
        double x=nbt.getDouble("X"), z=nbt.getDouble("Z");
        double r=nbt.getDouble("Radius"), life=nbt.getDouble("Life");
        if(!Double.isFinite(x)||!Double.isFinite(z)||!Double.isFinite(r)||!Double.isFinite(life)) return null;
        return new Event(type,x,z,nbt.getLong("Start"),Math.max(50,Math.min(900,r)),Math.max(.1,Math.min(6,life)));
    }
    private static StormEvents fromNbt(NbtCompound nbt,RegistryWrapper.WrapperLookup registry) {
        StormEvents state=new StormEvents();
        if(nbt.contains("Events",NbtElement.LIST_TYPE)) {
            NbtList list=nbt.getList("Events",NbtElement.COMPOUND_TYPE);
            for(int i=0;i<list.size() && state.saved.size()<MAX_EVENTS;i++) {
                Event e=parse(list.getCompound(i)); if(e!=null) state.saved.add(e);
            }
        } else if(nbt.contains("Type")) {
            // Backward compatible with the single saved storm from Alpha 0.6.
            Event e=parse(nbt); if(e!=null) state.saved.add(e);
        }
        return state;
    }
    private static NbtCompound encode(Event event) {
        NbtCompound nbt=new NbtCompound();
        nbt.putInt("Type",event.type()); nbt.putDouble("X",event.x()); nbt.putDouble("Z",event.z());
        nbt.putLong("Start",event.started()); nbt.putDouble("Radius",event.radius());
        nbt.putDouble("Life",event.lifeDays());
        return nbt;
    }
    @Override public NbtCompound writeNbt(NbtCompound nbt,RegistryWrapper.WrapperLookup registry) {
        NbtList list=new NbtList();
        for(Event e:saved) list.add(encode(e));
        nbt.put("Events",list);
        return nbt;
    }
    public static void sync(ServerWorld world) {
        StormEvents state=of(world);
        if(state.saved.removeIf(e->e.ageDays(world.getTimeOfDay(),AtmosphereSettings.get())>=e.lifeDays()))
            state.markDirty();
        snapshot=List.copyOf(state.saved);
    }
    public static void spawn(MinecraftServer server,int kind,double x,double z) {
        if(server==null || kind<1 || kind>5 || !Double.isFinite(x) || !Double.isFinite(z)) return;
        server.execute(()->{
            ServerWorld world=server.getOverworld(); if(world==null)return;
            StormEvents state=of(world);
            double radius=kind==WeatherCells.SQUALL?440:kind==WeatherCells.SUPERCELL?270:205;
            if(state.saved.size()>=MAX_EVENTS)state.saved.remove(0);
            state.saved.add(new Event(kind,x,z,world.getTimeOfDay(),radius,
                    kind>=WeatherCells.SUPERCELL?1.8:1.1));
            state.markDirty();snapshot=List.copyOf(state.saved);
        });
    }
    public static void clear(MinecraftServer server) {
        if(server==null)return;
        server.execute(()->{
            ServerWorld world=server.getOverworld();if(world==null)return;
            StormEvents state=of(world);state.saved.clear();state.markDirty();snapshot=List.of();
        });
    }
    public static Event activeAt(double x,double z,long time,AtmosphereSettings settings) {
        Event best=null; double power=0;
        for(Event e:snapshot) {
            double age=e.ageDays(time,settings);
            if(age>=e.lifeDays())continue;
            double d=Math.hypot(x-e.x(),z-e.z())/e.radius();
            if(d>3.5)continue;
            double contribution=WeatherCells.lifecycle(e.phase(time,settings))*Math.exp(-d*d);
            if(contribution>power){power=contribution;best=e;}
        }
        return best;
    }
    public static List<Event> events(){return snapshot;}
    /** Most recently created active storm, retained for old UI consumers. */
    public static Event current(){return snapshot.isEmpty()?null:snapshot.get(snapshot.size()-1);}
    public static void reset(){snapshot=List.of();}
}
