package dev.atmosphere.siren;

import dev.atmosphere.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

final class SirenWeather {
    private SirenWeather(){}
    static boolean danger(ServerWorld world,BlockPos pos,int range,int mask){
        if(world.getRegistryKey()!=World.OVERWORLD)return false;
        var s=AtmosphereSettings.get();long time=world.getTimeOfDay();
        int step=range/2;
        for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){
            var w=WeatherModel.sample(pos.getX()+i*step,pos.getZ()+j*step,time,s);
            if(((mask&1)!=0&&w.windKmh()>=65)||((mask&2)!=0&&w.precipitationKind()==4&&w.rainMmH()>5))return true;
        }
        if((mask&4)==0||s.tornadoChance==0||!s.customClouds)return false;
        double days=time/24000.0*s.weatherSpeed;
        int gx=(int)Math.floor((pos.getX()-days*80)/690),gz=(int)Math.floor((pos.getZ()-days*170)/690);
        for(int j=-3;j<=3;j++)for(int i=-3;i<=3;i++){
            var c=WeatherCells.cell(gx+i,gz+j,days);
            if(c.type()==WeatherCells.SUPERCELL&&c.rotation()>.22&&Math.hypot(c.x()-pos.getX(),c.z()-pos.getZ())<range
                    &&StormEvolution.tornadoActivity(c.id(),c.growth(),c.phase(),s.tornadoChance)>.65)return true;
        }
        for(var e:StormEvents.events())if(e.type()==WeatherCells.SUPERCELL&&e.ageDays(time,s)<e.lifeDays()){
            double phase=.28+Math.min(.999,e.ageDays(time,s)/e.lifeDays())*.72;
            long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());
            if(Math.hypot(e.x()-pos.getX(),e.z()-pos.getZ())<range&&StormEvolution.tornadoActivity(seed,
                    WeatherCells.lifecycle(phase),phase,s.tornadoChance)>.65)return true;
        }return false;
    }
}
