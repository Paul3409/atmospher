package dev.atmosphere;

/** One connected updraft and anvil surface, rooted at the existing hook/Wall Cloud. */
public final class SupercellGeometry {
    private SupercellGeometry() {}
    public record Point(double x,double y,double z,double nx,double ny,double nz) {}
    private static double profile(double t,double growth) {
        double anvil=1.28*StormEvolution.smooth(.45,.85,growth)*Math.exp(-Math.pow((t-.90)/.085,2));
        return (.52-.19*t+anvil)*(.35+.65*StormEvolution.smooth(0,.07,t))
                *Math.sqrt(Math.max(0,1-StormEvolution.smooth(.96,1,t)));
    }
    public static Point point(long seed,double t,double angle,double radius,double base,double height,
                              double wx,double wz,double jetX,double jetZ) {
        return point(seed,t,angle,radius,base,height,wx,wz,jetX,jetZ,1);
    }
    public static Point point(long seed,double t,double angle,double radius,double base,double height,
                              double wx,double wz,double jetX,double jetZ,double growth) {
        double jet=Math.max(1e-6,Math.hypot(jetX,jetZ));
        double lean=height*.32*t*t;
        double cx=(.05*wx+.35*wz)*radius+lean*jetX/jet;
        double cz=(.05*wz-.35*wx)*radius+lean*jetZ/jet;
        double noise=1+.045*Math.sin(angle*6+t*9+seed*.001)+.025*Math.cos(angle*11-t*17);
        double r=radius*profile(t,growth)*noise;
        double slope=radius*(profile(Math.min(1,t+.002),growth)-profile(Math.max(0,t-.002),growth))/(.004*Math.max(1,height));
        double length=Math.sqrt(1+slope*slope);
        return new Point(cx+Math.cos(angle)*r,base+8+height*t,cz+Math.sin(angle)*r,
                Math.cos(angle)/length,-slope/length,Math.sin(angle)/length);
    }
}
