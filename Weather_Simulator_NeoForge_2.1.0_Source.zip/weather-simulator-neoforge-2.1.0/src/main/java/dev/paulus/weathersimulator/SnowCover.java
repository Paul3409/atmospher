package dev.paulus.weathersimulator;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

import java.util.HashMap;
import java.util.ArrayList;
import java.nio.file.Files;
import java.nio.file.Path;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.util.Map;

/** Visual snow depth that accumulates below 0 °C and melts at two temperature-dependent rates. */
@EventBusSubscriber(modid=WeatherSimulatorMod.MOD_ID,value=Dist.CLIENT)
public final class SnowCover {
    private record Patch(int x,int y,int z,float depth){}
    private record SavedPatch(int x,int y,int z,float depth){}
    private static final Map<Long,Patch> PATCHES=new HashMap<>();private static Object level;private static long lastUpdate;
    private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();private static Path file;
    private static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath(WeatherSimulatorMod.MOD_ID,"textures/weather/snow_cover.png");
    private static final RenderType TYPE=RenderType.create("weather_simulator_snow_cover",DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP,VertexFormat.Mode.QUADS,8192,false,true,RenderType.CompositeState.builder().setShaderState(RenderStateShard.POSITION_COLOR_TEX_LIGHTMAP_SHADER).setTextureState(new RenderStateShard.TextureStateShard(TEXTURE,false,false)).setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY).setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST).setWriteMaskState(RenderStateShard.COLOR_WRITE).setCullState(RenderStateShard.NO_CULL).createCompositeState(false));
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        var mc=Minecraft.getInstance();if(mc.level==null||mc.player==null)return;
        if(level!=mc.level){save();level=mc.level;PATCHES.clear();lastUpdate=0;var directory=ZoneStore.worldDirectory();file=directory==null?null:directory.resolve("snow-cover.json");load();}
        if(!SimulatorConfig.ENABLED.get()||!SimulatorConfig.SNOW_COVER.get())return;long now=mc.level.getGameTime();if(now-lastUpdate<20)return;lastUpdate=now;
        int baseX=Math.floorDiv(mc.player.blockPosition().getX(),2)*2,baseZ=Math.floorDiv(mc.player.blockPosition().getZ(),2)*2;
        for(int dx=-32;dx<=32;dx+=2)for(int dz=-32;dz<=32;dz+=2){int x=baseX+dx,z=baseZ+dz,y=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,x,z);var ground=new BlockPos(x,y-1,z);if(!mc.level.hasChunkAt(ground)||!mc.level.getFluidState(ground).isEmpty()||!mc.level.canSeeSky(ground.above()))continue;
            var weather=WeatherModel.sample(x,y,z);double temperature=weather.temperature(y);long key=key(x,z);var old=PATCHES.get(key);float depth=old==null?0:old.depth;
            if(weather.kind(y)==WeatherModel.Kind.SNOW&&temperature<0)depth+=weather.intensity()*.075f*SimulatorConfig.SNOW_ACCUMULATION.get()/100f;
            else if(temperature>=0&&temperature<=1)depth-=.012f*SimulatorConfig.SLOW_MELT.get()/100f;
            else if(temperature>1)depth-=(float)(.055*(1+Math.min(3,(temperature-1)*.12))*SimulatorConfig.FAST_MELT.get()/100f);
            depth=Math.max(0,Math.min(1,depth));if(depth>.005f)PATCHES.put(key,new Patch(x,y,z,depth));else PATCHES.remove(key);
        }
        if(now%200==0)save();
    }
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||PATCHES.isEmpty()||!SimulatorConfig.SNOW_COVER.get())return;var mc=Minecraft.getInstance();var camera=event.getCamera().getPosition();var out=mc.renderBuffers().bufferSource().getBuffer(TYPE);var m=event.getPoseStack().last().pose();
        for(var patch:PATCHES.values()){double dx=patch.x-camera.x,dz=patch.z-camera.z;if(dx*dx+dz*dz>48*48)continue;float x=(float)dx,z=(float)dz,y=(float)(patch.y-camera.y+.015+patch.depth*.055);float a=.48f+.48f*patch.depth;
            out.addVertex(m,x-.05f,y,z-.05f).setColor(1f,1f,1f,a).setUv(0,0).setLight(0x00d000d0);out.addVertex(m,x+1.95f,y,z-.05f).setColor(1f,1f,1f,a).setUv(1,0).setLight(0x00d000d0);out.addVertex(m,x+1.95f,y,z+1.95f).setColor(1f,1f,1f,a).setUv(1,1).setLight(0x00d000d0);out.addVertex(m,x-.05f,y,z+1.95f).setColor(1f,1f,1f,a).setUv(0,1).setLight(0x00d000d0);
        }mc.renderBuffers().bufferSource().endBatch(TYPE);
    }
    private static long key(int x,int z){return ((long)x<<32)^(z&0xffffffffL);}
    private static void load(){if(file==null||!Files.isRegularFile(file))return;try(var reader=Files.newBufferedReader(file)){java.util.List<SavedPatch> saved=GSON.fromJson(reader,new TypeToken<java.util.List<SavedPatch>>(){}.getType());if(saved!=null)for(var p:saved)PATCHES.put(key(p.x,p.z),new Patch(p.x,p.y,p.z,p.depth));}catch(Exception e){WeatherSimulatorMod.error("Schneedecke konnte nicht geladen werden",e);}}
    private static void save(){if(file==null)return;try{Files.createDirectories(file.getParent());var saved=new ArrayList<SavedPatch>(PATCHES.size());for(var p:PATCHES.values())saved.add(new SavedPatch(p.x,p.y,p.z,p.depth));try(var writer=Files.newBufferedWriter(file)){GSON.toJson(saved,writer);}}catch(Exception e){WeatherSimulatorMod.error("Schneedecke konnte nicht gespeichert werden",e);}}
    private SnowCover(){}
}
