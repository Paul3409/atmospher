package dev.paulus.weathersimulator;

/** Pure manual resolver. It never creates, moves or changes weather by itself. */
public final class WeatherModel {
    public enum Kind { NONE,RAIN,SLEET,SNOW }
    public record Sample(boolean enabled,SimulatorConfig.PrecipitationMode mode,float intensity,double baseTemperature,double lapseRate,
                         int snowLine,int transition,double snowThreshold,double rainThreshold,int fogDensity,int fogStart,int fogEnd,
                         SimulatorConfig.WindDirection windDirection,double windSpeed,double gustStrength,int lightning,WeatherZone zone){
        public double temperature(double y){return baseTemperature-(y-64)*lapseRate/100.0;}
        public Kind kind(double surfaceY){
            if(!enabled||intensity<=0||mode==SimulatorConfig.PrecipitationMode.AUS)return Kind.NONE;
            return switch(mode){
                case REGEN->Kind.RAIN;case SCHNEEREGEN->Kind.SLEET;case SCHNEE->Kind.SNOW;
                case NACH_SCHNEEFALLGRENZE->{double half=transition*.5;yield surfaceY>snowLine+half?Kind.SNOW:surfaceY>=snowLine-half?Kind.SLEET:Kind.RAIN;}
                case NACH_TEMPERATUR->{double t=temperature(surfaceY);yield t<snowThreshold?Kind.SNOW:t<rainThreshold?Kind.SLEET:Kind.RAIN;}
                default->Kind.NONE;
            };
        }
        public String source(){return zone==null?"Global":zone.name;}
    }
    public static Sample sample(double x,double y,double z){
        var zone=ZoneStore.activeAt(x,y,z);if(zone!=null)return new Sample(zone.enabled,zone.precipitation,zone.intensity/100f,zone.temperature,zone.lapseRate,
            zone.snowLine,zone.transition,zone.snowThreshold,zone.rainThreshold,zone.fogDensity,zone.fogStart,zone.fogEnd,zone.windDirection,zone.windSpeed,zone.gustStrength,zone.lightning,zone);
        return new Sample(SimulatorConfig.ENABLED.get(),SimulatorConfig.PRECIPITATION.get(),SimulatorConfig.INTENSITY.get()/100f,SimulatorConfig.TEMPERATURE.get(),SimulatorConfig.LAPSE_RATE.get(),
            SimulatorConfig.SNOW_LINE.get(),SimulatorConfig.TRANSITION.get(),SimulatorConfig.SLEET_MIN.get(),SimulatorConfig.SNOW_MAX.get(),SimulatorConfig.FOG_DENSITY.get(),SimulatorConfig.FOG_START.get(),SimulatorConfig.FOG_END.get(),
            SimulatorConfig.WIND_DIRECTION.get(),SimulatorConfig.WIND_SPEED.get(),SimulatorConfig.GUST_STRENGTH.get(),SimulatorConfig.LIGHTNING.get(),null);
    }
    private WeatherModel(){}
}
