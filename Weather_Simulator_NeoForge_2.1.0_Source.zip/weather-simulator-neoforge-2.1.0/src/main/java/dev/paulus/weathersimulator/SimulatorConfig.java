package dev.paulus.weathersimulator;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class SimulatorConfig {
    public enum PrecipitationMode { AUS, REGEN, SCHNEEREGEN, SCHNEE, NACH_SCHNEEFALLGRENZE, NACH_TEMPERATUR }
    public enum WindDirection {
        NORD("Nord",0,1),NORDOST("Nordost",-.707,.707),OST("Ost",-1,0),SUEDOST("Südost",-.707,-.707),
        SUED("Süd",0,-1),SUEDWEST("Südwest",.707,-.707),WEST("West",1,0),NORDWEST("Nordwest",.707,.707);
        public final String label;public final double dx,dz;
        WindDirection(String label,double dx,double dz){this.label=label;this.dx=dx;this.dz=dz;}
        @Override public String toString(){return label;}
    }
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue ENABLED;
    public static final ModConfigSpec.EnumValue<PrecipitationMode> PRECIPITATION;
    public static final ModConfigSpec.IntValue INTENSITY;
    public static final ModConfigSpec.DoubleValue TEMPERATURE;
    public static final ModConfigSpec.DoubleValue LAPSE_RATE;
    public static final ModConfigSpec.IntValue SNOW_LINE;
    public static final ModConfigSpec.DoubleValue SLEET_MIN;
    public static final ModConfigSpec.DoubleValue SNOW_MAX;
    public static final ModConfigSpec.IntValue TRANSITION;
    public static final ModConfigSpec.IntValue FOG_DENSITY,FOG_START,FOG_END;
    public static final ModConfigSpec.EnumValue<WindDirection> WIND_DIRECTION;
    public static final ModConfigSpec.DoubleValue WIND_SPEED,GUST_STRENGTH;
    public static final ModConfigSpec.IntValue LIGHTNING;
    public static final ModConfigSpec.IntValue PARTICLE_DENSITY,RAIN_SIZE,SNOW_SIZE,SLEET_SIZE;
    public static final ModConfigSpec.BooleanValue SNOW_COVER;
    public static final ModConfigSpec.IntValue SNOW_ACCUMULATION,SLOW_MELT,FAST_MELT;
    static {
        var b=new ModConfigSpec.Builder();b.push("simulator");
        ENABLED=b.define("enabled",true);
        PRECIPITATION=b.defineEnum("precipitation",PrecipitationMode.AUS);
        INTENSITY=b.defineInRange("intensity",55,0,100);
        TEMPERATURE=b.defineInRange("temperatureAtY64",8.0,-40.0,45.0);
        LAPSE_RATE=b.defineInRange("coolingPer100Blocks",6.5,0.0,20.0);
        SNOW_LINE=b.defineInRange("snowLine",128,-64,384);
        TRANSITION=b.defineInRange("snowLineTransition",6,0,40);
        SLEET_MIN=b.defineInRange("sleetMinimumTemperature",0.0,-5.0,5.0);
        SNOW_MAX=b.defineInRange("snowMaximumTemperature",1.0,-5.0,5.0);
        FOG_DENSITY=b.defineInRange("fogDensity",0,0,100);
        FOG_START=b.defineInRange("fogStart",32,0,384);
        FOG_END=b.defineInRange("fogEnd",128,8,512);
        WIND_DIRECTION=b.defineEnum("windDirection",WindDirection.WEST);
        WIND_SPEED=b.defineInRange("windSpeed",1.0,0.0,5.0);
        GUST_STRENGTH=b.defineInRange("gustStrength",0.35,0.0,2.0);
        LIGHTNING=b.defineInRange("lightningFrequency",0,0,100);
        PARTICLE_DENSITY=b.defineInRange("particleDensity",100,10,200);
        RAIN_SIZE=b.defineInRange("rainSize",100,40,220);
        SNOW_SIZE=b.defineInRange("snowSize",100,40,220);
        SLEET_SIZE=b.defineInRange("sleetSize",100,40,220);
        SNOW_COVER=b.comment("Visual, locally simulated lying snow; does not replace world blocks.").define("snowCover",true);
        SNOW_ACCUMULATION=b.defineInRange("snowAccumulation",100,10,300);
        SLOW_MELT=b.comment("Melting from 0 to 1 degree Celsius.").defineInRange("slowMelt",35,1,200);
        FAST_MELT=b.comment("Melting above 1 degree Celsius.").defineInRange("fastMelt",160,10,500);
        b.pop();SPEC=b.build();
    }
    private SimulatorConfig(){}
}
