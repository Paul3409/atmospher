package dev.paulus.weathersimulator;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.Locale;

final class ZoneProfileScreen extends Screen {
    private final Screen parent;private int page;
    ZoneProfileScreen(Screen parent){super(Component.literal("Wetterzone einstellen"));this.parent=parent;}
    @Override protected void init(){var z=ZoneStore.selected();if(z==null){onClose();return;}int x=width/2-140,y=height/2-116,w=280;if(page==0){
        addRenderableWidget(Button.builder(Component.literal("Zone: "+(z.enabled?"AN":"AUS")),b->{z.enabled=!z.enabled;save();}).bounds(x,y,w,20).build());
        addRenderableWidget(Button.builder(Component.literal("Niederschlag: "+z.precipitation),b->{var v=SimulatorConfig.PrecipitationMode.values();z.precipitation=v[(z.precipitation.ordinal()+1)%v.length];save();}).bounds(x,y+24,w,20).build());
        addRenderableWidget(SimulatorSlider.integer(x,y+48,w,0,100,()->z.intensity,v->{z.intensity=v;ZoneStore.save();},v->"Staerke: "+v+"%"));
        addRenderableWidget(new SimulatorSlider(x,y+72,w,-40,45,()->z.temperature,v->{z.temperature=v;ZoneStore.save();},v->String.format(Locale.ROOT,"Temperatur Y 64: %.1f °C",v)));
        addRenderableWidget(new SimulatorSlider(x,y+96,w,0,20,()->z.lapseRate,v->{z.lapseRate=v;ZoneStore.save();},v->String.format(Locale.ROOT,"Abkuehlung/100: %.1f °C",v)));
        addRenderableWidget(SimulatorSlider.integer(x,y+120,w,-64,384,()->z.snowLine,v->{z.snowLine=v;ZoneStore.save();},v->"Schneefallgrenze: Y "+v));
        addRenderableWidget(SimulatorSlider.integer(x,y+144,w,-64,384,()->z.minY,v->{z.minY=Math.min(v,z.maxY);ZoneStore.save();},v->"Zone ab Y "+v));
        addRenderableWidget(SimulatorSlider.integer(x,y+168,w,-64,384,()->z.maxY,v->{z.maxY=Math.max(v,z.minY);ZoneStore.save();},v->"Zone bis Y "+v));
    }else if(page==1){
        addRenderableWidget(new SimulatorSlider(x,y,w,-5,5,()->z.snowThreshold,v->{z.snowThreshold=v;ZoneStore.save();},v->String.format(Locale.ROOT,"Schnee unter: %.1f °C",v)));
        addRenderableWidget(new SimulatorSlider(x,y+24,w,-5,5,()->z.rainThreshold,v->{z.rainThreshold=v;ZoneStore.save();},v->String.format(Locale.ROOT,"Regen ab: %.1f °C",v)));
        addRenderableWidget(SimulatorSlider.integer(x,y+48,w,0,40,()->z.transition,v->{z.transition=v;ZoneStore.save();},v->"Schneeregenband: "+v+" Bloecke"));
        addRenderableWidget(SimulatorSlider.integer(x,y+72,w,0,100,()->z.fogDensity,v->{z.fogDensity=v;ZoneStore.save();},v->"Nebeldichte: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+96,w,0,384,()->z.fogStart,v->{z.fogStart=v;ZoneStore.save();},v->"Nebelbeginn: "+v));
        addRenderableWidget(SimulatorSlider.integer(x,y+120,w,8,512,()->z.fogEnd,v->{z.fogEnd=v;ZoneStore.save();},v->"Nebelende: "+v));
    }else{
        addRenderableWidget(Button.builder(Component.literal("Wind aus: "+z.windDirection),b->{var v=SimulatorConfig.WindDirection.values();z.windDirection=v[(z.windDirection.ordinal()+1)%v.length];save();}).bounds(x,y,w,20).build());
        addRenderableWidget(new SimulatorSlider(x,y+24,w,0,5,()->z.windSpeed,v->{z.windSpeed=v;ZoneStore.save();},v->String.format(Locale.ROOT,"Windstaerke: %.2f",v)));
        addRenderableWidget(new SimulatorSlider(x,y+48,w,0,2,()->z.gustStrength,v->{z.gustStrength=v;ZoneStore.save();},v->String.format(Locale.ROOT,"Boeen: %.2f",v)));
        addRenderableWidget(SimulatorSlider.integer(x,y+72,w,0,100,()->z.lightning,v->{z.lightning=v;ZoneStore.save();},v->"Blitze: "+v+"%"));
    }addRenderableWidget(Button.builder(Component.literal("<"),b->{page=Math.floorMod(page-1,3);rebuildWidgets();}).bounds(x,y+196,38,20).build());addRenderableWidget(Button.builder(Component.literal(page==0?"Zonenwetter & Hoehe":page==1?"Temperatur & Nebel":"Wind & Gewitter"),b->{}).bounds(x+42,y+196,196,20).build());addRenderableWidget(Button.builder(Component.literal(">"),b->{page=(page+1)%3;rebuildWidgets();}).bounds(x+242,y+196,38,20).build());addRenderableWidget(Button.builder(Component.literal("Zurueck zur Karte"),b->onClose()).bounds(x,y+220,w,20).build());}
    private void save(){ZoneStore.save();rebuildWidgets();}
    @Override public void render(GuiGraphics gui,int mx,int my,float pt){super.render(gui,mx,my,pt);var z=ZoneStore.selected();if(z!=null)gui.drawCenteredString(font,z.name+" | "+z.cells.size()+" Felder",width/2,height/2-138,0xFFFFFF);}
    @Override public void onClose(){ZoneStore.save();minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
