package dev.paulus.weathersimulator;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(WeatherSimulatorMod.MOD_ID)
public final class WeatherSimulatorMod {
    public static final String MOD_ID="weather_simulator";
    private static final Logger LOGGER=LogUtils.getLogger();
    public WeatherSimulatorMod(IEventBus bus,ModContainer container){
        container.registerConfig(ModConfig.Type.CLIENT,SimulatorConfig.SPEC);
        LOGGER.info("WEATHER_SIMULATOR_READY Minecraft 1.21.1 / NeoForge 21.1.259");
    }
    static void error(String text,Throwable error){LOGGER.error(text,error);}
}
