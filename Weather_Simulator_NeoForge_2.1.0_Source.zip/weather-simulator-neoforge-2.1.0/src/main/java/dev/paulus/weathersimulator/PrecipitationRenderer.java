package dev.paulus.weathersimulator;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** Continuous world-space precipitation. Camera height never enters a particle trajectory. */
@EventBusSubscriber(modid=WeatherSimulatorMod.MOD_ID,value=Dist.CLIENT)
public final class PrecipitationRenderer {
    private static final ResourceLocation RAIN=ResourceLocation.fromNamespaceAndPath(WeatherSimulatorMod.MOD_ID,"textures/weather/rain.png");
    private static final ResourceLocation SNOW=ResourceLocation.fromNamespaceAndPath(WeatherSimulatorMod.MOD_ID,"textures/weather/snow.png");
    private static final RenderType RAIN_TYPE=type("weather_simulator_rain",RAIN),SNOW_TYPE=type("weather_simulator_snow",SNOW);
    private static RenderType type(String name,ResourceLocation texture){return RenderType.create(name,DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP,VertexFormat.Mode.QUADS,8192,false,true,RenderType.CompositeState.builder().setShaderState(RenderStateShard.POSITION_COLOR_TEX_LIGHTMAP_SHADER).setTextureState(new RenderStateShard.TextureStateShard(texture,false,false)).setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY).setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST).setWriteMaskState(RenderStateShard.COLOR_WRITE).setCullState(RenderStateShard.NO_CULL).createCompositeState(false));}
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||!SimulatorConfig.ENABLED.get())return;var mc=Minecraft.getInstance();if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var camera=event.getCamera().getPosition();double time=mc.level.getGameTime()+event.getPartialTick().getGameTimeDeltaTicks();var matrix=event.getPoseStack().last().pose();var buffers=mc.renderBuffers().bufferSource();
        int minX=(int)Math.floor((camera.x-34)/3),maxX=(int)Math.floor((camera.x+34)/3),minZ=(int)Math.floor((camera.z-34)/3),maxZ=(int)Math.floor((camera.z+34)/3);
        for(int ix=minX;ix<=maxX;ix++)for(int iz=minZ;iz<=maxZ;iz++)for(int n=0;n<3;n++){
            long seed=mix(ix,iz,n);double baseX=ix*3+unit(seed)*3,baseZ=iz*3+unit(seed>>>12)*3;int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)Math.floor(baseX),(int)Math.floor(baseZ));
            var weather=WeatherModel.sample(baseX,ground,baseZ);var kind=weather.kind(ground);if(kind==WeatherModel.Kind.NONE)continue;float intensity=weather.intensity()*SimulatorConfig.PARTICLE_DENSITY.get()/100f;if(unit(seed>>>24)>Math.min(1,intensity))continue;
            double top=ground+38+unit(seed>>>34)*16,span=top-ground-.15,speed=kind==WeatherModel.Kind.RAIN?2.15:kind==WeatherModel.Kind.SLEET?.62:.20;
            double travelled=mod(time*speed+unit(seed>>>44)*span,span),worldY=top-travelled;double life=travelled/span;
            double windTravel=travelled*(.018+.025*weather.windSpeed()),gust=Math.sin(time*.085+baseX*.11+baseZ*.07+unit(seed)*6.28)*weather.gustStrength();
            double worldX=baseX+weather.windDirection().dx*(windTravel+gust),worldZ=baseZ+weather.windDirection().dz*(windTravel+gust);
            if(kind==WeatherModel.Kind.SNOW){worldX+=Math.sin(time*.105+unit(seed>>>8)*18)*(.22+.26*life);worldZ+=Math.sin(time*.073+unit(seed>>>16)*21)*(.18+.22*life);}
            float fade=(float)Math.min(1,Math.min(life/.10,(1-life)/.08)),x=(float)(worldX-camera.x),y=(float)(worldY-camera.y),z=(float)(worldZ-camera.z);if(fade<=0)continue;
            if(kind==WeatherModel.Kind.SNOW){float size=.23f*SimulatorConfig.SNOW_SIZE.get()/100f;cross(buffers.getBuffer(SNOW_TYPE),matrix,x,y,z,size,size,.94f,.95f,.96f,.72f*fade);}
            else {float scale=(kind==WeatherModel.Kind.RAIN?SimulatorConfig.RAIN_SIZE.get():SimulatorConfig.SLEET_SIZE.get())/100f;float length=(kind==WeatherModel.Kind.RAIN?1.25f:.62f)*scale,width=.045f*scale;cross(buffers.getBuffer(RAIN_TYPE),matrix,x,y,z,width,length,.72f,.79f,.84f,.66f*fade);}
        }
        buffers.endBatch(RAIN_TYPE);buffers.endBatch(SNOW_TYPE);
    }
    private static void cross(VertexConsumer out,Matrix4f m,float x,float y,float z,float halfWidth,float height,float r,float g,float b,float a){
        quad(out,m,x-halfWidth,y,z,x+halfWidth,y,z,x+halfWidth,y+height,z,x-halfWidth,y+height,z,r,g,b,a);
        quad(out,m,x,y,z-halfWidth,x,y,z+halfWidth,x,y+height,z+halfWidth,x,y+height,z-halfWidth,r,g,b,a*.82f);
    }
    private static void quad(VertexConsumer out,Matrix4f m,float x0,float y0,float z0,float x1,float y1,float z1,float x2,float y2,float z2,float x3,float y3,float z3,float r,float g,float b,float a){out.addVertex(m,x0,y0,z0).setColor(r,g,b,a).setUv(0,1).setLight(0x00f000f0);out.addVertex(m,x1,y1,z1).setColor(r,g,b,a).setUv(1,1).setLight(0x00f000f0);out.addVertex(m,x2,y2,z2).setColor(r,g,b,a).setUv(1,0).setLight(0x00f000f0);out.addVertex(m,x3,y3,z3).setColor(r,g,b,a).setUv(0,0).setLight(0x00f000f0);}
    private static long mix(int x,int z,int n){long v=(long)x*73428767L^(long)z*912931L^(long)n*19349663L;v^=v>>>13;v*=1274126177L;return v^(v>>>16);}
    private static double unit(long v){return (v&65535)/65535.0;}
    private static double mod(double value,double modulus){double result=value%modulus;return result<0?result+modulus:result;}
    private PrecipitationRenderer(){}
}
