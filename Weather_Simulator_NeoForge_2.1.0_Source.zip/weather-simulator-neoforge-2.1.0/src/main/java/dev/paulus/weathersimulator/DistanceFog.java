package dev.paulus.weathersimulator;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Smoothly controls Minecraft's distance fog without geometry. */
@EventBusSubscriber(modid=WeatherSimulatorMod.MOD_ID,value=Dist.CLIENT)
public final class DistanceFog {
    private static Object level;private static float currentNear,currentFar;private static boolean initialized;
    @SubscribeEvent public static void render(ViewportEvent.RenderFog event){
        var mc=Minecraft.getInstance();if(mc.level==null||mc.player==null||!SimulatorConfig.ENABLED.get()){initialized=false;return;}
        if(level!=mc.level){level=mc.level;initialized=false;}
        var pos=event.getCamera().getPosition();var weather=WeatherModel.sample(pos.x,pos.y,pos.z);float amount=weather.fogDensity()/100f;if(amount<=0){initialized=false;return;}
        float targetNear=(float)Math.min(weather.fogStart(),weather.fogEnd()-1),targetFar=(float)Math.max(targetNear+1,weather.fogEnd());
        if(!initialized){currentNear=targetNear;currentFar=targetFar;initialized=true;}else{currentNear=lerp(currentNear,targetNear,.08f);currentFar=lerp(currentFar,targetFar,.08f);}
        event.setNearPlaneDistance(lerp(event.getNearPlaneDistance(),currentNear,amount));event.setFarPlaneDistance(lerp(event.getFarPlaneDistance(),currentFar,amount));event.setCanceled(true);
    }
    private static float lerp(float a,float b,float t){return a+(b-a)*t;}
    private DistanceFog(){}
}
