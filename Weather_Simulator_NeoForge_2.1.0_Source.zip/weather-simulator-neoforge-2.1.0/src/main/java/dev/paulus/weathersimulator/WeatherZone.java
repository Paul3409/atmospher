package dev.paulus.weathersimulator;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** A freely painted horizontal mask plus an explicit vertical range and weather profile. */
public final class WeatherZone {
    public String id=UUID.randomUUID().toString();
    public String name="Neue Zone";
    public boolean enabled=true;
    public int cellSize=4,minY=-64,maxY=384;
    public SimulatorConfig.PrecipitationMode precipitation=SimulatorConfig.PrecipitationMode.AUS;
    public int intensity=55;
    public double temperature=8,lapseRate=6.5;
    public int snowLine=128,transition=6;
    public double snowThreshold=0,rainThreshold=1;
    public int fogDensity=0,fogStart=32,fogEnd=128;
    public SimulatorConfig.WindDirection windDirection=SimulatorConfig.WindDirection.WEST;
    public double windSpeed=1,gustStrength=.35;
    public int lightning=0;
    public Set<Long> cells=new HashSet<>();
    public boolean contains(double x,double y,double z){return enabled&&y>=minY&&y<=maxY&&containsXZ(x,z);}
    public boolean containsXZ(double x,double z){return cells.contains(key(Math.floorDiv((int)Math.floor(x),cellSize),Math.floorDiv((int)Math.floor(z),cellSize)));}
    public void paint(double x,double z,double radius,boolean erase){
        int cx=Math.floorDiv((int)Math.floor(x),cellSize),cz=Math.floorDiv((int)Math.floor(z),cellSize);
        int reach=Math.max(1,(int)Math.ceil(radius/cellSize));double r=Math.max(cellSize*.7,radius);
        for(int dx=-reach;dx<=reach;dx++)for(int dz=-reach;dz<=reach;dz++){
            double px=(cx+dx+.5)*cellSize-x,pz=(cz+dz+.5)*cellSize-z;if(px*px+pz*pz>r*r)continue;
            long k=key(cx+dx,cz+dz);if(erase)cells.remove(k);else cells.add(k);
        }
    }
    public static long key(int x,int z){return ((long)x<<32)^(z&0xffffffffL);}
    public static int keyX(long key){return (int)(key>>32);}
    public static int keyZ(long key){return (int)key;}
}
