package dev.paulus.weathersimulator;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

public final class ClientKeys {
    private static final String CATEGORY="key.categories.weather_simulator";
    public static final KeyMapping MENU=new KeyMapping("key.weather_simulator.menu",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_M,CATEGORY);
    public static final KeyMapping MAP=new KeyMapping("key.weather_simulator.map",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_R,CATEGORY);
    @EventBusSubscriber(modid=WeatherSimulatorMod.MOD_ID,bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
    public static final class Registration {@SubscribeEvent public static void register(RegisterKeyMappingsEvent e){e.register(MENU);e.register(MAP);}}
    @EventBusSubscriber(modid=WeatherSimulatorMod.MOD_ID,value=Dist.CLIENT)
    public static final class Handler {@SubscribeEvent public static void tick(ClientTickEvent.Post e){var mc=Minecraft.getInstance();if(mc.player==null||mc.screen!=null)return;while(MENU.consumeClick())mc.setScreen(new SimulatorScreen());while(MAP.consumeClick())mc.setScreen(new ZoneMapScreen(new SimulatorScreen()));}}
    private ClientKeys(){}
}
