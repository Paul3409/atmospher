package dev.paulus.weathersimulator;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

@EventBusSubscriber(modid=WeatherSimulatorMod.MOD_ID,value=Dist.CLIENT)
public final class LightningRenderer {
    private static final RenderType TYPE=RenderType.create("weather_simulator_lightning",DefaultVertexFormat.POSITION_COLOR,VertexFormat.Mode.QUADS,1024,false,true,RenderType.CompositeState.builder().setShaderState(RenderStateShard.POSITION_COLOR_SHADER).setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY).setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST).setWriteMaskState(RenderStateShard.COLOR_WRITE).setCullState(RenderStateShard.NO_CULL).createCompositeState(false));
    @SubscribeEvent public static void render(RenderLevelStageEvent event){if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||!SimulatorConfig.ENABLED.get())return;var mc=Minecraft.getInstance();if(mc.level==null)return;long tick=mc.level.getGameTime();var cam=event.getCamera().getPosition();var local=WeatherModel.sample(cam.x,cam.y,cam.z);if(local.lightning()==0||local.intensity()<=0)return;long period=Math.max(50,24000L/local.lightning());long phase=Math.floorMod(tick,period);if(phase>3)return;long cycle=Math.floorDiv(tick,period);double wx=cam.x+Math.floorMod(cycle*73,141)-70,wz=cam.z+Math.floorMod(cycle*97,131)-65;int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)wx,(int)wz);var weather=WeatherModel.sample(wx,ground,wz);if(weather.lightning()==0||weather.kind(ground)==WeatherModel.Kind.NONE)return;double top=ground+70;var out=mc.renderBuffers().bufferSource().getBuffer(TYPE);var m=event.getPoseStack().last().pose();double x=wx-cam.x,z=wz-cam.z;for(int i=0;i<11;i++){double t0=i/11d,t1=(i+1)/11d;float y0=(float)(top+(ground-top)*t0-cam.y),y1=(float)(top+(ground-top)*t1-cam.y),a=(float)(Math.sin(i*4.37+cycle)*2.1),b=(float)(Math.sin((i+1)*4.37+cycle)*2.1),w=.32f;out.addVertex(m,(float)x+a-w,y0,(float)z).setColor(.88f,.92f,1f,.92f);out.addVertex(m,(float)x+a+w,y0,(float)z).setColor(.88f,.92f,1f,.92f);out.addVertex(m,(float)x+b+w,y1,(float)z).setColor(.88f,.92f,1f,.92f);out.addVertex(m,(float)x+b-w,y1,(float)z).setColor(.88f,.92f,1f,.92f);}mc.renderBuffers().bufferSource().endBatch(TYPE);}
    private LightningRenderer(){}
}
