package dev.paulus.weathersimulator;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.Locale;

public final class SimulatorScreen extends Screen {
    private int page;
    public SimulatorScreen(){super(Component.literal("Wettersimulator"));}
    @Override protected void init(){int x=width/2-140,y=height/2-116,w=280;if(page==0)weather(x,y,w);else if(page==1)snow(x,y,w);else if(page==2)air(x,y,w);else graphics(x,y,w);
        addRenderableWidget(Button.builder(Component.literal("<"),b->{page=Math.floorMod(page-1,4);rebuildWidgets();}).bounds(x,y+196,38,20).build());
        addRenderableWidget(Button.builder(Component.literal(pageName()),b->{}).bounds(x+42,y+196,196,20).build());
        addRenderableWidget(Button.builder(Component.literal(">"),b->{page=(page+1)%4;rebuildWidgets();}).bounds(x+242,y+196,38,20).build());
        addRenderableWidget(Button.builder(Component.literal("Wetterkarte / Zonen (R)"),b->minecraft.setScreen(new ZoneMapScreen(this))).bounds(x,y+220,184,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(x+188,y+220,92,20).build());}
    private void weather(int x,int y,int w){
        addRenderableWidget(Button.builder(Component.literal("Simulator: "+on(SimulatorConfig.ENABLED.get())),b->{SimulatorConfig.ENABLED.set(!SimulatorConfig.ENABLED.get());rebuildWidgets();}).bounds(x,y,w,20).build());
        addRenderableWidget(Button.builder(Component.literal("Niederschlag: "+SimulatorConfig.PRECIPITATION.get()),b->{var v=SimulatorConfig.PrecipitationMode.values(),c=SimulatorConfig.PRECIPITATION.get();SimulatorConfig.PRECIPITATION.set(v[(c.ordinal()+1)%v.length]);rebuildWidgets();}).bounds(x,y+24,w,20).build());
        addRenderableWidget(SimulatorSlider.integer(x,y+48,w,0,100,SimulatorConfig.INTENSITY::get,SimulatorConfig.INTENSITY::set,v->"Niederschlagsstaerke: "+v+"%"));
        addRenderableWidget(new SimulatorSlider(x,y+72,w,-40,45,SimulatorConfig.TEMPERATURE::get,SimulatorConfig.TEMPERATURE::set,v->String.format(Locale.ROOT,"Temperatur bei Y 64: %.1f °C",v)));
        addRenderableWidget(new SimulatorSlider(x,y+96,w,0,20,SimulatorConfig.LAPSE_RATE::get,SimulatorConfig.LAPSE_RATE::set,v->String.format(Locale.ROOT,"Abkuehlung je 100 Bloecke: %.1f °C",v)));
        addRenderableWidget(SimulatorSlider.integer(x,y+120,w,-64,384,SimulatorConfig.SNOW_LINE::get,SimulatorConfig.SNOW_LINE::set,v->"Schneefallgrenze: Y "+v));
        addRenderableWidget(SimulatorSlider.integer(x,y+144,w,0,40,SimulatorConfig.TRANSITION::get,SimulatorConfig.TRANSITION::set,v->"Schneeregenband: "+v+" Bloecke"));
    }
    private void snow(int x,int y,int w){
        addRenderableWidget(new SimulatorSlider(x,y,w,-5,5,SimulatorConfig.SLEET_MIN::get,SimulatorConfig.SLEET_MIN::set,v->String.format(Locale.ROOT,"Schnee unter: %.1f °C",v)));
        addRenderableWidget(new SimulatorSlider(x,y+24,w,-5,5,SimulatorConfig.SNOW_MAX::get,SimulatorConfig.SNOW_MAX::set,v->String.format(Locale.ROOT,"Regen ab: %.1f °C",v)));
        addRenderableWidget(Button.builder(Component.literal("Liegender Schnee: "+on(SimulatorConfig.SNOW_COVER.get())),b->{SimulatorConfig.SNOW_COVER.set(!SimulatorConfig.SNOW_COVER.get());rebuildWidgets();}).bounds(x,y+48,w,20).build());
        addRenderableWidget(SimulatorSlider.integer(x,y+72,w,10,300,SimulatorConfig.SNOW_ACCUMULATION::get,SimulatorConfig.SNOW_ACCUMULATION::set,v->"Schneeaufbau: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+96,w,1,200,SimulatorConfig.SLOW_MELT::get,SimulatorConfig.SLOW_MELT::set,v->"Tauen bei 0–1 °C: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+120,w,10,500,SimulatorConfig.FAST_MELT::get,SimulatorConfig.FAST_MELT::set,v->"Tauen ueber 1 °C: "+v+"%"));
    }
    private void air(int x,int y,int w){
        addRenderableWidget(SimulatorSlider.integer(x,y,w,0,100,SimulatorConfig.FOG_DENSITY::get,SimulatorConfig.FOG_DENSITY::set,v->"Nebeldichte: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+24,w,0,384,SimulatorConfig.FOG_START::get,SimulatorConfig.FOG_START::set,v->"Nebelbeginn: "+v+" Bloecke"));
        addRenderableWidget(SimulatorSlider.integer(x,y+48,w,8,512,SimulatorConfig.FOG_END::get,SimulatorConfig.FOG_END::set,v->"Nebelende: "+v+" Bloecke"));
        addRenderableWidget(Button.builder(Component.literal("Wind aus: "+SimulatorConfig.WIND_DIRECTION.get()),b->{var v=SimulatorConfig.WindDirection.values(),c=SimulatorConfig.WIND_DIRECTION.get();SimulatorConfig.WIND_DIRECTION.set(v[(c.ordinal()+1)%v.length]);rebuildWidgets();}).bounds(x,y+72,w,20).build());
        addRenderableWidget(new SimulatorSlider(x,y+96,w,0,5,SimulatorConfig.WIND_SPEED::get,SimulatorConfig.WIND_SPEED::set,v->String.format(Locale.ROOT,"Windstaerke: %.2f",v)));
        addRenderableWidget(new SimulatorSlider(x,y+120,w,0,2,SimulatorConfig.GUST_STRENGTH::get,SimulatorConfig.GUST_STRENGTH::set,v->String.format(Locale.ROOT,"Boeen: %.2f",v)));
        addRenderableWidget(SimulatorSlider.integer(x,y+144,w,0,100,SimulatorConfig.LIGHTNING::get,SimulatorConfig.LIGHTNING::set,v->"Blitzhaeufigkeit: "+v+"%"));
    }
    private void graphics(int x,int y,int w){
        addRenderableWidget(SimulatorSlider.integer(x,y,w,10,200,SimulatorConfig.PARTICLE_DENSITY::get,SimulatorConfig.PARTICLE_DENSITY::set,v->"Partikeldichte: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+24,w,40,220,SimulatorConfig.RAIN_SIZE::get,SimulatorConfig.RAIN_SIZE::set,v->"Regentropfen: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+48,w,40,220,SimulatorConfig.SNOW_SIZE::get,SimulatorConfig.SNOW_SIZE::set,v->"Schneeflocken: "+v+"%"));
        addRenderableWidget(SimulatorSlider.integer(x,y+72,w,40,220,SimulatorConfig.SLEET_SIZE::get,SimulatorConfig.SLEET_SIZE::set,v->"Schneeregen: "+v+"%"));
    }
    private String pageName(){return switch(page){case 0->"Wetter & Schneefallgrenze";case 1->"Temperatur & Schneedecke";case 2->"Nebel, Wind & Gewitter";default->"Partikeldarstellung";};}
    private static String on(boolean value){return value?"AN":"AUS";}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){super.render(gui,mouseX,mouseY,partialTick);gui.drawCenteredString(font,title,width/2,height/2-138,0xFFFFFF);if(minecraft.player!=null&&minecraft.level!=null){var p=minecraft.player;int surface=minecraft.level.getHeight(Heightmap.Types.MOTION_BLOCKING,p.blockPosition().getX(),p.blockPosition().getZ());var s=WeatherModel.sample(p.getX(),surface,p.getZ());gui.drawCenteredString(font,String.format(Locale.ROOT,"Wirksam: %s | Y %d | %.1f °C | %s",s.source(),surface,s.temperature(surface),s.kind(surface)),width/2,height/2+128,0xE2E2E2);}}
    @Override public boolean isPauseScreen(){return false;}
}
