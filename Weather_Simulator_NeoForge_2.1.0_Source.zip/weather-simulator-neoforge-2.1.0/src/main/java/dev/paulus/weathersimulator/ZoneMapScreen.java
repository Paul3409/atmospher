package dev.paulus.weathersimulator;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.Locale;

/** Cached terrain overview with freehand paint, eraser, zoom and per-zone profiles. */
final class ZoneMapScreen extends Screen {
    private final Screen parent;private double centerX,centerZ;private int blocksPerPixel=4,brush=12,mapX,mapY,mapW,mapH;private boolean erase,painting,terrainDirty=true;private int[] terrain;private int terrainCols,terrainRows;
    ZoneMapScreen(Screen parent){super(Component.literal("Wetterkarte – Freihand-Zonen"));this.parent=parent;}
    @Override protected void init(){mapW=Math.min(440,width-24);mapH=Math.min(238,height-94);mapX=(width-mapW)/2;mapY=30;if(centerX==0&&centerZ==0&&minecraft.player!=null){centerX=minecraft.player.getX();centerZ=minecraft.player.getZ();terrainDirty=true;}int y=height-56;
        addRenderableWidget(Button.builder(Component.literal("Neue Zone"),b->{ZoneStore.create(centerX,centerZ);erase=false;rebuildWidgets();}).bounds(width/2-220,y,86,20).build());
        addRenderableWidget(Button.builder(Component.literal(erase?"Radieren":"Malen"),b->{erase=!erase;rebuildWidgets();}).bounds(width/2-130,y,72,20).build());
        addRenderableWidget(Button.builder(Component.literal("Pinsel "+brush),b->{brush=brush>=48?4:brush*2;rebuildWidgets();}).bounds(width/2-54,y,76,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zone einstellen"),b->{if(ZoneStore.selected()!=null)minecraft.setScreen(new ZoneProfileScreen(this));}).bounds(width/2+26,y,116,20).build());
        addRenderableWidget(Button.builder(Component.literal("Loeschen"),b->{ZoneStore.deleteSelected();rebuildWidgets();}).bounds(width/2+146,y,74,20).build());
        addRenderableWidget(Button.builder(Component.literal("< Zone"),b->{ZoneStore.select(selectedIndex()-1);rebuildWidgets();}).bounds(width/2-220,y+24,72,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zone >"),b->{ZoneStore.select(selectedIndex()+1);rebuildWidgets();}).bounds(width/2-144,y+24,72,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zum Spieler"),b->{if(minecraft.player!=null){centerX=minecraft.player.getX();centerZ=minecraft.player.getZ();terrainDirty=true;}}).bounds(width/2-68,y+24,104,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(width/2+116,y+24,104,20).build());}
    private int selectedIndex(){var z=ZoneStore.selected();return z==null?0:ZoneStore.zones().indexOf(z);}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float pt){super.render(gui,mouseX,mouseY,pt);if(terrainDirty)cacheTerrain();gui.fill(mapX-2,mapY-2,mapX+mapW+2,mapY+mapH+2,0xFF91A0AA);drawTerrain(gui);drawZones(gui);int cx=mapX+mapW/2,cy=mapY+mapH/2;gui.fill(cx-3,cy,cx+4,cy+1,0xFFFFFFFF);gui.fill(cx,cy-3,cx+1,cy+4,0xFFFFFFFF);gui.drawCenteredString(font,title,width/2,9,0xFFFFFF);var z=ZoneStore.selected();gui.drawCenteredString(font,z==null?"Keine Zone – Neue Zone anklicken":z.name+" | "+z.cells.size()+" Felder | Y "+z.minY+" bis "+z.maxY,width/2,mapY+mapH+5,z==null?0xBBBBBB:0xFFFFFF);if(inMap(mouseX,mouseY))gui.drawString(font,String.format(Locale.ROOT,"X %.0f  Z %.0f | %d Block/Pixel | %s",worldX(mouseX),worldZ(mouseY),blocksPerPixel,erase?"Radierer":"Pinsel"),mapX+5,mapY+5,0xFFFFFFFF,false);}
    private void cacheTerrain(){terrainDirty=false;int step=4;terrainCols=(mapW+step-1)/step;terrainRows=(mapH+step-1)/step;terrain=new int[terrainCols*terrainRows];if(minecraft.level==null)return;for(int col=0;col<terrainCols;col++)for(int row=0;row<terrainRows;row++){int wx=(int)Math.floor(centerX+(col*step-mapW/2.0)*blocksPerPixel),wz=(int)Math.floor(centerZ+(row*step-mapH/2.0)*blocksPerPixel),h=minecraft.level.getHeight(Heightmap.Types.MOTION_BLOCKING,wx,wz);var p=net.minecraft.core.BlockPos.containing(wx,h-1,wz);boolean water=minecraft.level.hasChunkAt(p)&&!minecraft.level.getFluidState(p).isEmpty();int shade=Math.max(0,Math.min(55,h-minecraft.level.getSeaLevel()+22));terrain[col+row*terrainCols]=water?0xFF345D80:0xFF000000|((43+shade)<<16)|((69+shade)<<8)|(39+shade/2);}}
    private void drawTerrain(GuiGraphics gui){int step=4;if(terrain==null){gui.fill(mapX,mapY,mapX+mapW,mapY+mapH,0xFF25303A);return;}for(int col=0;col<terrainCols;col++)for(int row=0;row<terrainRows;row++)gui.fill(mapX+col*step,mapY+row*step,Math.min(mapX+mapW,mapX+(col+1)*step),Math.min(mapY+mapH,mapY+(row+1)*step),terrain[col+row*terrainCols]);}
    private void drawZones(GuiGraphics gui){var selected=ZoneStore.selected();for(var z:ZoneStore.zones()){int color=z==selected?0xAA48D8FF:0x7747FF86;for(long key:z.cells){double wx=(WeatherZone.keyX(key)+.5)*z.cellSize,wz=(WeatherZone.keyZ(key)+.5)*z.cellSize;int px=(int)Math.round(mapX+mapW/2+(wx-centerX)/blocksPerPixel),py=(int)Math.round(mapY+mapH/2+(wz-centerZ)/blocksPerPixel),size=Math.max(1,(int)Math.ceil(z.cellSize/(double)blocksPerPixel));if(px+size<mapX||py+size<mapY||px>=mapX+mapW||py>=mapY+mapH)continue;gui.fill(Math.max(mapX,px-size/2),Math.max(mapY,py-size/2),Math.min(mapX+mapW,px-size/2+size),Math.min(mapY+mapH,py-size/2+size),color);}}}
    @Override public boolean mouseClicked(double x,double y,int button){if(inMap(x,y)){if(button==0){painting=true;paint(x,y);return true;}if(button==1)return true;}return super.mouseClicked(x,y,button);}
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){if(button==0&&painting){paint(x,y);return true;}if(button==1&&inMap(x,y)){centerX-=dx*blocksPerPixel;centerZ-=dy*blocksPerPixel;terrainDirty=true;return true;}return super.mouseDragged(x,y,button,dx,dy);}
    @Override public boolean mouseReleased(double x,double y,int button){if(button==0&&painting){painting=false;ZoneStore.save();return true;}return super.mouseReleased(x,y,button);}
    @Override public boolean mouseScrolled(double x,double y,double sx,double sy){if(inMap(x,y)){blocksPerPixel=sy>0?Math.max(1,blocksPerPixel/2):Math.min(32,blocksPerPixel*2);terrainDirty=true;return true;}return super.mouseScrolled(x,y,sx,sy);}
    private void paint(double x,double y){var z=ZoneStore.selected();if(z!=null)z.paint(worldX(x),worldZ(y),brush,erase);}
    private boolean inMap(double x,double y){return x>=mapX&&x<mapX+mapW&&y>=mapY&&y<mapY+mapH;}
    private double worldX(double x){return centerX+(x-(mapX+mapW/2.0))*blocksPerPixel;}private double worldZ(double y){return centerZ+(y-(mapY+mapH/2.0))*blocksPerPixel;}
    @Override public void onClose(){ZoneStore.save();minecraft.setScreen(parent);}@Override public boolean isPauseScreen(){return false;}
}
