package dev.paulus.weathersimulator;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

final class SimulatorSlider extends AbstractSliderButton {
    private final double min,max;private final Consumer<Double> setter;private final Function<Double,String> text;
    SimulatorSlider(int x,int y,int w,double min,double max,Supplier<Double> getter,Consumer<Double> setter,Function<Double,String> text){
        super(x,y,w,20,Component.empty(),Math.max(0,Math.min(1,(getter.get()-min)/(max-min))));this.min=min;this.max=max;this.setter=setter;this.text=text;updateMessage();
    }
    static SimulatorSlider integer(int x,int y,int w,int min,int max,Supplier<Integer> getter,Consumer<Integer> setter,Function<Integer,String> text){
        return new SimulatorSlider(x,y,w,min,max,()->getter.get().doubleValue(),v->setter.accept((int)Math.round(v)),v->text.apply((int)Math.round(v)));
    }
    private double actual(){return min+(max-min)*value;}
    @Override protected void updateMessage(){setMessage(Component.literal(text.apply(actual())));}
    @Override protected void applyValue(){setter.accept(actual());}
}
