package dev.paulus.weathersimulator;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.fml.loading.FMLPaths;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Stores separate zone files per singleplayer save or multiplayer server. */
public final class ZoneStore {
    private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
    private static final List<WeatherZone> ZONES=new ArrayList<>();
    private static Object loadedLevel;
    private static Path loadedFile;
    private static int selected=-1;
    public static synchronized List<WeatherZone> zones(){ensureWorld();return Collections.unmodifiableList(ZONES);}
    public static synchronized WeatherZone selected(){ensureWorld();return selected>=0&&selected<ZONES.size()?ZONES.get(selected):null;}
    public static synchronized WeatherZone activeAt(double x,double y,double z){ensureWorld();for(int i=ZONES.size()-1;i>=0;i--){var zone=ZONES.get(i);if(zone.contains(x,y,z))return zone;}return null;}
    public static synchronized WeatherZone create(double x,double z){
        ensureWorld();var zone=new WeatherZone();zone.name="Wetterzone "+(ZONES.size()+1);
        zone.precipitation=SimulatorConfig.PRECIPITATION.get();zone.intensity=SimulatorConfig.INTENSITY.get();
        zone.temperature=SimulatorConfig.TEMPERATURE.get();zone.lapseRate=SimulatorConfig.LAPSE_RATE.get();
        zone.snowLine=SimulatorConfig.SNOW_LINE.get();zone.transition=SimulatorConfig.TRANSITION.get();
        zone.snowThreshold=SimulatorConfig.SLEET_MIN.get();zone.rainThreshold=SimulatorConfig.SNOW_MAX.get();
        zone.fogDensity=SimulatorConfig.FOG_DENSITY.get();zone.fogStart=SimulatorConfig.FOG_START.get();zone.fogEnd=SimulatorConfig.FOG_END.get();
        zone.windDirection=SimulatorConfig.WIND_DIRECTION.get();zone.windSpeed=SimulatorConfig.WIND_SPEED.get();zone.gustStrength=SimulatorConfig.GUST_STRENGTH.get();zone.lightning=SimulatorConfig.LIGHTNING.get();
        zone.paint(x,z,10,false);ZONES.add(zone);selected=ZONES.size()-1;save();return zone;
    }
    public static synchronized void select(int index){ensureWorld();selected=ZONES.isEmpty()?-1:Math.floorMod(index,ZONES.size());}
    public static synchronized void deleteSelected(){ensureWorld();if(selected<0||selected>=ZONES.size())return;ZONES.remove(selected);selected=Math.min(selected,ZONES.size()-1);save();}
    public static synchronized void save(){ensureWorld();if(loadedFile==null)return;try{Files.createDirectories(loadedFile.getParent());try(Writer writer=Files.newBufferedWriter(loadedFile)){GSON.toJson(ZONES,writer);}}catch(Exception e){WeatherSimulatorMod.error("Wetterzonen konnten nicht gespeichert werden",e);}}
    static synchronized Path worldDirectory(){ensureWorld();return loadedFile==null?null:loadedFile.getParent();}
    private static void ensureWorld(){
        var mc=Minecraft.getInstance();if(mc.level==loadedLevel)return;
        loadedLevel=mc.level;ZONES.clear();selected=-1;loadedFile=worldFile(mc);if(loadedFile==null||!Files.isRegularFile(loadedFile))return;
        try(Reader reader=Files.newBufferedReader(loadedFile)){List<WeatherZone> loaded=GSON.fromJson(reader,new TypeToken<List<WeatherZone>>(){}.getType());if(loaded!=null)ZONES.addAll(loaded);if(!ZONES.isEmpty())selected=0;}
        catch(Exception e){WeatherSimulatorMod.error("Wetterzonen konnten nicht geladen werden",e);}
    }
    private static Path worldFile(Minecraft mc){
        if(mc.level==null)return null;String identity;
        var server=mc.getSingleplayerServer();
        if(server!=null)identity=server.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize().toString();
        else identity=mc.getCurrentServer()==null?"unbekannt":mc.getCurrentServer().ip;
        String dimension=mc.level.dimension().location().toString();String safe=Integer.toHexString((identity+"|"+dimension).hashCode());
        return FMLPaths.CONFIGDIR.get().resolve("weather-simulator").resolve("worlds").resolve(safe+"-zones.json");
    }
    private ZoneStore(){}
}
