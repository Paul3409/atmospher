package dev.paulus.weathersimulator.mixin;

import dev.paulus.weathersimulator.SimulatorConfig;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces only precipitation visuals. Vanilla clouds are never intercepted. */
@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    @Inject(method="renderSnowAndRain",at=@At("HEAD"),cancellable=true)
    private void weatherSimulator$precipitation(CallbackInfo ci){if(SimulatorConfig.ENABLED.get())ci.cancel();}
    @Inject(method="tickRain",at=@At("HEAD"),cancellable=true)
    private void weatherSimulator$rainEffects(CallbackInfo ci){if(SimulatorConfig.ENABLED.get())ci.cancel();}
}
