package de.meteo;

import java.util.ArrayList;
import java.util.List;

/** A single closed height-field shell per cloud, with no internal translucent cubes. */
public final class CloudSurfaceMesh {
    private CloudSurfaceMesh() {}
    public record Face(float x0,float y0,float z0,float x1,float y1,float z1,
                       byte side,float shade) {}
    public record Mesh(List<Face> faces,float width,float height) {}

    private static double clamp(double v,double low,double high){return Math.max(low,Math.min(high,v));}
    private static double blob(double x,double z,double cx,double cz,double rx,double rz){
        double dx=(x-cx)/rx,dz=(z-cz)/rz;
        return Math.max(0,1-dx*dx-dz*dz);
    }
    private static double body(double x,double z,int type,int seed){
        double irregular=(CloudVolumeField.noise(x*2.8+7,2.1,z*2.8-4,seed)-.5)*.28;
        double fine=(CloudVolumeField.noise(x*6.1-3,5.7,z*6.1+8,seed+31)-.5)*.11;
        double shape;
        if(type==5){ // sparse upper-level wisps
            shape=Math.max(blob(x,z,-.20,-.22,.90,.20),blob(x,z,.26,.27,.72,.15))*.72;
        }else if(type==3||type==4||type==6||type==8){
            shape=Math.max(blob(x,z,-.33,-.12,.75,.70),blob(x,z,.30,.24,.74,.64));
            if(type==4)shape=Math.max(shape,blob(x,z,-.05,.40,.40,.35));
            // Broad gaps are part of the outline, not transparent layers.
            irregular*=1.5;
        }else if(type==9){
            shape=Math.max(blob(x,z,-.43,-.35,.40,.37),blob(x,z,.40,-.27,.36,.35));
            shape=Math.max(shape,blob(x,z,-.04,.42,.42,.32));
        }else{
            shape=Math.max(blob(x,z,-.30,-.10,.65,.61),blob(x,z,.30,.12,.62,.59));
            shape=Math.max(shape,blob(x,z,-.02,.35,.43,.42));
        }
        return clamp(shape+irregular+fine,0,1);
    }
    private static double roof(double x,double z,double density,int type,int seed){
        double rolls=(CloudVolumeField.noise(x*3.3+4,7,z*3.3-2,seed+71)-.5)*.22;
        double crown=type==7 ? blob(x,z,-.12,-.04,.40,.44)*.70
            : type==2 ? blob(x,z,-.18,-.10,.47,.50)*.46 : 0;
        return clamp(.20+density*.58+rolls+crown,.13,1.05);
    }
    /** Geometry is centered at the origin. The caller positions and grows it. */
    public static Mesh build(int cx,int cz,int type,int quality){
        int n=quality<=0?8:quality==1?11:quality==2?14:17;
        float width=type==7?150:type==6?154:type==8?148:type==5?128:
            type==9?100:type==3||type==4?116:type==2?92:82;
        float height=type==7?140:type==2?72:type==6?32:type==8?25:
            type==5?9:type==3?15:type==4?24:type==9?19:37;
        int seed=cx*73428767^cz*912931^0x4d455445;
        boolean[][] occupied=new boolean[n][n];
        float[][] top=new float[n][n];
        float[][] bottom=new float[n][n];
        float[][] shades=new float[n][n];
        double threshold=type==5?.24:type==6||type==8?.30:.24;
        for(int ix=0;ix<n;ix++)for(int iz=0;iz<n;iz++){
            double x=2*(ix+.5)/n-1,z=2*(iz+.5)/n-1;
            double density=body(x,z,type,seed);
            if(density<threshold)continue;
            occupied[ix][iz]=true;
            double edge=clamp((density-threshold)/.35,0,1);
            double thickness=type==5?.45:type==3?.62:1;
            top[ix][iz]=(float)(height*roof(x,z,density,type,seed)*(.35+.65*edge));
            bottom[ix][iz]=(float)(-height*.13*thickness*edge);
            shades[ix][iz]=(float)(CloudVolumeField.noise(x*4+9,3,z*4-5,seed+97)-.5);
        }
        List<Face> faces=new ArrayList<>(n*n*3);
        float step=width/n;
        for(int ix=0;ix<n;ix++)for(int iz=0;iz<n;iz++){
            if(!occupied[ix][iz])continue;
            float x0=(ix-n/2f)*step,x1=x0+step,z0=(iz-n/2f)*step,z1=z0+step;
            float y0=bottom[ix][iz],y1=top[ix][iz],shade=shades[ix][iz];
            faces.add(new Face(x0,y1,z0,x1,y1,z1,(byte)3,shade));
            faces.add(new Face(x0,y0,z0,x1,y0,z1,(byte)2,shade));
            float west=ix==0||!occupied[ix-1][iz]?y0:top[ix-1][iz];
            float east=ix==n-1||!occupied[ix+1][iz]?y0:top[ix+1][iz];
            float north=iz==0||!occupied[ix][iz-1]?y0:top[ix][iz-1];
            float south=iz==n-1||!occupied[ix][iz+1]?y0:top[ix][iz+1];
            if(y1>west)faces.add(new Face(x0,west,z0,x0,y1,z1,(byte)0,shade));
            if(y1>east)faces.add(new Face(x1,east,z0,x1,y1,z1,(byte)1,shade));
            if(y1>north)faces.add(new Face(x0,north,z0,x1,y1,z0,(byte)4,shade));
            if(y1>south)faces.add(new Face(x0,south,z1,x1,y1,z1,(byte)5,shade));
        }
        return new Mesh(List.copyOf(faces),width,height);
    }
}
