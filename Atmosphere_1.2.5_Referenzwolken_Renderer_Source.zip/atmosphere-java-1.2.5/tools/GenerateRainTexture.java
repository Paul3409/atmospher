import dev.atmosphere.RainVeil;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public final class GenerateRainTexture {
 public static void main(String[] args)throws Exception{
  var image=new BufferedImage(128,128,BufferedImage.TYPE_INT_ARGB);
  for(int y=0;y<128;y++)for(int x=0;x<128;x++){
   int alpha=(int)(255*RainVeil.opacity(x/127.0,y/127.0));
   image.setRGB(x,y,(alpha<<24)|0xDCE5EE);
  }
  ImageIO.write(image,"png",new File(args[0]));
 }
}
