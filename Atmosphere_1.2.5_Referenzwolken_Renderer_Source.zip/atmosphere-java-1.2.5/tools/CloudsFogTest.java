import dev.atmosphere.*;

/** Mathematical regressions, not a visual Minecraft test. */
public final class CloudsFogTest {
 static void ck(boolean ok,String text){if(!ok)throw new AssertionError(text);}
 public static void main(String[] args){
  int points=0;
  for(long seed:new long[]{0,42,Long.MIN_VALUE,Long.MAX_VALUE})for(double layer:new double[]{0,1}){
   for(int j=0;j<=40;j++)for(int i=0;i<=48;i++){
    double polar=j*Math.PI/40,angle=i*Math.PI*2/48;
    var p=CloudGeometry.point(seed,polar,angle,100,80,60,140,.8,.6,layer);
    var seam=CloudGeometry.point(seed,polar,angle+Math.PI*2,100,80,60,140,.8,.6,layer);
    ck(Double.isFinite(p.nx()+p.ny()+p.nz()+p.x()+p.y()+p.z()),"Invalid geometry");
    ck(Math.hypot(p.x()-seam.x(),p.z()-seam.z())<1e-7,"Cloud seam open");
    ck(p.y()>=140&&p.y()<=200,"Cloud below base or above top");
    ck(Math.abs(p.nx()*p.nx()+p.ny()*p.ny()+p.nz()*p.nz()-1)<1e-6,"Normal not unit length");
    points++;
   }
   var bottom=CloudGeometry.point(seed,Math.PI,1,100,80,60,140,0,0,layer);
   ck(Math.hypot(bottom.x(),bottom.z())<1e-8&&bottom.y()==140,"Bottom cap open");
   var flat=CloudGeometry.point(seed,Math.PI*.85,1,100,80,60,140,0,0,layer);
   ck(flat.y()-140<.1,"Underside not flat");
   var side=CloudGeometry.point(seed,Math.PI/2,0,100,80,60,140,0,0,layer);
   ck(side.nx()>.4,"Cloud normal faces inward");
  }
  var wall=SupercellGeometry.point(42,.065,0,270,150,355,1,0,.8,.6,1,0,42);
  var rotated=SupercellGeometry.point(42,.065,0,270,150,355,1,0,.8,.6,1,160,42);
  ck(Math.abs(wall.x()-13.5)>100,"Wall cloud is still a narrow vortex");
  ck(Math.hypot(wall.x()-rotated.x(),wall.z()-rotated.z())>.1,"No cloud rotation");
  var tip=SupercellGeometry.point(42,0,0,270,150,355,1,0,.8,.6,1,160,42);
  ck(Math.hypot(tip.x()-13.5,tip.z()+94.5)<1e-8&&tip.y()==108,"Wall cloud underside is hollow");
  var unit=CloudGeometry.unitMesh(42,32,24,false);
  ck(unit==CloudGeometry.unitMesh(42,32,24,false),"Static cloud shape rebuilt");
  var layerMesh=CloudGeometry.unitMesh(42,32,24,true);
  for(double layer:new double[]{0,.5,1})for(int j=0;j<=24;j++){
   var p=CloudGeometry.transform(unit[j][7],layerMesh[j][7],layer,100,80,60,140,.8,.6);
   ck(Double.isFinite(p.x()+p.y()+p.nz()),"Cached mesh transform invalid");
   ck(Math.abs(p.nx()*p.nx()+p.ny()*p.ny()+p.nz()*p.nz()-1)<1e-6,"Transformed normal not unit");
   if(layer!=.5){
    var direct=CloudGeometry.point(42,j*Math.PI/24,7*Math.PI*2/32,100,80,60,140,.8,.6,layer);
    ck(Math.abs(direct.x()-p.x())+Math.abs(direct.y()-p.y())+Math.abs(direct.z()-p.z())<1e-8,"Cached shape changes silhouette");
   }
  }
  ck(WeatherFog.density(.6,.2,false,200)==0,"Fog switch ignored");
  ck(WeatherFog.density(.6,.2,true,0)==0,"Fog zero ignored");
  ck(WeatherFog.density(0,0,true,200)==0,"Slider forces permanent fog");
  ck(WeatherFog.density(.3,0,true,200)==.6,"Fog multiplier not applied");
  ck(WeatherFog.density(.7,0,true,200)==1,"Fog overflows");
  ck(WeatherFog.visibility(.8)<WeatherFog.visibility(.4),"Stronger fog improves visibility");
  AtmosphereSettings s=new AtmosphereSettings();int dryCloud=0,dryOvercast=0,clear=0,wet=0;
  for(int day=0;day<48;day++)for(int x=-4000;x<=4000;x+=800)for(int z=-4000;z<=4000;z+=800){
   var w=WeatherModel.sample(x,z,day*24000L+6000,s);
   if(w.rainMmH()<.1&&w.cloudiness()>.4)dryCloud++;
   if(w.rainMmH()<.1&&w.cloudiness()>.7)dryOvercast++;
   if(w.cloudiness()<.15)clear++;
   if(w.rainMmH()>4)wet++;
  }
  ck(dryCloud>500&&dryOvercast>50,"Insufficient cloud without rain: "+dryCloud+"/"+dryOvercast);
  ck(clear>30&&wet>30,"Dry clouds removed clear/rainy weather");
  System.out.println("PASS: "+points+" cloud vertices, caps, normals, rotation, fog 0/100/200; dry cloudy="
    +dryCloud+", dry overcast="+dryOvercast+", clear="+clear+", wet="+wet);
 }
}
