import dev.atmosphere.*;
import java.util.Locale;

/**
 * Regression guard for the 1.1.5 weather balance:
 *  - the world must not be permanently dry (rain must reach a useful area share)
 *  - heavy rain must stay bounded (no runaway precipitation)
 *  - the season label must follow the temperature curve (spring is not shown while it freezes)
 *  - day 0 must start in a mild spring, not in deep winter
 */
public final class WetAreaAndSeasonTest {
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    public static void main(String[] args) {
        AtmosphereSettings s = AtmosphereSettings.get();
        int wet = 0, total = 0;
        double maxRain = 0;
        for (double x = -20000; x <= 20000; x += 250) {
            for (double z = -20000; z <= 20000; z += 250) {
                WeatherModel.Weather w = WeatherModel.sample(x, 70, z, .8, 24000L * 40 + 7000, s);
                total++;
                if (w.rainMmH() > .5) wet++;
                maxRain = Math.max(maxRain, w.rainMmH());
            }
        }
        double share = 100.0 * wet / total;
        check(share > 9.0, "world too dry: " + share + "% wet");
        check(share < 30.0, "world too wet: " + share + "% wet");
        check(maxRain > 30.0, "no intense rain at all");
        check(maxRain <= 150.0, "rain exceeds model bound: " + maxRain);

        // Season label must match the temperature: the coldest quarter must not be called summer.
        String[] seasons = WeatherModel.SEASONS;
        double summerMin = Double.POSITIVE_INFINITY, winterMax = Double.NEGATIVE_INFINITY;
        for (int day = 0; day < 48; day++) {
            WeatherModel.Weather w = WeatherModel.sample(0, 70, 0, .8, 24000L * day + 6000, s);
            if (w.season() == 1) summerMin = Math.min(summerMin, w.t2());
            if (w.season() == 3) winterMax = Math.max(winterMax, w.t2());
        }
        check(summerMin > 12.0, "summer too cold (" + summerMin + " °C) - label/curve mismatch");
        check(winterMax < 12.0, "winter too warm (" + winterMax + " °C) - label/curve mismatch");
        check(seasons.length == 4, "season table");

        // Day 0 must not be deep winter.
        WeatherModel.Weather day0 = WeatherModel.sample(0, 70, 0, .8, 6000, s);
        check(day0.t2() > 8.0, "day 0 is not spring: " + day0.t2() + " °C");

        System.out.printf(Locale.ROOT,
                "PASS wet area %.1f%%, max %.1f mm/h, summer min %.1f °C, winter max %.1f °C, day0 %.1f °C%n",
                share, maxRain, summerMin, winterMax, day0.t2());
    }
}
