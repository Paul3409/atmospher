"""Create peak-limited gain variants; normal 1.2.0 slices remain unchanged."""
import argparse,concurrent.futures,json,pathlib,subprocess
def main():
    parser=argparse.ArgumentParser();parser.add_argument("--project",required=True);args=parser.parse_args()
    assets=pathlib.Path(args.project)/"src/main/resources/assets/atmosphere"
    sounds=json.loads((assets/"sounds.json").read_text(encoding="utf-8"));jobs=[]
    for name,count in {"probe":13,"fire":32,"warning":34,"clear":35}.items():
        for muted in ("","m_"):
            for boost in (2,4):
                for i in range(count):
                    source=assets/"sounds"/f"siren_{name}_{muted}{i:02d}.ogg"
                    key=f"siren_{name}_{muted}g{boost}_{i:02d}"
                    target=assets/"sounds"/(key+".ogg")
                    jobs.append(["ffmpeg","-y","-loglevel","error","-i",str(source),"-af",f"volume={boost},alimiter=limit=0.95:level=0:latency=1","-c:a","libvorbis","-q:a","3",str(target)])
                    sounds[key]={"sounds":[{"name":"atmosphere:"+key,"stream":False}]}
    def run(cmd):subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,jobs))
    (assets/"sounds.json").write_text(json.dumps(sounds,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"Prepared {len(jobs)} peak-limited boosted slices")
if __name__=="__main__":main()
