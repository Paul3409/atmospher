import dev.atmosphere.*;
import java.util.*;

/** Pure model regressions for 1.2.2; not a Fabric API or visual game test. */
public final class WeatherVarietyTest {
    private static void ck(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        ClimateClock.publish(12345,480000,6000);
        ck(ClimateClock.days(6000,1)==20,"Clock snapshot");
        ck(ClimateClock.days(7000,2)==20+2000/24000.0,"Forecast offset");
        var before=WeatherCells.nearby(0,0,20,1000);
        ClimateClock.publish(12345,480000,18000); // /time set: same weather ticks
        ck(ClimateClock.days(18000,20)==20,"Daylight/speed command teleports climate");
        ck(before.equals(WeatherCells.nearby(0,0,20,1000)),"Daylight rerolls storms");
        ClimateClock.reset();ClimateClock.publish(12345,480000,18000); // save/load
        ck(before.equals(WeatherCells.nearby(0,0,20,1000)),"Reload changes ongoing cells");
        try(var scan=ClimateClock.freeze(12345,20,18000)){
            ClimateClock.publish(12345,504000,18000);
            ck(ClimateClock.days(18000,1)==20,"Radar scan drifts across rows");
        }
        ck(ClimateClock.days(18000,1)==21,"Radar scope leaks into live weather");
        Set<Long> identities=new HashSet<>();Set<Integer> types=new HashSet<>();
        int changed=0,north=0,south=0,east=0,west=0,supercells=0;
        for(int ep=0;ep<120;ep++){
            var cell=WeatherCells.generation(0,0,ep,ep*2.4+.9);
            ck(identities.add(cell.id()),"A later event reuses an identity");types.add(cell.type());
            ck(WeatherCells.generation(0,0,ep,ep*2.4+5).growth()==0,"Dead generation reborn");
            if(cell.type()==WeatherCells.SUPERCELL)supercells++;
            if(cell.windX()>.25)east++;if(cell.windX()<-.25)west++;
            if(cell.windZ()>.25)south++;if(cell.windZ()<-.25)north++;
            var next=WeatherCells.generation(0,0,ep+1,(ep+1)*2.4+.9);
            if(cell.type()!=next.type())changed++;
        }
        ck(types.size()>=4&&changed>20,"Location has permanent weather type");
        ck(north>5&&south>5&&east>5&&west>5,"Storms still only travel southeast");
        ck(supercells>0,"No natural supercells");
        // Enumeration remains complete where query tiles meet, even after long runs.
        int checked=0;
        for(double day:new double[]{.5,2.39999,2.40001,25,1000}){
            var all=WeatherCells.nearby(690,690,day,2500);
            for(var c:all)if(Math.hypot(c.x()-690,c.z()-690)<1000){
                var at=WeatherCells.nearby(c.x(),c.z(),day,0);
                ck(at.stream().anyMatch(a->a.id()==c.id()),"Catalogue loses advected cell");
                ck(Double.isFinite(WeatherCells.sample(c.x(),c.z(),day).rain()),"Invalid rain");checked++;
            }
            var a=WeatherCells.sample(689.999,690,day);var b=WeatherCells.sample(690.001,690,day);
            ck(Math.abs(a.rain()-b.rain())<.1,"Rain jumps at catalogue boundary");
            var sa=SynopticSystems.sample(4299.999,0,day);var sb=SynopticSystems.sample(4300.001,0,day);
            ck(Math.abs(sa.pressure()-sb.pressure())<.01,"Pressure jumps at cache boundary");
        }
        Set<Integer> regimes=new HashSet<>();
        for(long ep=0;ep<200;ep++)regimes.add(WeatherRegimes.kind(ep));
        ck(regimes.size()==9,"Missing synoptic regimes");
        for(int ep=1;ep<40;ep++){
            var a=WeatherRegimes.flow(0,0,ep*8-.00001);var b=WeatherRegimes.flow(0,0,ep*8+.00001);
            ck(Math.hypot(a.x()-b.x(),a.z()-b.z())<.001,"Regime changes abruptly");
        }
        int[] count=new int[4];
        for(int seed=0;seed<10000;seed++)for(int chance=0;chance<4;chance++){
            double a=StormEvolution.tornadoActivity(seed,1,.5,chance);
            if(a>.99)count[chance]++;
            ck(StormEvolution.tornadoActivity(seed,.3,.2,chance)==0,"Tornado without mature hook");
        }
        ck(count[0]==0&&count[1]>600&&count[1]<1000&&count[2]>2200&&count[2]<2800
                &&count[3]>5600&&count[3]<6400,"Wrong per-event tornado odds: "+Arrays.toString(count));
        double notch=StormEvolution.rainProfile(5,-35,100,42,WeatherCells.SUPERCELL);
        double tip=StormEvolution.rainProfile(26,-68,100,42,WeatherCells.SUPERCELL);
        ck(tip>notch*3,"Missing curled hook tip around dry inflow");
        ClimateClock.publish(54321,480000,6000);
        ck(!before.equals(WeatherCells.nearby(0,0,20,1000)),"Different worlds share event catalogue");
        ClimateClock.reset();
        System.out.println("PASS: saved-clock snapshots, finite IDs, "+types.size()+" cell types, 9 regimes, "
                +checked+" catalogue checks and tornado odds "+Arrays.toString(count));
    }
}
