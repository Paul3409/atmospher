package net.fabricmc.loader.api;
import java.nio.file.Path;
/** Test double only; never part of the Mod JAR. */
public final class FabricLoader {
 private static final FabricLoader INSTANCE=new FabricLoader();
 public static FabricLoader getInstance(){return INSTANCE;}
 public Path getConfigDir(){return Path.of(System.getProperty("atmosphere.test.config"));}
}
