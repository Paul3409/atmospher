package net.minecraft.client.util.math;
/** Stub: the real Matrix4f type is only needed by Minecraft; tools/ never render. */
public class MatrixStack {
    public Entry peek() { return new Entry(); }
    public static class Entry {
        public Object getPositionMatrix() { return null; }
    }
}
