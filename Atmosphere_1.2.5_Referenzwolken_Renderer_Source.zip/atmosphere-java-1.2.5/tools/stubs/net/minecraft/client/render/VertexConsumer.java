package net.minecraft.client.render;
/** Minimal stub so pure-maths classes that also emit geometry can be compiled by tools/. */
public interface VertexConsumer {
    VertexConsumer vertex(Object matrix, float x, float y, float z);
    VertexConsumer color(int r, int g, int b, int a);
    VertexConsumer texture(float u, float v);
    VertexConsumer overlay(int uv);
    VertexConsumer light(int uv);
    VertexConsumer normal(float x, float y, float z);
}
