package dev.atmosphere;
public class StormEvents {
 public record Event(int type,double x,double z,double radius,double lifeDays){
     public double ageDays(long time,AtmosphereSettings settings){return 0;}
     public long started(){return 0;}
 }
 /** Standalone model tests only; no persistent state or Fabric dependency. */
 public static Event testEvent;
 public static Event activeAt(double x,double z,long time,AtmosphereSettings s){return testEvent;}
}
