import dev.atmosphere.siren.*;
public final class SirenEngineTest {
    public static void main(String[] args){
        var engine=new SirenEngine();var a=engine.add(1,false);var b=engine.add(2,false);var control=engine.add(3,true);
        a.group=b.group=control.group="Dorf";b.delay=60;
        require(engine.start("Dorf",null,SirenProgram.FIRE.ordinal(),100,false)==2,"Controller included as sound source");
        require(a.start==100&&b.start==160,"Per-siren delay lost");
        engine.stop("Dorf",null,110,true);require(a.start<0&&b.start<0,"Stop fails to cancel delayed starts");
        var g=engine.group("Dorf");g.enabled=true;
        require(!engine.weather("Dorf",true,111),"Weather interrupts manual fire alarm");
        g.manualUntil=0;require(engine.weather("Dorf",true,3000),"Automatic warning missing");
        require(a.playing==SirenProgram.WARNING.ordinal(),"Weather starts wrong signal");
        require(!engine.weather("Dorf",true,3020),"Repeated warning spam");
        engine.weather("Dorf",false,3100);require(!engine.weather("Dorf",false,3200),"Premature all-clear");
        require(engine.weather("Dorf",false,4900)&&a.playing==SirenProgram.CLEAR.ordinal(),"All-clear missing after quiet period");
        g.paused=true;long before=a.start;require(!engine.weather("Dorf",true,10000)&&a.start==before,"Paused automation still triggers");
        engine.stop(null,null,10000,true);require(a.start<0&&b.start<0,"Global stop failed");
        engine.start(null,1L,0,12000,false);require(a.active(12001)&&!b.active(12001),"Single siren targeting failed");
        engine.expire(14000);require(a.start<0,"Finished alarm remains active");
        g.paused=false;g.manualUntil=0;g.nextWarning=0;g.autoClear=false;
        engine.weather("Dorf",true,15000);engine.expire(17000);engine.weather("Dorf",false,17000);
        engine.weather("Dorf",false,18800);require(a.start<0&&!g.warned,"Disabled automatic all-clear still sounds");
        require(SirenProgram.PROBE.segments==13&&SirenProgram.CLEAR.segments==35,"Asset slice count mismatch");
        require(SirenProgram.segment(80)==2,"Playback timing mismatch");
        boolean rejected=false;try{SirenEngine.groupName("../invalid");}catch(IllegalArgumentException expected){rejected=true;}
        require(rejected,"Invalid group accepted");
        System.out.println("PASS: delays, individual/group/global stop, pending cancellation, automation, manual priority and asset timing");
    }
    private static void require(boolean v,String message){if(!v)throw new AssertionError(message);}
}
