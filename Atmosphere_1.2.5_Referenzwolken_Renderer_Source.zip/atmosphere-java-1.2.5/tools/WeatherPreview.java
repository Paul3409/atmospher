import dev.atmosphere.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import javax.imageio.ImageIO;

/** Mathematical field preview only, not a screenshot or renderer verification. */
public final class WeatherPreview {
 public static void main(String[] args)throws Exception{
  BufferedImage image=new BufferedImage(660,740,BufferedImage.TYPE_INT_RGB);
  Graphics2D g=image.createGraphics();g.setColor(Color.BLACK);g.fillRect(0,0,660,740);
  for(int y=0;y<640;y+=4)for(int x=0;x<640;x+=4){
   double u=(x/640.0*3.2-1.6),v=1.6-y/640.0*3.2;
   double rain=105*StormEvolution.rainProfile(u*100,v*100,100,42,WeatherCells.SUPERCELL);
   g.setColor(new Color(RadarReflectivity.color(RadarReflectivity.dbz(rain,0))));g.fillRect(10+x,30+y,4,4);
  }
  for(int i=0;i<640;i++){g.setColor(new Color(RadarReflectivity.color(5+70*i/639.0)));g.drawLine(10+i,685,10+i,694);}
  g.setColor(Color.WHITE);g.drawString("1.2.4: dBZ-Modellvorschau - KEIN Ingame-Bild (hier nur Regen)",10,18);
  for(int d=5;d<=75;d+=10)g.drawString(Integer.toString(d),Math.min(632,10+(d-5)*640/70),708);
  g.drawString("dBZ-Farbskala | Maus im Spiel: dBZ UND mm/h | R unveraendert",10,730);
  g.dispose();ImageIO.write(image,"png",Path.of(args[0]).toFile());
 }
}
