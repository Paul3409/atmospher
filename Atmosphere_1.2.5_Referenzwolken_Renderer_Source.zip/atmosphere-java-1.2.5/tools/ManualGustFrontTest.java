import dev.atmosphere.*;

/** Run with tools/stubs (not the Minecraft-backed StormEvents implementation). */
public final class ManualGustFrontTest {
    public static void main(String[] args) {
        var s=new AtmosphereSettings();
        s.manualWind=true;s.windKmh=10;s.gustKmh=200;s.stormFrequency=0;s.stormStrength=0;
        double along=GustFront.leading(0,270,WeatherCells.SUPERCELL);
        double angle=StormEvolution.manualAngle(StormEvolution.manualSeed(0,0,0));
        double x=along*Math.cos(angle),z=along*Math.sin(angle);
        var baseline=WeatherModel.sample(x,z,0,s);
        StormEvents.testEvent=new StormEvents.Event(WeatherCells.SUPERCELL,0,0,270,1.8);
        var gust=WeatherModel.sample(x,z,0,s);
        require(gust.windKmh()>baseline.windKmh()+15,"Manual cell has no real gust under the shelf");
        require(gust.t2()<baseline.t2()-3,"Manual gust front has no cold air signal");
        s.windGusts=false;
        var disabled=WeatherModel.sample(x,z,0,s);
        require(Math.abs(disabled.windKmh()-10)<1e-8,"Gust toggle does not disable wind increase");
        StormEvents.testEvent=null;
        System.out.println("PASS: manual shelf produces wind and cooling in shared WeatherModel; gust toggle respected");
    }
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
}
