"""Build mono alarm slices and vanilla-textured block assets from the four supplied recordings.
Requires ffmpeg/ffprobe. Run only for asset preparation; not required to compile the mod.
"""
import argparse, concurrent.futures, json, math, pathlib, subprocess

def run(args):
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def main():
    parser=argparse.ArgumentParser()
    for name in ("probe","fire","warning","clear"): parser.add_argument("--"+name, required=True)
    parser.add_argument("--project",required=True);parser.add_argument("--scratch",required=True)
    args=parser.parse_args();root=pathlib.Path(args.project)/"src/main/resources"
    assets=root/"assets/atmosphere";scratch=pathlib.Path(args.scratch);scratch.mkdir(parents=True,exist_ok=True)
    sounds=json.loads((assets/"sounds.json").read_text(encoding="utf-8"));jobs=[]
    (assets/"sounds").mkdir(parents=True,exist_ok=True)
    for name in ("probe","fire","warning","clear"):
        source=getattr(args,name);wave=scratch/(name+".wav")
        run(["ffmpeg","-y","-i",source,"-ac","1","-ar","44100",str(wave)])
        seconds=float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",source],text=True))
        for muted in (False,True):
            for i in range(math.ceil(seconds/2)):
                key=f"siren_{name}_{'m_' if muted else ''}{i:02d}"
                cmd=["ffmpeg","-y","-ss",str(i*2),"-i",str(wave),"-t","2.1"]
                if muted:cmd += ["-af","lowpass=f=900"]
                cmd += ["-c:a","libvorbis","-q:a","3",str(assets/"sounds"/(key+".ogg"))]
                jobs.append(cmd);sounds[key]={"sounds":[{"name":"atmosphere:"+key,"stream":False}]}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,jobs))
    write(assets/"sounds.json",sounds)
    faces={side:{"texture":"#metal"} for side in ("up","down","north","south","east","west")}
    def box(start,end,texture="metal",rotation=None):
        value={"from":start,"to":end,"faces":{side:{"texture":"#"+texture} for side in faces}}
        if rotation:value["rotation"]={"origin":[8,8,8],"axis":"y","angle":rotation}
        return value
    siren={"parent":"minecraft:block/block","textures":{"metal":"minecraft:block/iron_block","dark":"minecraft:block/black_concrete","particle":"minecraft:block/iron_block"},
        "elements":[box([5,0,5],[11,2,11]),box([6,2,6],[10,9,10]),box([4,7,4],[12,10,12]),
                    box([3,10,3],[13,13,13],"dark"),box([2,9,2],[14,10,14]),box([2,13,2],[14,14,14]),
                    box([3,14,1],[13,15,3]),box([1,14,3],[15,15,13]),
                    box([3,14,13],[13,15,15]),box([3,15,3],[13,16,13])]}
    for x,z in ((3,3),(11,3),(3,11),(11,11)):siren["elements"].append(box([x,10,z],[x+2,13,z+2]))
    control={"parent":"minecraft:block/block","textures":{"metal":"minecraft:block/light_gray_concrete","panel":"minecraft:block/black_concrete","red":"minecraft:block/red_concrete","green":"minecraft:block/lime_concrete","particle":"minecraft:block/light_gray_concrete"},
        "elements":[box([0,0,0],[16,14,16]),box([1,14,1],[15,15,15],"panel"),box([3,15,4],[6,16,7],"green"),box([10,15,4],[13,16,7],"red")]}
    for name,model in (("e57_siren",siren),("siren_control",control)):
        write(assets/"models/block"/(name+".json"),model)
        write(assets/"models/item"/(name+".json"),{"parent":"atmosphere:block/"+name})
        write(assets/"blockstates"/(name+".json"),{"variants":{"":{"model":"atmosphere:block/"+name}}})
        write(root/"data/atmosphere/loot_table/blocks"/(name+".json"),{"type":"minecraft:block","pools":[{"rolls":1,"entries":[{"type":"minecraft:item","name":"atmosphere:"+name}],"conditions":[{"condition":"minecraft:survives_explosion"}]}]})
    write(root/"data/atmosphere/recipe/e57_siren.json",{"type":"minecraft:crafting_shaped","pattern":["III","IRI"," I "],"key":{"I":{"item":"minecraft:iron_ingot"},"R":{"item":"minecraft:redstone"}},"result":{"id":"atmosphere:e57_siren","count":1}})
    write(root/"data/atmosphere/recipe/siren_control.json",{"type":"minecraft:crafting_shaped","pattern":["III","RCR","III"],"key":{"I":{"item":"minecraft:iron_ingot"},"R":{"item":"minecraft:redstone"},"C":{"item":"minecraft:comparator"}},"result":{"id":"atmosphere:siren_control","count":1}})
    for locale,names in {"de_de":("E57-Sirene","Sirenen-Bedienstelle"),"en_us":("E57 Siren","Siren Control Panel")}.items():
        path=assets/"lang"/(locale+".json");data=json.loads(path.read_text(encoding="utf-8"))
        data.update({"block.atmosphere.e57_siren":names[0],"block.atmosphere.siren_control":names[1]});write(path,data)
    print(f"Prepared {len(jobs)} audio slices, two block models, recipes and translations")

if __name__=="__main__":main()
