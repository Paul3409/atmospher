import dev.atmosphere.*;
import java.util.Locale;

/**
 * Unit tests for the purely optical rainbow (no Minecraft classes involved).
 * Guards the physics limits and the colour/alpha tables.
 */
public final class RainbowMathTest {
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    public static void main(String[] args) {
        // Sun elevation: 0 = sunrise, .25 = noon, .5 = sunset, .75 = midnight.
        check(Math.abs(Rainbow.sunElevation(0.0)) < 1e-9, "sunrise must be 0 degrees");
        check(Math.abs(Rainbow.sunElevation(0.25) - 90.0) < 1e-9, "noon must be 90 degrees");
        check(Math.abs(Rainbow.sunElevation(0.5)) < 1e-9, "sunset must be 0 degrees");
        check(Rainbow.sunElevation(0.75) < -89.0, "midnight must be below the horizon");

        // A bow needs a low sun, real rain and a partly clear sky.
        check(Rainbow.visibility(25, 10, .5, true) > .05, "ideal conditions must show a bow");
        check(Rainbow.visibility(25, 10, .5, false) == 0, "disabled setting must hide the bow");
        check(Rainbow.visibility(-10, 10, .5, true) == 0, "night must hide the bow");
        check(Rainbow.visibility(80, 10, .5, true) == 0, "high sun must hide the bow");
        check(Rainbow.visibility(25, .2, .5, true) == 0, "no rain means no bow");
        check(Rainbow.visibility(25, 1.0, .75, true) > .10, "light rain under a normal cloud must still show a bow");
        check(Rainbow.visibility(25, 1.0, .75, true) < Rainbow.visibility(25, 15, .75, true), "stronger rain brightens the bow");
        check(Rainbow.visibility(25, 10, 1.0, true) < Rainbow.visibility(25, 10, .5, true), "overcast must dim the bow");
        check(Rainbow.visibility(25, 10, 1.0, true) > 0, "overcast still shows a faint bow");
        check(Rainbow.visibility(25, 10, .5, true) <= 1.0, "visibility must stay bounded");

        // Monotonic in rain intensity while everything else is fixed.
        double a = Rainbow.visibility(25, 3, .5, true);
        double b = Rainbow.visibility(25, 9, .5, true);
        double c = Rainbow.visibility(25, 40, .5, true);
        check(a <= b && b <= c, "stronger rain must not reduce visibility");

        // Colour tables: 7 bands, all in range, secondary bow reversed.
        for (int i = 0; i < 7; i++) {
            int[] primary = Rainbow.bandColor(i, false);
            int[] secondary = Rainbow.bandColor(i, true);
            for (int ch : primary) check(ch >= 0 && ch <= 255, "primary channel range");
            for (int ch : secondary) check(ch >= 0 && ch <= 255, "secondary channel range");
            int[] mirrored = Rainbow.bandColor(6 - i, false);
            check(secondary[0] == mirrored[0] && secondary[1] == mirrored[1] && secondary[2] == mirrored[2],
                    "secondary bow must reverse the colour order");
        }
        // Out of range indices must clamp instead of throwing.
        check(Rainbow.bandColor(-5, false).length == 3, "negative band index clamps");
        check(Rainbow.bandColor(99, true).length == 3, "large band index clamps");

        // Alpha: bounded, secondary dimmer than primary.
        for (int i = 0; i < 7; i++) {
            int pa = Rainbow.bandAlpha(1.0, false, i, 7);
            int sa = Rainbow.bandAlpha(1.0, true, i, 7);
            check(pa >= 0 && pa <= 255, "primary alpha range");
            check(sa >= 0 && sa <= 255, "secondary alpha range");
            check(sa < pa, "secondary bow must be dimmer");
            check(Rainbow.bandAlpha(0.0, false, i, 7) == 0, "zero visibility means zero alpha");
        }

        // Geometry sanity: the primary bow sits inside the secondary one.
        check(Rainbow.PRIMARY_ANGLE < Rainbow.SECONDARY_ANGLE, "primary inside secondary");

        System.out.printf(Locale.ROOT,
                "PASS RainbowMathTest: vis(25deg,10mm/h,.5)=%.2f, primary %.0f deg, secondary %.0f deg%n",
                Rainbow.visibility(25, 10, .5, true), Rainbow.PRIMARY_ANGLE, Rainbow.SECONDARY_ANGLE);
    }
}
