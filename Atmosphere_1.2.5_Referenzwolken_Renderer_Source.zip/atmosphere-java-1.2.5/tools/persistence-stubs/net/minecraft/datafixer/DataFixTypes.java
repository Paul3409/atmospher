package net.minecraft.datafixer;
public enum DataFixTypes {SAVED_DATA_MAP_DATA}
