package net.minecraft.world;
import java.util.*;
import net.minecraft.nbt.NbtCompound;
public class PersistentStateManager {
 public final Map<String,PersistentState> live=new HashMap<>();
 public final Map<String,NbtCompound> saved=new HashMap<>();
 @SuppressWarnings("unchecked") public <T extends PersistentState>T getOrCreate(PersistentState.Type<T> type,String key){
  return (T)live.computeIfAbsent(key,k->saved.containsKey(k)?type.reader().apply(saved.get(k),null):type.factory().get());
 }
 public void saveAndUnload(){live.forEach((k,v)->saved.put(k,v.writeNbt(new NbtCompound(),null)));live.clear();}
}
