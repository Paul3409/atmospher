package net.minecraft.world;
import java.util.function.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.datafixer.DataFixTypes;
public abstract class PersistentState {
 public record Type<T extends PersistentState>(Supplier<T> factory,BiFunction<NbtCompound,RegistryWrapper.WrapperLookup,T> reader,DataFixTypes fix){}
 public abstract NbtCompound writeNbt(NbtCompound n,RegistryWrapper.WrapperLookup registry);
 public void markDirty(){}
}
