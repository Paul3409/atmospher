package net.minecraft.server;
import net.minecraft.server.world.ServerWorld;
public class MinecraftServer {
 public final ServerWorld world=new ServerWorld();
 public ServerWorld getOverworld(){return world;} public void execute(Runnable r){r.run();}
}
