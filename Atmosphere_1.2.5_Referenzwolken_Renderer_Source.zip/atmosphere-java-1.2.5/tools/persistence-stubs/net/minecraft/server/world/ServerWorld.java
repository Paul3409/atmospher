package net.minecraft.server.world;
import net.minecraft.world.PersistentStateManager;
public class ServerWorld {
 public long age=50000,daylight=50000,seed=12345;
 private final PersistentStateManager states=new PersistentStateManager();
 public long getTime(){return age;} public long getTimeOfDay(){return daylight;} public long getSeed(){return seed;}
 public PersistentStateManager getPersistentStateManager(){return states;}
}
