package net.minecraft.registry;
public interface RegistryWrapper {interface WrapperLookup {}}
