package net.minecraft.nbt;
public class NbtElement {public static final int LIST_TYPE=9,COMPOUND_TYPE=10;}
