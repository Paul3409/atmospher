package net.minecraft.nbt;
import java.util.*;
public class NbtCompound {
 private final Map<String,Object> values=new HashMap<>();
 public void putDouble(String k,double v){values.put(k,v);} public double getDouble(String k){return ((Number)values.getOrDefault(k,0)).doubleValue();}
 public void putLong(String k,long v){values.put(k,v);} public long getLong(String k){return ((Number)values.getOrDefault(k,0)).longValue();}
 public void putInt(String k,int v){values.put(k,v);} public int getInt(String k){return ((Number)values.getOrDefault(k,0)).intValue();}
 public void putBoolean(String k,boolean v){values.put(k,v);} public boolean getBoolean(String k){return (Boolean)values.getOrDefault(k,false);}
 public boolean contains(String k){return values.containsKey(k);} public boolean contains(String k,int type){return values.containsKey(k);}
 public void put(String k,NbtList v){values.put(k,v);} public NbtList getList(String k,int type){return (NbtList)values.getOrDefault(k,new NbtList());}
}
