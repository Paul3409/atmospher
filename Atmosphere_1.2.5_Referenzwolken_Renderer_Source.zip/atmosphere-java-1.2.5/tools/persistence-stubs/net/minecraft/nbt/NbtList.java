package net.minecraft.nbt;
public class NbtList extends java.util.ArrayList<NbtCompound> {
 public NbtCompound getCompound(int i){return get(i);}
}
