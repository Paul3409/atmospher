import dev.atmosphere.*;
import java.util.List;

public final class CloudSceneTest {
 static void ck(boolean ok,String text){if(!ok)throw new AssertionError(text);}
 public static void main(String[] args){
  var storm=new WeatherCells.Cell(WeatherCells.SUPERCELL,0,0,270,1,1,1,.8,1,0,42);
  ck(CloudScene.backgroundVisibility(0,0,List.of(storm))==0,"Deck still hides mature cell");
  ck(CloudScene.backgroundVisibility(1000,0,List.of(storm))==1,"Distant clouds removed");
  double previous=-1;
  for(int x=0;x<1000;x++){
   double visible=CloudScene.backgroundVisibility(x,0,List.of(storm));
   ck(visible>=0&&visible<=1&&visible>=previous,"Background transition discontinuous");previous=visible;
  }
  var young=new WeatherCells.Cell(WeatherCells.SUPERCELL,0,0,270,.1,.1,0,.1,1,0,42);
  ck(CloudScene.backgroundVisibility(0,0,List.of(young))==1,"Young cell erases background");
  for(int q=0;q<4;q++)ck(CloudScene.stormLevels(q)>=44&&CloudScene.stormSides(q)>=48,"Reference shape loses lowering on low quality");
  for(int i=0;i<=100;i++){
   double t=i/100.0;
   var p=SupercellGeometry.point(42,t,.4,270,130,355,1,0,.8,.6);
   ck(Double.isFinite(p.x()+p.y()+p.z()+p.nx()),"Template invalid");
   if(t==0)ck(p.y()==88,"Wall lowering changed");
  }
  for(int i=0;i<=100;i++){
   double v=i/100.0;
   ck(RainVeil.opacity(0,v)==0&&RainVeil.opacity(1,v)==0,"Hard rain side edge");
   ck(RainVeil.opacity(v,0)==0&&RainVeil.opacity(v,1)==0,"Hard rain top/bottom edge");
   ck(RainVeil.opacity(.5,v)>=0&&RainVeil.opacity(.5,v)<=1,"Rain opacity out of bounds");
  }
  ck(RainVeil.opacity(.5,.3)>.1,"Rain invisible");
  ck(CloudLighting.shade(0,1,0,.4)>CloudLighting.shade(0,-1,0,.4),"Lighting inverted");
  System.out.println("PASS: full-scene background suppression, reference LOD floor, rain edge mask and shared lighting");
 }
}
