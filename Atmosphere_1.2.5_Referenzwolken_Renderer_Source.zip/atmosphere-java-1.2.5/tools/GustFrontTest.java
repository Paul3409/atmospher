import dev.atmosphere.GustFront;
import dev.atmosphere.ShelfCloudGeometry;
import dev.atmosphere.WeatherCells;

public final class GustFrontTest {
    public static void main(String[] args) {
        for(int type:new int[]{WeatherCells.SEVERE,WeatherCells.SUPERCELL,WeatherCells.SQUALL}) {
            for(int i=1;i<20;i++) {
                double side=i/20.0,across=(side*2-1)*GustFront.span(200,type);
                var edge=ShelfCloudGeometry.point(side,0,200,130,1,type);
                double leading=GustFront.leading(across,200,type);
                require(Math.abs(edge.along()-leading)<1e-8,"Shelf and wind-front position differ");
                require(GustFront.intensity(leading,across,200,1,type)>
                        GustFront.intensity(leading+150,across,200,1,type),"Wind does not peak at shelf edge");
                for(int j=0;j<=24;j++) {
                    var p=ShelfCloudGeometry.point(side,j*Math.PI/12,200,130,1,type);
                    require(Double.isFinite(p.y())&&Double.isFinite(p.along()),"Invalid shelf mesh");
                }
            }
        }
        require(GustFront.intensity(250,0,200,1,WeatherCells.SHOWER)==0,"Ordinary shower has severe gust front");
        require(GustFront.intensity(250,0,200,.1,WeatherCells.SEVERE)==0,"Shelf before storm development");
        require(GustFront.intensity(250,1000,200,1,WeatherCells.SEVERE)==0,"Front extends beyond cell span");
        System.out.println("PASS: bowed shelf edge matches wind peak, bounded reach and storm maturity");
    }
    private static void require(boolean v,String message){if(!v)throw new AssertionError(message);}
}
