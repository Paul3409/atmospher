package dev.atmosphere.visual;

import dev.atmosphere.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.util.ScreenshotRecorder;

/** Development fixture using only checked Yarn 1.21.1 entry points. */
public final class CloudVisualTest implements ClientModInitializer {
    private int tick;
    @Override public void onInitializeClient(){
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            if(client.world==null||client.player==null||client.getServer()==null)return;
            tick++;var s=AtmosphereSettings.get();
            if(tick==1){
                s.cloudFocus=true;s.customClouds=true;s.adaptiveGraphics=false;s.cloudDetail=2;s.quality=2;
                s.particles=false;s.weatherSounds=false;s.hud=false;s.atmosphericFog=false;s.weatherSpeed=1;
                s.visualLightning=false;s.cloudShadows=false;s.tornadoChance=0;
                StormEvents.spawn(client.getServer(),WeatherCells.SUPERCELL,0,0);
                client.options.hudHidden=true;
                client.getNetworkHandler().sendChatCommand("gamemode spectator");
                client.getNetworkHandler().sendChatCommand("tp @s -620 90 -450 -54 -15");
                System.out.println("ATMOSPHERE_VISUAL world ready");
            }
            if(tick==160)ScreenshotRecorder.saveScreenshot(client.runDirectory,"01-outside-focus.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==180)client.getNetworkHandler().sendChatCommand("tp @s -140 75 -80 -60 -45");
            if(tick==320)ScreenshotRecorder.saveScreenshot(client.runDirectory,"02-below-focus.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==340){s.cloudFocus=false;client.getNetworkHandler().sendChatCommand("tp @s -620 90 -450 -54 -15");}
            if(tick==500)ScreenshotRecorder.saveScreenshot(client.runDirectory,"03-outside-scene.png",client.getFramebuffer(),
                    text->System.out.println("ATMOSPHERE_VISUAL "+text.getString()));
            if(tick==540)client.scheduleStop();
        });
    }
}
