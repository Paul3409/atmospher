"""Create a disposable, command-enabled Minecraft 1.21.1 flat visual fixture."""
from pathlib import Path
import nbtlib as n

root=Path("run")
world=root/"saves"/"CloudPreview"
if (world/"level.dat").exists():
    raise SystemExit("Refusing to overwrite an existing CloudPreview world")
world.mkdir(parents=True,exist_ok=True)
S,I,L,B,C=n.String,n.Int,n.Long,n.Byte,n.Compound
dimensions=C({
 "minecraft:overworld":C({"type":S("minecraft:overworld"),"generator":C({"type":S("minecraft:flat"),"settings":C({
  "biome":S("minecraft:plains"),"lakes":B(0),"features":B(0),"structure_overrides":n.List[S]([]),
  "layers":n.List[C]([C({"height":I(1),"block":S("minecraft:bedrock")}),C({"height":I(130),"block":S("minecraft:dirt")}),C({"height":I(1),"block":S("minecraft:grass_block")})])})})}),
 "minecraft:the_nether":C({"type":S("minecraft:the_nether"),"generator":C({"type":S("minecraft:noise"),"settings":S("minecraft:nether"),"biome_source":C({"type":S("minecraft:multi_noise"),"preset":S("minecraft:nether")})})}),
 "minecraft:the_end":C({"type":S("minecraft:the_end"),"generator":C({"type":S("minecraft:noise"),"settings":S("minecraft:end"),"biome_source":C({"type":S("minecraft:the_end")})})})})
data=C({"DataVersion":I(3955),"LevelName":S("CloudPreview"),"GameType":I(1),"allowCommands":B(1),"initialized":B(1),
 "hardcore":B(0),"Difficulty":B(0),"Time":L(0),"DayTime":L(6000),"LastPlayed":L(0),
 "SpawnX":I(0),"SpawnY":I(69),"SpawnZ":I(0),"SpawnAngle":n.Float(0),
 "Version":C({"Id":I(3955),"Name":S("1.21.1"),"Snapshot":B(0),"Series":S("main")}),
 "GameRules":C({key:S(value) for key,value in {"doDaylightCycle":"false","doWeatherCycle":"false","doMobSpawning":"false","randomTickSpeed":"0","spawnRadius":"0"}.items()}),
 "DataPacks":C({"Enabled":n.List[S]([S("vanilla"),S("fabric")]),"Disabled":n.List[S]([])}),
 "enabled_features":n.List[S]([S("minecraft:vanilla")]),
 "WorldGenSettings":C({"seed":L(42),"generate_features":B(0),"bonus_chest":B(0),"dimensions":dimensions})})
n.File({"Data":data}).save(world/"level.dat",gzipped=True)
options=root/"options.txt"
if not options.exists():
    options.write_text("renderDistance:24\nsimulationDistance:5\nmaxFps:30\ngraphicsMode:1\nguiScale:2\nfullscreen:false\nfov:0.0\n",encoding="utf8")
