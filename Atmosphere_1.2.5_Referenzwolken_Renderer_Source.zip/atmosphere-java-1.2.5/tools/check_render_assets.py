"""Validate the 1.21.1 shader bundle and generated rain edge mask."""
import json,re
from pathlib import Path
from PIL import Image

root=Path(__file__).resolve().parents[1]
base=root/"src/main/resources/assets/atmosphere"
shader=base/"shaders/core"
data=json.loads((shader/"cloud_hull.json").read_text())
assert data["attributes"]==["Position","UV0","Color"]
assert data["vertex"]==data["fragment"]=="atmosphere:cloud_hull"
stages={s:(shader/f"cloud_hull.{s}").read_text() for s in ("vsh","fsh")}
for code in stages.values():
    assert code.startswith("#version 150")
uniforms={name:kind for code in stages.values() for kind,name in re.findall(r"uniform\s+(\w+)\s+(\w+);",code)}
declared={u["name"] for u in data["uniforms"]}|{s["name"] for s in data["samplers"]}
assert set(uniforms)==declared,(uniforms,declared)
for u in data["uniforms"]:
    assert u["count"]==len(u["values"])
assert "Light0_Direction" not in uniforms,"Entity light leaked into cloud shader"
vertex_out={name:kind for kind,name in re.findall(r"out\s+(\w+)\s+(\w+);",stages["vsh"])}
fragment_in={name:kind for kind,name in re.findall(r"in\s+(\w+)\s+(\w+);",stages["fsh"])}
assert vertex_out==fragment_in
image=Image.open(base/"textures/environment/rain_veil.png").convert("RGBA")
alpha=image.getchannel("A")
assert alpha.crop((0,0,image.width,1)).getextrema()[1]==0
assert alpha.crop((0,image.height-1,image.width,image.height)).getextrema()[1]==0
assert alpha.crop((0,0,1,image.height)).getextrema()[1]==0
assert alpha.crop((image.width-1,0,image.width,image.height)).getextrema()[1]==0
assert alpha.getextrema()[1]>20
print("PASS: 1.21.1 GLSL150 asset interface, uniforms, sampler and rain edge transparency")
