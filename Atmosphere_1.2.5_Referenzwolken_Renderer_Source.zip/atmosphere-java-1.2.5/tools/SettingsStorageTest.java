import dev.atmosphere.SettingsStorage;
import java.nio.file.*;
import java.util.Properties;
import java.io.*;
public final class SettingsStorageTest {
    public static void main(String[] args)throws Exception {
        Path dir=Files.createTempDirectory("atmosphere-config-test-");
        Path file=dir.resolve("settings.properties");
        try {
            var p=new Properties();p.setProperty("quality","2");SettingsStorage.write(file,p,"test");
            byte[] original=Files.readAllBytes(file);
            var broken=new Properties(){@Override public void store(OutputStream out,String comment)throws IOException {
                out.write(123);throw new IOException("Simulated interrupted serialization");
            }};
            boolean failed=false;
            try{SettingsStorage.write(file,broken,"test");}catch(IOException expected){failed=true;}
            if(!failed||!java.util.Arrays.equals(original,Files.readAllBytes(file)))throw new AssertionError("Old config lost");
            try(var files=Files.list(dir)){if(files.count()!=1)throw new AssertionError("Temporary file leaked");}
            System.out.println("PASS: config replacement preserves previous data after write failure");
        } finally {Files.deleteIfExists(file);Files.deleteIfExists(dir);}
    }
}
