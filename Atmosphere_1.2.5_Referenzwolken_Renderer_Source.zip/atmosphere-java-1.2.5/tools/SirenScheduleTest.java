import dev.atmosphere.siren.*;
public final class SirenScheduleTest {
    public static void main(String[] args){
        var e=new SirenEngine();var a=e.add(1,false);var b=e.add(2,false);a.group=b.group="Dorf";
        a.volume=180;a.levels[2]=200;a.delay=45;a.radius=1024;b.delay=10;b.radius=64;
        e.copyLevels(a);require(b.volume==180&&b.levels[2]==200&&b.delay==10&&b.radius==64,"Group gain copy changes unrelated settings");
        require(SirenGain.effective(200,200)==4&&SirenGain.effective(100,0)==0,"Gain range wrong");
        for(int i=0;i<=400;i++){double gain=i/100.0;int variant=SirenGain.variant(gain);require(gain/SirenGain.boost(variant)<=1,"OpenAL gain clamp remains");}
        require(SirenEngine.clockTicks("06:00")==0&&SirenEngine.clockTicks("12:00")==6000&&SirenEngine.clockTicks("00:00")==18000,"Minecraft clock conversion wrong");
        for(int h=0;h<24;h++)for(int m=0;m<60;m++){
            String clock=String.format(java.util.Locale.ROOT,"%02d:%02d",h,m);
            require(SirenEngine.clock(SirenEngine.clockTicks(clock)).equals(clock),"Clock roundtrip failed");
        }
        var g=e.group("Dorf");g.probeEnabled=true;g.probeTime=6000;
        e.schedule("Dorf",0,5999);e.schedule("Dorf",5,6000);require(a.start==50&&a.playing==0,"Probe not started at target time");
        e.schedule("Dorf",10,6001);require(a.start==50,"Probe repeats within same day");
        e.stop("Dorf",null,11,true);e.schedule("Dorf",12,5999);e.schedule("Dorf",13,6000);require(a.start<0,"Rewinding time repeats alarm");
        g.probePaused=true;e.schedule("Dorf",2500,29999);e.schedule("Dorf",2505,30000);require(a.start<0,"Paused probe starts");
        g.probePaused=false;e.schedule("Dorf",2510,30001);require(a.start<0,"Resume causes catch-up alarm");
        e.schedule("Dorf",5000,53999);e.schedule("Dorf",5005,54000);require(a.start==5050,"Next day's probe missing");
        e.stop("Dorf",null,5006,false);g.warned=true;e.schedule("Dorf",8000,77999);e.schedule("Dorf",8005,78000);require(a.start<0,"Probe interrupts weather warning");
        g.warned=false;g.probeEnabled=false;e.schedule("Dorf",11000,101999);e.schedule("Dorf",11005,102000);require(a.start<0,"Disabled probe starts");
        g.probeEnabled=true;e.schedule("Dorf",12000,130000);require(a.start<0,"Time jump causes catch-up probe");
        System.out.println("PASS: per-signal gain, group transfer, 1440 clock values, daily schedule, pause, rewind and alarm priority");
    }
    private static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
}
