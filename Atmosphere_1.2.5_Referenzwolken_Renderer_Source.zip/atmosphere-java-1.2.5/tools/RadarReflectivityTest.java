import dev.atmosphere.*;

public final class RadarReflectivityTest {
 static void ck(boolean v,String m){if(!v)throw new AssertionError(m);}
 public static void main(String[] args){
  ck(!Double.isFinite(RadarReflectivity.dbz(0,0)),"Dry weather gets echo");
  for(double r:new double[]{-.1,Double.NaN,Double.POSITIVE_INFINITY})
   ck(!Double.isFinite(RadarReflectivity.dbz(r,0)),"Invalid rate gets echo");
  for(double r:new double[]{.1,.5,1,5,10,20,50,100,150}){
   double d=RadarReflectivity.dbz(r,0);
   ck(Math.abs(d-(10*Math.log10(200)+16*Math.log10(r)))<1e-10,"Rain Z-R mismatch");
   ck(Math.abs(RadarReflectivity.rainRate(d)-r)<1e-8,"Rain Z-R round-trip");
  }
  ck(Math.abs(RadarReflectivity.dbz(1,0)-23.0103)<.0001,"1 mm/h benchmark");
  ck(Math.abs(RadarReflectivity.dbz(10,0)-39.0103)<.0001,"10 mm/h benchmark");
  for(int kind=0;kind<=4;kind++){
   double previous=-1e6;
   for(int i=1;i<=1500;i++){
    double d=RadarReflectivity.dbz(i/10.0,kind);
    ck(Double.isFinite(d)&&d>previous,"Frozen/mixed estimate not monotonic");previous=d;
   }
  }
  ck(RadarReflectivity.color(Double.NEGATIVE_INFINITY)==0xFF080B10,"No-echo colour");
  ck(RadarReflectivity.color(65)==0xFFF1ACDF,"Pink dBZ threshold");
  ck(RadarReflectivity.color(75)==0xFF780086,"Purple upper threshold");
  ck(RadarReflectivity.color(100)==RadarReflectivity.color(75),"Palette not bounded");
  ck(RadarReflectivity.dbz(100,4)>RadarReflectivity.dbz(100,0),"Hail estimate not separate");
  // The broad transition must already rain outside the old thin centreline.
  double broad=StormEvolution.rainProfile(-80,-5,100,42,WeatherCells.SUPERCELL);
  double notch=StormEvolution.rainProfile(5,-35,100,42,WeatherCells.SUPERCELL);
  ck(broad>.12&&broad>notch*3,"Rear flank still a pasted-on thin line");
  System.out.println("PASS: rain Z-R round-trip, 7500 mixed/frozen values, palette thresholds and broad hook root");
 }
}
