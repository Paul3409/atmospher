package dev.atmosphere;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.*;
import java.util.Properties;

/** Finish serialization before replacing the last known config. */
public final class SettingsStorage {
    private SettingsStorage() {}
    public static void write(Path file,Properties properties,String comment) throws IOException {
        Path parent=file.toAbsolutePath().getParent();
        Files.createDirectories(parent);
        Path temp=Files.createTempFile(parent,"atmosphere-",".tmp");
        try {
            try(OutputStream out=Files.newOutputStream(temp)){properties.store(out,comment);}
            try {Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException ex){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
        } finally {Files.deleteIfExists(temp);}
    }
}
