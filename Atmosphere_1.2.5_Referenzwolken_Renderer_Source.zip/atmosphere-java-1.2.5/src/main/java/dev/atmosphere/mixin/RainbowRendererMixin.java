package dev.atmosphere.mixin;

import dev.atmosphere.AtmosphereSettings;
import dev.atmosphere.Rainbow;
import dev.atmosphere.WeatherModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 1.1.7: draws the optical rainbow inside WorldRenderer's own render pass.
 *
 * <p>Why {@code renderSky} and why the buffer is flushed here:
 * <ul>
 *   <li>Emitting from a foreign Fabric event handler can request a RenderLayer
 *       off the render thread, which throws.</li>
 *   <li>The first 1.1.6 attempt hooked {@code renderSky}, but {@code renderSky}
 *       builds its own matrices from the projection matrix. A fresh
 *       {@code new MatrixStack()} therefore produced vertices far outside the
 *       frustum - the bow was emitted and then culled.</li>
 *   <li>{@code VertexConsumerProvider.Immediate.draw()} inside the injection is
 *       required, otherwise the batch is never submitted.</li>
 * </ul>
 * The bow is emitted at a fixed radius around the camera with an identity model
 * matrix, because {@code RenderLayer.getEntityTranslucent} already applies the
 * view rotation from the render system.
 */
@Mixin(WorldRenderer.class)
public abstract class RainbowRendererMixin {
    private static final Identifier ATMOSPHERE_WHITE =
            Identifier.of("atmosphere", "textures/environment/lightning.png");

    @Inject(method = "renderSky(Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V",
            at = @At("TAIL"))
    private void atmosphere$rainbow(org.joml.Matrix4f matrix4f, org.joml.Matrix4f projectionMatrix,
                                    float tickDelta, net.minecraft.client.render.Camera camera,
                                    boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        AtmosphereSettings s = AtmosphereSettings.get();
        if (!s.rainbow || client.world == null || client.player == null
                || client.world.getRegistryKey() != World.OVERWORLD) return;
        double skyAngle = client.world.getSkyAngle(tickDelta);
        Vec3d pos = camera.getPos();
        WeatherModel.Weather w = WeatherModel.sample(client.world, pos.x, pos.y, pos.z,
                client.world.getTimeOfDay(), s);
        double vis = Rainbow.visibility(Rainbow.sunElevation(skyAngle), w.rainMmH(), w.cloudiness(), true);
        if (vis < 0.02) return;
        VertexConsumerProvider.Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer v = consumers.getBuffer(RenderLayer.getEntityTranslucent(ATMOSPHERE_WHITE));
        // Identity matrix: renderSky's matrix already contains the world rotation.
        MatrixStack matrices = new MatrixStack();
        Rainbow.drawRainbow(v, matrices, pos, skyAngle, vis);
        // Flush immediately - without this the batch is dropped at the end of the frame.
        consumers.draw();
    }
}
