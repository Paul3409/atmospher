package dev.atmosphere.mixin;

import dev.atmosphere.StormLighting;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Verified against Yarn 1.21.1+build.3 ClientWorld sky methods. */
@Mixin(ClientWorld.class)
public abstract class StormSkyMixin {
    @Inject(method="getSkyBrightness(F)F",at=@At("RETURN"),cancellable=true)
    private void atmosphere$dimSkyLight(float tickDelta,CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue((float)(cir.getReturnValue()*StormLighting.factor()));
    }
    @Inject(method="getSkyColor(Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;",at=@At("RETURN"),cancellable=true)
    private void atmosphere$dimSkyColor(Vec3d cameraPos,float tickDelta,CallbackInfoReturnable<Vec3d> cir) {
        cir.setReturnValue(cir.getReturnValue().multiply(StormLighting.factor()));
    }
}
