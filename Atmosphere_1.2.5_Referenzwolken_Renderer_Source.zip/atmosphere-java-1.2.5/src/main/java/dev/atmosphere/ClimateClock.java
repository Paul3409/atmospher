package dev.atmosphere;

/** Shared immutable singleplayer clock. Daylight commands do not rewind weather.
 * Forecast callers supply their future daylight time relative to the snapshot. */
public final class ClimateClock {
    public record Snapshot(long seed,double ticks,long daylight) {}
    private static volatile Snapshot snapshot;
    private static final ThreadLocal<Snapshot> LOCAL=new ThreadLocal<>();
    public interface Scope extends AutoCloseable {@Override void close();}
    /** Freeze a multi-frame radar scan without changing the live server clock. */
    public static Scope freeze(long seed,double days,long daylight){
        Snapshot previous=LOCAL.get();LOCAL.set(new Snapshot(seed,days*24000,daylight));
        return ()->{if(previous==null)LOCAL.remove();else LOCAL.set(previous);};
    }
    private ClimateClock() {}
    public static void publish(long seed,double ticks,long daylight) {
        if(Double.isFinite(ticks)) snapshot=new Snapshot(seed,ticks,daylight);
    }
    public static double days(long daylight,double speed) {
        Snapshot s=LOCAL.get();if(s==null)s=snapshot;
        return s==null?daylight/24000.0*speed:
                (s.ticks()+((double)daylight-s.daylight())*speed)/24000.0;
    }
    public static long seed(){Snapshot s=LOCAL.get();if(s==null)s=snapshot;return s==null?0:s.seed();}
    public static void reset(){snapshot=null;}
}
