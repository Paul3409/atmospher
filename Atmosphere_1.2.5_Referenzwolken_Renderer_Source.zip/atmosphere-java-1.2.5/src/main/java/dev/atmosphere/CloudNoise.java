package dev.atmosphere;

/** Continuous 3-D value noise: seam/pole-safe, world/camera independent. */
public final class CloudNoise {
    private CloudNoise(){}
    private static double h(int x,int y,int z,long seed){return WeatherCells.hash(x^seed,z^((long)y*1000003),1501)*2-1;}
    public static double sample(double x,double y,double z,long seed){
        int ix=(int)Math.floor(x),iy=(int)Math.floor(y),iz=(int)Math.floor(z);
        double u=WeatherCells.smooth(0,1,x-ix),v=WeatherCells.smooth(0,1,y-iy),w=WeatherCells.smooth(0,1,z-iz);
        double a=h(ix,iy,iz,seed)*(1-u)+h(ix+1,iy,iz,seed)*u;
        double b=h(ix,iy+1,iz,seed)*(1-u)+h(ix+1,iy+1,iz,seed)*u;
        double c=h(ix,iy,iz+1,seed)*(1-u)+h(ix+1,iy,iz+1,seed)*u;
        double d=h(ix,iy+1,iz+1,seed)*(1-u)+h(ix+1,iy+1,iz+1,seed)*u;
        return (a*(1-v)+b*v)*(1-w)+(c*(1-v)+d*v)*w;
    }
    public static double billow(double x,double y,double z,long seed){
        return .28*sample(x*2.3,y*2.3,z*2.3,seed)
                +.14*sample(x*5.1,y*5.1,z*5.1,seed^37)
                +.055*sample(x*10.7,y*10.7,z*10.7,seed^73);
    }
}
