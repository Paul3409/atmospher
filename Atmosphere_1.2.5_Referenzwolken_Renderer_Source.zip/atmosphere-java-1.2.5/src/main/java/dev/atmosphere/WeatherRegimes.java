package dev.atmosphere;

/** Seeded large-scale steering, with continuously blended, non-cyclic episodes.
 * Coordinates use Minecraft north=-Z. Names describe wind FROM that direction. */
public final class WeatherRegimes {
    public static final String[] NAMES={"Westlage","Nordwestlage","Nordlage","Südwestlage",
            "Südlage","Ostlage","Ruhiges Hoch","Blocking","Abgetropftes Tief"};
    public record Flow(double x,double z,double humidity,double warmth,double lift,double shear,double blocking){}
    private static final double[][] VALUES={
        {1,.12,.79,.46,.68,.75,0},{.75,.70,.63,.19,.65,.67,.1},
        {.06,1,.58,.05,.48,.58,.25},{.78,-.65,.83,.87,.78,.87,0},
        {.1,-1,.65,1,.56,.59,.16},{-1,.1,.35,.36,.25,.42,.36},
        {.18,.06,.21,.58,.07,.13,.66},{-.18,.50,.39,.27,.32,.47,1},
        {.12,-.17,.88,.43,.78,.59,.72}};
    private WeatherRegimes(){}
    private static long episode(double days){return (long)Math.floor(days/8.0);}
    public static int kind(long ep){return (int)(WeatherCells.hash(ep,ClimateClock.seed(),1101)*VALUES.length);}
    public static Flow flow(double x,double z,double days){
        long ep=episode(days);double local=days-ep*8;
        double start=5+1.4*WeatherCells.hash(ep,ClimateClock.seed(),1103);
        double blend=WeatherCells.smooth(start,8,local);
        double[] a=VALUES[kind(ep)],b=VALUES[kind(ep+1)],v=new double[7];
        for(int i=0;i<v.length;i++)v[i]=a[i]+(b[i]-a[i])*blend;
        // Ridges and troughs deflect the steering; blocking produces a stronger bend.
        double wave=x/3700+z/6500+days*.13+WeatherCells.hash(ClimateClock.seed(),0,1109)*6.2831853;
        double angle=(.20+.65*v[6])*Math.sin(wave);
        double cx=Math.cos(angle),sn=Math.sin(angle);
        return new Flow(v[0]*cx-v[1]*sn,v[0]*sn+v[1]*cx,v[2],v[3],v[4],v[5],v[6]);
    }
}
