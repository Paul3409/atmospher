package dev.atmosphere;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/**
 * Purely optical rainbow: a procedural bow emitted as coloured vertices, no texture
 * and no world interaction. It only appears when the sun is low, the player is in or
 * near rain and the anti-solar point is inside the visible half of the sky.
 *
 * <p>The visibility window and the colour tables are pure functions so they can be
 * unit-tested without Minecraft; the geometry itself is emitted by
 * {@link #drawRainbow}, which is called from inside WorldRenderer's vertex buffer.
 */
public final class Rainbow {
    /** Radius of the primary bow in degrees of arc. */
    public static final double PRIMARY_ANGLE = 42.0;
    /** Secondary bow (reversed colour order, dimmer) sits further out. */
    public static final double SECONDARY_ANGLE = 51.0;
    private static final double DISTANCE = 340.0;
    private static final int BANDS = 7;
    private static final int SEGMENTS = 24;
    private Rainbow() {}

    /** Sun elevation in degrees; negative means below the horizon. */
    public static double sunElevation(double skyAngle) {
        // Vanilla skyAngle: 0 = sunrise, 0.25 = noon, 0.5 = sunset, 0.75 = midnight.
        return Math.sin(skyAngle * Math.PI * 2.0) * 90.0;
    }

    /**
     * Visibility factor 0..1. The bow needs a low sun (3-52 degrees), rain and a
     * partly clear sky. Returns 0 whenever the bow cannot physically appear.
     */
    public static double visibility(double sunElevationDegrees, double rainMmH, double cloudiness, boolean enabled) {
        if (!enabled) return 0;
        if (sunElevationDegrees < 3.0 || sunElevationDegrees > 52.0) return 0;
        if (rainMmH < 0.5) return 0;
        // 1.1.7: the old 1.2 mm/h threshold hid the bow in ordinary drizzle, and
        // cloudiness 0.75 (a normal rain cloud) still scored only 0.45 clarity.
        // Rain saturates quickly, overcast only dampens instead of cancelling.
        double rain = Math.min(1.0, 0.45 + rainMmH / 12.0);
        double clarity = Math.max(0.22, Math.min(1.0, (1.05 - cloudiness) / 0.55));
        double sun = Math.sin(Math.toRadians(Math.min(52.0, sunElevationDegrees)) / 52.0 * Math.PI * 0.5);
        return Math.max(0.0, Math.min(1.0, rain * clarity * (0.55 + 0.45 * sun)));
    }

    /** Colour of band index 0..6 for the primary bow (violet inside, red outside). */
    public static int[] bandColor(int index, boolean secondary) {
        int[][] primary = {
                {132, 92, 214}, {72, 118, 224}, {74, 178, 208}, {96, 206, 122},
                {220, 214, 92}, {234, 152, 68}, {226, 96, 82}};
        int[][] table = secondary ? reverse(primary) : primary;
        int i = Math.max(0, Math.min(table.length - 1, index));
        return table[i];
    }

    private static int[][] reverse(int[][] bands) {
        int[][] out = new int[bands.length][];
        for (int i = 0; i < bands.length; i++) out[i] = bands[bands.length - 1 - i];
        return out;
    }

    /** Alpha for one band: dimmer secondary bow, soft fade towards the band edges. */
    public static int bandAlpha(double visibility, boolean secondary, int index, int bands) {
        double edge = 1.0 - 0.35 * Math.abs((index + 0.5) / bands * 2.0 - 1.0);
        double base = secondary ? 0.40 : 0.88; // 1.1.7: was 0.30 / 0.62, far too faint
        return (int) Math.max(0, Math.min(255, 255 * visibility * base * edge));
    }

    /**
     * Emits both bows into the given vertex consumer. The caller supplies the
     * world-anchored camera position, the sun's sky angle and the already computed
     * visibility, so this method has no side effects and allocates only small arrays.
     */
    public static void drawRainbow(VertexConsumer v, MatrixStack m, Vec3d cam,
                                   double skyAngle, double visibility) {
        if (visibility < 0.02) return;
        // Anti-solar horizontal direction: the bow is centred opposite the sun.
        double a = skyAngle * Math.PI * 2.0;
        double ax = -Math.cos(a), az = 0.0;
        double len = Math.hypot(ax, az);
        if (len < 1e-4) return;
        ax /= len;
        az /= len;
        drawBow(v, m, cam, ax, az, PRIMARY_ANGLE, visibility, false);
        drawBow(v, m, cam, ax, az, SECONDARY_ANGLE, visibility * 0.55, true);
    }

    private static void drawBow(VertexConsumer v, MatrixStack m, Vec3d cam,
                                double ax, double az, double angleDeg, double vis, boolean secondary) {
        double halfWidth = secondary ? 3.4 : 2.6; // 1.1.7: wider so the bands read as a bow
        double r0 = Math.tan(Math.toRadians(angleDeg - halfWidth)) * DISTANCE;
        double r1 = Math.tan(Math.toRadians(angleDeg + halfWidth)) * DISTANCE;
        // Perpendicular axis in the horizontal plane, so the arc stands upright.
        double px = -az, pz = ax;
        for (int b = 0; b < BANDS; b++) {
            int[] rgb = bandColor(b, secondary);
            int alpha = bandAlpha(vis, secondary, b, BANDS);
            if (alpha <= 1) continue;
            double t0 = b / (double) BANDS, t1 = (b + 1) / (double) BANDS;
            double ra0 = r0 + (r1 - r0) * t0, ra1 = r0 + (r1 - r0) * t1;
            for (int seg = 0; seg < SEGMENTS; seg++) {
                double a0 = Math.PI * seg / SEGMENTS;
                double a1 = Math.PI * (seg + 1) / SEGMENTS;
                double[] p = point(ax, az, px, pz, a0, ra0);
                double[] q = point(ax, az, px, pz, a1, ra0);
                double[] r = point(ax, az, px, pz, a1, ra1);
                double[] o = point(ax, az, px, pz, a0, ra1);
                // Only draw arc pieces that stay above the camera horizon.
                if (p[1] < -DISTANCE * 0.05 && q[1] < -DISTANCE * 0.05
                        && r[1] < -DISTANCE * 0.05 && o[1] < -DISTANCE * 0.05) continue;
                put(v, m, cam, p, rgb, alpha);
                put(v, m, cam, q, rgb, alpha);
                put(v, m, cam, r, rgb, alpha);
                put(v, m, cam, o, rgb, alpha);
            }
        }
    }

    /** Point on the bow: polar angle a (0..PI) around the anti-solar axis. */
    private static double[] point(double ax, double az, double px, double pz, double a, double radius) {
        double horiz = Math.cos(a) * radius;
        double up = Math.sin(a) * radius;
        return new double[]{ax * DISTANCE + px * horiz, up, az * DISTANCE + pz * horiz};
    }

    private static void put(VertexConsumer v, MatrixStack m, Vec3d cam, double[] p,
                            int[] rgb, int alpha) {
        v.vertex(m.peek().getPositionMatrix(),
                        (float) (p[0] - cam.x), (float) (p[1] - cam.y), (float) (p[2] - cam.z))
                .color(rgb[0], rgb[1], rgb[2], alpha)
                .texture(0.5f, 0.5f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(0xF000F0)
                .normal(0, 1, 0);
    }
}
