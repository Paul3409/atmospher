package dev.atmosphere.siren;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.*;
import net.minecraft.world.*;

public class SirenBlock extends Block {
    public static final MapCodec<SirenBlock> CODEC=createCodec(SirenBlock::new);
    final boolean controller;
    public SirenBlock(Settings settings){this(settings,false);}
    protected SirenBlock(Settings settings,boolean controller){super(settings);this.controller=controller;}
    @Override protected MapCodec<? extends Block> getCodec(){return CODEC;}
    private static final VoxelShape SHAPE=VoxelShapes.union(Block.createCuboidShape(6,0,6,10,9,10),Block.createCuboidShape(2,8,2,14,16,14));
    @Override protected VoxelShape getOutlineShape(BlockState state,BlockView world,BlockPos pos,ShapeContext context){return controller?VoxelShapes.fullCube():SHAPE;}
    @Override protected VoxelShape getCollisionShape(BlockState state,BlockView world,BlockPos pos,ShapeContext context){return getOutlineShape(state,world,pos,context);}
    @Override public void onPlaced(World world,BlockPos pos,BlockState state,LivingEntity placer,ItemStack stack){
        super.onPlaced(world,pos,state,placer,stack);
        if(world instanceof ServerWorld sw)SirenSystem.add(sw,pos,controller);
    }
    @Override protected ActionResult onUse(BlockState state,World world,BlockPos pos,PlayerEntity player,BlockHitResult hit){
        if(world instanceof ServerWorld sw&&player instanceof ServerPlayerEntity sp)SirenSystem.open(sw,pos,sp,controller);
        return ActionResult.SUCCESS;
    }
    @Override protected void onStateReplaced(BlockState old,World world,BlockPos pos,BlockState next,boolean moved){
        if(!old.isOf(next.getBlock())&&world instanceof ServerWorld sw){var s=SirenWorldState.of(sw);s.engine.nodes.remove(pos.asLong());s.markDirty();}
        super.onStateReplaced(old,world,pos,next,moved);
    }
    public static final class Control extends SirenBlock {
        public static final MapCodec<Control> CODEC=createCodec(Control::new);
        public Control(Settings settings){super(settings,true);}
        @Override protected MapCodec<? extends Block> getCodec(){return CODEC;}
    }
}
