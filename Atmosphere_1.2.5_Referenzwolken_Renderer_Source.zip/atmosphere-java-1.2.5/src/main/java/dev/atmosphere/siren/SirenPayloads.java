package dev.atmosphere.siren;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public final class SirenPayloads {
    private SirenPayloads(){}
    public record Request(String json) implements CustomPayload {
        public static final Id<Request> ID=new Id<>(Identifier.of("atmosphere","siren_request"));
        public static final PacketCodec<RegistryByteBuf,Request> CODEC=PacketCodec.tuple(PacketCodecs.STRING,Request::json,Request::new);
        @Override public Id<? extends CustomPayload> getId(){return ID;}
    }
    public record Status(String json) implements CustomPayload {
        public static final Id<Status> ID=new Id<>(Identifier.of("atmosphere","siren_status"));
        public static final PacketCodec<RegistryByteBuf,Status> CODEC=PacketCodec.tuple(PacketCodecs.STRING,Status::json,Status::new);
        @Override public Id<? extends CustomPayload> getId(){return ID;}
    }
}
