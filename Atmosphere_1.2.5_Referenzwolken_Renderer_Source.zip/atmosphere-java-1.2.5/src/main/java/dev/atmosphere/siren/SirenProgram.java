package dev.atmosphere.siren;

public enum SirenProgram {
    PROBE("Probealarm","probe",25.495542), FIRE("Feueralarm","fire",63.425333),
    WARNING("Bevölkerungswarnung","warning",67.874167), CLEAR("Entwarnung","clear",69.986917);
    public final String label,asset; public final int ticks,segments;
    SirenProgram(String label,String asset,double seconds){this.label=label;this.asset=asset;
        ticks=(int)Math.ceil(seconds*20);segments=(int)Math.ceil(seconds/2);}
    public static SirenProgram of(int index){return values()[Math.max(0,Math.min(values().length-1,index))];}
    public static int segment(long elapsed){return (int)(elapsed/40);}
}
