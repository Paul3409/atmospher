package dev.atmosphere.siren;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;

public final class SirenBlocks {
    public static final Block SIREN=new SirenBlock(AbstractBlock.Settings.create().strength(2f).nonOpaque());
    public static final Block CONTROL=new SirenBlock.Control(AbstractBlock.Settings.create().strength(2f));
    private SirenBlocks(){}
    public static void register(){
        register("e57_siren",SIREN);register("siren_control",CONTROL);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.REDSTONE).register(entries->{entries.add(SIREN);entries.add(CONTROL);});
    }
    private static void register(String name,Block block){
        Identifier id=Identifier.of("atmosphere",name);Registry.register(Registries.BLOCK,id,block);
        Registry.register(Registries.ITEM,id,new BlockItem(block,new Item.Settings()));
    }
}
