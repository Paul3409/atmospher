package dev.atmosphere.siren;

import java.util.*;

/** Pure scheduling and grouping; clocks use server world ticks, never wall-clock timers. */
public final class SirenEngine {
    public static final int LIMIT=128;
    public static final class Node {
        public final long pos; public final boolean controller;
        public String group="Ort"; public int radius=512,volume=80,delay=0,selected=0;
        public final int[] levels={100,100,100,100};
        public long start=-1; public int playing=0; public boolean lastStart,lastStop,automatic;
        public Node(long pos,boolean controller){this.pos=pos;this.controller=controller;}
        public boolean active(long now){return !controller&&start>=0&&now<start+SirenProgram.of(playing).ticks+80;}
    }
    public static final class Group {
        public boolean enabled,paused,warned,autoClear=true; public int hazards=7;
        public long manualUntil,quietSince=-1,nextWarning;
        public boolean probeEnabled,probePaused;
        public int probeTime=6000;
        public long probeChecked=Long.MIN_VALUE,probeOccurrence=Long.MIN_VALUE;
    }
    public final Map<Long,Node> nodes=new LinkedHashMap<>();
    public final Map<String,Group> groups=new LinkedHashMap<>();
    public static String groupName(String name){
        String s=name.strip();if(!s.matches("[\\p{L}\\p{N}_ -]{1,24}"))throw new IllegalArgumentException("Gruppenname: 1–24 Buchstaben/Ziffern");return s;
    }
    public Group group(String name){return groups.computeIfAbsent(name,k->new Group());}
    public Node add(long pos,boolean controller){
        if(nodes.containsKey(pos))return nodes.get(pos);
        if(nodes.size()>=LIMIT)throw new IllegalArgumentException("Maximal 128 Sirenen/Bedienstellen");
        Node n=new Node(pos,controller);nodes.put(pos,n);group(n.group);return n;
    }
    public int start(String group,Long only,int signal,long now,boolean automatic){
        int count=0;for(Node n:nodes.values())if(!n.controller&&(only!=null?n.pos==only:group==null||n.group.equals(group))){
            n.playing=SirenProgram.of(signal).ordinal();n.start=now+n.delay;n.automatic=automatic;count++;
            if(!automatic)group(n.group).manualUntil=now+n.delay+SirenProgram.of(signal).ticks+2400;
        }return count;
    }
    public int stop(String group,Long only,long now,boolean manual){
        int count=0;for(Node n:nodes.values())if(!n.controller&&(only!=null?n.pos==only:group==null||n.group.equals(group))){
            if(n.start>=0)count++;n.start=-1;if(manual)group(n.group).manualUntil=now+2400;
        }return count;
    }
    public boolean expire(long now){boolean changed=false;for(Node n:nodes.values())if(n.start>=0&&!n.active(now)){
        n.start=-1;changed=true;}return changed;}
    public int copyLevels(Node source){int count=0;for(Node n:nodes.values())if(!n.controller&&n.group.equals(source.group)){
        n.volume=source.volume;System.arraycopy(source.levels,0,n.levels,0,4);count++;
    }return count;}
    public static int clockTicks(String clock){
        if(!clock.matches("[0-2][0-9]:[0-5][0-9]"))throw new IllegalArgumentException("Uhrzeit als HH:MM eingeben");
        int hour=Integer.parseInt(clock.substring(0,2)),minute=Integer.parseInt(clock.substring(3));
        if(hour>23)throw new IllegalArgumentException("Stunde muss zwischen 00 und 23 liegen");
        return Math.floorMod(hour*1000+minute*1000/60-6000,24000);
    }
    public static String clock(int ticks){
        int t=Math.floorMod(ticks+6000,24000);
        return String.format(java.util.Locale.ROOT,"%02d:%02d",t/1000,Math.min(59,(int)Math.round(t%1000*.06)));
    }
    /** A due probe is consumed even when skipped, paused or suppressed by an emergency. */
    public boolean schedule(String name,long now,long time){
        Group g=group(name);long previous=g.probeChecked;g.probeChecked=time;
        if(previous==Long.MIN_VALUE||time<previous)return true;
        long due=Math.floorDiv(time-g.probeTime,24000)*24000+g.probeTime;
        if(time-previous>200){g.probeOccurrence=Math.max(g.probeOccurrence,due);return true;}
        if(due<=previous||due<=g.probeOccurrence)return false;
        g.probeOccurrence=due;
        if(!g.probeEnabled||g.probePaused||now<g.manualUntil||g.warned)return true;
        if(nodes.values().stream().anyMatch(n->n.group.equals(name)&&n.active(now)))return true;
        start(name,null,SirenProgram.PROBE.ordinal(),now,true);return true;
    }
    public boolean weather(String group,boolean danger,long now){
        Group g=group(group);if(!g.enabled||g.paused||now<g.manualUntil)return false;
        if(danger){g.quietSince=-1;if(now>=g.nextWarning){
            start(group,null,SirenProgram.WARNING.ordinal(),now,true);g.warned=true;g.nextWarning=now+6000;return true;
        }}else if(g.warned){
            if(g.quietSince<0)g.quietSince=now;
            if(now-g.quietSince>=1800){if(g.autoClear)start(group,null,SirenProgram.CLEAR.ordinal(),now,true);g.warned=false;g.quietSince=-1;return true;}
        }return false;
    }
}
