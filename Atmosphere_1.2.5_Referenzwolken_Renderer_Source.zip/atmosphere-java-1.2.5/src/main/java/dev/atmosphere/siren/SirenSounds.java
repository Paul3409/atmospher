package dev.atmosphere.siren;
import net.minecraft.sound.SoundEvent;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
public final class SirenSounds {
    public static final SoundEvent[][][][] EVENTS=new SoundEvent[4][][][];
    private SirenSounds(){}
    public static void register(){for(var p:SirenProgram.values()){
        EVENTS[p.ordinal()]=new SoundEvent[2][3][p.segments];for(int muffled=0;muffled<2;muffled++)for(int variant=0;variant<3;variant++)for(int i=0;i<p.segments;i++){
            String gain=variant==0?"":"g"+SirenGain.boost(variant)+"_";
            var id=Identifier.of("atmosphere",String.format(java.util.Locale.ROOT,"siren_%s_%s%s%02d",p.asset,muffled==1?"m_":"",gain,i));
            EVENTS[p.ordinal()][muffled][variant][i]=Registry.register(Registries.SOUND_EVENT,id,SoundEvent.of(id));
        }
    }}
}
