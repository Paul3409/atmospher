package dev.atmosphere.siren;

/** Bounded gain selection; boosted recordings reserve actual headroom beyond Minecraft's volume clamp. */
public final class SirenGain {
    private SirenGain(){}
    public static int bound(int value){return Math.max(0,Math.min(200,value));}
    public static double effective(int master,int signal){return bound(master)/100.0*bound(signal)/100.0;}
    public static int variant(double gain){return gain<=1?0:gain<=2?1:2;}
    public static int boost(int variant){return variant==0?1:variant==1?2:4;}
}
