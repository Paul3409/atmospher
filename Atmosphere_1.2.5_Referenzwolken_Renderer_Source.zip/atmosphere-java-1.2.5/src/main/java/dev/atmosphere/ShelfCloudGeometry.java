package dev.atmosphere;

/** Closed curved shelf; local coordinates are along the cell motion and across it. */
public final class ShelfCloudGeometry {
    private ShelfCloudGeometry() {}
    public record Point(double along,double across,double y,double normalAlong,double normalY) {}
    public static Point point(double side,double angle,double radius,double base,double growth,int type) {
        double across=(side*2-1)*GustFront.span(radius,type);
        double taper=Math.sqrt(Math.max(0,1-Math.pow(side*2-1,2)));
        double depth=radius*.24*taper;
        double thickness=(8+radius*.045)*taper;
        double leading=GustFront.leading(across,radius,type);
        double along=leading-depth+Math.cos(angle)*depth;
        double y=base+8+Math.sin(angle)*thickness
                +Math.sin(angle*2)*thickness*.14
                +Math.sin(side*19)*1.5*taper*growth;
        return new Point(along,across,y,Math.cos(angle),Math.sin(angle));
    }
}
