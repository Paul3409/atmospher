package dev.atmosphere;

/** Shared bowed boundary for shelf geometry and the actual near-surface wind field. */
public final class GustFront {
    private GustFront() {}
    public static double maturity(double growth,int type) {
        return type<WeatherCells.SEVERE?0:StormEvolution.smooth(.30,.78,growth);
    }
    public static double span(double radius,int type) {
        return radius*(type==WeatherCells.SQUALL?2.4:1.45);
    }
    public static double leading(double across,double radius,int type) {
        double side=across/span(radius,type);
        return radius*(1.10+.15*(1-side*side));
    }
    public static double intensity(double along,double across,double radius,double growth,int type) {
        double power=maturity(growth,type);
        if(power==0||Math.abs(across)>=span(radius,type))return 0;
        double band=Math.exp(-Math.pow((along-leading(across,radius,type))/Math.max(25,radius*.26),2));
        double edge=1-StormEvolution.smooth(.75,1,Math.abs(across)/span(radius,type));
        return StormEvolution.clamp(band*edge*power,0,1);
    }
}
