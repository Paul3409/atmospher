package dev.atmosphere;

import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Atmosphere 1.1.1: deterministic, continuous GAME-SCALE synoptic fields.
 * This is not a numerical forecast: a sparsely populated track catalogue supplies
 * developing highs and lows; long-wave background pressure/geopotential and an
 * independent wavy upper-air jet prevent the old moving checkerboard pattern.
 * Radar contours, fronts, clouds and precipitation all sample these same fields.
 */
public final class SynopticSystems {
    private SynopticSystems() {}
    public record Field(double pressure,double height500,double vx,double vz,
            double frontalLift,double moisture,double cyclone,double anticyclone,
            double shear,double lowX,double lowZ,double cold,double warm,double occluded,
            double postFront,double inversion) {
        public double speed(){return Math.hypot(vx,vz);}
    }
    public record SystemInfo(boolean low,double x,double z,double corePressure,double strength,double age,long id,
                             double heading,double aspect) {}
    public record FrontPoint(double x,double z) {}
    private static final double TAU=2*Math.PI;
    private static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    private static double hash(int x,int z,int salt){return WeatherCells.hash(x^ClimateClock.seed(),
            z^(ClimateClock.seed()>>>32),salt);}
    private record Key(int x,int z,long days,int range,int lifetime,int highPower,int revision,long seed){}
    private static final Map<Key,List<SystemInfo>> CACHE=new LinkedHashMap<>(96,.75f,true){
        @Override protected boolean removeEldestEntry(Map.Entry<Key,List<SystemInfo>> e){return size()>96;}
    };

    /** Smoothly flowing jet axis with meanders, jet streaks and meridional motion. */
    public static double[] jetstream(double x,double z,double days) {
        double longitude=x/2850.0-days*.16;
        double axis=980*Math.sin(longitude*.76+.4*Math.sin(days*.085))
                + 365*Math.sin(longitude*1.81+days*.091);
        // Jet bands repeat only over planetary distances, not on a 3 km grid.
        double distance=(z-axis)/5500.0;
        double band=Math.exp(-Math.pow(Math.sin(distance*Math.PI),2)/.105);
        double streak=.75+.25*Math.sin(longitude*1.4-days*.23+1.3);
        double intensity=20+132*band*streak;
        double slope=(980*.76/2850*Math.cos(longitude*.76+.4*Math.sin(days*.085))
                +365*1.81/2850*Math.cos(longitude*1.81+days*.091));
        double scale=1/Math.sqrt(1+slope*slope);
        WeatherRegimes.Flow flow=WeatherRegimes.flow(x,z,days);
        double n=Math.max(.2,Math.hypot(flow.x(),flow.z()));
        return new double[]{intensity*(flow.x()/n*.86+scale*.14),
                intensity*(flow.z()/n*.86+slope*scale*.14)};
    }

    /** Sparse, asynchronously born tracks. IDs remain stable while each low matures. */
    public static List<SystemInfo> systems(double x,double z,double days,int range) {
        int tx=(int)Math.floor(x/4300),tz=(int)Math.floor(z/4300);
        Key key=new Key(tx,tz,Double.doubleToLongBits(days),range,AtmosphereSettings.get().pressureLifetime,
                AtmosphereSettings.get().highPressureStrength,ManualPressureSystems.revision(),ClimateClock.seed());
        synchronized(CACHE){
            List<SystemInfo> value=CACHE.get(key);
            if(value==null){value=buildSystems((tx+.5)*4300,(tz+.5)*4300,days,range+2150);CACHE.put(key,value);}
            return value;
        }
    }
    private static List<SystemInfo> buildSystems(double x,double z,double days,int range){
        ArrayList<SystemInfo> out=new ArrayList<>();
        final double tile=4300, period=6.5;
        int gx=(int)Math.floor(x/tile),gz=(int)Math.floor(z/tile);
        // Include full lifetime drift in every direction, not just western origins.
        int r=Math.max(1,(int)Math.ceil((range+8500.0)/tile));
        int epoch=(int)Math.floor(days/period);
        AtmosphereSettings tuning=AtmosphereSettings.get();
        int history=tuning.pressureLifetime==2?3:2;
        for(int ep=epoch-history;ep<=epoch;ep++) for(int j=-r;j<=r;j++) for(int i=-r;i<=r;i++) {
            int ix=gx+i,iz=gz+j;
            double occur=hash(ix+ep*97,iz-ep*53,914);
            if(occur>.59)continue; // empty areas, no one-to-one high/low tiling
            double born=ep*period+2.9*hash(ix,iz,ep*37+917);
            boolean fastRunner=hash(ix,iz,ep*37+927)<.035
                    && Math.hypot(jetstream(ix*tile,iz*tile,ep*period)[0],
                                  jetstream(ix*tile,iz*tile,ep*period)[1])>62;
            double life=fastRunner?(.95+1.0*hash(ix,iz,ep*37+928)):
                    (2.1+5.7*hash(ix,iz,ep*37+918));
            life *= WeatherTuning.lifetime(tuning.pressureLifetime);
            double age=(days-born)/life;
            if(age<=0||age>=1)continue;
            double maturity=Math.pow(Math.sin(age*Math.PI),.73);
            boolean low=hash(ix,iz,ep*37+919)<.54;
            double travel=(fastRunner?590:165)+400*hash(ix,iz,ep*37+921);
            double pathDays=days-born;
            double sx=(ix+.12+.76*hash(ix,iz,ep*37+922))*tile;
            double sz=(iz+.12+.76*hash(ix,iz,ep*37+923))*tile;
            double heading=0;
            // Fixed-step path integration avoids speed/position jumps at regime changes.
            double elapsed=0;
            while(elapsed<pathDays){
                double step=Math.min(.25,pathDays-elapsed);
                WeatherRegimes.Flow f=WeatherRegimes.flow(sx,sz,born+elapsed+step*.5);
                double speed=travel*(low?1:.35)*(1-.58*f.blocking());
                heading=Math.atan2(f.z(),f.x());
                // In a block, lows wrap south of the upstream ridge while highs stall.
                double bend=low?f.blocking()*.8*Math.sin((sx/tile)+(born+elapsed)*.18):0;
                heading+=bend+(hash(ix,iz,ep*37+920)-.5)*.28;
                sx+=Math.cos(heading)*speed*step;sz+=Math.sin(heading)*speed*step;elapsed+=step;
            }
            double pressure=low ? 1007-(12+(fastRunner?38:30)*hash(ix,iz,ep*37+924))*maturity
                                  :1019+(12+23*hash(ix,iz,ep*37+925))*maturity;
            long id=(((long)ix&0x1fffffL)<<42)^(((long)iz&0x1fffffL)<<21)^(ep&0x1fffffL)^ClimateClock.seed();
            double aspect=.76+.70*hash(ix,iz,ep*37+929);
            out.add(new SystemInfo(low,sx,sz,pressure,maturity,age,id,heading,aspect));
        }
        // A building high steers neighbouring lows around its ridge. This coupling
        // is continuous and uses the very centres shown by the pressure layer.
        List<SystemInfo> uncoupled=List.copyOf(out);
        for(int i=0;i<out.size();i++){
            SystemInfo low=out.get(i);if(!low.low())continue;
            double fx=0,fz=0;
            for(SystemInfo high:uncoupled)if(!high.low()){
                double dx=low.x()-high.x(),dz=low.z()-high.z(),d=Math.hypot(dx,dz);
                if(d>5000)continue;
                double influence=Math.exp(-Math.pow(d/2300,2))*high.strength()
                        *WeatherTuning.pressureStrength(tuning.highPressureStrength);
                fx+=(-dz+.18*dx)/Math.max(300,d)*influence;
                fz+=(dx+.18*dz)/Math.max(300,d)*influence;
            }
            double ageRamp=WeatherCells.smooth(0,.45,low.age());
            double dx=520*Math.tanh(fx)*ageRamp,dz=520*Math.tanh(fz)*ageRamp;
            double heading=Math.atan2(Math.sin(low.heading())+fz*.6,
                    Math.cos(low.heading())+fx*.6);
            out.set(i,new SystemInfo(true,low.x()+dx,low.z()+dz,low.corePressure(),
                    low.strength(),low.age(),low.id(),heading,low.aspect()));
        }
        for(ManualPressureSystems.Centre c:ManualPressureSystems.centres()) {
            double elapsed=Math.max(0,days-(Double.isFinite(c.bornDays())?c.bornDays():
                    c.started()/24000.0*AtmosphereSettings.get().weatherSpeed));
            WeatherRegimes.Flow f=WeatherRegimes.flow(c.x(),c.z(),days);
            double heading=Math.atan2(f.z(),f.x());
            double sx=c.x()+elapsed*195*Math.cos(heading),sz=c.z()+elapsed*195*Math.sin(heading);
            if(Math.abs(sx-x)<range+2250&&Math.abs(sz-z)<range+2250)
                out.add(new SystemInfo(c.low(),sx,sz,c.coreHpa(),1,.42,c.id(),heading,1.12));
        }
        out.removeIf(s->Math.abs(s.x()-x)>range+2750||Math.abs(s.z()-z)>range+2750);
        return List.copyOf(out);
    }
    /** Exactly ONE curved arc of each kind, with an occlusion replacing the inner section. */
    public static FrontPoint frontPoint(SystemInfo s,int kind,double t) {
        double ang=s.heading()+(kind==0?2.16:kind==1?.30:-.52);
        double bend=.23*Math.sin(t*2.2+WeatherCells.hash(s.id(),0,1151)*TAU)+.32*t*t
                +(kind==2?s.age()*.5:0);
        double length=(kind==0?1280:kind==1?1450:640)*t;
        return new FrontPoint(s.x()+Math.cos(ang+bend)*length,
                s.z()+Math.sin(ang+bend)*length);
    }
    private static double distance(double x,double z,FrontPoint a,FrontPoint b) {
        double dx=b.x()-a.x(),dz=b.z()-a.z();
        double t=clamp(((x-a.x())*dx+(z-a.z())*dz)/Math.max(1,dx*dx+dz*dz),0,1);
        return Math.hypot(x-a.x()-dx*t,z-a.z()-dz*t);
    }
    private static double frontDistance(SystemInfo s,int k,double x,double z) {
        double d=Double.POSITIVE_INFINITY;
        FrontPoint a=frontPoint(s,k,0);
        for(int i=1;i<=7;i++) {FrontPoint b=frontPoint(s,k,i/7.0);d=Math.min(d,distance(x,z,a,b));a=b;}
        return d;
    }
    public static Field sample(double x,double z,double days) {
        // Smooth long waves superimposed on pressure anomalies, never rendered as separate circles.
        double phase=x/4300.0-days*.11;
        double p=1015.0+3.8*Math.sin(phase+.42*Math.sin(z/5100.0))
                +2.6*Math.cos(z/3900.0+phase*.53);
        double h=560+14*Math.sin(phase*.79+z/5100.0)+8*Math.cos(z/3400.0-days*.14);
        double[] jet=jetstream(x,z,days);
        double vx=jet[0]*.23,vz=jet[1]*.23;
        double front=0,humid=0,cyclone=0,high=0,shear=0,cold=0,warm=0,occ=0,post=0,inv=0;
        double nearest=0,bx=x,bz=z;
        for(SystemInfo sys:systems(x,z,days,2350)) {
            double dx=x-sys.x(),dz=z-sys.z(),d=Math.hypot(dx,dz);
            if(d>2750)continue;
            double radius=sys.low()?990:1240;
            double co=Math.cos(sys.heading()),si=Math.sin(sys.heading());
            double along=(dx*co+dz*si)/sys.aspect(),across=(-dx*si+dz*co)*sys.aspect();
            double influence=Math.exp(-.5*(along*along+across*across)/(radius*radius))*sys.strength();
            // Independent pressure-system intensity, not a random rain multiplier.
            // The field is shared by radar, clouds, wind and local precipitation.
            double power=WeatherTuning.pressureStrength(sys.low()
                    ? AtmosphereSettings.get().lowPressureStrength
                    : AtmosphereSettings.get().highPressureStrength);
            if (power <= 0) continue;
            double anomaly=sys.corePressure()-(sys.low()?1007:1019);
            // Wide, coherent pressure perturbations; system central pressure is approximate
            // because neighbouring systems and planetary waves also contribute.
            p+=((sys.low()?-10:10)+anomaly)*influence*power;
            h+=((sys.low()?-12:13)+anomaly*.70)*influence*power;
            double swirl=(sys.low()?1:-.55)*(12+44*influence)*power
                    *Math.exp(-(d/1550)*(d/1550))/Math.max(210,d);
            // Northern-hemisphere circulation in Minecraft's south-positive Z.
            vx+=dz*swirl;vz-=dx*swirl;
            double effective=clamp(influence*power,0,1);
            if(sys.low()) {
                cyclone=Math.max(cyclone,effective);
                if(effective>nearest){nearest=effective;bx=sys.x();bz=sys.z();}
                if(d>1650)continue;
                double maturity=clamp((sys.age()-.35)/.42,0,1);
                double cd=frontDistance(sys,0,x,z),wd=frontDistance(sys,1,x,z),od=frontDistance(sys,2,x,z);
                double inner=clamp((d-140)/330,0,1);
                double ca=Math.exp(-Math.pow(cd/125,2))*(1-maturity*(1-inner));
                double wa=Math.exp(-Math.pow(wd/245,2))*(1-maturity*(1-inner));
                double oa=Math.exp(-Math.pow(od/175,2))*maturity;
                cold=Math.max(cold,ca*effective);
                warm=Math.max(warm,wa*effective);
                occ=Math.max(occ,oa*effective);
                front=Math.max(front,Math.max(ca,Math.max(wa*.70,oa*.9))*effective);
                double rear=clamp((-along*.62-across*.23)/780,0,1);
                post=Math.max(post,rear*Math.exp(-Math.pow((d-850)/980,2))*effective);
                humid=Math.max(humid,Math.max(effective*.43,front*.95));
                shear=Math.max(shear,effective*.28+front*.63);
            }else {high=Math.max(high,effective);inv=Math.max(inv,effective);}
        }
        double jetShear=clamp((Math.hypot(jet[0],jet[1])-60)/100,0,1);
        shear=Math.max(shear,jetShear*.33);
        return new Field(clamp(p,947,1052),clamp(h,490,612),vx,vz,
            clamp(front,0,1),clamp(humid,0,1),clamp(cyclone,0,1),clamp(high,0,1),
            clamp(shear,0,1),bx,bz,clamp(cold,0,1),clamp(warm,0,1),
            clamp(occ,0,1),clamp(post,0,1),clamp(inv,0,1));
    }
    public static double[] upperWind(double x,double z,double days,double altitude) {
        Field f=sample(x,z,days);
        double a=clamp(altitude,0,1);
        double[] jet=jetstream(x,z,days);
        return new double[]{f.vx()*(1-a)+jet[0]*a,f.vz()*(1-a)+jet[1]*a};
    }
    public static double radialVelocity(double rx,double rz,double x,double z,double vx,double vz) {
        double dx=x-rx,dz=z-rz,d=Math.hypot(dx,dz);
        return d<.000001?0:(vx*dx+vz*dz)/d;
    }
    public static double[] rotationalVelocity(double x,double z,WeatherCells.Cell cell) {
        if(cell==null||cell.type()<WeatherCells.SUPERCELL)return new double[]{0,0};
        double dx=x-cell.x(),dz=z-cell.z(),dist=Math.hypot(dx,dz),r=Math.max(55,cell.radius()*.52);
        double amount=cell.rotation()*55*Math.exp(-Math.pow((dist-r*.56)/r,2));
        double n=Math.max(18,dist);return new double[]{-dz/n*amount,dx/n*amount};
    }
    public static int pressureContour(double p){return (int)Math.floor(p/4.0);}
}
