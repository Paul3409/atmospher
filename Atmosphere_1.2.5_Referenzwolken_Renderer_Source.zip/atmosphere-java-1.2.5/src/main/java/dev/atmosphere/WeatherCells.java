package dev.atmosphere;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Deterministic mesoscale storm cells. Pure Java: no loaded chunks and no global RNG.
 * Finite-lived generations: each birth receives a new identity and environment.
 * This is a stylised weather simulation, not an NWP solver.
 */
public final class WeatherCells {
    public static final int NONE=0, SHOWER=1, THUNDER=2, SEVERE=3, SUPERCELL=4, SQUALL=5;
    public static final String[] NAMES = {"Kein", "Schauer", "Gewitter", "Starkes Gewitter", "Superzelle", "Squall Line"};
    public record Cell(int type, double x, double z, double radius, double intensity,
                       double growth, double anvil, double rotation, double windX, double windZ,
                       long id, double phase, double speedBlocksPerDay, double cycleDurationDays) {
        public Cell(int type,double x,double z,double radius,double intensity,double growth,
                    double anvil,double rotation,double windX,double windZ,long id) {
            this(type,x,z,radius,intensity,growth,anvil,rotation,windX,windZ,id,.48,200,1.8);
        }
        public String stage() { return StormEvolution.stage(phase); }
        public double ageDays() { return clamp(phase,0,1)*cycleDurationDays; }
    }
    public record Field(double rain, double storm, double cloud, double development, double gustFront,
                        int type, double centerX, double centerZ, double radius,
                        double anvil, double rotation, double windX, double windZ, long id,
                        double gustCenterX,double gustCenterZ) { }
    private static final double TAU = Math.PI*2;
    private static final double SPACING = 690.0;
    private static final double PERIOD=2.4;
    private record Key(int x,int z,long time,long seed){}
    private static final Map<Key,List<Cell>> CACHE=new LinkedHashMap<>(128,.75f,true){
        @Override protected boolean removeEldestEntry(Map.Entry<Key,List<Cell>> e){return size()>128;}
    };
    private WeatherCells() {}

    public static double smooth(double start, double end, double v) {
        double t = clamp((v-start)/(end-start),0,1);
        return t*t*(3-2*t);
    }
    public static double lifecycle(double phase) {
        phase -= Math.floor(phase);
        double birth = smooth(.02,.32,phase);
        double decay = 1-smooth(.65,.97,phase);
        return birth*decay;
    }
    public static Cell cell(int gx, int gz, double weatherDays) {
        return generation(gx,gz,(long)Math.floor(weatherDays/PERIOD),weatherDays);
    }
    /** Explicit epoch for tests and catalogue enumeration; phase never loops. */
    public static Cell generation(int gx,int gz,long epoch,double days){
        long id=mix(((long)gx*341873128712L)^((long)gz*132897987541L)
                ^epoch*0x632be59bd9b4e019L^ClimateClock.seed());
        double born=epoch*PERIOD+hash(id,0,43);
        double life=.82+1.58*hash(id,0,41),age=days-born;
        double phase=age/life;
        double x=(gx+.10+.80*hash(id,0,11))*SPACING;
        double z=(gz+.10+.80*hash(id,0,13))*SPACING;
        WeatherRegimes.Flow flow=WeatherRegimes.flow(x,z,born);
        double direction=Math.atan2(flow.z(),flow.x())+(hash(id,0,19)-.5)*1.2;
        double wx=Math.cos(direction),wz=Math.sin(direction);
        double speed=170+hash(id,0,17)*100;
        double shear=clamp(flow.shear()*.60+hash(id,0,31)*.55,0,1);
        double potential=clamp(.13+flow.humidity()*.27+flow.lift()*.20
                +flow.warmth()*.13+(hash(id,0,37)-.5)*.80,0,1);
        int type = potential > .95 && shear > .52 ? SQUALL :
                   potential > .84 && shear > .55 ? SUPERCELL :
                   potential > .69 ? SEVERE : potential > .43 ? THUNDER : SHOWER;
        double growth=phase<=0||phase>=1?0:lifecycle(phase);
        double radius = (type == SQUALL ? 240 : type == SUPERCELL ? 195 : 105)
                + 65*hash(id,0,47);
        double intensity=growth*(.45+.55*hash(id,0,53))*(.65+.35*flow.humidity());
        double anvil = type >= THUNDER ? smooth(.35,.80,growth) : 0;
        return new Cell(type,x+age*speed*wx,z+age*speed*wz,radius,intensity,growth,anvil,
                shear*growth,wx,wz,id,phase,speed,life);
    }
    private static long mix(long h){h^=h>>>30;h*=-4658895280553007687L;h^=h>>>27;
        h*=-7723592293110705685L;return h^(h>>>31);}
    /** All consumers enumerate this same bounded catalogue, not inverse global drift. */
    public static List<Cell> nearby(double x,double z,double days,double range){
        ArrayList<Cell> out=new ArrayList<>();
        int gx=(int)Math.floor(x/SPACING),gz=(int)Math.floor(z/SPACING);
        int r=(int)Math.ceil((Math.max(0,range)+2050)/SPACING);
        long epoch=(long)Math.floor(days/PERIOD);
        for(long ep=epoch-2;ep<=epoch;ep++)for(int j=-r;j<=r;j++)for(int i=-r;i<=r;i++){
            Cell c=generation(gx+i,gz+j,ep,days);
            if(c.growth()<=0||hash(c.id(),0,71)>.58)continue;
            if(Math.abs(x-c.x())>range+c.radius()*4||Math.abs(z-c.z())>range+c.radius()*4)continue;
            out.add(c);
        }
        return List.copyOf(out);
    }
    private static List<Cell> local(double x,double z,double days){
        int gx=(int)Math.floor(x/SPACING),gz=(int)Math.floor(z/SPACING);
        Key key=new Key(gx,gz,Double.doubleToLongBits(days),ClimateClock.seed());
        synchronized(CACHE){
            List<Cell> cells=CACHE.get(key);
            if(cells==null){cells=nearby((gx+.5)*SPACING,(gz+.5)*SPACING,days,SPACING*.5);CACHE.put(key,cells);}
            return cells;
        }
    }

    /** Max of the local cells: returns a continuous 2-D storm field and a leading cell. */
    public static Field sample(double x, double z, double weatherDays) {
        double best=0, cloud=0, gustFront=0, rain=0;
        Cell leading = null;
        Cell gustSource = null;
        for(Cell c:local(x,z,weatherDays)) {
            double dx=x-c.x(), dz=z-c.z();
            if(dx*dx+dz*dz>c.radius()*c.radius()*16)continue;
            double across=dx*(-c.windZ())+dz*c.windX();
            double along=dx*c.windX()+dz*c.windZ();
            double boundary=StormEvolution.gustFront(along,across,c.radius(),c.growth(),c.type());
            if(boundary>gustFront){gustFront=boundary;gustSource=c;}
            // Bend the rain shield without creating frame-to-frame random noise.
            double bend = Math.sin(across / (c.radius()*.62) + hash(c.id(),0,719)*TAU)
                    * c.radius()*.24;
            if(c.type()!=SUPERCELL)along -= bend;
            double reach = c.radius()*(.55+.62*c.growth());
            double norm;
            if(c.type()==SQUALL) {
                // Elongated, slightly bowed front, not an infinitely repeated straight strip.
                double bow=27*Math.sin(across/230.0+(c.id()%1000003)*.01);
                norm=Math.pow((along-bow)/Math.max(30,reach*.40),2)
                     +Math.pow(across/(reach*2.3),2);
            } else if(c.type()==SUPERCELL) {
                // Oblique, rotating elliptical updraft/precipitation sector.
                double a=across + along*.34*c.rotation();
                norm=Math.pow(a/(reach*.83),2)+Math.pow(along/(reach*1.35),2);
            } else {
                norm=(dx*dx+dz*dz)/(reach*reach);
            }
            double texture=StormEvolution.precipitationStructure(along,across,c.radius(),c.id(),c.type());
            double shape=Math.exp(-norm*1.15)*(.58+.42*texture);
            double convective=shape*c.intensity();
            double localRain=StormEvolution.rainProfile(along,across,c.radius(),c.id(),c.type(),c.growth())
                    *c.intensity()*c.intensity()
                    *(c.type()==SHOWER?23:c.type()==THUNDER?48:c.type()==SEVERE?84:
                    c.type()==SUPERCELL?104:91);
            rain=Math.max(rain,localRain);
            double spread=Math.exp(-norm*.46)*c.growth();
            cloud=Math.max(cloud,spread);
            if(convective>best) {best=convective; leading=c;}
        }
        if (leading == null) return new Field(0,0,cloud,0,gustFront,NONE,x,z,100,0,0,1,0,0,x,z);
        double strength=smooth(.12,.93,best);
        return new Field(rain,strength,cloud,leading.growth(),gustFront,leading.type(),leading.x(),leading.z(),
                leading.radius(),leading.anvil(),leading.rotation(),leading.windX(),leading.windZ(),leading.id(),
                gustSource==null?x:gustSource.x(),gustSource==null?z:gustSource.z());
    }
    public static double clamp(double x,double low,double high) {return Math.max(low,Math.min(high,x));}
    public static double hash(long x,long z,int salt) {
        long h=x*341873128712L ^ z*132897987541L ^ salt*2177342783L;
        h^=h>>>30;h*=-4658895280553007687L;h^=h>>>27;h*=-7723592293110705685L;h^=h>>>31;
        return (h>>>11)*0x1.0p-53;
    }
}
