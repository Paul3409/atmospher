package dev.atmosphere;

/** Same single light evaluation in the game and mathematical preview. */
public final class CloudLighting {
    private CloudLighting(){}
    public static double shade(double nx,double ny,double nz,double sun){
        double facing=nx*Math.cos(sun)*.72+ny*.62+nz*Math.sin(sun)*.72;
        return .58+.35*Math.max(0,facing);
    }
}
