package dev.atmosphere;

/** Weather fog only. Cloud immersion remains a separate physical visibility effect. */
public final class WeatherFog {
    private WeatherFog(){}
    public static double density(double natural,double rain,boolean enabled,int percent){
        if(!enabled||percent<=0)return 0;
        return WeatherCells.clamp(Math.max(natural,rain)*WeatherCells.clamp(percent,0,200)/100.0,0,1);
    }
    public static double visibility(double density){
        return 320-235*WeatherCells.clamp(density,0,1);
    }
}
