package dev.atmosphere;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.random.Random;

/** One smoothly controlled loop for the nearest active tornado. */
public final class TornadoAmbience {
    private static Roar roar;
    private static ClientWorld world;
    private TornadoAmbience() {}
    public static void register(){ClientTickEvents.END_CLIENT_TICK.register(TornadoAmbience::tick);}
    private static void tick(MinecraftClient client) {
        var s=AtmosphereSettings.get();
        if(client.world==null||client.player==null||!s.weatherSounds||!s.customClouds||s.tornadoChance==0
                ||s.tornadoVolume==0||world!=client.world) {
            if(roar!=null){client.getSoundManager().stop(roar);roar=null;}
            world=client.world;
            if(client.world==null||client.player==null||!s.weatherSounds||!s.customClouds
                    ||s.tornadoChance==0||s.tornadoVolume==0)return;
        }
        if(client.isPaused())return;
        TornadoTracker.Active nearest=null;double distance=1200;
        for(var tornado:TornadoTracker.nearby(client,s)) {
            double d=Math.hypot(tornado.x()-client.player.getX(),tornado.z()-client.player.getZ());
            if(d<distance){distance=d;nearest=tornado;}
        }
        if(nearest==null) {
            if(roar!=null){roar.target=0;if(roar.isDone())roar=null;}
            return;
        }
        if(roar==null||roar.isDone()) {
            roar=new Roar();client.getSoundManager().play(roar);
        }
        boolean sheltered=!client.world.isSkyVisible(client.player.getBlockPos().up());
        roar.target=(float)(TornadoGeometry.soundGain(distance,nearest.width(),nearest.activity(),sheltered)*s.tornadoVolume/100.0);
        roar.targetPitch=(float)(.94-Math.min(.25,nearest.width()/180)-(sheltered?.09:0));
        roar.move(nearest.x(),client.player.getY(),nearest.z());
    }
    private static final class Roar extends MovingSoundInstance {
        float target,targetPitch=.85f;
        Roar(){
            super(AtmosphereMod.TORNADO_ROAR,SoundCategory.WEATHER,Random.create());
            repeat=true;repeatDelay=0;relative=false;attenuationType=SoundInstance.AttenuationType.NONE;
            volume=.001f;pitch=.85f;
        }
        void move(double x,double y,double z){this.x=x;this.y=y;this.z=z;}
        @Override public void tick(){
            volume+=(target-volume)*.06f;pitch+=(targetPitch-pitch)*.04f;
            if(target==0&&volume<.0005f)setDone();
        }
    }
}
