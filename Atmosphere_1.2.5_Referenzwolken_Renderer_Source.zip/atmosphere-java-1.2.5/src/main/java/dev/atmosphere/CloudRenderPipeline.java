package dev.atmosphere;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/** Minecraft 1.21.1 pipeline. CoreShaderRegistrationCallback belongs to rendering-v1
 * 5.0.5+df16efd019 in Fabric API 0.115.6+1.21.1. No later RenderPipeline API. */
public final class CloudRenderPipeline extends RenderLayer {
    private static final Identifier TEXTURE=Identifier.of("atmosphere","textures/environment/cloud_surface.png");
    // Qualify explicitly: RenderLayer inherits a different nested RenderPhase.ShaderProgram.
    private static net.minecraft.client.gl.ShaderProgram shader;
    private static float fogStart=900,fogEnd=2600;
    private static final RenderLayer LAYER=new CloudRenderPipeline();
    private CloudRenderPipeline(){
        super("atmosphere_cloud_hull",VertexFormats.POSITION_TEXTURE_COLOR,VertexFormat.DrawMode.QUADS,
                262144,false,false,CloudRenderPipeline::begin,CloudRenderPipeline::end);
    }
    public static void register(){
        CoreShaderRegistrationCallback.EVENT.register(context->context.register(
                Identifier.of("atmosphere","cloud_hull"),VertexFormats.POSITION_TEXTURE_COLOR,p->shader=p));
    }
    public static RenderLayer layer(){return LAYER;}
    public static void visibility(double weatherFog){
        fogEnd=weatherFog<.12?2600:(float)WeatherFog.visibility(weatherFog);
        fogStart=weatherFog<.12?900:fogEnd*.08f;
    }
    private static void begin(){
        RenderSystem.setShader(()->shader);RenderSystem.setShaderTexture(0,TEXTURE);
        if(shader!=null){
            var start=shader.getUniform("CloudFogStart");var end=shader.getUniform("CloudFogEnd");
            if(start!=null)start.set(fogStart);if(end!=null)end.set(fogEnd);
        }
        RenderSystem.enableDepthTest();RenderSystem.depthFunc(515);RenderSystem.depthMask(true);
        RenderSystem.enableCull();RenderSystem.disableBlend();
    }
    private static void end(){
        RenderSystem.depthMask(true);RenderSystem.enableCull();RenderSystem.disableBlend();
    }
}
