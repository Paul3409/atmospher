package dev.atmosphere;

import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

/** Save clock integration rather than multiplying absolute world time by speed. */
public final class ClimateState extends PersistentState {
    private static final Type<ClimateState> TYPE=new Type<>(ClimateState::new,
            ClimateState::read,DataFixTypes.SAVED_DATA_MAP_DATA);
    private double ticks;
    private long seed,lastAge;
    private boolean initialized;
    private boolean published;
    private ClimateState() {}
    private static ClimateState read(NbtCompound n,RegistryWrapper.WrapperLookup registry){
        ClimateState s=new ClimateState();s.ticks=n.getDouble("WeatherTicks");
        s.seed=n.getLong("Seed");s.lastAge=n.getLong("LastAge");
        s.initialized=Double.isFinite(s.ticks)&&n.contains("WeatherTicks");return s;
    }
    @Override public NbtCompound writeNbt(NbtCompound n,RegistryWrapper.WrapperLookup registry){
        n.putDouble("WeatherTicks",ticks);n.putLong("Seed",seed);n.putLong("LastAge",lastAge);return n;
    }
    public static void tick(ServerWorld world){
        ClimateState s=world.getPersistentStateManager().getOrCreate(TYPE,"atmosphere_climate_v122");
        long age=world.getTime();double speed=AtmosphereSettings.get().weatherSpeed;
        if(!s.initialized){s.seed=world.getSeed();s.ticks=age*speed;s.lastAge=age;s.initialized=true;}
        // No offline catch-up; a reset of world age cannot reverse the climate.
        long delta=Math.max(0,Math.min(20,age-s.lastAge));
        s.ticks+=delta*speed;s.lastAge=age;
        ClimateClock.publish(s.seed,s.ticks,world.getTimeOfDay());s.markDirty();
        if(!s.published){s.published=true;StormEvents.sync(world);ManualPressureSystems.sync(world);}
    }
}
