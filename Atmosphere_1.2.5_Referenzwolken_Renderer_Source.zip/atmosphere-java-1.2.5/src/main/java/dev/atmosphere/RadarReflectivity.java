package dev.atmosphere;

/** Synthetic reflectivity, not an independent radar measurement.
 * Rain: Marshall-Palmer Z=200 R^1.6. Frozen/mixed hydrometeors use deliberately
 * simplified illustrative coefficients; these are NOT universal conversions. */
public final class RadarReflectivity {
    private RadarReflectivity(){}
    public static final double MIN_DBZ=5,MAX_DBZ=75;
    public static double dbz(double mmh,int kind){
        if(!Double.isFinite(mmh)||mmh<.1)return Double.NEGATIVE_INFINITY;
        double a=switch(kind){case 1->75;case 2->160;case 3->500;case 4->3200;default->200;};
        double b=switch(kind){case 1->2;case 2->1.7;case 3->1.5;case 4->1.45;default->1.6;};
        return 10*(Math.log10(a)+b*Math.log10(mmh));
    }
    public static double rainRate(double dbz){return Math.pow(Math.pow(10,dbz/10)/200,1/1.6);}
    private static final int[] COLORS={0x00D5E3,0x00B1EA,0x0082EF,0x0044F1,0x00EF00,
            0x00BF00,0x008500,0xFFFF00,0xFFBA00,0xFF6500,0xFF0900,0xB80000,
            0xF1ACDF,0xBA42B9,0x780086};
    public static int color(double dbz){
        if(!Double.isFinite(dbz)||dbz<MIN_DBZ)return 0xFF080B10;
        double value=WeatherCells.clamp(Math.floor((dbz-MIN_DBZ)/2.5)*2.5/5,0,COLORS.length-1);
        int i=Math.min(COLORS.length-2,(int)value);double t=value-i;
        int a=COLORS[i],b=COLORS[i+1];
        int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t);
        int g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t);
        int blue=(int)((a&255)*(1-t)+(b&255)*t);
        return 0xFF000000|(r<<16)|(g<<8)|blue;
    }
}
