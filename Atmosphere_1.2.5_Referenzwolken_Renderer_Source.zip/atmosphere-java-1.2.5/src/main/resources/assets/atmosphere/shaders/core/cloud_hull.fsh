#version 150
uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float CloudFogStart;
uniform float CloudFogEnd;
uniform vec4 FogColor;
in vec4 vertexColor;
in vec2 texCoord0;
in float vertexDistance;
out vec4 fragColor;
// Stable screen-door coverage: fragments that survive write real depth.
// No glass-like accumulation of front/back surfaces or overlapping decks.
const int BAYER[16] = int[16](0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5);
void main() {
    float coverage = smoothstep(0.0, 0.82, vertexColor.a * ColorModulator.a);
    ivec2 pixel = ivec2(gl_FragCoord.xy) & ivec2(3);
    float threshold = (float(BAYER[pixel.y*4+pixel.x]) + 0.5) / 16.0;
    if (coverage <= threshold) discard;
    vec3 tint = vertexColor.rgb * ColorModulator.rgb;
    tint *= 0.96 + 0.04 * texture(Sampler0, texCoord0).r;
    float fog = smoothstep(CloudFogStart, max(CloudFogStart + 0.001, CloudFogEnd), vertexDistance);
    fragColor = vec4(mix(tint, FogColor.rgb, fog), 1.0);
}
