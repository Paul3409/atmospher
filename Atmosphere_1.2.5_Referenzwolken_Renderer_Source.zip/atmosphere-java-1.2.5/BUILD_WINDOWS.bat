@echo off
cd /d "%~dp0"
echo Atmosphere 1.2.5 - Wolkenrenderer und Referenzform - Fabric 1.21.1 / Java 21
set "ATMOSPHERE_GRADLE=C:\Gradle\gradle-8.14.6\bin\gradle.bat"
if not exist "%ATMOSPHERE_GRADLE%" (
 echo Gradle wurde unter "%ATMOSPHERE_GRADLE%" nicht gefunden.
 echo Bitte den Gradle-Pfad in BUILD_WINDOWS.bat anpassen.
 pause
 exit /b 1
)
echo Gradle startet. Die Ausgabe erscheint hier und in build-output.log.
powershell.exe -NoProfile -Command "& $env:ATMOSPHERE_GRADLE clean build --no-daemon --console=plain --info --stacktrace 2>&1 | Tee-Object -FilePath 'build-output.log'; exit $LASTEXITCODE"
if errorlevel 1 (
 echo BUILD FEHLGESCHLAGEN - Ausgabe steht in build-output.log.
 pause
 exit /b 1
)
echo Fertig: build\libs\atmosphere-1.2.5.jar
pause
