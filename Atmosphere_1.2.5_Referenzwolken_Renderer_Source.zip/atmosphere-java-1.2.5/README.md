# Atmosphere 1.2.5 – Referenzform und neuer Wolken-Renderpfad

**Ausschließlich Minecraft/Fabric 1.21.1 · Yarn 1.21.1+build.3 · Fabric API 0.115.6+1.21.1 · Java 21**

## Neu in 1.2.5

- Die vom Nutzer bevorzugte frühere 1.2.4-Vorschau ist wieder die Formreferenz: breiter Amboss, eingeschnürter Aufwind, ausgeprägte Basis und darunter die deutlich erkennbare Absenkung. Die nachträgliche Glättung der unteren Kontur ist zurückgenommen. Eine Oberfläche verbindet alle Teile; der Tornado setzt unten an.
- **Eigener Wolken-Shader für 1.21.1**, registriert über `CoreShaderRegistrationCallback` aus `fabric-rendering-v1` **5.0.5+df16efd019**. Ressourcen unter `assets/atmosphere/shaders/core/cloud_hull.{json,vsh,fsh}`, GLSL 150 und `VertexFormats.POSITION_TEXTURE_COLOR`. Es wird ausdrücklich nicht die RenderPipeline-/Shader-Registrierung späterer Minecraft-Versionen verwendet.
- Wolkenkörper verwenden Tiefenpuffer und Verdeckungsprüfung statt durchsichtiger Entity-Hüllen. Dadurch überlagern sich Vorder-/Rückseiten nicht mehr wie Glasflächen. Bei Ein-/Ausblendung und am Rand wird eine kleine pixelweise Deckungsmaske genutzt. Es bleibt ein stilisierter Oberflächenrenderer, kein fotorealistischer Raymarching-Volumenrenderer.
- Die Beleuchtung wird einmalig berechnet; der Standard-Entity-Shader beleuchtet die Wolke nicht zusätzlich. Vorschau und Renderer benutzen dieselbe Java-Lichtfunktion. Wolkenfernsicht ist von der normalen Bodensichtweite getrennt; echter Wetternebel und Wolkenimmersion bleiben berücksichtigt. Die Kameraprojektion begrenzt weiterhin die Fernsicht: Für den kompletten äußeren Zellaufbau sind z.B. 24 Chunks sinnvoll.
- Alte 7-/8-seitige Wolken-Ellipsoide sind auf die gemeinsame gerundete Geometrie umgestellt, künstliche Wolkenbrücken entfallen. Unter reifen Gewitterzellen wird die Hintergrunddecke weich zurückgenommen, damit sie nicht durch die eigentliche Zellenbasis schneidet. Über der Superzellen-Wall-Cloud werden keine zusätzlichen Zufluss-/Shelf-Platten mehr aufgelegt. Böenfront-Wind/Kühlung bleiben erhalten; sichtbare Shelf Clouds anderer Gewittertypen bleiben vorhanden.
- Mindestauflösung der Superzellenbasis auch bei niedriger Grafik; Grafikautomatik reduziert höhere Wolkendetails höchstens bis „Ausgewogen“. Die Radarauflösung bleibt eine getrennte Einstellung.
- Regenvorhänge erhalten eine eigene Textur mit an allen vier Kanten auf null auslaufender Transparenz. 16 schmale Abschnitte ersetzen die fünf harten Großflächen. Wolken, Tornadoeffekte, Regen und Schatten werden getrennt gesammelt und gezeichnet, ohne ungültige VertexConsumer nach einem RenderLayer-Wechsel weiterzuverwenden.
- **Grafik → Ansicht: Normal / Zellenfokus**: Zellenfokus zeigt nur die jüngste aktive manuelle Superzelle oder sonst die nächstgelegene natürliche Superzelle, ohne Hintergrunddecke und entfernte Regenvorhänge. Das ist ein reiner optischer Vergleichsmodus, keine Änderung an Wetter, Radar, Wind oder gespeicherten Zellen. Der HUD-Zusatz `ZELLENFOKUS` erinnert an den Modus. Ohne aktive Superzelle bleibt diese Ansicht leer. Danach wieder auf Normal stellen.
- dBZ-Radar, Nebelregler, Sirenen, Wetteruhr und gespeicherte Daten bleiben erhalten. Die bestätigte Tornadogeometrie wird nicht verändert.

## Prüfen im Spiel

1. Welt sichern, nur `atmosphere-1.2.5.jar` zusammen mit Fabric API für **1.21.1** verwenden. Alternativ `BUILD_WINDOWS.bat` mit Java 21 ausführen; bei Fehlern `build-output.log` sichern. HUD muss 1.2.5 anzeigen.
2. Am Tag eine manuelle Superzelle erzeugen. **Grafik → Details: Hoch**, für einen festen Vergleich **Grafikautomatik AUS** unter Wind; zunächst **Ansicht: Zellenfokus** wählen. Aus etwa **700–1000 Blöcken Entfernung** die gesamte Zelle ansehen, möglichst mit 24 Chunks Sichtweite. Nah direkt darunter kann man den oberen Aufwind naturgemäß nicht wie in der Außenansicht der Vorschau sehen.
3. Bevorzugte Kontur vergleichen: breiter Amboss, eingeschnürter Aufwind, gegliederte Basis und darunter die geschlossene rotierende Absenkung. Anschließend schräg von unten betrachten. Keine sichtbaren inneren Flächen durch die äußere Wolkenhaut.
4. Auf **Ansicht: Normal** zurückschalten. Die normale Bewölkung darf die Zelle nicht wieder mit groben Platten verdecken. Trockene Wolken und Shelf Clouds gewöhnlicher Gewitter müssen erhalten bleiben. Nebel AN/AUS und 0/100/200 % vergleichen. Für eine Außenansicht ohne wetterbedingte Sichtbehinderung eine klare Testlage wählen.
5. Regengebiet ansehen: Übergänge der entfernten Regenvorhänge sollen weich auslaufen, keine fünf massiven rechteckigen Wände mehr. Nahe Regenpartikel sind weiterhin ein eigener Effekt.
6. Details Leicht/Ausgewogen/Hoch wechseln und Grafikautomatik prüfen. Form bleibt dieselbe, Auflösung/Fernsicht ändern sich. Beim Annähern dürfen Wolken nicht wegen nachgeladenem Terrain ihre Höhe ändern.
7. Tornadoform/Bodenkontakt, Radar auf Jetzt mit dBZ und mm/h, Sirenen und Speichern/Laden kurz gegenprüfen. Bei Darstellungsfehlern bitte Minecraft-Grafikmodus, Renderdistanz, Wolkendetails und gegebenenfalls aktive Shader-/Grafikmods nennen.

## Technische Prüfungen und Vorschauen

`bash tools/test-model.sh`: 15 Modell-/Geometrie-/Persistenz-/Sirenen-Testprogramme einschließlich Hintergrundverdeckung, Mindestauflösung und Regenrandmaske. `tools/check_render_assets.py` prüft JSON/GLSL-Schnittstellen und Texturtransparenz; im Build werden GLSL-Vertex-/Fragmentshader zusätzlich mit glslang gelinkt. Modellbilder in `previews/` sind entsprechend gekennzeichnet und keine Spielaufnahmen.

Der optionale Entwicklungs-Quellensatz `tools/visual-test` ist **nicht Bestandteil der produktiven Mod-JAR**. Nur `-PvisualTest` aktiviert eine separate Test-Mod. Sie benutzt ausschließlich die geprüften Yarn-1.21.1-Schnittstellen und eine neue Wegwerf-Testwelt aus `tools/create_visual_world.py` (DataVersion 3955). Sie erzeugt Außen-/Unteransichten und eine komplette Szene; Produktionswelten werden dabei nicht geöffnet oder verändert. Der Clienttest kann über den GitHub-Workflow laufen. Testlogs und tatsächliche Clientbilder sind getrennte Artefakte; eine reine Modellvorschau ist kein Nachweis für korrekte Ingame-Darstellung.

## Vorheriger Stand: 1.2.4

**Minecraft/Fabric 1.21.1 · Yarn 1.21.1+build.3 · Fabric API 0.115.6+1.21.1 · Java 21 · Einzelspieler**

Die Mod-Metadaten erlauben ausdrücklich nur Minecraft 1.21.1; spätere 1.21.x-Versionen sind damit nicht ungeprüft freigegeben.

## Neu in 1.2.4

- **Wall Cloud und Superzelle sind eine gemeinsame geschlossene Oberfläche.** Die separate linsenförmige Wall-Cloud-Geometrie und die kleinen umlaufenden Röhrchen entfallen. Die abgesenkte Unterseite verbreitert sich kontinuierlich in die Hauptbasis, darüber folgen geneigter Aufwind und seitlich ausladender Amboss. Die rotierenden Unregelmäßigkeiten der unteren Wolke gehören zur Oberfläche, nicht zu einem aufgesetzten Teller. Die Wolkenhöhe bleibt unabhängig vom Nachladen des Geländes; nur sichtbarer Funnel/Bodenstaub nutzen geladene Geländehöhen. Liegt das Gelände bereits in der Wall Cloud, wird kein umgedrehter Funnel zwischen Wolke und höherem Boden gezeichnet. Es werden dafür keine Chunks nachgeladen.
- **Natürlichere Wolkenformen:** räumliche, mehrskalige Ausbuchtungen statt fast gleichförmiger Sinus-/Ringformen; leicht unregelmäßige Unterseiten, weichere Silhouetten und Oberflächennormalen. Der Amboss hat gröbere, sanftere Randformen als der quellende Aufwind. Die allgemeine trockene Bewölkung aus 1.2.3 bleibt bestehen. Es bleibt ein stilisierter Mesh-Renderer, kein fotorealistischer Raymarching-Shader.
- **Begrenzte Geometrie-Caches:** normale Wolken verwenden wiederverwendete normierte Grundformen und werden daraus skaliert. Die Grundformen bleiben kameraunabhängig; mehr Details ändern die Auflösung, nicht das Wetter. Das teurere Superzellenrelief wird innerhalb eines Ticks wiederverwendet. Es werden keine Gelände-Chunks für die Geometrie nachgeladen.
- **Flächiger Hook-Echo-Anschluss:** verbreiterter rückseitiger Niederschlag und ein weich verbundener Haken ersetzen das bisherige Maximum aus Regengebiet und schmalem Streifen. Auch schwächere Intensitätsflächen folgen der Krümmung; erst die Spitze verjüngt sich. Der trockene Einströmbereich bleibt bestehen. Das ist eine Änderung des Niederschlagsfeldes für Spiel und Radar, keine zusätzliche Zeichenlinie.
- **Niederschlagsradar in dBZ:** Türkis/Blau → Grün → Gelb → Orange → Rot → Rosa/Violett, mit numerischer Skala 5–75 dBZ. Die Farben gelten für Reflektivität, nicht als feste Kennung für Schnee oder Hagel. Der Mod verändert die Regenraten nicht, nur um höhere Farben zu erreichen.
- **Mausanzeige unter der Karte:** geschätzte dBZ, dieselben mm/h wie im Radar-Sample und Niederschlagsart. `~` kennzeichnet Modellwerte. Unter 0,1 mm/h steht `-- dBZ (kein Echo)` statt eines erfundenen Nullwerts; mathematisch ist dBZ bei genau null Niederschlag nicht endlich. HUD und andere Regenangaben bleiben in mm/h.
- **Umrechnung:** für Regen `Z = 200 · R^1,6`, `dBZ = 10 log10(Z)`. Beispiele: 1 mm/h ≈ 23,0 dBZ; 10 mm/h ≈ 39,0 dBZ; 100 mm/h ≈ 55,0 dBZ. Für Schnee wird illustrativ `75 · R²`, Schneeregen `160 · R^1,7`, Graupel `500 · R^1,5` und Hagel `3200 · R^1,45` verwendet. Diese Werte sind vereinfachte Spielmodell-Abschätzungen, **keine universell gültigen meteorologischen Umrechnungen oder unabhängigen Radarmessungen**. Die mm/h sind die Niederschlagsrate des vorhandenen Modells, bei gefrorenen Arten nicht die Schneehöhe.
- **Erhalten:** ursprüngliche Tornadoform aus 1.1.13 ohne Spiralbänder, Funnel-Absenkung, Bodenkontakt und einstellbare Ereignischance, Wetteruhr und Weltdaten, Nebelschalter/0–200 % sowie alle Sirenenfunktionen. Der Ansatzpunkt des Funnels folgt der nun tiefer integrierten Wall Cloud. Die verworfene separate Wall-Cloud-Implementierung ist im archivierten 1.2.3-Quellpaket weiterhin verfügbar.

## Test 1.2.4

1. Welt sichern. Java 21 verwenden, `BUILD_WINDOWS.bat` starten oder die fertig gebaute JAR installieren. Nur `atmosphere-1.2.4.jar` mit Fabric API in `mods/` verwenden; alte Atmosphere-JARs außerhalb aufbewahren. Im HUD muss 1.2.4 stehen. Bei Buildproblemen `build-output.log` sichern.
2. Manuelle Superzelle erzeugen, am Tag zuerst seitlich aus 300–700 Blöcken, dann von unten betrachten. Die Wall Cloud soll sichtbar abgesenkt, geschlossen und in die Hauptbasis eingebettet sein – keine separate Scheibe, kein offener Ring. Mindestens 20–30 Sekunden beobachten: Die untere Wolkenstruktur dreht sich langsam. Beim Wechsel zwischen Leicht/Hoch darf dieselbe Zelle nicht eine andere Grundform erhalten.
3. Gewöhnliche Wolken bei trockenem Wetter seitlich/von unten anschauen. Auf größere unregelmäßige Wölbungen und weichere Ränder achten; auch klare und bedeckte Abschnitte müssen erhalten bleiben. Das erste Laden neuer Formen sowie FPS bei Hoch gegenprüfen.
4. Radar auf **Jetzt**, 500/1500 Blöcke stellen. Fronten/Isobaren für die Formprüfung ausblenden. Rückseitiger Niederschlag soll flächig in den Haken übergehen statt als schmaler angehängter Strich zu erscheinen. Kern und trockenen Bereich durchfliegen: Radar und örtlicher Niederschlag vergleichen.
5. In der Ansicht **Radar dBZ** müssen die neue Farbskala und dBZ-Zahlen stehen. Maus über trockene Fläche, schwaches Echo, Kern und Haken bewegen: unten müssen dBZ **und** mm/h mit Niederschlagsart erscheinen. Trocken: `-- dBZ` plus Rate, keine Anzeige `Infinity`/`NaN`. Bei einem reinen Regenwert von 10 mm/h sind etwa 39 dBZ plausibel. +3 Spielstunden ist eine Prognose, nicht die aktuelle Zelle.
6. Optional zum Prüfen manuell 1/10/100 mm/h Regen wählen und Hover-Werte vergleichen; danach Automatik wieder einschalten. Bei Schnee/Graupel/Hagel müssen Typ und modellabhängige dBZ-Werte passen; Schnee wird nicht mehr automatisch weiß eingefärbt und Violett ist keine sichere Hageldiagnose.
7. Bei einem Tornado die bekannte Form, Absenkung und Bodenkontakt prüfen; „Häufig“ bedeutet weiter 60 % pro Ereignis. Nebel AN/AUS/0–200 %, Speichern/Neuladen und Sirenen kurz gegenprüfen.

## Vorschauen und Prüfungen

Die Bilder unter `previews/` sind **mathematische Modellvorschauen, keine Ingame-Screenshots**. Sie zeigen dieselben Geometrie-/Niederschlagsfunktionen; Minecraft-Textur, Transparenz, Nebel und reale Performance werden damit nicht getestet. `tools/CloudShapePreview.java` und `tools/WeatherPreview.java` erzeugen sie reproduzierbar mit Java 21 nach `bash tools/test-model.sh`.

`tools/test-model.sh` führt **14 Testprogramme** aus: unter anderem 16.072 Wolkenpunkte, geschlossene Oberflächen/Rotation, wiederverwendete Grundformen, trockene Bewölkung, 7.500 Reflektivitätswerte, Z–R-Rückrechnung, Farbgrenzen, flächiger Hook-Ansatz, Wetterzustand/Nebel-Speicherung und Sirenenregressionen. Die Test-Doubles in `tools/` gehören nicht zur Mod-JAR und ersetzen keinen Fabric-Build oder Ingame-Sichttest.

## Vorheriger Stand: 1.2.3

**Fabric 1.21.1 · Minecraft 1.21.1 · Java 21 · Einzelspieler**

## Neu in 1.2.3

- Allgemeine Wolken bestehen aus einer geschlossenen zusammenhängenden Oberfläche mit abgeflachter Unterseite und unregelmäßig gewölbter Oberseite. Die vorherigen übereinandergelegten Basis-/Turm-/Puffkörper der unteren Bewölkung entfallen. Schichtbewölkung ist breiter und flacher; Quellwolken wachsen höher und neigen sich mit dem Wind. Glatte Oberflächennormalen und begrenzte Detailstufen statt scharf gegeneinander beleuchteter Einzelflächen. Form, Basis und Entwicklungsstand sind unabhängig von Kamera und Qualitätsstufe; die Qualität bestimmt die Zahl der Flächen und Sichtweite.
- Ein eigenständiges, langsam ziehendes Feld erzeugt lockere bis dichte trockene Bewölkung, ohne daraus automatisch Regen abzuleiten. Kräftiges Hochdruckabsinken kann weiter aufklaren; Winterinversionen können Wolken erhalten. Trockene Schichtwolken sind langlebiger als einzelne Quellwolken und überdecken größere Bereiche.
- Superzellen: breitere untere Basis, eingeschnürter geneigter Aufwind und größerer seitlich ausladender Amboss auf einer zusammenhängenden Oberfläche. Die Form orientiert sich am besprochenen Aufbau, ist aber kein kopiertes Blockmodell und kein fotorealistischer Volumenrenderer.
- Die kleine hohle „Meso“-Röhre wird durch eine rund doppelt so breite, geschlossene, flache Wall Cloud ersetzt. Ihre Oberseite greift in die Hauptwolke; die Unterseite hängt abgesenkt darunter. Asymmetrische Wolkenstrukturen rotieren langsam im breiten Bereich. Ein- und Ausblenden folgen der Zellentwicklung.
- Die bereits bestätigte Tornadogeometrie aus 1.1.13 bleibt **unverändert**, einschließlich Größenprofil, Rotation und Funnel-Absenkung. Die Tornadobreite wird nicht mit der größeren Wall Cloud vergrößert. Tornados bleiben an ausreichend reife Hook-Echo-Superzellen und die eingestellte Chance gebunden.
- Das tatsächliche Hook-Echo-Niederschlagsfeld folgt einer unregelmäßigen Kurve mit breitem Ansatz und dünner auslaufender eingerollter Spitze. Unterschiedliche Intensitäten entlang des Arms, asymmetrisch ineinander übergehende Kerne und räumlich zusammenhängende kleine Unregelmäßigkeiten ersetzen den gleichmäßig dicken Bogen. Radar und Regen im Spiel nutzen weiterhin dasselbe Feld. Es gibt keine nur im Radar aufgemalten Strukturen.
- Unter **Grafik**: **Wetternebel AN/AUS** und direkt daneben **Nebelstärke 0–200 %** als Regler. 100 % = normale wetterabhängige Dichte; 0 % oder AUS = kein zusätzlicher Wetter-/Regennebel. 200 % verstärkt vorhandenen Nebel, erzeugt aber keinen Dauernebel in trockener Luft. Werte werden beim Verlassen des Menüs gespeichert. Alte Konfigurationen erhalten 100 % und behalten ihren bisherigen Schalter.
- Wolkenimmersion beim Hineinfliegen bleibt ein eigener Effekt, unabhängig vom Bodennebelregler. Unter Wasser, in Lava, Pulverschnee sowie bei Blindheit/Dunkelheit greift die Wetternebelanpassung nicht ein. Normale Minecraft-Fernsicht bleibt bestehen; der Regler betrifft Atmosphere-Wetternebel.
- Die Sirenenfunktionen und ihre Daten sind unverändert. Die optional besprochenen zusätzlichen Punkte 5, 7 und 8 (neues Zuflussband, weitergehender Umbau der Niederschlagswand, verschiedene Superzellenklassen) sind nicht Teil dieses Updates.

## Test 1.2.3

1. Welt sichern. `BUILD_WINDOWS.bat` mit Java 21 ausführen oder die fertig gebaute JAR verwenden. Nur `atmosphere-1.2.3.jar` zusammen mit Fabric API installieren; ältere Atmosphere-JAR entfernen/außerhalb des mods-Ordners aufbewahren. HUD muss 1.2.3 anzeigen. Bei Buildfehlern `build-output.log` sichern.
2. Bei **automatischem Wetter** einige Wetterlagen beobachten, vorübergehend mit Wettertempo 20: lockere Quellwolken und dichtere flache Bewölkung sollen auch bei 0 mm/h auftreten. Es muss weiterhin klare Abschnitte und echten Regen geben. Nicht ausschließlich manuell erzeugte Gewitter anschauen.
3. Wolken seitlich, von unten und von oben betrachten. Unterseiten sollen flacher, Körper zusammenhängender und Übergänge weniger kantig sein. Zwischen Leicht/Hoch wechseln: dieselbe grobe Form, unterschiedliche Feinheit. Danach Wettertempo zurücksetzen.
4. Eine Superzelle erzeugen und aus 300–700 Blöcken Entfernung am Tag beobachten: breitere geschlossene Wall Cloud unter der Basis, kein offenes Rohr; darüber Aufwind und seitlich ausladender Amboss. Rotation der Wolkenstrukturen mindestens 20–30 Sekunden beobachten. Bei einem Tornado darf die bekannte Funnel-/Tornadoform nicht zu einem breiten Meso-Zylinder oder einer Spirale werden. „Häufig“ ist weiter 60 % pro Ereignis, keine Garantie.
5. Radar zunächst auf **Jetzt** stellen, 500/1500 Blöcke und Isobaren/Fronten für die Formprüfung ausschalten. Unregelmäßigen Ansatz, wechselnde Intensitäten und schmaler auslaufende Hook-Spitze prüfen. Regenkern und trockenen Einströmbereich durchfliegen und mit der Karte vergleichen; +3 Spielstunden ist keine Gegenwartsanzeige.
6. **Grafik → Wetternebel**: AN bei 0/100/200 % vergleichen, anschließend AUS. Am besten morgens in einer ruhigen feuchten Lage auf niedriger Höhe testen; tagsüber bei trockener Luft darf auch 200 % klar bleiben. Nebelregler kann bei einer trockenen Wetterlage scheinbar wirkungslos sein – das ist beabsichtigt. Wolkeninneres bleibt trüb. Unter Wasser/Lava dürfen die bisherigen Sichteffekte nicht verändert werden.
7. Regler z.B. auf 137 % stellen, Menü mit Fertig oder Escape verlassen, neu öffnen und anschließend Spiel neu starten: Wert und AN/AUS müssen erhalten bleiben. Kurz Sichtweite/FPS bei Hoch sowie Sirenen und Speichern/Laden bestehender Zellen gegenprüfen.

### Automatische Prüfungen

`bash tools/test-model.sh` führt 13 Testprogramme mit Java 21 aus: bisherige Wetter-/Tornado-/Sirenenregressionen, 16.072 Wolkenoberflächenpunkte mit Naht-, Normalen- und Abschlussprüfungen, trockene Bewölkung in 5.808 Wetterproben, Nebelkurven sowie Lesen/Schreiben/Migration der echten Einstellungen gegen einen Loader-Test-Dummy. Das ersetzt keine visuelle Prüfung in Minecraft.

## Vorherige Änderungen: 1.2.2

**Fabric 1.21.1 · Minecraft 1.21.1 · Java 21 · Einzelspieler**

## Neu in 1.2.2

- Neue natürliche Wetterereignisse statt wiederkehrender Zellen derselben Rasterkennung: jede Generation bekommt eigene Kennung, Position, Typ, Lebensdauer, Zugrichtung und Intensität. Ein abgestorbenes Ereignis erwacht nicht erneut. Unterschiedliche Welten erhalten unterschiedliche Kataloge.
- Wetteruhr und Weltseed werden in `atmosphere_climate_v122.dat` gespeichert. Änderungen der Minecraft-Tageszeit rollen das Wetter nicht neu aus. Wettertempo verändert nur den weiteren Verlauf, nicht die bisher vergangene Wetterzeit. Tageslicht und Jahreszeitenanzeige folgen weiterhin der Minecraft-Uhr. Beim ersten Update wird die neue Wetterbasis einmalig initialisiert; die alte natürliche Wetterkarte kann daher anders aussehen.
- Neun fließend wechselnde Strömungsmuster: West, Nordwest, Nord, Südwest, Süd, Ost, ruhiges Hoch, Blocking und abgetropftes/langsames Tief. Feuchtigkeit, Wärme, Hebung und Scherung beeinflussen die möglichen Zelltypen. Kein Ort ist dauerhaft an einen bestimmten Gewitter- oder Tornadotyp gebunden; Biome und Jahreszeiten dürfen trotzdem unterschiedliche Risiken behalten.
- Hochs und Tiefs haben variable Lebenszyklen und gestreckte Druckfelder. Ihre Bahnen folgen der wechselnden Strömung. Hochdruckeinfluss bremst und lenkt benachbarte Tiefs um; Fronten orientieren sich an der jeweiligen Strömungsrichtung. Drehsinn der Bodenströmung für die Nordhalbkugel korrigiert. Es handelt sich um ein vereinfachtes Spielmodell, nicht um eine numerische Wettervorhersage oder garantierte reale Wetterabfolge.
- Superzellen: breiter, geneigter Aufwindkörper mit abgerundeten, horizontalen Wolkenschichtungen und Amboss. Wall Cloud, seitlicher Zufluss und getrennte Niederschlagswand bleiben verbunden. Die bestätigte Tornadosilhouette aus 1.1.13 bleibt ohne Spiralbänder erhalten; ihre Rotation funktioniert nun auch bei angehaltener Tageszeit.
- Hook Echo: asymmetrischer Niederschlagsschirm, mehrere Kerne, gebogener rückseitiger Niederschlagsarm mit eingerollter, schmaler Spitze und trockenerem Einströmbereich. Dasselbe Niederschlagsfeld speist Radar und Wetter im Spiel – keine nur aufgemalte Radarform. Die Fotos sind Formreferenzen, keine Zusage fotorealistischer Minecraft-Darstellung.
- Tornadochance pro neuer Superzelle: Aus 0 %, Selten 8 %, Normal 25 %, Häufig 60 %. Ein ausreichend reifes Hook Echo bleibt Voraussetzung. Häufig ist ausdrücklich keine Garantie mehr.
- Gemeinsamer Ereigniskatalog für Wetter, Radar, Wolken, Tornadoton/-staub und bestehende Sirenenwarnungen. Radarabfragen werden pro Scan eingefroren; die Regenberechnung erhält ein Zeitbudget je Bild (mindestens eine Zeile). Begrenzte Katalog-Caches vermeiden unnötige Wiederholungsrechnungen. Die Sirenenfunktionen selbst sind unverändert.
- Alte manuelle Zellen/Druckgebiete werden beim Laden auf gespeicherte Wetterstartzeiten umgestellt. Ihre Daten bleiben erhalten; natürliches Wetter nutzt die neue Generationenlogik.

## Test 1.2.2

1. Welt sichern. `BUILD_WINDOWS.bat` ausführen (Java 21); nur `atmosphere-1.2.2.jar` mit Fabric API verwenden. Im HUD muss 1.2.2 stehen. Buildfehler: `build-output.log` aufbewahren.
2. Eine manuelle Superzelle erzeugen, Radar bei 500/1500 Blöcken öffnen. Bei ihrer Reifung gebogenen Niederschlagsarm, eingerollte Spitze und trockenen Einströmbereich prüfen. In Regenkern und trockeneren Bereich fliegen: Radar und örtlicher Niederschlag sollen zueinander passen. Für die Formprüfung Isobaren/Fronten vorübergehend ausblenden.
3. Die Zelle aus einiger Entfernung am Tag betrachten: breiter geschichteter Wolkenkörper, Amboss, abgesenkte Wall Cloud, seitlicher Zufluss und getrennte Regenwand. Tornadochance zunächst „Häufig“: nicht jede Zelle wird einen Tornado bilden. Falls einer entsteht, bekannte geschlossene Silhouette ohne Spiralbänder prüfen.
4. Wettertempo vorübergehend auf 20 setzen und 5–10 Minuten beobachten: neue Zellen sollen andere Positionen, Formen, Typen und Bahnen bekommen. Für mehrere Großwetterlagen länger laufen lassen; sie wechseln bewusst langsamer als einzelne Zellen. Danach Tempo zurückstellen: keine sprunghafte Ortsänderung derselben Zelle.
5. Während einer aktiven Zelle speichern, verlassen und laden: kein Neustart und keine neue Auslosung dieser Zelle. `/time set day` bzw. `/time set night` darf Tageslicht ändern, aber nicht die Wetterereignisse zurücksetzen. Mit `/gamerule doDaylightCycle false` sollen Wetter, Radar und Tornadorotation weiterlaufen; anschließend wieder `true` setzen.
6. Luftdruck-/Frontenkarte über mehrere Wettertage betrachten: unterschiedliche Hoch-/Tiefbahnen, auch meridionale Ablenkungen und langsamere/blockierte Systeme. Nicht jede Episode muss dieselbe Nordlage ergeben. Am gleichen Ort über mehrere Ereignisse vergleichen, nicht nur dieselbe gespeicherte Zelle neu laden.
7. Radar „Hoch“ öffnen, schließen, erneut öffnen und Ansichten wechseln. Ladezeit/Ruckler vergleichen. Zuletzt kurz Sirenenwarnung, Signalpegel und Probeplan prüfen; Probeplan bleibt an der Minecraft-Uhr, nicht an der Wetteruhr.

### Prüfen ohne Minecraft

`bash tools/test-model.sh` führt Modell-, Geometrie-, Zustands- und Sirenenregressionen mit Java 21 aus. Die separaten Test-Doubles unter `tools/` gehören nicht zur Mod und ersetzen keinen Fabric-Build/Ingame-Test. `WeatherVarietyTest` prüft neue Kennungen, Auslaufen, Weltenseed, Kataloggrenzen, Strömungswechsel, Scan-Zeit und Tornadohäufigkeiten; `ClimatePersistenceTest` prüft die echten Zustandsklassen mit NBT-Test-Doubles einschließlich Altstand-Migration.

## Bisheriger Stand

## Neu in 1.2.1

- Gesamtlautstärke jeder Sirene von 0 bis 200 Prozent. Zusätzlich vier getrennte Signalpegel (ebenfalls 0–200 Prozent). 100 Prozent Signalpegel entspricht dem bisherigen Verhalten.
- Unter „Pegel & Probeplan“ lassen sich die Werte auf alle Sirenen derselben Gruppe übertragen. Reichweite und Startverzögerung werden dabei nicht kopiert. An einer Bedienstelle können die Pegel als Gruppenvorlage eingestellt werden.
- Gesamt- und Signalpegel wirken gemeinsam: z.B. Gesamt 100 Prozent und Warnung 150 Prozent. Für Verstärkungen über dem Normalpegel stehen begrenzte Audiofassungen bereit; ein Limiter begrenzt Pegelspitzen. Die normalen Aufnahmen bleiben unverändert. Die tatsächliche Lautstärke hängt weiterhin vom Minecraft-Master-/Wetterregler und Abstand ab.
- Eine Bedienstelle kann einen täglichen Probealarm der Gruppe zur Minecraft-Uhrzeit HH:MM planen. Zeitplan und Pause sind unabhängig von der Wetterautomatik einstellbar. Ohne aktivierten Plan passiert nichts automatisch.
- Probealarme unterbrechen keine aktiven Alarme oder Gefahrenwarnungen. Nach Pause, Zeitrücksprung oder verpasster Uhrzeit gibt es keinen nachträglichen Alarm. Ein bereits ausgelöster Zeitpunkt wird nicht durch Zurückstellen der Uhr erneut ausgelöst.
- Gruppen, Pegel, Zeitplan und die letzte Auslösung werden in der Welt gespeichert. Bestehende 1.2.0-Daten bekommen automatisch vier Signalpegel von 100 Prozent und einen ausgeschalteten Probeplan.

## Test 1.2.1

1. `BUILD_WINDOWS.bat` starten, nur `atmosphere-1.2.1.jar` verwenden. Bei Buildfehlern `build-output.log` sichern.
2. Sirene rechts anklicken, „Pegel & Probeplan“ öffnen. Gesamtlautstärke auf 100 Prozent, Warnung und Entwarnung z.B. auf 150 Prozent stellen und speichern. Alle vier Signale vergleichen; dann Gesamtlautstärke 200 Prozent und 0 Prozent prüfen.
3. Zwei Sirenen derselben Gruppe mit unterschiedlichen Startverzögerungen verwenden. Pegel übertragen: Die Pegel müssen übereinstimmen; Startverzögerung und Hörweite müssen verschieden bleiben.
4. An der Bedienstelle dieselbe Gruppe wählen, einen wenige Minecraft-Minuten entfernten Zeitpunkt HH:MM einstellen, tägliche Probe aktivieren und speichern. Ein Minecraft-Tag beginnt um 06:00; 12:00 entspricht `/time set 6000`.
5. Auslösung zur Uhrzeit, Pause, Abschalten und Speichern/Neuladen prüfen. Uhrzeit testweise zurückstellen: keine doppelte Auslösung desselben Zeitpunkts. Ein gleichzeitig laufender Feueralarm darf nicht durch die Probe überschrieben werden.
6. Laufende Probe und wartende Sirenen mit Gruppenstopp abbrechen. Pegelsteuerung und Stopp auch bei Wetterwarnungen kurz prüfen.

Zusätzliche Audioassets können nach `prepare_siren_assets.py` mit `tools/prepare_siren_gain_assets.py --project PROJEKTORDNER` aus den vorhandenen normalen OGG-Abschnitten aufgebaut werden. ffmpeg wird nur zur Asset-Aufbereitung benötigt, nicht zum normalen Mod-Build.

## Neu in 1.2.0

- Platzierbare E57-Sirene und separate Bedienstelle. Beide sind in der Redstone-Kreativgruppe und über Rezepte erhältlich.
- Vier vom Nutzer gelieferte elektronische Sirenensignale: Probealarm (25,5 s), Feueralarm (63,4 s), Bevölkerungswarnung (67,9 s), Entwarnung (70 s). Die Originalabläufe einschließlich Ausklang bleiben erhalten.
- Gruppen, Einzelstart, Gruppenstart und Gesamtstart. Jede Sirene hat 0–3 Sekunden Startverzug, 64–1024 Blöcke Hörweite und 0–100 % Lautstärke. Entfernung fügt eine kurze Schalllaufzeit hinzu.
- Stopp jederzeit: einzelne Sirene, Gruppe oder alle. Auch wartende Starts werden verworfen. Laufende Abschnitte blenden kurz aus.
- Redstone: Nordseite = Stopp; alle übrigen Seiten = Start des gespeicherten Signals. An der Bedienstelle wird die Gruppe gesteuert. Stopp hat Vorrang, Start reagiert auf eine neue steigende Flanke.
- Gruppenautomatik an einer Bedienstelle: starke Böen (ab 65 km/h), Hagel und aktive Tornados im Warnradius sind einzeln zuschaltbar. Ohne Gefahr über 90 Sekunden folgt optional Entwarnung. Wiederholungen sind auf frühestens fünf Minuten begrenzt. Manuelle Alarme sperren die Automatik während des Signals und zwei Minuten danach. Automatik kann dauerhaft pausiert werden.
- Einstellungen und Alarmzeitpunkte werden pro Welt gespeichert. Unbeladene Sirenenpositionen erzwingen keine Chunk-Ladung. Maximal 128 Sirenen/Bedienstellen; höchstens 16 nahe Sirenen werden gleichzeitig hörbar berechnet.

## Bedienung und Test

1. `BUILD_WINDOWS.bat` starten, nur `atmosphere-1.2.0.jar` mit Fabric API verwenden. Bei Fehlern `build-output.log` sichern. Vor dem Test eine Weltkopie verwenden.
2. In der Redstone-Kreativgruppe E57 und Bedienstelle holen; alternativ `/give @s atmosphere:e57_siren` und `/give @s atmosphere:siren_control`.
3. Zwei Sirenen auf Dächer/Stangen setzen und rechts anklicken. Gleichen Gruppennamen vergeben, an einer Sirene 0 s, an der anderen z.B. 1,5 s Startverzug einstellen. Speichern drücken. Reichweite und Lautstärke werden direkt an den Sirenen eingestellt.
4. Bedienstelle platzieren, derselben Gruppe zuordnen, Signal wählen und Gruppe starten. Alle vier Signale prüfen. Auch während der Startverzögerung stoppen: keine Sirene darf später doch losgehen.
5. Näher herangehen, weiter entfernen und hinter/in ein Gebäude gehen. Entfernte Signale sollen leiser, verdeckte dumpfer sein. Wer mitten im Alarm in Hörweite kommt, hört ab dem nächsten zeitlich passenden Abschnitt (bis zu zwei Sekunden Wartezeit).
6. Bei ausgeschalteter Wetterautomatik Redstone testen: Nordseite Stopp, andere Seite Start. Bei dauerhaftem Startsignal darf der Alarm nach Ende nicht endlos neu starten.
7. An der Bedienstelle Automatik einschalten, gewünschte Gefahren wählen und speichern. Starke Wetterlage erzeugen. Warnung, manuelle Übersteuerung, Pause und optionale Entwarnung prüfen. Mehrere Bedienstellen derselben Gruppe überwachen gemeinsam ihre Gebiete.
8. Welt speichern/neuladen und Gruppen/Einstellungen prüfen. Die normalen Wetterfunktionen kurz gegen 1.1.16 vergleichen.

Die Audioabschnitte enthalten jeweils zwei Sekunden Nutzsignal plus einen kurzen Überlappungsbereich; so lassen sich Startversatz, Betreten der Hörweite und Stopp steuern. WAV-Zwischenstände und die ursprünglichen MP3-Dateien sind nicht im Projekt nötig. `tools/prepare_siren_assets.py` dokumentiert die Aufbereitung der vom Nutzer bereitgestellten Aufnahmen; zum normalen Bauen wird kein ffmpeg benötigt.

## Prüfstatus

Die Sirenen-Zeitsteuerung und die neuen Pegel-/Probeplan-Tests bestehen: Verzögerungen, Einzel-/Gruppen-/Gesamtstopp, manuelle Priorität, 1.440 Uhrzeiten, Pause, Zeitrücksprünge und Gruppenübertragung. Alle 684 Mono-Audioabschnitte, Ressourcenverweise und JSON-Dateien wurden geprüft. Alle 48 Java-Dateien wurden syntaktisch geprüft. Der vollständige Gradle-Build wurde versucht, wird hier jedoch vor der Kompilierung durch HTTP 403 beim Mojang-Download blockiert. Blockregistrierung, Fabric-Netzwerk, Audio und GUI sind daher noch nicht durch einen vollständigen Build/Spielstart bestätigt.

## Änderungen in 1.1.16

- Eine verbundene Wolkenoberfläche ersetzt bei klassischen Superzellen die übereinandergesetzten Hauptwolkenkörper. Sie beginnt am bisherigen Hook-/Wall-Cloud-Bereich und verbindet Aufwindturm und Amboss.
- Der Aufwind liegt seitlich zum Niederschlagskern und neigt sich mit der Höhe in Richtung Höhenwind. Der Amboss breitet sich erst bei entsprechender Entwicklung aus. Kleinere Oberflächenverformungen sorgen für eine unregelmäßige Silhouette.
- Shelf Cloud, Regenfeld, Radar, Sound, Staub und die bestätigte Tornadooptik werden weiterverwendet. LP-/HP-Varianten sind nicht Bestandteil dieses Updates.
- Fehlerprüfung: Konfigurationen werden erst nach vollständigem Schreiben ersetzt. Ungültige Unicode-Einträge werden beim Laden abgefangen. Ungültige Zellkoordinaten werden vor der Erzeugung abgewiesen.

## Spieltest für 1.1.16

1. Mit `BUILD_WINDOWS.bat` bauen und nur `atmosphere-1.1.16.jar` verwenden. Bei Fehlern `build-output.log` sichern.
2. Eine neue manuelle Superzelle erzeugen, eigene Wolken aktivieren. Mit Abstand die gesamte Zelle betrachten: zusammenhängender Aufwindturm, seitlicher Versatz zum Regenkern und geneigter Anschluss zum Amboss.
3. Mit Wettergeschwindigkeit 5x die Entwicklung beobachten; bei einer natürlichen jungen Zelle soll der Amboss anfangs kleiner sein. Manuelle Zellen starten bereits weit entwickelt.
4. Hook, Niederschlag und Radar vergleichen; Shelf Cloud, Tornado und Sound kurz gegen 1.1.15 prüfen.
5. Leicht und Hoch vergleichen und auf FPS achten. Einstellungen ändern, Spiel neu starten und prüfen, ob sie erhalten geblieben sind. Geschwindigkeit anschließend zurückstellen.

Prüfergebnis: 3.750 Zellzustände, 16.000 Wettermodell-Abfragen, die neue Superzellengeometrie und der Erhalt der alten Konfiguration bei simuliertem Schreibfehler bestanden. Alle 36 Java-Quelldateien wurden auf Syntax geprüft. Der vollständige Gradle-Build wurde versucht, scheitert hier aber vor der Kompilierung am HTTP-403-Block beim Mojang-Download. Fabric-APIs, Mixins und Darstellung sind deshalb noch nicht durch einen vollständigen Build/Spielstart bestätigt.

## Änderungen in 1.1.15

- Tornados verwenden wieder die Silhouette, gleichmäßige Rotation und ruhige Schattierung von 1.1.13. Die Spiralbänder und die mit der Höhe unterschiedliche Drehgeschwindigkeit aus 1.1.14 sind entfernt. Sound und bodenabhängiger Staub bleiben erhalten.
- Vor starken Gewittern, Superzellen und Squall Lines erscheint eine zusammenhängende, gebogene Shelf Cloud mit dunkler Unterkante. Ihre Ausdehnung und Form folgen der Entwicklungsstufe der Zelle; niedrige Wolkendetails reduzieren nur die Auflösung.
- Die sichtbare Vorderkante und das Böenmaximum verwenden dieselbe Grenzlinie. Auch manuelle Zellen erzeugen an dieser Grenze Böen, Winddrehung im automatischen Windmodus und einen kurzen Temperaturrückgang. Radar und HUD lesen weiterhin dasselbe Wettermodell.
- Weltstände und Einstellungen bleiben kompatibel. Keine Blockzerstörung und kein Tornadoschaden.

## Wichtigster Spieltest 1.1.15

1. `BUILD_WINDOWS.bat` starten und ausschließlich `atmosphere-1.1.15.jar` mit Fabric API einsetzen. Bei Fehlern `build-output.log` sichern.
2. Eigene Wolken und Windböen einschalten, Windmodus Automatisch und Wettermodus Automatisch wählen. Ein starkes Gewitter oder eine Squall Line manuell erzeugen. Die breite, tiefhängende Shelf Cloud aus einiger Entfernung und beim Durchqueren der Vorderkante betrachten.
3. Unter der Vorderkante Windstärke/-richtung und Temperatur im HUD beobachten. Windböen aus- und einschalten; die zusätzliche Böe muss darauf reagieren. Das Wolkenband soll auch bei Leicht sichtbar bleiben.
4. Neue manuelle Superzelle bei Tornadochance Häufig erzeugen: Der Trichter muss wieder ruhig und geschlossen wie in 1.1.13 aussehen. Sound und Staub sollen erhalten sein.

Prüfung: 3.750 Zellzustände, die Tornado- und Shelf-Geometrie, die manuelle Böenfront sowie 16.000 Wettermodell-Abfragen bestanden. Der vollständige Gradle-Build wurde versucht, scheitert hier aber vor der Kompilierung am HTTP-403-Block beim Mojang-Download. Fabric-Kompilierung und Sichtprüfung im Spiel sind daher noch offen.

## Änderungen in 1.1.14

1. Spiralförmige Kondensationsbänder und feinere Verformungen machen die Rotation der Tornadooberfläche sichtbar. Die Höhenringe bleiben auf ihrer Höhe.
2. Die Staubzone ist breiter und unregelmäßiger. Eigene Partikel kreisen bodennah einwärts und steigen auf. Boden, heller Sand, roter Sand und Schnee ergeben unterschiedliche Farben. Ein globales Partikelbudget begrenzt die Last; Blöcke werden nicht verändert.
3. Der Funnel schließt mit passender Breite an die Wall Cloud an. Rotierende Wolkenfetzen und ein seitliches Inflow-Band ergänzen den Übergang.
4. Der schmale Funnel entwickelt sich zur pro Zelle bestimmten Reifeform. In der Auflösung wird er dünner, schiefer und seilartig.
5. Ein eigener, prozedural erzeugter Tornadoloop wird anhand von Abstand, Breite, Aktivität und Gebäudeschutz geregelt. Unter Sound ist Tornadodröhnen separat einstellbar. Der Loop endet beim Abschalten oder Weltwechsel.
6. Superzellen erhalten einen flacheren, weiter ausladenden Amboss und eine ausgeprägte vordere Regenwand. Die Regenwand prüft das gemeinsame Niederschlagsfeld; die trockenere Hook-Einbuchtung bleibt davon ausgespart.

## Spieltest 1.1.14

- Bauen mit `BUILD_WINDOWS.bat`, nur `atmosphere-1.1.14.jar` verwenden. Bei Fehlern `build-output.log` sichern.
- Eigene Wolken und Partikel einschalten, Tornadochance Häufig, Wettergeschwindigkeit zum Test 5x. Eine neue manuelle Superzelle erzeugen.
- Spiralförmige Bänder, weicheren Anschluss zur Wall Cloud und seitliche Wolkenzufuhr beobachten. Im Verlauf auf Verbreiterung und spätes Ausdünnen achten.
- Auf Boden, Sand und Schnee Staubfarbe und kreisende, aufsteigende Partikel vergleichen. Dazu nahe am Hook bleiben, damit das Gelände geladen ist.
- Tornadodröhnen unter Sound prüfen: Annähern, entfernen, Gebäude betreten, Lautstärke auf 0 und wieder erhöhen. Tornadochance Aus und Weltwechsel müssen den Loop beenden.
- Superzelle aus der Entfernung betrachten: Amboss, Regenwand und trockenere Hook-Zone mit dem Radar vergleichen. Bei Leicht und Hoch auf FPS und Partikelmenge achten.

Neue Assets: `tornado_roar.ogg` wurde aus Rauschsignalen synthetisiert; `vortex_dust.png` verwendet die vorhandene Cloud-Puff-Textur des Projekts. Es wurden keine fremden Soundaufnahmen übernommen.

Prüfstatus: Die Modell- und Geometrietests (einschließlich Formwandel und Sound-Abstandskurve) bestanden. JSON und Audioformat wurden geprüft. Der vollständige Gradle-Build wurde versucht, aber der Download von Mojangs Versionsdatei wurde in der Entwicklungsumgebung mit HTTP 403 blockiert. Kompilierung mit Fabric und Laufzeitverhalten sind daher noch nicht bestätigt.

## Änderungen in 1.1.13

- Ein durchgehendes Tornadomesh ersetzt die gestapelten Wolkenkörper. Die Oberfläche dreht sich horizontal, ohne ihre Höhenringe nach oben zu verschieben. Seil-, Kegel- und Keilformen werden stabil pro Zelle ausgewählt.
- Die Wolkenbasis am Hook hängt als rotierende Wall Cloud nach unten. Der Funnel wächst daran stufenlos bis zur Geländeoberfläche. Die bisherige Wolken-Höhenbegrenzung bei Y=100 gilt für ihn nicht mehr.
- Eine rotierende Staubzone und ein begrenzter Partikelstrom liegen am Boden. Gelände wird nur in geladenen Chunks abgefragt.
- Das Hook Echo beschreibt einen offenen gekrümmten Bogen um eine trockenere Einbuchtung. Radar und Niederschlag nutzen dasselbe Feld.
- Unter starken Zellen werden Himmelsfarbe und Himmelshelligkeit sanft gedämpft. Oberhalb der Wolkenbasis und außerhalb der Zellen klingt der Effekt ab.

## Test für 1.1.13

1. Mit `BUILD_WINDOWS.bat` bauen und nur `atmosphere-1.1.13.jar` einsetzen. Build-Ausgabe bleibt in `build-output.log`.
2. Eigene Wolken einschalten, Tornadochance Häufig und zum Test Wettergeschwindigkeit 5x wählen. Neue manuelle Superzelle erzeugen.
3. Unterhalb der Wolkenbasis auf die abgesenkte Wall Cloud achten. Der Funnel soll daran beginnen, sich horizontal drehen und zum Boden wachsen. Den Hook-Bereich aus der Nähe beobachten, damit das Gelände geladen ist.
4. Bei Bodenkontakt müssen Staubzone und Partikel über dem Gelände erscheinen. Niedrige Wolkendetails dürfen den Tornado nicht ausblenden.
5. Radar auf 500 Blöcke/Hoch: offenen Hook-Bogen und Einbuchtung mit dem Niederschlag im Spiel vergleichen.
6. Zwischen starkem Zellkern und Außenbereich wechseln: Himmel und Landschaft sollen unter der Zelle dunkler sein. Abschließend Chance Aus prüfen und Geschwindigkeit zurückstellen.

Die Wetter- und Geometrietests sind ausführbar; ein vollständiger Fabric-Build und Spieltest bleiben erforderlich.

## Korrekturen in 1.1.12

- Tornadobildung und Auflösung folgen dem Alter der Zelle. Volle Zellstärke schaltet den Tornado nicht länger aus.
- Radar und Darstellung verwenden denselben Lebenszyklus. Manuell erzeugte Zellen erhalten dabei eine einheitliche Zeitphase.
- Niedrige Wolkendetails reduzieren die Tornadogeometrie, statt den Tornado zu entfernen.
- Modellprüfung erfolgreich: 3.750 Zellzustände sowie zusätzliche Tests für die reife Phase, Abschaltung und Auflösung. Vollständiger Fabric-Build und Spielstart bleiben ungeprüft.

## Test für 1.1.12

1. Mit `BUILD_WINDOWS.bat` bauen, nur `atmosphere-1.1.12.jar` verwenden.
2. Eigene Wolken einschalten, Tornadochance auf Häufig und Wetter-Zeitskalierung zum Test auf 5x stellen. Eine neue manuelle Superzelle erzeugen und ihren Hook-Bereich aus der Nähe beobachten (Gelände muss geladen sein).
3. Trichterbildung, Bodenkontakt und eine anhaltende Reifephase beobachten. Danach Wolkendetails auf Leicht stellen: Der Tornado soll weiterhin sichtbar bleiben.
4. Tornadochance auf Aus stellen: Der Tornado muss verschwinden. Zum Abschluss die Wetter-Zeitskalierung wieder zurückstellen.

## Build-Korrektur für 1.1.11

- Fehlenden lokalen MinecraftClient in der Tornado-Renderfunktion ergänzt. Der Zugriff auf `client.world` war zuvor ein Kompilierfehler.
- Das Windows-Buildskript wartet nun korrekt auf Gradle und speichert dessen vollständige Ausgabe in `build-output.log`.
- Gradles Fortschritt wird gleichzeitig im Fenster angezeigt. Fehlt der eingetragene Gradle-Pfad, erscheint sofort eine verständliche Meldung.
- Modellprüfung tatsächlich ausgeführt: 3.750 deterministische Zellzustände sowie Hook- und Tornadobedingungen bestanden. Vollständiger Fabric-Build und Spielstart noch nicht verifiziert.

## Was in 1.1.11 geändert wurde

- Das Hook Echo krümmt sich um eine niederschlagsarme Einbuchtung und entwickelt sich erst mit der Superzelle. Manuelle und natürliche Superzellen nutzen dasselbe Regenprofil.
- Tornados sind ausschließlich an reife Superzellen mit Hook Echo gebunden. Auf der Grafikseite lässt sich die Chance auf Aus, Selten, Normal oder Häufig stellen. Standard ist Selten.
- Der Tornado sitzt unter der Wall Cloud, wächst bei geladenem Gelände bis zum Boden und bekommt eine Staubzone. Er bleibt ein visueller Effekt ohne Blockschaden oder Kräfte auf Wesen.
- Das Radar verwendet eine kontrastreichere Farbskala, markiert aktive Tornados und scannt bei hoher Auflösung mehr Zeilen pro Frame. Entfernte Wetterzellen werden früher aus der Modellberechnung ausgeschlossen.

## Spieltest

1. `BUILD_WINDOWS.bat` starten und nur die neue `atmosphere-1.1.11.jar` zusammen mit Fabric API in `mods` legen.
2. Eine manuelle Superzelle erzeugen, Radar auf 500 Blöcke und Hoch stellen. Auf gekrümmten Haken und trockene Einbuchtung achten. Regen an beiden Orten mit HUD und Partikeln vergleichen.
3. Tornadochance auf Aus: Auch bei reifem Hook Echo darf kein Tornado erscheinen. Danach auf Häufig stellen und eine reife Superzelle beobachten. Der Tornado soll am Hook Echo bis zum Boden reichen.
4. Ladezeit des Radars bei Hoch vergleichen; außerdem auf Ruckler, Weltneustart und `latest.log` achten.

## Was in 1.1.10 geändert wurde

- Manuell erzeugte Superzellen nutzen jetzt dasselbe Regenprofil wie natürliche Zellen statt eines kreisförmigen Gaußfelds.
- Der Schirm ist asymmetrischer; ein schmalerer, gebogener Haken umschließt eine trockenere Einbuchtung.
- Die Ausrichtung ist stabil und wird für die manuelle Wolke und das Regenfeld gemeinsam verwendet. Bestehende gespeicherte Wetterzellen bleiben kompatibel.
- Radar und Niederschlag im Spiel werden weiterhin aus demselben Wettermodell berechnet.

## Wichtigster Spieltest

Eine Superzelle manuell erzeugen, Radar auf 500 Blöcke stellen und den versetzten starken Kern, den Haken und die trockene Einbuchtung vergleichen. Danach zum Kern und zur Einbuchtung laufen: HUD-Regen und sichtbare Partikel müssen zur Radarfarbe passen. Auch nach einem Weltneustart prüfen.

## Was in 1.1.9 geändert wurde

- Superzellen erhalten einen breiten Regenschirm, einen kompakten Starkregenkern, einen gekrümmten Haken und eine trockenere Einbuchtung.
- Schauer können Nebenkerne bilden; Squall Lines besitzen gebogene, unterschiedlich starke Abschnitte.
- Radar, Niederschlagspartikel und Wetteranzeige verwenden dasselbe lokale Regenfeld. Der Radar-Cache wird alle 100 statt 600 Ticks erneuert.
- An starken Böenfronten dreht der Wind aus der Zelle heraus; geeignete intensive Superzellenkerne können Hagel erzeugen.
- Bestehende Welten und Einstellungen bleiben lesbar. Die Wettereffekte ändern keine Blöcke und verursachen keinen Blitzschaden.

## Test im Spiel

1. Mit `BUILD_WINDOWS.bat` bauen und nur `atmosphere-1.1.11.jar` zusammen mit Fabric API in `mods` legen.
2. Eine Superzelle auslösen oder im Radar suchen. Starkregenkern, Haken und trockenere Einbuchtung beobachten.
3. Im Radar einen Punkt am Kern und einen Punkt in der Einbuchtung wählen und die jeweilige Niederschlagsstärke im HUD/Spiel vergleichen.
4. Bei einer heranziehenden starken Zelle Windrichtung, Böen und möglichen Hagel beobachten.
5. Welt neu laden und auf stabiles Zellmuster sowie Fehler in `latest.log` prüfen.

## Was in 1.1.8 geändert wurde

- Starke Gewitterzellen haben jetzt eine räumlich begrenzte Böenfront vor dem Kern. Sie wächst erst während der Reifephase und nutzt die vorhandene Windböen-Einstellung.
- Der Niederschlagskern liegt leicht hinter dem Aufwind. Wolken, Regen und Wind treffen deshalb nicht mehr exakt am selben Ort zusammen.
- Das Regenfeld bleibt Teil des gemeinsamen Modells und erscheint dadurch auch auf dem Radar.
- Zellen erhalten gebogene, ungleichmäßige Regenbänder mit Lücken und Nebenbereichen; Squall Lines sind abschnittsweise unterbrochen. Die Muster sind räumlich glatt und pro Zelle stabil.
- Der eigenständige Gewitter-Smoke-Test prüft nun die Grenzen des neuen Böenfelds.

Diese Version verändert keine Blöcke und erzeugt keine schädigenden Blitz-Entities. Ein echter Fabric-Build und Test im Spiel bleiben erforderlich.

## Was in 1.1.7 geändert wurde

### Regenbogen sichtbar gemacht (Fehler aus 1.1.6)

Der Bogen wurde in 1.1.6 berechnet, aber nie gezeichnet. Drei Ursachen:

1. **Falsche Matrix:** `renderSky` baut seine eigenen Matrizen aus der Projektionsmatrix. Ein frisches `new MatrixStack()` erzeugte Vertices weit außerhalb des Frustums – der Bogen wurde emittiert und dann weggecullt. Jetzt wird die Identitätsmatrix benutzt, weil `RenderLayer.getEntityTranslucent` die View-Rotation ohnehin selbst anwendet.
2. **Puffer nie geflusht:** `VertexConsumerProvider.Immediate.draw()` fehlte – der Batch verfiel am Frameende.
3. **Schwellen zu streng:** Regen unter 1,2 mm/h ergab 0, und 75 % Bewölkung (normal bei Regen!) drückte die Sichtbarkeit auf 0,45. Jetzt: Regen ab 0,5 mm/h, Bewölkung dämpft statt auszuschalten, Mindestklarheit 0,22.

Zusätzlich: Bänder **heller** (Alpha 0,88 statt 0,62), **breiter** (2,6° statt 1,9°) und der Bogen weiter weg (340 statt 220 Blöcke), damit er nicht hinter Gelände verschwindet.

### Wolken: Variante 1 + 2

- **Variante 1 – Flächennormale:** Helligkeit wird jetzt **pro Quad** aus der tatsächlichen Flächennormale der drei verschobenen Eckpunkte berechnet, nicht mehr pro Vertex aus der glatten Kugelnormale. Das beseitigt die harten, kastenförmigen Facetten aus 1.1.6.
- **Variante 2 – Selbstschattierung:** Ein Beer-Lambert-artiger Test läuft in drei Schritten von jedem Quad in Richtung Sonne durch das Ellipsoid. Punkte, deren Pfad im Inneren bleibt, werden verdunkelt (`occlusion`, gedeckelt auf 0,85). Ergebnis: echte Unterseite statt flacher Fläche.
- Helligkeitsbereich gemessen: **0,20 bis 0,96** über 126 Test-Quads – sichtbarer Verlauf, keine Ausreißer.
- Die Sonnenrichtung folgt jetzt dem Tageszyklus (`RENDER_SUN_AZIMUTH`), nicht mehr einer festen Konstante.

### Test-Infrastruktur

- `tools/stubs` enthält jetzt `VertexConsumer`, `OverlayTexture`, `MatrixStack` und `Vec3d`, damit `Rainbow.java` (Mathematik **und** Geometrie) ohne Fabric kompiliert und getestet werden kann. Der Fehler aus 1.1.6 wäre damit sofort aufgefallen.
- `RainbowMathTest` um zwei Fälle erweitert: leichter Regen unter normaler Bewölkung muss sichtbar sein, und stärkerer Regen darf den Bogen nicht schwächen.

## Was in 1.1.6 geändert wurde

- **Nebel zähmen:** Die Sichtweite war bei normalem Regen auf ~60 Blöcke zusammengefallen (`195 − 166·combined`), bei Starkregen auf 29. Neue Kurve `320 − 190·combined`: bei mittlerem Regen **~206 Blöcke**, der Horizont bleibt lesbar. Regennebel setzt erst ab 25 mm/h ein (vorher 12) und die Mindest-Sichtweite liegt bei 48 statt 12 Blöcken.
- **Wolkenschatten dunkeln jetzt ab:** Die Bodenschatten erschienen als helle Rechtecke, weil eine weiße Textur mit dunklem Tint über helles Gras geblendet wurde. `cloud_shadow.png` ist jetzt eine **schwarze Alpha-Maske** mit weichem Wolkenrand, gerendert über `getEntityTranslucentCull` – Blending kann damit nur abdunkeln. Weniger Schatten (12 statt 18), dafür sichtbar.
- **Regen fällt sichtbar:** Lebensdauer 30 → 22 Ticks, Schwerkraft 0,55 → 1,15, Fallgeschwindigkeit −0,48 → −0,85 (−1,25 bei Starkregen), Streifen länger (0,17–0,36 statt 0,10–0,26). Tropfen schweben nicht mehr.
- **Regenbogen (neu):** Prozeduraler Bogen aus farbigen Vertices, kein Asset, keine Weltinteraktion. Primärbogen bei 42°, sekundärer bei 51° mit umgekehrter Farbfolge. Erscheint nur bei Sonnenhöhe 3–52°, Regen über 1,2 mm/h und nicht vollständig bedecktem Himmel. Schalter im Menü unter **Grafik → Regenbogen**.
- **Neuer Test:** `tools/RainbowMathTest.java` prüft Sonnenhöhe, Sichtbarkeitsfenster (Nacht/Hohersonne/Trockenheit/Bedeckung), Monotonie im Regen, Farbtabellen und Alpha-Grenzen.

### Technische Notiz zum Regenbogen

Der Bogen wird in `mixin/RainbowRendererMixin.java` am Ende von `WorldRenderer.renderSky` gezeichnet, also im **eigenen** Vertex-Buffer des Renderers. Das ist bewusst so: ein RenderLayer aus einem fremden Event-Handler anzufordern kann außerhalb des Render-Threads werfen.

## Was in 1.1.5 geändert wurde

- **Nasse Fläche statt Dauer-Trockenheit:** Über 20.000 × 20.000 Blöcke waren in 1.1.4 nur **7,3 %** der Fläche nass, an einzelnen Tagen unter 5 %. Frontregen greift jetzt früher (`pow(front, 1.45)` statt `1.65`) und die Regenuntergrenze liegt bei −0,4 statt −1,6 mm/h. Ergebnis: **11–17 % nasse Fläche**, Spitzenregen unverändert begrenzt (Messung: max. 72 mm/h, Modellgrenze 150).
- **Jahreszeiten stimmen jetzt mit der Temperatur überein:** Tag 0 war vorher mitten im Winter (−1,2 °C), obwohl „Frühling" angezeigt wurde. Die Jahreskurve ist um +0,15 verschoben, das Saison-Label folgt derselben Phase. Tag 0 ist jetzt mild (18,2 °C), Sommer nie unter 18,9 °C, Winter nie über 7,4 °C.
- **Wolkenschatten sehen wie Wolken aus:** `cloud_shadow.png` war eine vollflächig weiße Kachel – die Bodenschatten erschienen als Rechtecke. Neu: 128×128-Textur mit 4 Oktaven Wertrauschen und weichem Alpha-Rand. Zusätzlich ein Quad pro Wolke statt eines 4×4-Rasters, max. 12 statt 18 Schatten, dunklerer Blaugrau-Tint (12/18/28).
- **Regenpartikel neu:** `rain_streak.png` war eine 2-Pixel-Linie. Neu: 16×32-Streifen mit transparentem Kopf, Tropfenkopf unten und weichem Alpha-Rand. Partikel schlanker (0,10–0,26 statt 0,14–0,39), Alpha 0,74 statt 0,87, kühlere Farbe. Spritzer häufiger (jeder 7. statt 12. Treffer).
- **Sound-Streaming korrigiert:** Alle 34 Clips waren mit `stream: true` markiert, obwohl sie nur 6 Sekunden lang sind. Streaming kostet dort nur I/O und Thread-Zeit; jetzt `stream: false`.
- **HUD zeigt die richtige Version:** Die Wetteranzeige behauptete weiterhin „ATMOSPHERE 1.1.3".
- **Neuer Regressionstest:** `tools/WetAreaAndSeasonTest.java` prüft nasse Fläche (9–30 %), Regenobergrenze, Saison-Label gegen Temperatur und den Tag-0-Start.

## Was in 1.1.4 geändert wurde

- **Hochdruck 0–200 % und Tiefdruck 0–200 % separat:** Die Stärke wirkt auf das gemeinsame synoptische Druckfeld sowie Hoch-/Tief-Einfluss, Fronten und rotierenden Wind. Dadurch wirken die Einstellungen auf Niederschlag, Wolken und Radar, statt nur die Regenwahrscheinlichkeit zu verändern. **100 % ist das alte Verhalten aus 1.1.3.**
- **Lebensdauer Kurz / Normal / Lang:** Natürlich erzeugte Druckgebiete halten ungefähr 70 %, 100 % oder 155 % der bisherigen Dauer. Nicht die Minecraft-Tageslänge oder die bereits manuell gesetzten Hochs und Tiefs werden verändert.
- **Blitzhelligkeit 25–200 % / Blitzgröße 25–200 %:** Getrennt von der bestehenden Blitzhäufigkeit. Optische Lichtimpulse sind begrenzt; keine echten Feuer-/Schadensblitze.
- **Donnerlautstärke 0–200 %** unabhängig von der Blitzhäufigkeit; Ausgabewerte begrenzt.
- **Windton 0–100 % (Standard 40 %):** Eine sanfte Brise ist bereits ab etwa 2 km/h hörbar; Lautstärke blendet weich ein und wächst mit der Windgeschwindigkeit. Es werden bestehende Audio-Clips einschließlich `wind.ogg`, `wind_light.ogg`, `wind_base.ogg`, `snow_wind.ogg` und der stärkeren Böen-Clips situationsabhängig genutzt. Die vorhandenen 34 Audioclips bleiben erhalten, werden **nicht** gleichzeitig abgespielt.
- **Menü:** Neue Seite **Druck** mit Hoch/Tief-Stärke, Lebensdauer und bisherigen Druck-/Gewittersteuerungen. Auf **Sound**: Blitz-Helligkeit, Blitz-Größe, Donner- und Wind-Lautstärke. Wetterradar verwirft zwischengespeicherte Druckfelder, wenn diese Einstellungen verändert werden.
- **Vorhandenes unverändert:** Watteartige Cloud Engine 7.0, stabile Wolken, Radar, Fronten, Schneeakkumulation, Sounddateien, Gewitter-Soundkulisse, sichere Funnel Clouds, Grafikprofile, manuelle Wetterfunktionen.

### Bedienung und Werte

Alle neuen Regler sind zyklische Schaltflächen im Atmosphere-Menü. Ein Klick erhöht den Wert (je 25 Prozentpunkte bei Druck, Blitz und Donner; Wind je 10); am Höchstwert beginnt die Einstellung wieder beim Mindestwert. Die Werte werden unter `config/atmosphere.properties` gespeichert, ältere Dateien bleiben kompatibel. **Standardwerte:** Hoch 100 %, Tief 100 %, Dauer Normal, Blitz-Helligkeit 100 %, Blitzgröße 100 %, Donner 100 %, Windton 40 %.

**Tipp:** Für kräftige, aber plausible Wetterlagen: Hoch 125 %, Tief 150 %, Dauer Lang; Blitzhelligkeit 125 %, Größe 125 %, Windton 50 %. Extreme Einstellungen wie 200 % können deutlich mehr Niederschlag/kräftigere Winde erzeugen. Änderungen betreffen clientseitige Einzelspieler-Wetterberechnungen, nicht Server mit synchronisiertem globalem Wetter.

## Bauen unter Windows

1. ZIP entpacken und Eingabeaufforderung im Ordner `atmosphere-java-1.2.5` öffnen.
2. Java 21 installieren (die Fabric-/Minecraft-Abhängigkeiten lädt Gradle beim ersten Build selbst).
3. Bauen – entweder per Doppelklick auf `BUILD_WINDOWS.bat` oder im Terminal:

   ```bat
   gradle clean build
   ```

   Der Pfad in `BUILD_WINDOWS.bat` muss auf die eigene Gradle-Installation zeigen.

4. Die fertige Mod liegt bei erfolgreichem Build unter `build\libs\atmosphere-1.2.5.jar`. Lege nur **eine** Atmosphere-JAR in `mods/`, zusammen mit Fabric API. Erstelle vor dem ersten Spielstart ein Backup deiner Welt.

## Entwicklungsprüfung und Einschränkungen

Die mitgelieferten `tools/` sind eigenständige Java-Tests für die Wettermodelle; die Minecraft-/Fabric-API und das tatsächliche Audio-Rendering können nur mit vollständigem Fabric-Build bzw. im Spiel getestet werden. Ein regulärer Minecraft-Start kann in dieser Umgebung nicht garantiert werden. Die neuen Schalter wurden so angelegt, dass die bisherigen 1.1.3-Standardeinstellungen (bis auf den bereits bei wenig Wind hörbaren Windton) erhalten bleiben.

Alle Tests laufen ohne Minecraft. Kurzbefehl (Java 21, aus dem Projektordner):

```bat
javac -d build-test -encoding UTF-8 tools/stubs/**/*.java src/main/java/dev/atmosphere/{WeatherModel,WeatherTuning,WeatherCells,SoftCloudMath,StormEvolution,CloudField,SynopticSystems,SnowRates}.java
javac -cp build-test -d build-test -encoding UTF-8 tools/*.java
java -cp build-test WetAreaAndSeasonTest
java -cp build-test RainbowMathTest
```

**Empfohlener Funktionstest:** Erst mit normalen Druckeinstellungen starten, dann ein Hoch und Tief mit 150 % vergleichen, Radar schließen und neu öffnen, Windton bei 5–15 km/h mit manuellem Wind testen, Blitzgröße/Helligkeit und Donner getrennt einstellen. Bei Fehlern die erste `error:`-Meldung aus dem Build oder die `latest.log` mitschicken.
