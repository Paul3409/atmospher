package dev.atmosphere;

/** Closed cloud surface: flat underside, coherent multi-scale upper billows.
 * Shape is independent of quality/camera; quality changes only tessellation. */
public final class CloudGeometry {
    private CloudGeometry(){}
    public record Point(double x,double y,double z,double nx,double ny,double nz){}
    private record Position(double x,double y,double z){}
    private record MeshKey(long seed,int sides,int levels,boolean layer){}
    private static final java.util.Map<MeshKey,Point[][]> SHAPES=new java.util.LinkedHashMap<>(512,.75f,true){
        @Override protected boolean removeEldestEntry(java.util.Map.Entry<MeshKey,Point[][]> e){return size()>512;}
    };
    public static synchronized Point[][] unitMesh(long seed,int sides,int levels,boolean layer){
        MeshKey key=new MeshKey(seed,sides,levels,layer);Point[][] mesh=SHAPES.get(key);
        if(mesh==null){
            mesh=new Point[levels+1][sides+1];
            for(int j=0;j<=levels;j++)for(int i=0;i<=sides;i++)
                mesh[j][i]=point(seed,j*Math.PI/levels,i*Math.PI*2/sides,1,1,1,0,0,0,layer?1:0);
            SHAPES.put(key,mesh);
        }
        return mesh;
    }
    private static Position position(long seed,double p,double a,double width,double depth,
                                     double height,double base,double wx,double wz,double layered){
        double c=Math.cos(p),s=Math.sin(p),nx=s*Math.cos(a),nz=s*Math.sin(a);
        double top=WeatherCells.smooth(-.18,.55,c);
        double noise=CloudNoise.billow(nx,c,nz,seed);
        double billow=1+noise*(1-.58*layered)*(.70+.30*top);
        double r=s*billow;
        double vertical=c>=0?.25+.75*c:.25*Math.pow(1+c,3);
        vertical=WeatherCells.clamp(vertical*(1+noise*.65*s*s*top*(1-.75*layered))
                +.025*s*s*s*s*(1-top)*(noise+.5),0,1);
        double y=base+height*vertical;
        double lean=height*.16*vertical*vertical;
        return new Position(width*r*Math.cos(a)+wx*lean,y,depth*r*Math.sin(a)+wz*lean);
    }
    /** Transform cached unit meshes; no expensive 3-D noise during rescaling. */
    public static Point transform(Point a,Point b,double layer,double width,double depth,double height,
                                  double base,double wx,double wz){
        double x=a.x+(b.x-a.x)*layer,y=a.y+(b.y-a.y)*layer,z=a.z+(b.z-a.z)*layer;
        double nx=(a.nx+(b.nx-a.nx)*layer)/Math.max(.001,width);
        double nz=(a.nz+(b.nz-a.nz)*layer)/Math.max(.001,depth);
        double ny=(a.ny+(b.ny-a.ny)*layer)/Math.max(.001,height)-.32*y*(wx*nx+wz*nz);
        double n=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));
        double lean=height*.16*y*y;
        return new Point(x*width+wx*lean,base+y*height,z*depth+wz*lean,nx/n,ny/n,nz/n);
    }
    public static Point point(long seed,double polar,double angle,double width,double depth,
                               double height,double base,double wx,double wz,double layered){
        Position v=position(seed,polar,angle,width,depth,height,base,wx,wz,layered);
        if(polar<1e-6||polar>Math.PI-1e-6)
            return new Point(v.x,v.y,v.z,0,polar<1?1:-1,0);
        double e=.009;
        Position p=position(seed,polar+e,angle,width,depth,height,base,wx,wz,layered);
        Position a=position(seed,polar,angle+e,width,depth,height,base,wx,wz,layered);
        double px=p.x-v.x,py=p.y-v.y,pz=p.z-v.z;
        double ax=a.x-v.x,ay=a.y-v.y,az=a.z-v.z;
        double nx=pz*ay-py*az,ny=px*az-pz*ax,nz=py*ax-px*ay;
        double n=Math.max(1e-12,Math.sqrt(nx*nx+ny*ny+nz*nz));
        return new Point(v.x,v.y,v.z,nx/n,ny/n,nz/n);
    }
}
