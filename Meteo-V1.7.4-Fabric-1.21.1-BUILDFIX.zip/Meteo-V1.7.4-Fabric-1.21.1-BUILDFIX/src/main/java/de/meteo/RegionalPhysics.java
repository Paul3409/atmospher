package de.meteo;
/** Bounded, explicitly stepped mesoscale prototype. Not a Navier-Stokes solver. */
public final class RegionalPhysics {
    private RegionalPhysics() {}
    public static final int N=11;
    public static final double DX=256.0, DT_MAX=6.0;
    public static final class Grid {
        public final double[][] t=new double[N][N], q=new double[N][N], p=new double[N][N];
        public final double[][] u=new double[N][N], v=new double[N][N], baseline=new double[N][N], baselineQ=new double[N][N];
        public double originX,originZ;
        public long steps;
        public double seconds;
    }
    public static double clamp(double x,double lo,double hi){return Math.max(lo,Math.min(hi,x));}
    private static int wrap(int n){return Math.floorMod(n,N);}
    private static double at(double[][] a,int x,int z){return a[wrap(x)][wrap(z)];}
    /** First-order signed donor transport + symmetric mixing. CFL < 1 for |u|+|v| < 42.7 m/s. */
    private static double scalar(double[][] a,int x,int z,double u,double v,double dt){
        double h=at(a,x,z);
        double ux=u>=0?at(a,x-1,z):at(a,x+1,z);
        double vz=v>=0?at(a,x,z-1):at(a,x,z+1);
        double adv=dt/DX*(Math.abs(u)*(h-ux)+Math.abs(v)*(h-vz));
        double lap=at(a,x-1,z)+at(a,x+1,z)+at(a,x,z-1)+at(a,x,z+1)-4*h;
        return h-adv+0.008*dt/6.0*lap;
    }
    public static void step(Grid g,double dt){step(g,dt,WeatherDynamics.DEFAULT);}
    public static void step(Grid g,double dt,WeatherDynamics.Settings settings){
        if(!(dt>0 && dt<=DT_MAX))throw new IllegalArgumentException("dt must be 0..6 seconds");
        var weather=WeatherDynamics.at(g.seconds,g.originX+N*DX/2,g.originZ+N*DX/2,settings);
        double[][] nt=new double[N][N],nq=new double[N][N],np=new double[N][N],nu=new double[N][N],nv=new double[N][N];
        for(int x=0;x<N;x++)for(int z=0;z<N;z++){
            double u=g.u[x][z],v=g.v[x][z];
            // Temperatures and humidity evolve via bounded transport and slow environmental exchange.
            nt[x][z]=scalar(g.t,x,z,u,v,dt)+dt*(g.baseline[x][z]+weather.temperatureOffset()-g.t[x][z])/9000.0;
            nq[x][z]=Math.max(0,scalar(g.q,x,z,u,v,dt)+dt*(g.baselineQ[x][z]*weather.humidityFactor()-g.q[x][z])/6200.0);
            // Pressure is a slowly transported regional perturbation, not a feedback amplifier.
            np[x][z]=scalar(g.p,x,z,u,v,dt)+dt*(weather.pressure()-g.p[x][z])/8500.0;
            // Diagnostic pressure-gradient wind with finite response time and friction.
            double px=(at(g.p,x+1,z)-at(g.p,x-1,z))/(2*DX);
            double pz=(at(g.p,x,z+1)-at(g.p,x,z-1))/(2*DX);
            double targetU=weather.targetU()-350.0*px, targetV=weather.targetV()-350.0*pz;
            nu[x][z]=clamp(u+dt*(targetU-u)/1800.0,-18,18);
            nv[x][z]=clamp(v+dt*(targetV-v)/1800.0,-18,18);
        }
        for(int x=0;x<N;x++)for(int z=0;z<N;z++){
            g.t[x][z]=nt[x][z];g.q[x][z]=nq[x][z];g.p[x][z]=np[x][z];
            g.u[x][z]=nu[x][z];g.v[x][z]=nv[x][z];
        }
        g.steps++;g.seconds+=dt;
    }
}
