package dev.atmosphere.siren;
import net.minecraft.sound.SoundEvent;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
public final class SirenSounds {
    public static final SoundEvent[][][] EVENTS=new SoundEvent[4][][];
    private SirenSounds(){}
    public static void register(){for(var p:SirenProgram.values()){
        EVENTS[p.ordinal()]=new SoundEvent[2][p.segments];for(int muffled=0;muffled<2;muffled++)for(int i=0;i<p.segments;i++){
            var id=Identifier.of("atmosphere",String.format(java.util.Locale.ROOT,"siren_%s_%s%02d",p.asset,muffled==1?"m_":"",i));
            EVENTS[p.ordinal()][muffled][i]=Registry.register(Registries.SOUND_EVENT,id,SoundEvent.of(id));
        }
    }}
}
