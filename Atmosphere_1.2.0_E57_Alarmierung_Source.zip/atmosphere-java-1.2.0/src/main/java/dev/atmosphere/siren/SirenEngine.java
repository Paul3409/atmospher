package dev.atmosphere.siren;

import java.util.*;

/** Pure scheduling and grouping; clocks use server world ticks, never wall-clock timers. */
public final class SirenEngine {
    public static final int LIMIT=128;
    public static final class Node {
        public final long pos; public final boolean controller;
        public String group="Ort"; public int radius=512,volume=80,delay=0,selected=0;
        public long start=-1; public int playing=0; public boolean lastStart,lastStop,automatic;
        public Node(long pos,boolean controller){this.pos=pos;this.controller=controller;}
        public boolean active(long now){return !controller&&start>=0&&now<start+SirenProgram.of(playing).ticks+80;}
    }
    public static final class Group {
        public boolean enabled,paused,warned,autoClear=true; public int hazards=7;
        public long manualUntil,quietSince=-1,nextWarning;
    }
    public final Map<Long,Node> nodes=new LinkedHashMap<>();
    public final Map<String,Group> groups=new LinkedHashMap<>();
    public static String groupName(String name){
        String s=name.strip();if(!s.matches("[\\p{L}\\p{N}_ -]{1,24}"))throw new IllegalArgumentException("Gruppenname: 1–24 Buchstaben/Ziffern");return s;
    }
    public Group group(String name){return groups.computeIfAbsent(name,k->new Group());}
    public Node add(long pos,boolean controller){
        if(nodes.containsKey(pos))return nodes.get(pos);
        if(nodes.size()>=LIMIT)throw new IllegalArgumentException("Maximal 128 Sirenen/Bedienstellen");
        Node n=new Node(pos,controller);nodes.put(pos,n);group(n.group);return n;
    }
    public int start(String group,Long only,int signal,long now,boolean automatic){
        int count=0;for(Node n:nodes.values())if(!n.controller&&(only!=null?n.pos==only:group==null||n.group.equals(group))){
            n.playing=SirenProgram.of(signal).ordinal();n.start=now+n.delay;n.automatic=automatic;count++;
            if(!automatic)group(n.group).manualUntil=now+n.delay+SirenProgram.of(signal).ticks+2400;
        }return count;
    }
    public int stop(String group,Long only,long now,boolean manual){
        int count=0;for(Node n:nodes.values())if(!n.controller&&(only!=null?n.pos==only:group==null||n.group.equals(group))){
            if(n.start>=0)count++;n.start=-1;if(manual)group(n.group).manualUntil=now+2400;
        }return count;
    }
    public boolean expire(long now){boolean changed=false;for(Node n:nodes.values())if(n.start>=0&&!n.active(now)){
        n.start=-1;changed=true;}return changed;}
    public boolean weather(String group,boolean danger,long now){
        Group g=group(group);if(!g.enabled||g.paused||now<g.manualUntil)return false;
        if(danger){g.quietSince=-1;if(now>=g.nextWarning){
            start(group,null,SirenProgram.WARNING.ordinal(),now,true);g.warned=true;g.nextWarning=now+6000;return true;
        }}else if(g.warned){
            if(g.quietSince<0)g.quietSince=now;
            if(now-g.quietSince>=1800){if(g.autoClear)start(group,null,SirenProgram.CLEAR.ordinal(),now,true);g.warned=false;g.quietSince=-1;return true;}
        }return false;
    }
}
