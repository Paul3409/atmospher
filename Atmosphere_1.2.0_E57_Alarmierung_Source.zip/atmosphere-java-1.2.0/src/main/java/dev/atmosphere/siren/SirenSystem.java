package dev.atmosphere.siren;

import com.google.gson.*;
import net.fabricmc.fabric.api.networking.v1.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.*;

public final class SirenSystem {
    private SirenSystem(){}
    public static void register(){
        SirenBlocks.register();SirenSounds.register();
        PayloadTypeRegistry.playC2S().register(SirenPayloads.Request.ID,SirenPayloads.Request.CODEC);
        PayloadTypeRegistry.playS2C().register(SirenPayloads.Status.ID,SirenPayloads.Status.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SirenPayloads.Request.ID,(payload,context)->{
            if(payload.json().length()>4096)return;
            context.server().execute(()->request(context.player(),payload.json()));
        });
        ServerTickEvents.END_WORLD_TICK.register(SirenSystem::tick);
    }
    public static SirenEngine.Node add(ServerWorld world,BlockPos pos,boolean controller){
        var state=SirenWorldState.of(world);try{var n=state.engine.add(pos.asLong(),controller);state.markDirty();return n;}
        catch(IllegalArgumentException ex){return null;}
    }
    public static void open(ServerWorld world,BlockPos pos,ServerPlayerEntity player,boolean controller){
        var n=add(world,pos,controller);if(n==null){player.sendMessage(Text.literal("Maximal 128 Sirenen/Bedienstellen"),false);return;}
        status(player,n,true,"Nordseite: Redstone-Stopp; übrige Seiten: Start");
    }
    private static void send(ServerPlayerEntity player,JsonObject json){
        if(ServerPlayNetworking.canSend(player,SirenPayloads.Status.ID))ServerPlayNetworking.send(player,new SirenPayloads.Status(json.toString()));
    }
    private static void status(ServerPlayerEntity player,SirenEngine.Node n,boolean open,String message){
        var engine=SirenWorldState.of(player.getServerWorld()).engine;var g=engine.group(n.group);
        var b=new JsonObject();b.addProperty("type","screen");b.addProperty("open",open);b.addProperty("pos",n.pos);
        b.addProperty("controller",n.controller);b.addProperty("group",n.group);b.addProperty("signal",n.selected);
        b.addProperty("radius",n.radius);b.addProperty("volume",n.volume);b.addProperty("delay",n.delay);
        b.addProperty("auto",g.enabled);b.addProperty("paused",g.paused);b.addProperty("hazards",g.hazards);b.addProperty("message",message);
        b.addProperty("clear",g.autoClear);
        var names=new JsonArray();engine.groups.keySet().forEach(names::add);b.add("groups",names);send(player,b);
    }
    private static int integer(JsonObject b,String name,int lo,int hi){return Math.max(lo,Math.min(hi,b.get(name).getAsInt()));}
    private static void request(ServerPlayerEntity player,String json){
        try{
            var b=JsonParser.parseString(json).getAsJsonObject();var pos=BlockPos.fromLong(b.get("pos").getAsLong());
            var world=player.getServerWorld();
            if(player.squaredDistanceTo(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5)>64||!world.isChunkLoaded(pos))return;
            var block=world.getBlockState(pos).getBlock();if(block!=SirenBlocks.SIREN&&block!=SirenBlocks.CONTROL)return;
            var state=SirenWorldState.of(world);var engine=state.engine;
            var n=engine.add(pos.asLong(),block==SirenBlocks.CONTROL);
            String action=b.get("action").getAsString();long now=world.getTime();
            // Stop actions work independently of unsaved/invalid text fields.
            if(action.equals("stop_all")){engine.stop(null,null,now,true);state.markDirty();status(player,n,false,"Alle Signale und wartenden Starts gestoppt");return;}
            if(action.equals("stop_group")){engine.stop(n.group,null,now,true);state.markDirty();status(player,n,false,"Gruppe gestoppt");return;}
            if(action.equals("stop_single")){engine.stop(n.controller?n.group:null,n.controller?null:n.pos,now,true);state.markDirty();status(player,n,false,"Gestoppt");return;}
            String group=SirenEngine.groupName(b.get("group").getAsString());
            if(!engine.groups.containsKey(group)&&engine.groups.size()>=128)throw new IllegalArgumentException("Zu viele Gruppen");
            n.group=group;n.selected=integer(b,"signal",0,3);n.radius=integer(b,"radius",64,1024);
            n.volume=integer(b,"volume",0,100);n.delay=integer(b,"delay",0,60);
            var g=engine.group(group);g.enabled=b.get("auto").getAsBoolean();g.paused=b.get("paused").getAsBoolean();g.hazards=integer(b,"hazards",0,7);
            g.autoClear=b.get("clear").getAsBoolean();
            String message="Gespeichert";
            if(action.equals("start_group"))message=engine.start(n.group,null,n.selected,now,false)+" Sirenen starten";
            if(action.equals("start_single"))message=engine.start(null,n.controller?null:n.pos,n.selected,now,false)+" Sirenen starten";
            state.markDirty();status(player,n,false,message);
        }catch(RuntimeException ex){player.sendMessage(Text.literal("Sirenenaktion ungültig: "+ex.getMessage()),false);}
    }
    private static void tick(ServerWorld world){
        long now=world.getTime();if(now%5!=0)return;
        var state=SirenWorldState.of(world);var engine=state.engine;boolean changed=engine.expire(now);
        var iterator=engine.nodes.values().iterator();
        while(iterator.hasNext()){
            var n=iterator.next();var pos=BlockPos.fromLong(n.pos);if(!world.isChunkLoaded(pos))continue;
            var block=world.getBlockState(pos).getBlock();
            if(block!=(n.controller?SirenBlocks.CONTROL:SirenBlocks.SIREN)){iterator.remove();changed=true;continue;}
            boolean stop=world.getEmittedRedstonePower(pos.north(),Direction.NORTH)>0;
            boolean start=false;for(Direction side:Direction.values())if(side!=Direction.NORTH&&world.getEmittedRedstonePower(pos.offset(side),side)>0)start=true;
            if(stop&&!n.lastStop){engine.stop(n.controller?n.group:null,n.controller?null:n.pos,now,true);changed=true;}
            else if(!stop&&start&&!n.lastStart){engine.start(n.controller?n.group:null,n.controller?null:n.pos,n.selected,now,false);changed=true;}
            if(start!=n.lastStart||stop!=n.lastStop)changed=true;n.lastStart=start;n.lastStop=stop;
        }
        if(now%20==0){
            var controls=engine.nodes.values().stream().filter(n->n.controller).toList();
            if(!controls.isEmpty()){
                var n=controls.get((int)Math.floorMod(now/20,controls.size()));var g=engine.group(n.group);
                if(g.enabled&&!g.paused&&now>=g.manualUntil)
                    changed|=engine.weather(n.group,controls.stream().filter(c->c.group.equals(n.group)).anyMatch(c->
                            SirenWeather.danger(world,BlockPos.fromLong(c.pos),c.radius,g.hazards)),now);
            }
        }
        if(changed)state.markDirty();
        for(var player:world.getPlayers()){
            var b=new JsonObject();b.addProperty("type","audio");b.addProperty("now",now);var list=new JsonArray();
            for(var n:engine.nodes.values())if(n.active(now)){
                var p=BlockPos.fromLong(n.pos);
                if(player.squaredDistanceTo(p.getX()+.5,p.getY()+.5,p.getZ()+.5)>(n.radius+32.0)*(n.radius+32.0))continue;
                var v=new JsonObject();v.addProperty("pos",n.pos);v.addProperty("start",n.start);v.addProperty("signal",n.playing);
                v.addProperty("radius",n.radius);v.addProperty("volume",n.volume);list.add(v);
            }b.add("nodes",list);send(player,b);
        }
    }
}
