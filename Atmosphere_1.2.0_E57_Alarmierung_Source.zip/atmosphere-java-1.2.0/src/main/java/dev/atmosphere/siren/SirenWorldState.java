package dev.atmosphere.siren;

import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.*;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

public final class SirenWorldState extends PersistentState {
    public final SirenEngine engine=new SirenEngine();
    private static final Type<SirenWorldState> TYPE=new Type<>(SirenWorldState::new,SirenWorldState::read,DataFixTypes.SAVED_DATA_MAP_DATA);
    public static SirenWorldState of(ServerWorld world){return world.getPersistentStateManager().getOrCreate(TYPE,"atmosphere_sirens_v1");}
    private static int bound(int n,int lo,int hi){return Math.max(lo,Math.min(hi,n));}
    private static SirenWorldState read(NbtCompound root,RegistryWrapper.WrapperLookup lookup){
        var state=new SirenWorldState();var list=root.getList("Nodes",NbtElement.COMPOUND_TYPE);
        for(int i=0;i<list.size()&&state.engine.nodes.size()<SirenEngine.LIMIT;i++){
            var b=list.getCompound(i);try{
                var n=state.engine.add(b.getLong("Pos"),b.getBoolean("Controller"));
                n.group=SirenEngine.groupName(b.getString("Group"));
                n.radius=bound(b.getInt("Radius"),64,1024);n.volume=bound(b.getInt("Volume"),0,100);
                n.delay=bound(b.getInt("Delay"),0,60);n.selected=bound(b.getInt("Selected"),0,3);
                n.start=b.contains("Start")?b.getLong("Start"):-1;n.playing=bound(b.getInt("Playing"),0,3);
                n.automatic=b.getBoolean("Automatic");n.lastStart=b.getBoolean("LastStart");n.lastStop=b.getBoolean("LastStop");
            }catch(IllegalArgumentException ex){System.err.println("[Atmosphere] Ungültiger Sireneneintrag: "+ex.getMessage());}
        }
        var groups=root.getList("Groups",NbtElement.COMPOUND_TYPE);
        for(int i=0;i<groups.size()&&i<128;i++)try{
            var b=groups.getCompound(i);var g=state.engine.group(SirenEngine.groupName(b.getString("Name")));
            g.enabled=b.getBoolean("Enabled");g.paused=b.getBoolean("Paused");g.hazards=b.getInt("Hazards")&7;
            g.autoClear=!b.contains("AutoClear")||b.getBoolean("AutoClear");
            g.warned=b.getBoolean("Warned");g.manualUntil=b.getLong("ManualUntil");g.nextWarning=b.getLong("NextWarning");
        }catch(IllegalArgumentException ex){System.err.println("[Atmosphere] Ungültige Sirenengruppe");}
        return state;
    }
    @Override public NbtCompound writeNbt(NbtCompound root,RegistryWrapper.WrapperLookup lookup){
        var list=new NbtList();for(var n:engine.nodes.values()){
            var b=new NbtCompound();b.putLong("Pos",n.pos);b.putBoolean("Controller",n.controller);b.putString("Group",n.group);
            b.putInt("Radius",n.radius);b.putInt("Volume",n.volume);b.putInt("Delay",n.delay);b.putInt("Selected",n.selected);
            b.putLong("Start",n.start);b.putInt("Playing",n.playing);b.putBoolean("Automatic",n.automatic);
            b.putBoolean("LastStart",n.lastStart);b.putBoolean("LastStop",n.lastStop);list.add(b);
        }root.put("Nodes",list);
        var groups=new NbtList();for(var e:engine.groups.entrySet()){
            var b=new NbtCompound();var g=e.getValue();b.putString("Name",e.getKey());b.putBoolean("Enabled",g.enabled);
            b.putBoolean("Paused",g.paused);b.putInt("Hazards",g.hazards);b.putBoolean("Warned",g.warned);
            b.putBoolean("AutoClear",g.autoClear);
            b.putLong("ManualUntil",g.manualUntil);b.putLong("NextWarning",g.nextWarning);groups.add(b);
        }root.put("Groups",groups);return root;
    }
}
