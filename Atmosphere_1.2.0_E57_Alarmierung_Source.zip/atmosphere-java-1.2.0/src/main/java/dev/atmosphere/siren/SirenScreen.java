package dev.atmosphere.siren;

import com.google.gson.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;

public final class SirenScreen extends Screen {
    private JsonObject data;private TextFieldWidget group;
    private int signal,radius,volume,delay,hazards;private boolean auto,paused,controller,clear;
    private String feedback="";private int x,y;
    private ButtonWidget signalButton,radiusButton,volumeButton,delayButton,autoButton,pauseButton,windButton,hailButton,tornadoButton;
    public SirenScreen(JsonObject data){super(Text.literal(data.get("controller").getAsBoolean()?"Sirenen-Bedienstelle":"E57-Sirene"));this.data=data;load();}
    private void load(){signal=data.get("signal").getAsInt();radius=data.get("radius").getAsInt();volume=data.get("volume").getAsInt();delay=data.get("delay").getAsInt();
        hazards=data.get("hazards").getAsInt();auto=data.get("auto").getAsBoolean();paused=data.get("paused").getAsBoolean();controller=data.get("controller").getAsBoolean();clear=data.get("clear").getAsBoolean();feedback=data.get("message").getAsString();}
    @Override protected void init(){
        x=width/2-164;y=Math.max(0,(height-240)/2);
        group=new TextFieldWidget(textRenderer,x+57,y+20,213,20,Text.literal("Gruppe"));group.setMaxLength(24);group.setText(data.get("group").getAsString());addDrawableChild(group);
        button(x+274,y+20,54,"Wechsel",()->{
            var names=data.getAsJsonArray("groups");if(names.isEmpty())return;int current=-1;
            for(int i=0;i<names.size();i++)if(names.get(i).getAsString().equals(group.getText()))current=i;
            group.setText(names.get((current+1)%names.size()).getAsString());
        });
        signalButton=button(x,y+44,328,"",()->{signal=(signal+1)%4;labels();});
        radiusButton=button(x,y+68,162,"",()->{radius=radius>=1024?64:radius<128?128:radius<256?256:radius<512?512:1024;labels();});
        volumeButton=button(x+166,y+68,162,"",()->{volume=volume>=100?0:Math.min(100,volume+10);labels();});
        delayButton=button(x,y+92,162,"",()->{if(controller)clear=!clear;else delay=delay>=60?0:delay+5;labels();});
        button(x+166,y+92,162,"Speichern",()->send("save"));
        autoButton=button(x,y+116,162,"",()->{auto=!auto;labels();});
        pauseButton=button(x+166,y+116,162,"",()->{paused=!paused;labels();});
        windButton=button(x,y+140,106,"",()->{hazards^=1;labels();});
        hailButton=button(x+111,y+140,106,"",()->{hazards^=2;labels();});
        tornadoButton=button(x+222,y+140,106,"",()->{hazards^=4;labels();});
        button(x,y+164,106,controller?"Alle starten":"Diese starten",()->send("start_single"));
        button(x+111,y+164,106,"Gruppe starten",()->send("start_group"));
        button(x+222,y+164,106,controller?"Gruppe stoppen":"Diese stoppen",()->send("stop_single"));
        button(x,y+188,106,"Stopp Gruppe",()->send("stop_group"));
        button(x+111,y+188,106,"Stopp ALLE",()->send("stop_all"));
        button(x+222,y+188,106,"Schließen",this::close);
        labels();
    }
    private ButtonWidget button(int x,int y,int width,String text,Runnable action){return addDrawableChild(ButtonWidget.builder(Text.literal(text),b->action.run()).dimensions(x,y,width,20).build());}
    private void labels(){
        signalButton.setMessage(Text.literal("Signal: "+SirenProgram.of(signal).label));radiusButton.setMessage(Text.literal((controller?"Warnradius: ":"Hörweite: ")+radius+" Bl."));
        volumeButton.active=!controller;volumeButton.setMessage(Text.literal(controller?"Lautstärke: je Sirene":"Lautstärke: "+volume+"%"));delayButton.setMessage(Text.literal(controller?"Auto-Entwarnung: "+(clear?"AN":"AUS"):String.format(java.util.Locale.GERMANY,"Startverzug: %.2f s",delay/20.0)));
        autoButton.setMessage(Text.literal("Gruppen-Automatik: "+(auto?"AN":"AUS")));pauseButton.setMessage(Text.literal("Automatik pausiert: "+(paused?"JA":"NEIN")));
        windButton.setMessage(Text.literal("Böen: "+((hazards&1)!=0?"AN":"AUS")));hailButton.setMessage(Text.literal("Hagel: "+((hazards&2)!=0?"AN":"AUS")));tornadoButton.setMessage(Text.literal("Tornado: "+((hazards&4)!=0?"AN":"AUS")));
    }
    private void send(String action){
        var b=new JsonObject();b.addProperty("pos",data.get("pos").getAsLong());b.addProperty("action",action);b.addProperty("group",group.getText());
        b.addProperty("signal",signal);b.addProperty("radius",radius);b.addProperty("volume",volume);b.addProperty("delay",delay);b.addProperty("auto",auto);b.addProperty("paused",paused);b.addProperty("hazards",hazards);
        b.addProperty("clear",clear);
        SirenClient.request(b);
    }
    public void accept(JsonObject data){this.data=data;feedback=data.get("message").getAsString();}
    @Override public boolean shouldPause(){return false;}
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){
        super.render(context,mouseX,mouseY,delta);context.drawCenteredTextWithShadow(textRenderer,title,width/2,y+4,0xFFFFFF);
        context.drawTextWithShadow(textRenderer,"Gruppe:",x,y+26,0xFFFFFF);
        String message=feedback.length()>53?feedback.substring(0,53):feedback;
        context.drawCenteredTextWithShadow(textRenderer,message,width/2,y+215,0xFFDD99);
        context.drawCenteredTextWithShadow(textRenderer,"Automatik benötigt eine Bedienstelle der Gruppe.",width/2,y+228,0xAACCBB);
    }
}
