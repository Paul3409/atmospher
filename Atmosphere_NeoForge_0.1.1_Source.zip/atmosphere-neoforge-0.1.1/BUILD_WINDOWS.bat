@echo off
cd /d "%~dp0"
echo Atmosphere Companion 0.1.0 - NeoForge 21.1.219 / Minecraft 1.21.1 / Java 21
where gradle >nul 2>&1
if errorlevel 1 (
 echo Gradle 8.14.3 muss im PATH vorhanden sein.
 pause
 exit /b 1
)
gradle clean build --no-daemon --console=plain
if errorlevel 1 (
 echo Build fehlgeschlagen.
 pause
 exit /b 1
)
echo Fertig: build\libs\atmosphere-companion-neoforge-0.1.0.jar
pause
