package dev.atmosphere.companion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Locale;

/** Main manual control desk. Every slider changes the active weather immediately. */
public final class WeatherSimulatorScreen extends Screen {
    private int page;
    public WeatherSimulatorScreen(){super(Component.literal("Atmosphere – Wettersimulator"));}
    private WeatherSimulatorScreen(int page){this();this.page=page;}
    @Override protected void init(){
        int x=width/2-130,y=height/2-116,w=260;
        if(page==0)globalPage(x,y,w);else if(page==1)atmospherePage(x,y,w);else graphicsPage(x,y,w);
        addRenderableWidget(Button.builder(Component.literal("<"),b->{page=Math.floorMod(page-1,3);rebuildWidgets();}).bounds(x,y+196,36,20).build());
        addRenderableWidget(Button.builder(Component.literal(pageName()),b->{}).bounds(x+40,y+196,180,20).build());
        addRenderableWidget(Button.builder(Component.literal(">"),b->{page=(page+1)%3;rebuildWidgets();}).bounds(x+224,y+196,36,20).build());
        addRenderableWidget(Button.builder(Component.literal("Wetterkarte / Zonen"),b->minecraft.setScreen(new WeatherMapScreen(this)))
            .bounds(x,y+220,166,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(x+170,y+220,90,20).build());
    }
    private void globalPage(int x,int y,int w){
        addRenderableWidget(Button.builder(Component.literal("Wettersimulator: "+on(CloudConfig.SIMULATOR_ENABLED.get())),b->{
            CloudConfig.SIMULATOR_ENABLED.set(!CloudConfig.SIMULATOR_ENABLED.get());rebuildWidgets();}).bounds(x,y,w,20).build());
        addRenderableWidget(Button.builder(Component.literal("Niederschlag: "+CloudConfig.MANUAL_PRECIPITATION.get()),b->{
            var values=CloudConfig.PrecipitationSelection.values();var current=CloudConfig.MANUAL_PRECIPITATION.get();
            CloudConfig.MANUAL_PRECIPITATION.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();}).bounds(x,y+24,w,20).build());
        addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,0,100,CloudConfig.MANUAL_INTENSITY::get,CloudConfig.MANUAL_INTENSITY::set,v->"Niederschlagsstaerke: "+v+"%"));
        addRenderableWidget(new AtmosphereSlider(x,y+72,w,-40,45,CloudConfig.MANUAL_TEMPERATURE::get,CloudConfig.MANUAL_TEMPERATURE::set,
            v->String.format(Locale.ROOT,"Temperatur: %.1f °C",v)));
        addRenderableWidget(new AtmosphereSlider(x,y+96,w,0,20,CloudConfig.HEIGHT_COOLING::get,CloudConfig.HEIGHT_COOLING::set,
            v->String.format(Locale.ROOT,"Abkuehlung/100 Bloecke: %.1f °C",v)));
        addRenderableWidget(AtmosphereSlider.integer(x,y+120,w,-64,384,CloudConfig.SNOW_LINE::get,CloudConfig.SNOW_LINE::set,v->"Schneefallgrenze: Y "+v));
        addRenderableWidget(AtmosphereSlider.integer(x,y+144,w,0,48,CloudConfig.SNOW_TRANSITION::get,CloudConfig.SNOW_TRANSITION::set,v->"Schneeregen-Uebergang: ±"+v+" Bloecke"));
    }
    private void atmospherePage(int x,int y,int w){
        addRenderableWidget(AtmosphereSlider.integer(x,y,w,0,100,CloudConfig.MANUAL_FOG_DENSITY::get,CloudConfig.MANUAL_FOG_DENSITY::set,v->"Nebeldichte: "+v+"%"));
        addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,0,384,CloudConfig.MANUAL_FOG_START::get,CloudConfig.MANUAL_FOG_START::set,v->"Nebel beginnt bei: "+v+" Bloecken"));
        addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,8,512,CloudConfig.MANUAL_FOG_END::get,CloudConfig.MANUAL_FOG_END::set,v->"Volle Nebeldichte bei: "+v+" Bloecken"));
        addRenderableWidget(Button.builder(Component.literal("Wind aus: "+CloudConfig.WIND_DIRECTION.get()),b->{
            var values=CloudConfig.WindDirection.values();var current=CloudConfig.WIND_DIRECTION.get();
            CloudConfig.WIND_DIRECTION.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();}).bounds(x,y+72,w,20).build());
        addRenderableWidget(new AtmosphereSlider(x,y+96,w,0,5,CloudConfig.WIND_SPEED::get,CloudConfig.WIND_SPEED::set,
            v->String.format(Locale.ROOT,"Windstaerke: %.2f",v)));
        addRenderableWidget(AtmosphereSlider.integer(x,y+120,w,0,100,CloudConfig.MANUAL_LIGHTNING::get,CloudConfig.MANUAL_LIGHTNING::set,v->"Blitzhaeufigkeit: "+v+"%"));
        addRenderableWidget(AtmosphereSlider.integer(x,y+144,w,0,100,CloudConfig.SOUND_VOLUME::get,CloudConfig.SOUND_VOLUME::set,v->"Wetterlautstaerke: "+v+"%"));
    }
    private void graphicsPage(int x,int y,int w){
        addRenderableWidget(Button.builder(Component.literal("Partikel: "+CloudConfig.PARTICLE_MODE.get()),b->{
            var values=CloudConfig.ParticleMode.values();var current=CloudConfig.PARTICLE_MODE.get();
            CloudConfig.PARTICLE_MODE.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();}).bounds(x,y,w,20).build());
        addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,0,200,CloudConfig.PRECIPITATION_DENSITY::get,CloudConfig.PRECIPITATION_DENSITY::set,v->"Partikeldichte: "+v+"%"));
        addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,40,220,CloudConfig.RAIN_PARTICLE_SIZE::get,CloudConfig.RAIN_PARTICLE_SIZE::set,v->"Regentropfen: "+v+"%"));
        addRenderableWidget(AtmosphereSlider.integer(x,y+72,w,40,220,CloudConfig.SNOW_PARTICLE_SIZE::get,CloudConfig.SNOW_PARTICLE_SIZE::set,v->"Schneeflocken: "+v+"%"));
        addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,40,220,CloudConfig.SLEET_PARTICLE_SIZE::get,CloudConfig.SLEET_PARTICLE_SIZE::set,v->"Schneeregen: "+v+"%"));
        addRenderableWidget(Button.builder(Component.literal("Boden-/Wasserspritzer: "+on(CloudConfig.SPLASHES.get())),b->{CloudConfig.SPLASHES.set(!CloudConfig.SPLASHES.get());rebuildWidgets();}).bounds(x,y+120,w,20).build());
        addRenderableWidget(Button.builder(Component.literal("Wettersounds: "+on(CloudConfig.WEATHER_SOUNDS.get())),b->{CloudConfig.WEATHER_SOUNDS.set(!CloudConfig.WEATHER_SOUNDS.get());rebuildWidgets();}).bounds(x,y+144,w,20).build());
    }
    private String pageName(){return switch(page){case 0->"Wetter & Temperatur";case 1->"Nebel, Wind & Gewitter";default->"Darstellung & Ton";};}
    private static String on(boolean value){return value?"AN":"AUS";}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);gui.drawCenteredString(font,title,width/2,height/2-138,0xFFFFFF);
        if(page==0&&minecraft!=null&&minecraft.player!=null){var p=minecraft.player;var sample=ManualWeather.sample(p.getX(),p.getY(),p.getZ());
            gui.drawCenteredString(font,String.format(Locale.ROOT,"Lokal: %.1f °C | %s | %d Zone(n)",WeatherField.temperature(p.getX(),p.getY(),p.getZ()),sample.kind(p.getY()),WeatherZoneManager.zones().size()),width/2,height/2+128,0xD8D8D8);}
    }
    @Override public boolean isPauseScreen(){return false;}
}
