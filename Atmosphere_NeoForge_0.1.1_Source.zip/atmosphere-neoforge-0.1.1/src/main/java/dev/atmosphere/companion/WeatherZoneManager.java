package dev.atmosphere.companion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.Minecraft;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Client-side persistence for deliberately painted weather zones. Last zone in the list has priority. */
public final class WeatherZoneManager {
    private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE=FMLPaths.CONFIGDIR.get().resolve("atmosphere-weather-zones.json");
    private static final List<ManualWeatherZone> ZONES=new ArrayList<>();
    private static boolean loaded;
    private static int selected=-1;

    public static synchronized List<ManualWeatherZone> zones(){load();return Collections.unmodifiableList(ZONES);}
    public static synchronized ManualWeatherZone selected(){load();return selected>=0&&selected<ZONES.size()?ZONES.get(selected):null;}
    public static synchronized ManualWeatherZone createAt(double x,double z){
        load();
        var zone=new ManualWeatherZone();
        zone.name="Wetterzone "+(ZONES.size()+1);
        zone.dimension=currentDimension();
        zone.precipitation=CloudConfig.MANUAL_PRECIPITATION.get();
        zone.intensity=CloudConfig.MANUAL_INTENSITY.get();
        zone.temperature=CloudConfig.MANUAL_TEMPERATURE.get();
        zone.snowLine=CloudConfig.SNOW_LINE.get();
        zone.snowTransition=CloudConfig.SNOW_TRANSITION.get();
        zone.fogDensity=CloudConfig.MANUAL_FOG_DENSITY.get();
        zone.fogStart=CloudConfig.MANUAL_FOG_START.get();
        zone.fogEnd=CloudConfig.MANUAL_FOG_END.get();
        zone.windDirection=CloudConfig.WIND_DIRECTION.get();
        zone.windSpeed=CloudConfig.WIND_SPEED.get();
        zone.lightning=CloudConfig.MANUAL_LIGHTNING.get();
        zone.paint(x,z,10,false);
        ZONES.add(zone);selected=ZONES.size()-1;save();return zone;
    }
    public static synchronized void select(int index){load();selected=ZONES.isEmpty()?-1:Math.floorMod(index,ZONES.size());}
    public static synchronized void select(ManualWeatherZone zone){load();selected=ZONES.indexOf(zone);}
    public static synchronized void deleteSelected(){load();if(selected<0||selected>=ZONES.size())return;ZONES.remove(selected);selected=Math.min(selected,ZONES.size()-1);save();}
    public static synchronized ManualWeatherZone at(double x,double y,double z){
        load();String dimension=currentDimension();
        for(int i=ZONES.size()-1;i>=0;i--){var zone=ZONES.get(i);if(zone.dimension.equals(dimension)&&zone.contains(x,y,z))return zone;}
        return null;
    }
    public static synchronized void save(){
        load();
        try{Files.createDirectories(FILE.getParent());try(Writer writer=Files.newBufferedWriter(FILE)){GSON.toJson(ZONES,writer);}}
        catch(IOException exception){AtmosphereCompanion.logError("Wetterzonen konnten nicht gespeichert werden",exception);}
    }
    private static synchronized void load(){
        if(loaded)return;loaded=true;
        if(!Files.isRegularFile(FILE))return;
        try(Reader reader=Files.newBufferedReader(FILE)){
            List<ManualWeatherZone> saved=GSON.fromJson(reader,new TypeToken<List<ManualWeatherZone>>(){}.getType());
            if(saved!=null)ZONES.addAll(saved);
            if(!ZONES.isEmpty())selected=0;
        }catch(Exception exception){AtmosphereCompanion.logError("Wetterzonen konnten nicht geladen werden",exception);}
    }
    private static String currentDimension(){
        var level=Minecraft.getInstance().level;
        return level==null?"minecraft:overworld":level.dimension().location().toString();
    }
    private WeatherZoneManager(){}
}
