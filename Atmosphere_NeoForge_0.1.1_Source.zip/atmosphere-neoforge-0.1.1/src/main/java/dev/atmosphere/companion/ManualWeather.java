package dev.atmosphere.companion;

/** Resolves the global simulator settings and the highest-priority painted zone at a world position. */
public final class ManualWeather {
    public record Sample(boolean enabled,CloudConfig.PrecipitationSelection selection,float intensity,
                         double temperature,int snowLine,int snowTransition,int fogDensity,int fogStart,int fogEnd,
                         CloudConfig.WindDirection windDirection,double windSpeed,int lightning,ManualWeatherZone zone){
        public WeatherField.PrecipitationKind kind(double y){
            if(!enabled||intensity<=0||selection==CloudConfig.PrecipitationSelection.AUS)return WeatherField.PrecipitationKind.NONE;
            return switch(selection){
                case REGEN->WeatherField.PrecipitationKind.RAIN;
                case SCHNEEREGEN->WeatherField.PrecipitationKind.SLEET;
                case SCHNEE->WeatherField.PrecipitationKind.SNOW;
                case AUTOMATISCH->y>snowLine+snowTransition?WeatherField.PrecipitationKind.SNOW:
                    y>=snowLine-snowTransition?WeatherField.PrecipitationKind.SLEET:WeatherField.PrecipitationKind.RAIN;
                default->WeatherField.PrecipitationKind.NONE;
            };
        }
    }
    public static Sample sample(double x,double y,double z){
        var zone=WeatherZoneManager.at(x,y,z);
        if(zone!=null)return new Sample(zone.enabled,zone.precipitation,zone.intensity/100f,zone.temperature,
            zone.snowLine,zone.snowTransition,zone.fogDensity,zone.fogStart,zone.fogEnd,
            zone.windDirection,zone.windSpeed,zone.lightning,zone);
        return new Sample(CloudConfig.SIMULATOR_ENABLED.get(),CloudConfig.MANUAL_PRECIPITATION.get(),
            CloudConfig.MANUAL_INTENSITY.get()/100f,CloudConfig.MANUAL_TEMPERATURE.get(),CloudConfig.SNOW_LINE.get(),
            CloudConfig.SNOW_TRANSITION.get(),CloudConfig.MANUAL_FOG_DENSITY.get(),CloudConfig.MANUAL_FOG_START.get(),
            CloudConfig.MANUAL_FOG_END.get(),CloudConfig.WIND_DIRECTION.get(),CloudConfig.WIND_SPEED.get(),
            CloudConfig.MANUAL_LIGHTNING.get(),null);
    }
    private ManualWeather(){}
}
