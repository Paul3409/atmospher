package dev.atmosphere.companion;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Soft, world anchored ground fog, strengthened in wet hollows and beside water. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class TerrainFogRenderer {
    private static final RenderType FOG=RenderType.create("atmosphere_terrain_fog",DefaultVertexFormat.POSITION_COLOR,
        VertexFormat.Mode.QUADS,8192,false,true,RenderType.CompositeState.builder()
            .setShaderState(RenderStateShard.POSITION_COLOR_SHADER)
            .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
            .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
            .setWriteMaskState(RenderStateShard.COLOR_WRITE)
            .setCullState(RenderStateShard.NO_CULL).createCompositeState(false));
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD||!CloudConfig.FOG_ENABLED.get()||CloudConfig.FOG_DENSITY.get()==0)return;
        var camera=event.getCamera().getPosition();
        if(camera.y>mc.level.getSeaLevel()+155)return;
        var out=mc.renderBuffers().bufferSource().getBuffer(FOG);
        var matrix=event.getPoseStack().last().pose();
        int cx=(int)Math.floor(camera.x/24),cz=(int)Math.floor(camera.z/24);
        for(int gx=cx-19;gx<=cx+19;gx++)for(int gz=cz-19;gz<=cz+19;gz++){
            double wx=gx*24+12,wz=gz*24+12;
            double dx=wx-camera.x,dz=wz-camera.z,distance=Math.hypot(dx,dz);
            if(distance>430)continue;
            double strength=WeatherField.fogPotential(wx,wz);
            if(strength<.055)continue;
            int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)wx,(int)wz);
            if(ground<=mc.level.getMinBuildHeight()+1)continue;
            double top=ground+3+strength*11;
            double radius=22+strength*17;
            double fade=Math.max(0,Math.min(1,(distance-26)/90.0))*Math.max(0,Math.min(1,(430-distance)/100.0));
            float alpha=(float)Math.min(.105,strength*.095*fade);
            if(alpha<.003)continue;
            double y0=ground-camera.y+.15,y1=top-camera.y;
            double wobble=1+Math.sin(wx*.021+wz*.017)*.13;
            double inv=distance<1?0:1/distance;
            float sx=(float)(-dz*inv*radius*wobble),sz=(float)(dx*inv*radius*wobble);
            float x=(float)dx,z=(float)dz;
            // Two camera-facing, softly faded banks instead of a hard fog sheet.
            quad(out,matrix,x,z,sx,sz,(float)y0,(float)(y0+(y1-y0)*.56),alpha*.2f,alpha);
            quad(out,matrix,x,z,sx*.82f,sz*.82f,(float)(y0+(y1-y0)*.56),(float)y1,alpha,alpha*.08f);
        }
        mc.renderBuffers().bufferSource().endBatch(FOG);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,float x,float z,float sx,float sz,float y0,float y1,float a0,float a1){
        out.addVertex(m,x-sx,y0,z-sz).setColor(.68f,.70f,.69f,a0);
        out.addVertex(m,x+sx,y0,z+sz).setColor(.68f,.70f,.69f,a0);
        out.addVertex(m,x+sx,y1,z+sz).setColor(.68f,.70f,.69f,a1);
        out.addVertex(m,x-sx,y1,z-sz).setColor(.68f,.70f,.69f,a1);
    }
    private TerrainFogRenderer(){}
}
