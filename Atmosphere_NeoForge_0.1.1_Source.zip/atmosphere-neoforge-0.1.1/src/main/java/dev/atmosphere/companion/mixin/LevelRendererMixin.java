package dev.atmosphere.companion.mixin;

import dev.atmosphere.companion.CloudConfig;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hide only the vanilla client renderer; the server weather remains untouched. */
@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    private static boolean loggedClouds, loggedRain, loggedRainTick;
    @Inject(method="renderClouds",at=@At("HEAD"),cancellable=true)
    private void atmosphere$hideVanillaClouds(CallbackInfo ci) {
        if(CloudConfig.HIDE_VANILLA_CLOUDS.get()) {
            if(Boolean.getBoolean("atmosphere.smokeTest")&&!loggedClouds){loggedClouds=true;System.out.println("ATMOSPHERE_TEST_HIDE_CLOUDS");}
            ci.cancel();
        }
    }
    @Inject(method="renderSnowAndRain",at=@At("HEAD"),cancellable=true)
    private void atmosphere$hideVanillaPrecipitation(CallbackInfo ci) {
        if(CloudConfig.HIDE_VANILLA_PRECIPITATION.get()) {
            if(Boolean.getBoolean("atmosphere.smokeTest")&&!loggedRain){loggedRain=true;System.out.println("ATMOSPHERE_TEST_HIDE_PRECIPITATION");}
            ci.cancel();
        }
    }
    @Inject(method="tickRain",at=@At("HEAD"),cancellable=true)
    private void atmosphere$hideVanillaRainEffects(CallbackInfo ci) {
        if(CloudConfig.HIDE_VANILLA_PRECIPITATION.get()) {
            if(Boolean.getBoolean("atmosphere.smokeTest")&&!loggedRainTick){loggedRainTick=true;System.out.println("ATMOSPHERE_TEST_HIDE_RAIN_EFFECTS");}
            ci.cancel();
        }
    }
}
