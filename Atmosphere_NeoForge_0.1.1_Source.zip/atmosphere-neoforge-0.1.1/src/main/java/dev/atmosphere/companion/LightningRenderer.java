package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Short-lived visual lightning within a rainy cumulonimbus footprint. No fire or damage. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class LightningRenderer {
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||!CloudConfig.LIGHTNING.get())return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var type=WeatherField.activeType();
        if(type!=CloudConfig.CloudType.CUMULONIMBUS&&type!=CloudConfig.CloudType.CUMULONIMBUS_GROSS)return;
        int frequency=CloudConfig.LIGHTNING_FREQUENCY.get();
        if(frequency==0)return;
        long period=Math.max(45,20000L/frequency);
        long tick=mc.level.getGameTime();
        if(Math.floorMod(tick,period)>4)return;
        long cycle=Math.floorDiv(tick,period);
        var camera=event.getCamera().getPosition();
        double centerX=Math.floor((camera.x+256)/512)*512;
        double centerZ=Math.floor((camera.z+256)/512)*512;
        double wx=centerX+((cycle*73)%137)-68;
        double wz=centerZ+((cycle*97)%119)-59;
        if(WeatherField.precipitation(wx,wz)<.35)return;
        double distance=Math.hypot(wx-camera.x,wz-camera.z);
        if(distance>420)return;
        int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)wx,(int)wz);
        if(ground<=mc.level.getMinBuildHeight()+2)ground=mc.level.getSeaLevel();
        double top=WeatherField.cloudBaseAt(wx,wz)-3;
        if(top<=ground+10)return;
        var buffers=mc.renderBuffers().bufferSource();
        var out=buffers.getBuffer(WeatherCurtainRenderer.CURTAIN);
        var m=event.getPoseStack().last().pose();
        double x0=wx-camera.x,z0=wz-camera.z;
        int segments=10;
        for(int i=0;i<segments;i++){
            double t0=i/(double)segments,t1=(i+1)/(double)segments;
            float y0=(float)(top+(ground-top)*t0-camera.y),y1=(float)(top+(ground-top)*t1-camera.y);
            float zig0=(float)(Math.sin(i*3.73+cycle)*2.8),zig1=(float)(Math.sin((i+1)*3.73+cycle)*2.8);
            float x=(float)x0,z=(float)z0,width=i<3?.8f:.5f;
            out.addVertex(m,x+zig0-width,y0,z).setColor(.80f,.86f,1f,.95f);
            out.addVertex(m,x+zig0+width,y0,z).setColor(.80f,.86f,1f,.95f);
            out.addVertex(m,x+zig1+width,y1,z).setColor(.80f,.86f,1f,.95f);
            out.addVertex(m,x+zig1-width,y1,z).setColor(.80f,.86f,1f,.95f);
        }
        buffers.endBatch(WeatherCurtainRenderer.CURTAIN);
    }
    private LightningRenderer(){}
}
