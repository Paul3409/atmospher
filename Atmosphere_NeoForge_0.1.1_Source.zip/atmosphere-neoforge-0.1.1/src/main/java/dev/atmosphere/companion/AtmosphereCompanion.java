package dev.atmosphere.companion;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import org.slf4j.Logger;

/** Independent foundation for the new weather mod. */
@Mod(AtmosphereCompanion.MOD_ID)
public final class AtmosphereCompanion {
    public static final String MOD_ID="atmosphere_companion";
    private static final Logger LOGGER=LogUtils.getLogger();
    public AtmosphereCompanion(IEventBus bus, ModContainer container){
        bus.addListener(this::setup);
        if (FMLEnvironment.dist.isClient()) {
            container.registerConfig(ModConfig.Type.CLIENT, CloudConfig.SPEC);
            container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        }
    }
    private void setup(FMLCommonSetupEvent event){
        event.enqueueWork(()->LOGGER.info("ATMOSPHERE_NEO_READY Minecraft=1.21.1; independent foundation"));
    }
}
