package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Lightweight procedural streak particles, clipped to the same field as the radar. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class PrecipitationRenderer {
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var cam=event.getCamera().getPosition();
        double base=WeatherField.cloudBase();
        if(cam.y>base+8)return;
        var buffers=mc.renderBuffers().bufferSource();
        var renderType=RenderType.debugQuads();
        var out=buffers.getBuffer(renderType);
        var matrix=event.getPoseStack().last().pose();
        double time=mc.level.getGameTime()+event.getPartialTick().getGameTimeDeltaTicks();
        int minX=(int)Math.floor((cam.x-28)/4),maxX=(int)Math.floor((cam.x+28)/4);
        int minZ=(int)Math.floor((cam.z-28)/4),maxZ=(int)Math.floor((cam.z+28)/4);
        for(int ix=minX;ix<=maxX;ix++)for(int iz=minZ;iz<=maxZ;iz++)for(int n=0;n<3;n++){
            long hash=((long)ix*73428767L)^((long)iz*912931L)^(n*19349663L);
            hash^=hash>>>13;hash*=1274126177L;hash^=hash>>>16;
            double px=ix*4+((hash&1023)/1023.0)*4,pz=iz*4+(((hash>>>10)&1023)/1023.0)*4;
            float intensity=WeatherField.precipitation(px,pz);
            if(intensity<=0||((hash>>>20)&1023)/1023.0>intensity*.8)continue;
            double phase=(((hash>>>32)&65535)/65535.0)*26;
            double py=cam.y-12+Math.floorMod((long)Math.floor(phase-time*1.2),26);
            if(py>base)continue;
            float x=(float)(px-cam.x),y=(float)(py-cam.y),z=(float)(pz-cam.z);
            float w=.035f;
            out.addVertex(matrix,x-w,y,z).setColor(.30f,.50f,.88f,.85f);
            out.addVertex(matrix,x+w,y,z).setColor(.30f,.50f,.88f,.85f);
            out.addVertex(matrix,x+w,y+1.45f,z).setColor(.30f,.50f,.88f,.30f);
            out.addVertex(matrix,x-w,y+1.45f,z).setColor(.30f,.50f,.88f,.30f);
        }
        buffers.endBatch(renderType);
    }
    private PrecipitationRenderer(){}
}
