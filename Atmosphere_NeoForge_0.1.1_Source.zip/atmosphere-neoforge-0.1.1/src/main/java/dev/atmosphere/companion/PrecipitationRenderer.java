package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Lightweight procedural streak particles, clipped to the same field as the radar. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class PrecipitationRenderer {
    private static final ResourceLocation RAIN=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,"textures/particle/rain_streak.png");
    private static final ResourceLocation SNOW=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,"textures/particle/snow_flake.png");
    private static final RenderType RAIN_TYPE=textured("atmosphere_fabric_rain",RAIN);
    private static final RenderType SNOW_TYPE=textured("atmosphere_fabric_snow",SNOW);
    private static RenderType textured(String name,ResourceLocation texture){
        return RenderType.create(name,DefaultVertexFormat.POSITION_TEX_COLOR,VertexFormat.Mode.QUADS,4096,false,true,
            RenderType.CompositeState.builder().setShaderState(RenderStateShard.POSITION_TEX_COLOR_SHADER)
                .setTextureState(new RenderStateShard.TextureStateShard(texture,false,false))
                .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST).setWriteMaskState(RenderStateShard.COLOR_WRITE)
                .setCullState(RenderStateShard.NO_CULL).createCompositeState(false));
    }
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var cam=event.getCamera().getPosition();
        if(CloudConfig.PRECIPITATION_DENSITY.get()==0)return;
        double base=WeatherField.cloudBase();
        if(cam.y>base+8)return;
        var buffers=mc.renderBuffers().bufferSource();
        var matrix=event.getPoseStack().last().pose();
        double time=mc.level.getGameTime()+event.getPartialTick().getGameTimeDeltaTicks();
        int minX=(int)Math.floor((cam.x-28)/4),maxX=(int)Math.floor((cam.x+28)/4);
        int minZ=(int)Math.floor((cam.z-28)/4),maxZ=(int)Math.floor((cam.z+28)/4);
        for(int ix=minX;ix<=maxX;ix++)for(int iz=minZ;iz<=maxZ;iz++)for(int n=0;n<4;n++){
            long hash=((long)ix*73428767L)^((long)iz*912931L)^(n*19349663L);
            hash^=hash>>>13;hash*=1274126177L;hash^=hash>>>16;
            double px=ix*4+((hash&1023)/1023.0)*4,pz=iz*4+(((hash>>>10)&1023)/1023.0)*4;
            float intensity=WeatherField.precipitation(px,pz);
            if(intensity<=0||((hash>>>20)&1023)/1023.0>intensity*.8)continue;
            var kind=WeatherField.precipitationKind(px,cam.y,pz);
            if(kind==WeatherField.PrecipitationKind.SNOW&&!CloudConfig.OPTICAL_SNOW.get())continue;
            double phase=(((hash>>>32)&65535)/65535.0)*26;
            double speed=kind==WeatherField.PrecipitationKind.SNOW?.085:
                kind==WeatherField.PrecipitationKind.SLEET?.34:2.35;
            double py=cam.y-12+Math.floorMod((long)Math.floor(phase-time*speed),26);
            if(py>WeatherField.cloudBaseAt(px,pz))continue;
            int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)Math.floor(px),(int)Math.floor(pz));
            if(py<=ground+.05)continue; // roofs, foliage and terrain stop the local precipitation
            float x=(float)(px-cam.x),y=(float)(py-cam.y),z=(float)(pz-cam.z);
            double gust=Math.sin(time*.041+px*.019+pz*.013)*(.10+.34*intensity);
            float windX=(float)(CloudConfig.WIND_DIRECTION.get().dx*gust),windZ=(float)(CloudConfig.WIND_DIRECTION.get().dz*gust);
            if(kind==WeatherField.PrecipitationKind.SNOW){
                float drift=(float)(Math.sin(time*.031+phase)*.42+Math.sin(time*.017+phase*1.7)*.24);
                float flutter=(float)Math.sin(time*.048+phase*.8)*.15f;
                float size=.34f*CloudConfig.SNOW_PARTICLE_SIZE.get()/100f;
                quad(buffers.getBuffer(SNOW_TYPE),matrix,x+drift+windX,y,z+flutter+windZ,size,size,.90f,.91f,.89f,.76f);
            }else if(kind==WeatherField.PrecipitationKind.SLEET){
                float size=CloudConfig.SLEET_PARTICLE_SIZE.get()/100f;
                quad(buffers.getBuffer(RAIN_TYPE),matrix,x+windX,y,z+windZ,.075f*size,.72f*size,.78f,.81f,.82f,.68f);
                if((hash&3)==0)quad(buffers.getBuffer(SNOW_TYPE),matrix,x-windX,y,z-windZ,.19f*size,.19f*size,.88f,.89f,.87f,.64f);
            }else{
                float size=CloudConfig.RAIN_PARTICLE_SIZE.get()/100f;
                quad(buffers.getBuffer(RAIN_TYPE),matrix,x+windX,y,z+windZ,.055f*size,1.45f*size,.70f,.70f,.67f,.78f);
                if(CloudConfig.SPLASHES.get()&&py-ground<1.8&&((hash>>>25)&3)==0){
                    float splash=.12f*size;
                    quad(buffers.getBuffer(SNOW_TYPE),matrix,x,(float)(ground+.04-cam.y),z,splash,splash,.72f,.72f,.69f,.42f);
                }
            }
        }
        buffers.endBatch(RAIN_TYPE);buffers.endBatch(SNOW_TYPE);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                             float x,float y,float z,float w,float h,float r,float g,float b,float a){
        quad(out,m,x,y,z,w,h,r,g,b,a,false);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                             float x,float y,float z,float w,float h,float r,float g,float b,float a,boolean cross){
        if(cross){
            out.addVertex(m,x,y,z-w).setUv(0,1).setColor(r,g,b,a);
            out.addVertex(m,x,y,z+w).setUv(1,1).setColor(r,g,b,a);
            out.addVertex(m,x,y+h,z+w).setUv(1,0).setColor(r,g,b,a);
            out.addVertex(m,x,y+h,z-w).setUv(0,0).setColor(r,g,b,a);
        }else{
            out.addVertex(m,x-w,y,z).setUv(0,1).setColor(r,g,b,a);
            out.addVertex(m,x+w,y,z).setUv(1,1).setColor(r,g,b,a);
            out.addVertex(m,x+w,y+h,z).setUv(1,0).setColor(r,g,b,a*.72f);
            out.addVertex(m,x-w,y+h,z).setUv(0,0).setColor(r,g,b,a*.72f);
        }
    }
    private PrecipitationRenderer(){}
}
