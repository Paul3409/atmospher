package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Lightweight procedural streak particles, clipped to the same field as the radar. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class PrecipitationRenderer {
    private static final ResourceLocation RAIN=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,"textures/particle/rain_streak.png");
    private static final ResourceLocation SNOW=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,"textures/particle/snow_flake.png");
    private static final RenderType RAIN_TYPE=textured("atmosphere_fabric_rain",RAIN);
    private static final RenderType SNOW_TYPE=textured("atmosphere_fabric_snow",SNOW);
    private static RenderType textured(String name,ResourceLocation texture){
        return RenderType.create(name,DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP,VertexFormat.Mode.QUADS,4096,false,true,
            RenderType.CompositeState.builder().setShaderState(RenderStateShard.POSITION_COLOR_TEX_LIGHTMAP_SHADER)
                .setTextureState(new RenderStateShard.TextureStateShard(texture,false,false))
                .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST).setWriteMaskState(RenderStateShard.COLOR_WRITE)
                .setCullState(RenderStateShard.NO_CULL).createCompositeState(false));
    }
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var cam=event.getCamera().getPosition();
        if(!CloudConfig.SIMULATOR_ENABLED.get()||CloudConfig.PRECIPITATION_DENSITY.get()==0)return;
        var buffers=mc.renderBuffers().bufferSource();
        var matrix=event.getPoseStack().last().pose();
        double time=mc.level.getGameTime()+event.getPartialTick().getGameTimeDeltaTicks();
        int minX=(int)Math.floor((cam.x-28)/4),maxX=(int)Math.floor((cam.x+28)/4);
        int minZ=(int)Math.floor((cam.z-28)/4),maxZ=(int)Math.floor((cam.z+28)/4);
        for(int ix=minX;ix<=maxX;ix++)for(int iz=minZ;iz<=maxZ;iz++)for(int n=0;n<4;n++){
            long hash=((long)ix*73428767L)^((long)iz*912931L)^(n*19349663L);
            hash^=hash>>>13;hash*=1274126177L;hash^=hash>>>16;
            double px=ix*4+((hash&1023)/1023.0)*4,pz=iz*4+(((hash>>>10)&1023)/1023.0)*4;
            int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)Math.floor(px),(int)Math.floor(pz));
            var weather=ManualWeather.sample(px,ground,pz);
            float intensity=(weather.enabled()?weather.intensity():0)*CloudConfig.PRECIPITATION_DENSITY.get()/100f;
            if(intensity<=0||((hash>>>20)&1023)/1023.0>Math.min(1,intensity))continue;
            var kind=WeatherField.precipitationKind(px,ground,pz);
            if(kind==WeatherField.PrecipitationKind.SNOW&&!CloudConfig.OPTICAL_SNOW.get())continue;
            double phase=((hash>>>32)&65535)/65535.0;
            double speed=kind==WeatherField.PrecipitationKind.SNOW?.085:
                kind==WeatherField.PrecipitationKind.SLEET?.34:2.35;
            double top=Math.max(ground+18,cam.y+42);
            double py=worldY(phase,time,ground,top,speed);
            if(py>top)continue;
            if(py<=ground+.05)continue; // roofs, foliage and terrain stop the local precipitation
            float x=(float)(px-cam.x),y=(float)(py-cam.y),z=(float)(pz-cam.z);
            double gust=Math.sin(time*.041+px*.019+pz*.013)*(.10+.34*intensity);
            float windX=(float)(weather.windDirection().dx*gust*weather.windSpeed()),windZ=(float)(weather.windDirection().dz*gust*weather.windSpeed());
            if(kind==WeatherField.PrecipitationKind.SNOW){
                float drift=(float)(Math.sin(time*.031+phase*31)*.42+Math.sin(time*.017+phase*53)*.24);
                float flutter=(float)Math.sin(time*.048+phase*41)*.15f;
                float size=.34f*CloudConfig.SNOW_PARTICLE_SIZE.get()/100f;
                var snow=buffers.getBuffer(SNOW_TYPE);
                quad(snow,matrix,x+drift+windX,y,z+flutter+windZ,size,size,.90f,.91f,.89f,.62f);
                if(CloudConfig.PARTICLE_MODE.get()!=CloudConfig.ParticleMode.TWO_D)
                    quad(snow,matrix,x+drift+windX,y,z+flutter+windZ,size,size,.90f,.91f,.89f,.56f,true);
                if(CloudConfig.PARTICLE_MODE.get()==CloudConfig.ParticleMode.THREE_D_HIGH)
                    horizontal(snow,matrix,x+drift+windX,y+size*.5f,z+flutter+windZ,size,.90f,.91f,.89f,.42f);
            }else if(kind==WeatherField.PrecipitationKind.SLEET){
                float size=CloudConfig.SLEET_PARTICLE_SIZE.get()/100f;
                var sleet=buffers.getBuffer(RAIN_TYPE);
                quad(sleet,matrix,x+windX,y,z+windZ,.075f*size,.72f*size,.78f,.81f,.82f,.58f);
                if(CloudConfig.PARTICLE_MODE.get()!=CloudConfig.ParticleMode.TWO_D)
                    quad(sleet,matrix,x+windX,y,z+windZ,.075f*size,.72f*size,.78f,.81f,.82f,.44f,true);
                if((hash&3)==0)quad(buffers.getBuffer(SNOW_TYPE),matrix,x-windX,y,z-windZ,.19f*size,.19f*size,.88f,.89f,.87f,.64f);
            }else{
                float size=CloudConfig.RAIN_PARTICLE_SIZE.get()/100f;
                var rainOut=buffers.getBuffer(RAIN_TYPE);
                quad(rainOut,matrix,x+windX,y,z+windZ,.055f*size,1.45f*size,.70f,.70f,.67f,.68f);
                if(CloudConfig.PARTICLE_MODE.get()!=CloudConfig.ParticleMode.TWO_D)
                    quad(rainOut,matrix,x+windX,y,z+windZ,.055f*size,1.45f*size,.70f,.70f,.67f,.48f,true);
                if(CloudConfig.SPLASHES.get()&&py-ground<1.8&&((hash>>>25)&3)==0){
                    float splash=.12f*size;
                    quad(buffers.getBuffer(SNOW_TYPE),matrix,x,(float)(ground+.04-cam.y),z,splash,splash,.72f,.72f,.69f,.42f);
                }
            }
        }
        buffers.endBatch(RAIN_TYPE);buffers.endBatch(SNOW_TYPE);
    }
    /** Deterministic continuous world-space trajectory, intentionally independent of camera/player coordinates. */
    static double worldY(double phase,double time,double ground,double top,double speed){
        double span=Math.max(10,Math.min(58,top-ground));
        double cycle=phase*span-time*speed;
        cycle=cycle-Math.floor(cycle/span)*span;
        return ground+.08+cycle;
    }
    private static void horizontal(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                                   float x,float y,float z,float s,float r,float g,float b,float a){
        out.addVertex(m,x-s,y,z-s).setColor(r,g,b,a).setUv(0,0).setLight(0x00f000f0);
        out.addVertex(m,x+s,y,z-s).setColor(r,g,b,a).setUv(1,0).setLight(0x00f000f0);
        out.addVertex(m,x+s,y,z+s).setColor(r,g,b,a).setUv(1,1).setLight(0x00f000f0);
        out.addVertex(m,x-s,y,z+s).setColor(r,g,b,a).setUv(0,1).setLight(0x00f000f0);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                             float x,float y,float z,float w,float h,float r,float g,float b,float a){
        quad(out,m,x,y,z,w,h,r,g,b,a,false);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                             float x,float y,float z,float w,float h,float r,float g,float b,float a,boolean cross){
        if(cross){
            out.addVertex(m,x,y,z-w).setColor(r,g,b,a).setUv(0,1).setLight(0x00f000f0);
            out.addVertex(m,x,y,z+w).setColor(r,g,b,a).setUv(1,1).setLight(0x00f000f0);
            out.addVertex(m,x,y+h,z+w).setColor(r,g,b,a).setUv(1,0).setLight(0x00f000f0);
            out.addVertex(m,x,y+h,z-w).setColor(r,g,b,a).setUv(0,0).setLight(0x00f000f0);
        }else{
            out.addVertex(m,x-w,y,z).setColor(r,g,b,a).setUv(0,1).setLight(0x00f000f0);
            out.addVertex(m,x+w,y,z).setColor(r,g,b,a).setUv(1,1).setLight(0x00f000f0);
            out.addVertex(m,x+w,y+h,z).setColor(r,g,b,a*.72f).setUv(1,0).setLight(0x00f000f0);
            out.addVertex(m,x-w,y+h,z).setColor(r,g,b,a*.72f).setUv(0,0).setLight(0x00f000f0);
        }
    }
    private PrecipitationRenderer(){}
}
