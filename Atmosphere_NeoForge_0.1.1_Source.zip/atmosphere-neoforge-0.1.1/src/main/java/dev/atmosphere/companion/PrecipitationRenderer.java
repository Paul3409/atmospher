package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Lightweight procedural streak particles, clipped to the same field as the radar. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class PrecipitationRenderer {
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var cam=event.getCamera().getPosition();
        if(CloudConfig.PRECIPITATION_DENSITY.get()==0)return;
        double base=WeatherField.cloudBase();
        if(cam.y>base+8)return;
        var buffers=mc.renderBuffers().bufferSource();
        var renderType=WeatherCurtainRenderer.CURTAIN;
        var out=buffers.getBuffer(renderType);
        var matrix=event.getPoseStack().last().pose();
        double time=mc.level.getGameTime()+event.getPartialTick().getGameTimeDeltaTicks();
        int minX=(int)Math.floor((cam.x-28)/4),maxX=(int)Math.floor((cam.x+28)/4);
        int minZ=(int)Math.floor((cam.z-28)/4),maxZ=(int)Math.floor((cam.z+28)/4);
        for(int ix=minX;ix<=maxX;ix++)for(int iz=minZ;iz<=maxZ;iz++)for(int n=0;n<4;n++){
            long hash=((long)ix*73428767L)^((long)iz*912931L)^(n*19349663L);
            hash^=hash>>>13;hash*=1274126177L;hash^=hash>>>16;
            double px=ix*4+((hash&1023)/1023.0)*4,pz=iz*4+(((hash>>>10)&1023)/1023.0)*4;
            float intensity=WeatherField.precipitation(px,pz);
            if(intensity<=0||((hash>>>20)&1023)/1023.0>intensity*.8)continue;
            var kind=WeatherField.precipitationKind(px,cam.y,pz);
            if(kind==WeatherField.PrecipitationKind.SNOW&&!CloudConfig.OPTICAL_SNOW.get())continue;
            double phase=(((hash>>>32)&65535)/65535.0)*26;
            double speed=kind==WeatherField.PrecipitationKind.SNOW?.20:
                kind==WeatherField.PrecipitationKind.SLEET?.60:1.2;
            double py=cam.y-12+Math.floorMod((long)Math.floor(phase-time*speed),26);
            if(py>WeatherField.cloudBaseAt(px,pz))continue;
            float x=(float)(px-cam.x),y=(float)(py-cam.y),z=(float)(pz-cam.z);
            if(kind==WeatherField.PrecipitationKind.SNOW){
                float drift=(float)Math.sin(time*.07+phase)*.16f;
                quad(out,matrix,x+drift,y,z,.065f,.065f,.90f,.94f,1f,.72f);
                quad(out,matrix,x+drift,y,z,.065f,.065f,.90f,.94f,1f,.72f,true);
            }else if(kind==WeatherField.PrecipitationKind.SLEET){
                quad(out,matrix,x,y,z,.025f,.55f,.78f,.83f,.90f,.55f);
            }else quad(out,matrix,x,y,z,.014f,1.25f,.62f,.67f,.74f,.55f);
        }
        buffers.endBatch(renderType);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                             float x,float y,float z,float w,float h,float r,float g,float b,float a){
        quad(out,m,x,y,z,w,h,r,g,b,a,false);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,org.joml.Matrix4f m,
                             float x,float y,float z,float w,float h,float r,float g,float b,float a,boolean cross){
        if(cross){
            out.addVertex(m,x,y,z-w).setColor(r,g,b,a);
            out.addVertex(m,x,y,z+w).setColor(r,g,b,a);
            out.addVertex(m,x,y+h,z+w).setColor(r,g,b,a);
            out.addVertex(m,x,y+h,z-w).setColor(r,g,b,a);
        }else{
            out.addVertex(m,x-w,y,z).setColor(r,g,b,a);
            out.addVertex(m,x+w,y,z).setColor(r,g,b,a);
            out.addVertex(m,x+w,y+h,z).setColor(r,g,b,a*.45f);
            out.addVertex(m,x-w,y+h,z).setColor(r,g,b,a*.45f);
        }
    }
    private PrecipitationRenderer(){}
}
