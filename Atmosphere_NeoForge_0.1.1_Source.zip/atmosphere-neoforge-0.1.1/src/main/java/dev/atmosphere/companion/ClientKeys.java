package dev.atmosphere.companion;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.lwjgl.glfw.GLFW;

public final class ClientKeys {
    private static final String CATEGORY="key.categories.atmosphere_companion";
    public static final KeyMapping RADAR=new KeyMapping("key.atmosphere_companion.radar",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_R,CATEGORY);
    public static final KeyMapping MENU=new KeyMapping("key.atmosphere_companion.menu",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_M,CATEGORY);
    @EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
    public static final class Registration {
        @SubscribeEvent public static void register(RegisterKeyMappingsEvent event){event.register(RADAR);event.register(MENU);}
    }
    @EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
    public static final class Handler {
        @SubscribeEvent public static void tick(ClientTickEvent.Post event){
            var mc=Minecraft.getInstance();
            if(mc.player==null||mc.screen!=null)return;
            while(RADAR.consumeClick())mc.setScreen(new WeatherMapScreen(new WeatherSimulatorScreen()));
            while(MENU.consumeClick())mc.setScreen(new WeatherSimulatorScreen());
        }
    }
    private ClientKeys(){}
}
