package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Local, softly layered weather ambience sourced from the original Fabric edition. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class WeatherSoundscape {
    private static long nextRain,nextWind,nextThunder;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null||!CloudConfig.WEATHER_SOUNDS.get())return;
        long now=mc.level.getGameTime();
        double x=mc.player.getX(),z=mc.player.getZ();
        float rain=WeatherField.precipitation(x,z);
        boolean indoors=!mc.level.canSeeSky(mc.player.blockPosition().above());
        float damping=indoors?(float)(1-CloudConfig.INDOOR_DAMPING.get()/100.0*.82):1;
        float master=CloudConfig.SOUND_VOLUME.get()/100f;
        if(rain>.02f&&now>=nextRain){
            String sound=rain>.68?"rain_heavy":rain>.28?"rain_medium":"rain_light";
            play(mc,sound,master*CloudConfig.RAIN_VOLUME.get()/100f*damping*(.22f+.70f*rain),.96f+rain*.06f);
            nextRain=now+112;
        }
        float wind=(float)(CloudConfig.WIND_SPEED.get()/5.0);
        if(wind>.08&&now>=nextWind){
            play(mc,"wind_forest",master*CloudConfig.WIND_VOLUME.get()/100f*damping*(.10f+.38f*wind),.92f+wind*.12f);
            nextWind=now+116;
        }
        var cell=WeatherCells.sample(x,z,now);
        if(cell.type()>=WeatherCells.THUNDER&&cell.development()>.42&&now>=nextThunder){
            double chance=.0045*CloudConfig.LIGHTNING_FREQUENCY.get()/100.0*cell.development();
            if(mc.level.random.nextDouble()<chance){
                play(mc,"thunder_rumble",master*CloudConfig.THUNDER_VOLUME.get()/100f*(.35f+.45f*(float)cell.development()),.87f+(float)mc.level.random.nextDouble()*.18f);
                nextThunder=now+100+mc.level.random.nextInt(180);
            }
        }
    }
    private static void play(Minecraft mc,String name,float volume,float pitch){
        if(volume<=.005f)return;
        var id=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,name);
        mc.getSoundManager().play(new SimpleSoundInstance(id,SoundSource.WEATHER,volume,pitch,
            RandomSource.create(),false,0,SoundInstance.Attenuation.NONE,0,0,0,true));
    }
    private WeatherSoundscape(){}
}
