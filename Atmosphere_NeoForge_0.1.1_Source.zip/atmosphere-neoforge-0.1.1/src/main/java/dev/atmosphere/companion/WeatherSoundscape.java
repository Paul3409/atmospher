package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Persistent Fabric sound layers with per-tick crossfades; only thunder is event based. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class WeatherSoundscape {
    private static Object soundLevel;
    private static FadingLoop light,medium,heavy,wind;
    private static long nextThunder;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null){shutdown();return;}
        if(soundLevel!=mc.level){shutdown();soundLevel=mc.level;
            light=start(mc,"rain_light");medium=start(mc,"rain_medium");heavy=start(mc,"rain_heavy");wind=start(mc,"wind_forest");
        }
        long now=mc.level.getGameTime();
        float rainValue=WeatherField.precipitation(mc.player.getX(),mc.player.getZ());
        boolean enabled=CloudConfig.WEATHER_SOUNDS.get();
        boolean indoors=!mc.level.canSeeSky(mc.player.blockPosition().above());
        float damping=indoors?(float)(1-CloudConfig.INDOOR_DAMPING.get()/100.0*.82):1;
        float master=enabled?CloudConfig.SOUND_VOLUME.get()/100f:0;
        float rainMaster=master*CloudConfig.RAIN_VOLUME.get()/100f*damping;
        float low=1-smooth(.18f,.48f,rainValue),high=smooth(.52f,.82f,rainValue);
        float mid=Math.max(0,1-Math.abs(rainValue-.48f)/.36f);
        light.target=rainValue<.015f?0:rainMaster*rainValue*low*.74f;
        medium.target=rainValue<.12f?0:rainMaster*mid*(.20f+.63f*rainValue);
        heavy.target=rainMaster*high*(.28f+.65f*rainValue);
        float windValue=(float)(CloudConfig.WIND_SPEED.get()/5.0);
        wind.target=master*CloudConfig.WIND_VOLUME.get()/100f*damping*windValue*.46f;
        var cell=WeatherCells.sample(mc.player.getX(),mc.player.getZ(),now);
        if(enabled&&cell.type()>=WeatherCells.THUNDER&&cell.development()>.42&&now>=nextThunder){
            double chance=.0045*CloudConfig.LIGHTNING_FREQUENCY.get()/100.0*cell.development();
            if(mc.level.random.nextDouble()<chance){playThunder(mc,master*CloudConfig.THUNDER_VOLUME.get()/100f*(.35f+.45f*(float)cell.development()));
                nextThunder=now+100+mc.level.random.nextInt(180);}
        }
    }
    private static float smooth(float a,float b,float x){float t=Mth.clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);}
    private static FadingLoop start(Minecraft mc,String name){var loop=new FadingLoop(name);mc.getSoundManager().play(loop);return loop;}
    private static void playThunder(Minecraft mc,float volume){
        var id=ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,"thunder_rumble");
        mc.getSoundManager().play(new SimpleSoundInstance(id,SoundSource.WEATHER,volume,.87f+mc.level.random.nextFloat()*.18f,
            RandomSource.create(),false,0,SoundInstance.Attenuation.NONE,0,0,0,true));
    }
    private static void shutdown(){if(light!=null)light.finish();if(medium!=null)medium.finish();if(heavy!=null)heavy.finish();if(wind!=null)wind.finish();
        light=medium=heavy=wind=null;soundLevel=null;}
    private static final class FadingLoop extends AbstractTickableSoundInstance {
        float target;
        FadingLoop(String name){super(SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(AtmosphereCompanion.MOD_ID,name)),
            SoundSource.WEATHER,RandomSource.create());looping=true;delay=0;attenuation=Attenuation.NONE;relative=true;volume=0;pitch=1;}
        @Override public void tick(){volume+=(target-volume)*.045f;if(volume<.0005f&&target==0)volume=0;}
        void finish(){stop();}
    }
    private WeatherSoundscape(){}
}
