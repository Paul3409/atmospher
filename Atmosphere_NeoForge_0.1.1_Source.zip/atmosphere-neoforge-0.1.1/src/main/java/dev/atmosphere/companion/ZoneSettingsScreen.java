package dev.atmosphere.companion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Locale;

/** Precise weather and vertical range controls for the selected freehand zone. */
public final class ZoneSettingsScreen extends Screen {
    private final Screen parent;private int page;
    ZoneSettingsScreen(Screen parent){super(Component.literal("Wetterzone einstellen"));this.parent=parent;}
    @Override protected void init(){
        var zone=WeatherZoneManager.selected();if(zone==null){onClose();return;}
        int x=width/2-130,y=height/2-116,w=260;
        if(page==0){
            addRenderableWidget(Button.builder(Component.literal("Zone: "+(zone.enabled?"AN":"AUS")),b->{zone.enabled=!zone.enabled;save();}).bounds(x,y,w,20).build());
            addRenderableWidget(Button.builder(Component.literal("Niederschlag: "+zone.precipitation),b->{var v=CloudConfig.PrecipitationSelection.values();zone.precipitation=v[(zone.precipitation.ordinal()+1)%v.length];save();}).bounds(x,y+24,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,0,100,()->zone.intensity,v->{zone.intensity=v;WeatherZoneManager.save();},v->"Staerke: "+v+"%"));
            addRenderableWidget(new AtmosphereSlider(x,y+72,w,-40,45,()->zone.temperature,v->{zone.temperature=v;WeatherZoneManager.save();},v->String.format(Locale.ROOT,"Temperatur: %.1f °C",v)));
            addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,-64,384,()->zone.snowLine,v->{zone.snowLine=v;WeatherZoneManager.save();},v->"Schneefallgrenze: Y "+v));
            addRenderableWidget(AtmosphereSlider.integer(x,y+120,w,0,48,()->zone.snowTransition,v->{zone.snowTransition=v;WeatherZoneManager.save();},v->"Schneeregen: ±"+v+" Bloecke"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+144,w,-64,384,()->zone.minY,v->{zone.minY=Math.min(v,zone.maxY);WeatherZoneManager.save();},v->"Zone ab Hoehe Y "+v));
            addRenderableWidget(AtmosphereSlider.integer(x,y+168,w,-64,384,()->zone.maxY,v->{zone.maxY=Math.max(v,zone.minY);WeatherZoneManager.save();},v->"Zone bis Hoehe Y "+v));
        }else{
            addRenderableWidget(AtmosphereSlider.integer(x,y,w,0,100,()->zone.fogDensity,v->{zone.fogDensity=v;WeatherZoneManager.save();},v->"Nebeldichte: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,0,384,()->zone.fogStart,v->{zone.fogStart=v;WeatherZoneManager.save();},v->"Nebelbeginn: "+v+" Bloecke"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,8,512,()->zone.fogEnd,v->{zone.fogEnd=v;WeatherZoneManager.save();},v->"Nebelende: "+v+" Bloecke"));
            addRenderableWidget(Button.builder(Component.literal("Wind aus: "+zone.windDirection),b->{var v=CloudConfig.WindDirection.values();zone.windDirection=v[(zone.windDirection.ordinal()+1)%v.length];save();}).bounds(x,y+72,w,20).build());
            addRenderableWidget(new AtmosphereSlider(x,y+96,w,0,5,()->zone.windSpeed,v->{zone.windSpeed=v;WeatherZoneManager.save();},v->String.format(Locale.ROOT,"Windstaerke: %.2f",v)));
            addRenderableWidget(AtmosphereSlider.integer(x,y+120,w,0,100,()->zone.lightning,v->{zone.lightning=v;WeatherZoneManager.save();},v->"Blitzhaeufigkeit: "+v+"%"));
        }
        addRenderableWidget(Button.builder(Component.literal("<"),b->{page=1-page;rebuildWidgets();}).bounds(x,y+196,36,20).build());
        addRenderableWidget(Button.builder(Component.literal(page==0?"Wetter & Hoehe":"Nebel, Wind & Gewitter"),b->{}).bounds(x+40,y+196,180,20).build());
        addRenderableWidget(Button.builder(Component.literal(">"),b->{page=1-page;rebuildWidgets();}).bounds(x+224,y+196,36,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zurueck zur Karte"),b->onClose()).bounds(x,y+220,w,20).build());
    }
    private void save(){WeatherZoneManager.save();rebuildWidgets();}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){super.render(gui,mouseX,mouseY,partialTick);var z=WeatherZoneManager.selected();if(z!=null)gui.drawCenteredString(font,z.name+" | "+z.cells.size()+" Rasterfelder",width/2,height/2-138,0xFFFFFF);}
    @Override public void onClose(){WeatherZoneManager.save();minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
