package dev.atmosphere.companion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Locale;

/** Top-down world map for painting and erasing precise local weather masks. */
public final class WeatherMapScreen extends Screen {
    private final Screen parent;
    private double centerX,centerZ;
    private int blocksPerPixel=4;
    private int brush=12;
    private boolean erase;
    private boolean painting;
    private int mapX,mapY,mapW,mapH;
    WeatherMapScreen(Screen parent){super(Component.literal("Atmosphere – Wetterkarte"));this.parent=parent;}
    @Override protected void init(){
        mapW=Math.min(420,width-24);mapH=Math.min(238,height-94);mapX=(width-mapW)/2;mapY=30;
        if(centerX==0&&centerZ==0&&minecraft.player!=null){centerX=minecraft.player.getX();centerZ=minecraft.player.getZ();}
        int y=height-56;
        addRenderableWidget(Button.builder(Component.literal("Neue Zone"),b->{var z=WeatherZoneManager.createAt(centerX,centerZ);erase=false;rebuildWidgets();}).bounds(width/2-210,y,82,20).build());
        addRenderableWidget(Button.builder(Component.literal(erase?"Radieren":"Malen"),b->{erase=!erase;rebuildWidgets();}).bounds(width/2-124,y,72,20).build());
        addRenderableWidget(Button.builder(Component.literal("Pinsel: "+brush),b->{brush=brush>=48?4:brush*2;rebuildWidgets();}).bounds(width/2-48,y,82,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zone einstellen"),b->{if(WeatherZoneManager.selected()!=null)minecraft.setScreen(new ZoneSettingsScreen(this));}).bounds(width/2+38,y,112,20).build());
        addRenderableWidget(Button.builder(Component.literal("Loeschen"),b->{WeatherZoneManager.deleteSelected();rebuildWidgets();}).bounds(width/2+154,y,70,20).build());
        addRenderableWidget(Button.builder(Component.literal("< Zone"),b->{WeatherZoneManager.select(selectedIndex()-1);rebuildWidgets();}).bounds(width/2-210,y+24,70,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zone >"),b->{WeatherZoneManager.select(selectedIndex()+1);rebuildWidgets();}).bounds(width/2-136,y+24,70,20).build());
        addRenderableWidget(Button.builder(Component.literal("Zum Spieler"),b->{if(minecraft.player!=null){centerX=minecraft.player.getX();centerZ=minecraft.player.getZ();}}).bounds(width/2-62,y+24,96,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(width/2+120,y+24,104,20).build());
    }
    private int selectedIndex(){var selected=WeatherZoneManager.selected();return selected==null?0:WeatherZoneManager.zones().indexOf(selected);}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        gui.fill(mapX-2,mapY-2,mapX+mapW+2,mapY+mapH+2,0xFF82909A);
        drawTerrain(gui);drawZones(gui);
        int cx=mapX+mapW/2,cy=mapY+mapH/2;gui.fill(cx-2,cy,cx+3,cy+1,0xFFFFFFFF);gui.fill(cx,cy-2,cx+1,cy+3,0xFFFFFFFF);
        gui.drawCenteredString(font,title,width/2,9,0xFFFFFF);
        var zone=WeatherZoneManager.selected();String label=zone==null?"Keine Zone – zuerst 'Neue Zone' waehlen":
            zone.name+" | "+zone.cells.size()+" Felder | Y "+zone.minY+" bis "+zone.maxY;
        gui.drawCenteredString(font,label,width/2,mapY+mapH+5,zone==null?0xFFBBBBBB:0xFFE6E6E6);
        if(inMap(mouseX,mouseY)){
            double wx=worldX(mouseX),wz=worldZ(mouseY);
            gui.drawString(font,String.format(Locale.ROOT,"X %.0f  Z %.0f | %d Block/Pixel | Linksklick: %s | Rechtsziehen: Karte",wx,wz,blocksPerPixel,erase?"radieren":"malen"),mapX+4,mapY+4,0xFFFFFFFF,false);
        }
    }
    private void drawTerrain(GuiGraphics gui){
        if(minecraft.level==null){gui.fill(mapX,mapY,mapX+mapW,mapY+mapH,0xFF25303A);return;}
        int step=4;
        for(int px=0;px<mapW;px+=step)for(int py=0;py<mapH;py+=step){
            int wx=(int)Math.floor(centerX+(px-mapW/2.0)*blocksPerPixel);
            int wz=(int)Math.floor(centerZ+(py-mapH/2.0)*blocksPerPixel);
            int h=minecraft.level.getHeight(Heightmap.Types.MOTION_BLOCKING,wx,wz);
            var pos=net.minecraft.core.BlockPos.containing(wx,h-1,wz);
            boolean water=minecraft.level.hasChunkAt(pos)&&!minecraft.level.getFluidState(pos).isEmpty();
            int shade=Math.max(0,Math.min(55,h-minecraft.level.getSeaLevel()+22));
            int color=water?0xFF345A78:0xFF000000|((45+shade)<<16)|((72+shade)<<8)|(43+shade/2);
            gui.fill(mapX+px,mapY+py,Math.min(mapX+mapW,mapX+px+step),Math.min(mapY+mapH,mapY+py+step),color);
        }
    }
    private void drawZones(GuiGraphics gui){
        var selected=WeatherZoneManager.selected();
        for(var zone:WeatherZoneManager.zones()){
            int color=zone==selected?0x9946D9FF:0x6644FF86;
            for(long key:zone.cells){
                double wx=(ManualWeatherZone.keyX(key)+.5)*zone.cellSize;
                double wz=(ManualWeatherZone.keyZ(key)+.5)*zone.cellSize;
                int px=(int)Math.round(mapX+mapW/2+(wx-centerX)/blocksPerPixel);
                int py=(int)Math.round(mapY+mapH/2+(wz-centerZ)/blocksPerPixel);
                int size=Math.max(1,(int)Math.ceil(zone.cellSize/(double)blocksPerPixel));
                if(px+size<mapX||py+size<mapY||px>=mapX+mapW||py>=mapY+mapH)continue;
                gui.fill(Math.max(mapX,px-size/2),Math.max(mapY,py-size/2),Math.min(mapX+mapW,px-size/2+size),Math.min(mapY+mapH,py-size/2+size),color);
            }
        }
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button){
        if(inMap(mouseX,mouseY)){if(button==0){painting=true;paint(mouseX,mouseY);return true;}if(button==1)return true;}
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override public boolean mouseDragged(double mouseX,double mouseY,int button,double dragX,double dragY){
        if(button==0&&painting){paint(mouseX,mouseY);return true;}
        if(button==1&&inMap(mouseX,mouseY)){centerX-=dragX*blocksPerPixel;centerZ-=dragY*blocksPerPixel;return true;}
        return super.mouseDragged(mouseX,mouseY,button,dragX,dragY);
    }
    @Override public boolean mouseReleased(double mouseX,double mouseY,int button){if(button==0&&painting){painting=false;WeatherZoneManager.save();return true;}return super.mouseReleased(mouseX,mouseY,button);}
    @Override public boolean mouseScrolled(double mouseX,double mouseY,double scrollX,double scrollY){
        if(inMap(mouseX,mouseY)){blocksPerPixel=scrollY>0?Math.max(1,blocksPerPixel/2):Math.min(32,blocksPerPixel*2);return true;}
        return super.mouseScrolled(mouseX,mouseY,scrollX,scrollY);
    }
    private void paint(double mouseX,double mouseY){var zone=WeatherZoneManager.selected();if(zone!=null)zone.paint(worldX(mouseX),worldZ(mouseY),brush,erase);}
    private boolean inMap(double x,double y){return x>=mapX&&x<mapX+mapW&&y>=mapY&&y<mapY+mapH;}
    private double worldX(double mouseX){return centerX+(mouseX-(mapX+mapW/2.0))*blocksPerPixel;}
    private double worldZ(double mouseY){return centerZ+(mouseY-(mapY+mapH/2.0))*blocksPerPixel;}
    @Override public void onClose(){WeatherZoneManager.save();minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
