package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.Locale;

/** Fabric 1.2.12 style radar backed by the exact field used by clouds and precipitation. */
public final class RadarScreen extends Screen {
    private static final int[] RANGES={500,1000,1500,2500,5000};
    private WeatherCells.Sample[] cells=new WeatherCells.Sample[0];
    private double[] rates=new double[0],dbz=new double[0],radial=new double[0],pressure=new double[0];
    private WeatherField.PrecipitationKind[] kinds=new WeatherField.PrecipitationKind[0];
    private int cols,rows,left,top,mapSize; private long cacheTick=Long.MIN_VALUE; private double cacheX,cacheZ;
    public RadarScreen(){super(Component.literal("Atmosphere – Wetterradar"));}

    @Override protected void init(){
        int x=width/2-166,y=4;
        addRenderableWidget(Button.builder(Component.literal("Ansicht: "+viewLabel()),b->{
            var all=CloudConfig.RadarView.values();var v=CloudConfig.RADAR_VIEW.get();
            CloudConfig.RADAR_VIEW.set(all[(v.ordinal()+1)%all.length]);rebuildWidgets();
        }).bounds(x,y,160,20).build());
        addRenderableWidget(Button.builder(Component.literal("Reichweite: "+CloudConfig.RADAR_RANGE.get()+" Bl."),b->{
            int current=CloudConfig.RADAR_RANGE.get(),next=RANGES[0];
            for(int r:RANGES)if(r>current){next=r;break;}
            CloudConfig.RADAR_RANGE.set(next);invalidate();rebuildWidgets();
        }).bounds(x+166,y,160,20).build());
        addRenderableWidget(Button.builder(Component.literal("Qualitaet: "+CloudConfig.RADAR_QUALITY.get()),b->{
            var all=CloudConfig.RadarQuality.values();var q=CloudConfig.RADAR_QUALITY.get();
            CloudConfig.RADAR_QUALITY.set(all[(q.ordinal()+1)%all.length]);invalidate();rebuildWidgets();
        }).bounds(x,y+24,160,20).build());
        addRenderableWidget(Button.builder(Component.literal("Isobaren: "+on(CloudConfig.RADAR_ISOBARS.get())),b->{
            CloudConfig.RADAR_ISOBARS.set(!CloudConfig.RADAR_ISOBARS.get());rebuildWidgets();
        }).bounds(x+166,y+24,160,20).build());
    }
    private void invalidate(){cacheTick=Long.MIN_VALUE;}
    private String viewLabel(){return switch(CloudConfig.RADAR_VIEW.get()){case DBZ->"Radar dBZ";case ZELLEN->"Zellen";case DOPPLER->"Doppler";case LUFTDRUCK->"Luftdruck";};}
    private static String on(boolean b){return b?"AN":"AUS";}

    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        var mc=Minecraft.getInstance();var player=mc.player;if(player==null||mc.level==null)return;
        mapSize=Math.max(120,Math.min(width-28,height-142));left=(width-mapSize)/2;top=58;
        int wanted=new int[]{61,81,101,121}[CloudConfig.RADAR_QUALITY.get().ordinal()];
        long tick=mc.level.getGameTime();double px=player.getX(),pz=player.getZ();
        if(cols!=wanted||tick-cacheTick>=100||Math.hypot(px-cacheX,pz-cacheZ)>CloudConfig.RADAR_RANGE.get()/12.0)
            scan(px,pz,tick,wanted,player.getY());
        var view=CloudConfig.RADAR_VIEW.get();
        for(int z=0;z<rows;z++)for(int x=0;x<cols;x++){
            int i=z*cols+x;int color=switch(view){case DBZ->RadarReflectivity.color(dbz[i]);case ZELLEN->cellColor(cells[i]);case DOPPLER->velocityColor(radial[i]);case LUFTDRUCK->pressureColor(pressure[i]);};
            gui.fill(left+x*mapSize/cols,top+z*mapSize/rows,left+(x+1)*mapSize/cols,top+(z+1)*mapSize/rows,color);
        }
        if(CloudConfig.RADAR_ISOBARS.get()||view==CloudConfig.RadarView.LUFTDRUCK)drawIsobars(gui);
        if(CloudConfig.RADAR_FRONTS.get())drawFronts(gui);
        if(CloudConfig.RADAR_LIGHTNING.get()&&(view==CloudConfig.RadarView.DBZ||view==CloudConfig.RadarView.ZELLEN))drawLightning(gui);
        int middle=mapSize/2;gui.fill(left,top+middle,left+mapSize,top+middle+1,0x553F5565);gui.fill(left+middle,top,left+middle+1,top+mapSize,0x553F5565);
        gui.fill(left+middle-2,top+middle-2,left+middle+3,top+middle+3,0xFFFFFFFF);gui.drawString(font,"N ^",left+6,top+5,0xFFFFFFFF,false);
        gui.drawCenteredString(font,title,width/2,48,0xFFFFFFFF);
        if(view==CloudConfig.RadarView.DBZ)drawScale(gui,left,top+mapSize+5,mapSize);else gui.drawCenteredString(font,legend(view),width/2,top+mapSize+7,0xFFCDE3F0);
        if(CloudConfig.RADAR_TOOLTIPS.get())drawReading(gui,mouseX,mouseY,view);
    }
    private void scan(double px,double pz,long tick,int count,double y){
        cols=rows=count;int n=count*count;cells=new WeatherCells.Sample[n];rates=new double[n];dbz=new double[n];radial=new double[n];pressure=new double[n];kinds=new WeatherField.PrecipitationKind[n];
        cacheX=px;cacheZ=pz;cacheTick=tick;double range=CloudConfig.RADAR_RANGE.get();
        for(int z=0;z<count;z++)for(int x=0;x<count;x++){
            int i=z*count+x;double wx=px+((x+.5)/count*2-1)*range,wz=pz+((z+.5)/count*2-1)*range;
            cells[i]=WeatherCells.sample(wx,wz,tick);rates[i]=WeatherField.precipitationMmH(wx,wz);
            kinds[i]=rates[i]<.1?WeatherField.PrecipitationKind.NONE:WeatherField.kind(WeatherField.temperature(wx,y,wz));dbz[i]=RadarReflectivity.dbz(rates[i],kinds[i]);pressure[i]=cells[i].pressure();
            double dx=wx-px,dz=wz-pz,len=Math.max(1,Math.hypot(dx,dz));radial[i]=(cells[i].velocityX()*dx/len+cells[i].velocityZ()*dz/len)*.42;
        }
    }
    private void drawReading(GuiGraphics gui,int mx,int my,CloudConfig.RadarView view){
        int y=top+mapSize+(view==CloudConfig.RadarView.DBZ?27:20);
        if(mx<left||mx>=left+mapSize||my<top||my>=top+mapSize){gui.drawCenteredString(font,"Maus auf Karte: Messwerte anzeigen",width/2,y,0xFF7FA8BC);return;}
        int ix=Math.min(cols-1,(mx-left)*cols/mapSize),iz=Math.min(rows-1,(my-top)*rows/mapSize),i=iz*cols+ix;
        String s=switch(view){case DBZ->Double.isFinite(dbz[i])?String.format(Locale.GERMANY,"~%.1f dBZ | %.1f mm/h | %s",dbz[i],rates[i],kindName(kinds[i])):String.format(Locale.GERMANY,"-- dBZ (kein Echo) | %.2f mm/h | Trocken",rates[i]);
            case ZELLEN->String.format(Locale.GERMANY,"%s | %s | Intensitaet %.0f%%",cells[i].typeName(),cells[i].stage(),cells[i].development()*100);
            case DOPPLER->String.format(Locale.GERMANY,"Radialwind: %+.1f km/h | %s",radial[i],cells[i].typeName());case LUFTDRUCK->String.format(Locale.GERMANY,"Luftdruck: %.1f hPa | Feuchte %.0f%%",pressure[i],cells[i].humidity()*100);};
        int tx=Math.max(4,Math.min(width-font.width(s)-8,mx+10)),ty=Math.max(top+3,Math.min(top+mapSize-14,my+12));gui.fill(tx-3,ty-2,tx+font.width(s)+4,ty+11,0xE90D1823);gui.drawString(font,s,tx,ty,0xFFFDFAE7,false);gui.drawCenteredString(font,s,width/2,y,0xFFFFFFAE);
    }
    private void drawScale(GuiGraphics g,int x,int y,int w){for(int i=0;i<w;i++)g.fill(x+i,y,x+i+1,y+5,RadarReflectivity.color(5+70.0*i/Math.max(1,w-1)));int[] ticks=w<260?new int[]{5,25,45,65,75}:new int[]{5,15,25,35,45,55,65,75};for(int v:ticks){String s=Integer.toString(v);int px=x+(v-5)*w/70;px=Math.max(x,Math.min(x+w-font.width(s),px-font.width(s)/2));g.drawString(font,s,px,y+7,0xFFCDE3F0,false);}}
    private void drawIsobars(GuiGraphics g){for(int z=1;z<rows;z++)for(int x=1;x<cols;x++){int i=z*cols+x,l=i-1,u=i-cols;int a=(int)Math.floor(pressure[i]/4),b=(int)Math.floor(pressure[l]/4),c=(int)Math.floor(pressure[u]/4);if(a!=b||a!=c){int px=left+x*mapSize/cols,py=top+z*mapSize/rows;g.fill(px,py,px+1,py+1,0x99E8EDF0);}}}
    private void drawFronts(GuiGraphics g){
        for(int z=2;z<rows-2;z+=2)for(int x=2;x<cols-2;x+=2){int i=z*cols+x;
            double gx=pressure[i+1]-pressure[i-1],gz=pressure[i+cols]-pressure[i-cols];
            if(Math.hypot(gx,gz)<.44)continue;
            int px=left+x*mapSize/cols,py=top+z*mapSize/rows;
            int tint=cells[i].humidity()>.64?0xDD3B8FFF:0xDDFF6166;g.fill(px,py,px+2,py+2,tint);
        }
    }
    private void drawLightning(GuiGraphics g){
        long bucket=cacheTick/9;
        for(int z=1;z<rows-1;z++)for(int x=1;x<cols-1;x++){int i=z*cols+x;var s=cells[i];
            if(s.type()<WeatherCells.THUNDER||s.development()<.64||rates[i]<18)continue;
            long h=s.id()^(x*341873128712L)^(z*132897987541L)^bucket*31;
            if((h&1023)!=0)continue;int px=left+x*mapSize/cols,py=top+z*mapSize/rows;g.drawString(font,"*",px-2,py-4,0xFFFFFF73,false);
        }
    }
    private static int cellColor(WeatherCells.Sample s){if(s.cloud()<.02)return 0xF00D1820;double v=Math.min(1,s.development());int base=s.type()==WeatherCells.SEVERE?0xFFFF3C29:s.type()==WeatherCells.SQUALL?0xFFFF9A2E:s.type()==WeatherCells.THUNDER?0xFFF2D33D:s.type()==WeatherCells.SHOWER?0xFF3ED36C:0xFF66869A;return blend(0xFF16252E,base,(float)(.25+.75*v));}
    private static int velocityColor(double v){double f=Math.min(1,Math.abs(v)/55);return v<0?blend(0xFF77777C,0xFF00D85A,(float)f):blend(0xFF77777C,0xFFFF3535,(float)f);}
    private static int pressureColor(double p){return blend(0xFF284B9B,0xFFD24A3A,(float)Math.max(0,Math.min(1,(p-980)/65)));}
    private static int blend(int a,int b,float t){int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t),g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t),bl=(int)((a&255)*(1-t)+(b&255)*t);return 0xFF000000|(r<<16)|(g<<8)|bl;}
    private static String kindName(WeatherField.PrecipitationKind k){return switch(k){case RAIN->"Regen";case SLEET->"Schneeregen";case SNOW->"Schnee";default->"Trocken";};}
    private static String legend(CloudConfig.RadarView v){return switch(v){case ZELLEN->"Zelltyp, Entwicklung und Organisation";case DOPPLER->"Gruen: zum Radar | Rot: vom Radar";case LUFTDRUCK->"Bodendruck in hPa | Linien: 4 hPa";default->"";};}
    @Override public boolean isPauseScreen(){return false;}
}
