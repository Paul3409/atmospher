package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Radar samples the exact same world-space precipitation function as particles. */
public final class RadarScreen extends Screen {
    public RadarScreen(){super(Component.literal("Atmosphere – Niederschlagsradar"));}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        int count=41,cell=Math.max(3,Math.min(8,(height-46)/count)),left=(width-count*cell)/2,top=(height-count*cell)/2;
        var player=Minecraft.getInstance().player;
        if(player==null)return;
        double px=player.getX(),pz=player.getZ();
        for(int z=0;z<count;z++)for(int x=0;x<count;x++){
            float rain=WeatherField.precipitation(px+(x-count/2)*8,pz+(z-count/2)*8);
            int color=rain<.03?0xCC17242E:rain<.25?0xDD237B70:rain<.55?0xDD3AC248:rain<.8?0xDDF4CE36:0xDDEF6045;
            gui.fill(left+x*cell,top+z*cell,left+(x+1)*cell-1,top+(z+1)*cell-1,color);
        }
        gui.fill(left+count/2*cell+2,top+count/2*cell+2,left+count/2*cell+6,top+count/2*cell+6,0xFFFFFFFF);
        gui.drawCenteredString(font,title,width/2,top-15,0xFFFFFF);
        gui.drawCenteredString(font,"Mitte: Spieler  |  8 Bloecke pro Feld  |  Grau: trocken",width/2,top+count*cell+6,0xFFFFFF);
    }
    @Override public boolean isPauseScreen(){return false;}
}
