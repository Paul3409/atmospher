package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Radar samples the exact same world-space precipitation function as particles. */
public final class RadarScreen extends Screen {
    public RadarScreen(){super(Component.literal("Atmosphere – Niederschlagsradar"));}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        int count=101,cell=Math.max(2,Math.min(4,(height-74)/count)),size=count*cell;
        int left=(width-size)/2,top=(height-size)/2;
        var player=Minecraft.getInstance().player;
        if(player==null)return;
        double px=player.getX(),pz=player.getZ();
        int zoom=CloudConfig.RADAR_ZOOM.get();
        for(int z=0;z<count;z++)for(int x=0;x<count;x++){
            double wx=px+(x-count/2)*zoom,wz=pz+(z-count/2)*zoom;
            float rain=(WeatherField.precipitation(wx,wz)+WeatherField.precipitation(wx+zoom*.5,wz)+
                WeatherField.precipitation(wx,wz+zoom*.5)+WeatherField.precipitation(wx+zoom*.5,wz+zoom*.5))*.25f;
            var kind=WeatherField.precipitationKind(wx,player.getY(),wz);
            int color=radarColor(rain,kind);
            gui.fill(left+x*cell,top+z*cell,left+(x+1)*cell,top+(z+1)*cell,color);
        }
        int middle=count/2*cell;
        gui.fill(left,top+middle,left+size,top+middle+1,0x553F5565);
        gui.fill(left+middle,top,left+middle+1,top+size,0x553F5565);
        gui.fill(left+middle-2,top+middle-2,left+middle+3,top+middle+3,0xFFFFFFFF);
        gui.drawString(font,"N",left+size/2-3,top+3,0xFFFFFFFF,false);
        gui.drawCenteredString(font,title,width/2,top-15,0xFFFFFF);
        gui.drawCenteredString(font,zoom+" Bloecke/Pixel  |  Blau: Schnee  |  Violett: Schneeregen  |  Gruen–Rot: Regen",
            width/2,top+size+6,0xFFFFFF);
    }
    private static int radarColor(float value,WeatherField.PrecipitationKind kind){
        if(value<.015f)return 0xE3152028;
        value=Math.max(0,Math.min(1,value));
        if(kind==WeatherField.PrecipitationKind.SNOW)return blend(0xFFBFE9FF,0xFF2879D0,value);
        if(kind==WeatherField.PrecipitationKind.SLEET)return blend(0xFFD2B8F2,0xFF7350A8,value);
        if(value<.35f)return blend(0xFF1A7D70,0xFF49D455,value/.35f);
        if(value<.7f)return blend(0xFF49D455,0xFFF2D33D,(value-.35f)/.35f);
        return blend(0xFFF2D33D,0xFFE84D43,(value-.7f)/.3f);
    }
    private static int blend(int a,int b,float t){
        int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t);
        int g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t);
        int bl=(int)((a&255)*(1-t)+(b&255)*t);
        return 0xEE000000|(r<<16)|(g<<8)|bl;
    }
    @Override public boolean isPauseScreen(){return false;}
}
