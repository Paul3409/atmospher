package dev.atmosphere.companion;

/** Fabric 1.2.12 compatible synthetic radar reflectivity and colour table. */
public final class RadarReflectivity {
    public static final double MIN_DBZ=5,MAX_DBZ=75;
    private static final int[] COLORS={0x00D5E3,0x00B1EA,0x0082EF,0x0044F1,0x00EF00,
        0x00BF00,0x008500,0xFFFF00,0xFFBA00,0xFF6500,0xFF0900,0xB80000,
        0xF1ACDF,0xBA42B9,0x780086};
    private RadarReflectivity(){}

    public static double dbz(double mmh,WeatherField.PrecipitationKind kind){
        if(!Double.isFinite(mmh)||mmh<.1)return Double.NEGATIVE_INFINITY;
        double a=switch(kind){case SNOW->75;case SLEET->160;default->200;};
        double b=switch(kind){case SNOW->2.0;case SLEET->1.7;default->1.6;};
        return 10*(Math.log10(a)+b*Math.log10(mmh));
    }
    public static double rainRate(double dbz){return Math.pow(Math.pow(10,dbz/10)/200,1/1.6);}
    public static int color(double dbz){
        if(!Double.isFinite(dbz)||dbz<MIN_DBZ)return 0xF0080B10;
        double value=clamp(Math.floor((dbz-MIN_DBZ)/2.5)*2.5/5,0,COLORS.length-1);
        int i=Math.min(COLORS.length-2,(int)value);double t=value-i;
        int a=COLORS[i],b=COLORS[i+1];
        int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t);
        int g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t);
        int blue=(int)((a&255)*(1-t)+(b&255)*t);
        return 0xFF000000|(r<<16)|(g<<8)|blue;
    }
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
}
