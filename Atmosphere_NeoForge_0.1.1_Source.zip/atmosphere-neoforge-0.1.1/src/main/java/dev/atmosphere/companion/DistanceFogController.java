package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Uses Minecraft's own distance fog pipeline; no fog meshes or screen-facing polygons are created. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class DistanceFogController {
    @SubscribeEvent public static void fog(ViewportEvent.RenderFog event){
        var mc=Minecraft.getInstance();if(mc.level==null||mc.player==null||!CloudConfig.SIMULATOR_ENABLED.get())return;
        var p=event.getCamera().getPosition();var sample=ManualWeather.sample(p.x,p.y,p.z);
        float amount=sample.fogDensity()/100f;if(amount<=0)return;
        float near=(float)Math.min(sample.fogStart(),sample.fogEnd()-1);
        float far=(float)Math.max(near+1,sample.fogEnd());
        event.setNearPlaneDistance(lerp(event.getNearPlaneDistance(),near,amount));
        event.setFarPlaneDistance(lerp(event.getFarPlaneDistance(),far,amount));
        event.setCanceled(true);
    }
    private static float lerp(float a,float b,float t){return a+(b-a)*t;}
    private DistanceFogController(){}
}
