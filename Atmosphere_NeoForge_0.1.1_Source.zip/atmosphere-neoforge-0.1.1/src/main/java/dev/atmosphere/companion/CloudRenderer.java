package dev.atmosphere.companion;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** One bounded implicit cloud surface sampled once per quality setting. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class CloudRenderer {
    private static final double GRID=512;
    private static final double[][] LOBES={
        {0,0,0,90,27,72},{-58,3,0,58,24,58},{55,5,0,63,29,57},
        {0,8,48,62,30,51},{5,8,-48,66,31,53},{-35,25,20,50,29,47},
        {35,28,-12,55,34,51},{0,40,0,50,34,50},{-70,-5,25,35,17,32},
        {75,-4,-22,38,18,35},{-18,-12,-44,38,16,31},{28,-13,42,39,17,34},
        {-40,-18,12,32,17,29},{18,-20,-20,34,19,32},{44,-17,24,30,16,27}
    };
    private static final int[][] CORNERS={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    private static final int[][] TETS={{0,5,1,6},{0,1,2,6},{0,2,3,6},{0,3,7,6},{0,7,4,6},{0,4,5,6}};
    private static float[][] mesh;
    private static CloudConfig.Quality cachedQuality;
    private static CloudConfig.CloudType cachedType;

    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var quality=CloudConfig.QUALITY.get();
        var type=CloudConfig.CLOUD_TYPE.get();
        if(type==CloudConfig.CloudType.AUTO){
            CloudConfig.CloudType[] families={CloudConfig.CloudType.CUMULUS,CloudConfig.CloudType.STRATOCUMULUS,
                CloudConfig.CloudType.STRATUS,CloudConfig.CloudType.NIMBOSTRATUS,CloudConfig.CloudType.CUMULONIMBUS};
            type=families[(int)Math.floorMod(mc.level.getDayTime()/24000L/2L,families.length)];
        }
        if(mesh==null||cachedQuality!=quality||cachedType!=type)prepare(quality,type);
        var camera=event.getCamera().getPosition();
        double spacing=(type==CloudConfig.CloudType.STRATUS||type==CloudConfig.CloudType.NIMBOSTRATUS)?280:GRID;
        int cx=(int)Math.floor(camera.x/spacing),cz=(int)Math.floor(camera.z/spacing);
        var buffers=mc.renderBuffers().bufferSource();
        var type=RenderType.debugQuads();
        var out=buffers.getBuffer(type);
        Matrix4f matrix=event.getPoseStack().last().pose();
        for(int gx=cx-2;gx<=cx+2;gx++)for(int gz=cz-2;gz<=cz+2;gz++){
            double x=gx*spacing-camera.x,z=gz*spacing-camera.z;
            if(x*x+z*z>530*530)continue;
            double y=CloudConfig.HEIGHT.get()-camera.y;
            for(float[] v:mesh)out.addVertex(matrix,(float)x+v[0],(float)y+v[1],(float)z+v[2])
                .setColor(v[3],v[3]*1.02f,v[3]*1.06f,1f);
        }
        buffers.endBatch(type);
    }
    private static void prepare(CloudConfig.Quality quality,CloudConfig.CloudType type){
        cachedQuality=quality;
        cachedType=type;
        int step=quality==CloudConfig.Quality.LOW?10:quality==CloudConfig.Quality.MEDIUM?7:5;
        int nx=300/step,ny=225/step,nz=280/step;
        float[][][] values=new float[nx+1][ny+1][nz+1];
        for(int i=0;i<=nx;i++)for(int j=0;j<=ny;j++)for(int k=0;k<=nz;k++)
            values[i][j][k]=(float)field(type,-150+i*step,-70+j*step,-140+k*step);
        List<float[]> result=new ArrayList<>();
        for(int i=0;i<nx;i++)for(int j=0;j<ny;j++)for(int k=0;k<nz;k++){
            float[][] p=new float[8][4];
            int inside=0;
            for(int c=0;c<8;c++){
                int[] d=CORNERS[c];int ix=i+d[0],iy=j+d[1],iz=k+d[2];
                p[c]=new float[]{-150+ix*step,-70+iy*step,-140+iz*step,values[ix][iy][iz]};
                if(p[c][3]<0)inside++;
            }
            if(inside==0||inside==8)continue;
            for(int[] t:TETS)polygon(result,p,t);
        }
        mesh=result.toArray(float[][]::new);
    }
    private static void polygon(List<float[]> out,float[][] p,int[] t){
        int[] in=new int[4],outside=new int[4];int ni=0,no=0;
        for(int c:t)if(p[c][3]<0)in[ni++]=c;else outside[no++]=c;
        if(ni==0||ni==4)return;
        if(ni==1){float[] a=edge(p[in[0]],p[outside[0]]),b=edge(p[in[0]],p[outside[1]]),c=edge(p[in[0]],p[outside[2]]);tri(out,a,b,c);}
        else if(ni==3){float[] a=edge(p[outside[0]],p[in[0]]),b=edge(p[outside[0]],p[in[1]]),c=edge(p[outside[0]],p[in[2]]);tri(out,a,b,c);}
        else {float[] a=edge(p[in[0]],p[outside[0]]),b=edge(p[in[0]],p[outside[1]]),c=edge(p[in[1]],p[outside[0]]),d=edge(p[in[1]],p[outside[1]]);tri(out,a,b,c);tri(out,b,c,d);}
    }
    private static float[] edge(float[] a,float[] b){
        float t=a[3]/(a[3]-b[3]);
        float x=a[0]+t*(b[0]-a[0]),y=a[1]+t*(b[1]-a[1]),z=a[2]+t*(b[2]-a[2]);
        float base=cachedType==CloudConfig.CloudType.CUMULUS?.58f:cachedType==CloudConfig.CloudType.NIMBOSTRATUS?.29f:.39f;
        float shade=(float)(base+.20*Math.max(0,Math.min(1,(y+25)/95))+.025*Math.sin(x*.09+z*.06));
        return new float[]{x,y,z,shade};
    }
    private static void tri(List<float[]> out,float[] a,float[] b,float[] c){out.add(a);out.add(b);out.add(c);out.add(c);}
    private static double field(CloudConfig.CloudType type,double x,double y,double z){
        if(type==CloudConfig.CloudType.STRATUS||type==CloudConfig.CloudType.NIMBOSTRATUS){
            double broad=3.2*Math.sin(x*.027+z*.013)+2.5*Math.cos(z*.031-x*.015);
            double detail=1.3*Math.sin(x*.12+z*.08)*Math.cos(z*.10-x*.04);
            double bottom=(type==CloudConfig.CloudType.STRATUS?-14:-27)+broad+detail;
            double top=(type==CloudConfig.CloudType.STRATUS?4:5)+broad*.45;
            double side=Math.max(Math.abs(x)-145,Math.abs(z)-135);
            return Math.max(Math.max(bottom-y,y-top),side);
        }
        double shape=1e5;
        for(double[] l:LOBES){
            double h=type==CloudConfig.CloudType.CUMULONIMBUS?1.8:type==CloudConfig.CloudType.CUMULUS?1.05:.42;
            double spread=type==CloudConfig.CloudType.STRATOCUMULUS?1.22:1;
            double dx=(x-l[0]*spread)/(l[3]*spread),dy=(y-l[1]*h)/(l[4]*h),dz=(z-l[2]*spread)/(l[5]*spread);
            double d=(Math.sqrt(dx*dx+dy*dy+dz*dz)-1)*Math.min(l[3],Math.min(l[4],l[5]));
            double blend=Math.max(0,12-Math.abs(shape-d))/12;
            shape=Math.min(shape,d)-blend*blend*3;
        }
        double rough=2.0*Math.sin(.11*x+.07*z)*Math.cos(.13*z-.08*y)
            +1.5*Math.sin(.21*x-.17*y+.16*z);
        if(y<0)rough*=1.5;
        return shape+rough;
    }
    private CloudRenderer(){}
}
