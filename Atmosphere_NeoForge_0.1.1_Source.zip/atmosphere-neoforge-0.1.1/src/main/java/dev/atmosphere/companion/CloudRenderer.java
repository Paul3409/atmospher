package dev.atmosphere.companion;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** A first independent deterministic cloud field. Not a weather simulation. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID, value=Dist.CLIENT)
public final class CloudRenderer {
    private static final double GRID = 512.0;
    private static float[][][] meshes;
    private static int cachedSegments;
    private static final double[][] LOBES = {
        {0,0,0,90,27,72}, {-58,3,0,58,24,58}, {55,5,0,63,29,57},
        {0,8,48,62,30,51}, {5,8,-48,66,31,53}, {-35,25,20,50,29,47},
        {35,28,-12,55,34,51}, {0,40,0,50,34,50}, {-70,-5,25,35,17,32},
        {75,-4,-22,38,18,35}, {-18,-12,-44,38,16,31}, {28,-13,42,39,17,34},
        {-40,-18,12,32,17,29}, {18,-20,-20,34,19,32}, {44,-17,24,30,16,27}
    };
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if (event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        var mc=Minecraft.getInstance();
        if (mc.level==null || mc.level.dimension()!=Level.OVERWORLD) return;
        var camera=event.getCamera().getPosition();
        int cx=(int)Math.floor(camera.x/GRID), cz=(int)Math.floor(camera.z/GRID);
        var buffers=mc.renderBuffers().bufferSource();
        var out=buffers.getBuffer(RenderType.debugQuads());
        Matrix4f matrix=event.getPoseStack().last().pose();
        var quality=CloudConfig.QUALITY.get();
        int segments=quality==CloudConfig.Quality.LOW?10:quality==CloudConfig.Quality.MEDIUM?16:24;
        int count=quality==CloudConfig.Quality.LOW?10:quality==CloudConfig.Quality.MEDIUM?13:15;
        if (meshes==null || cachedSegments!=segments) prepareMeshes(segments);
        for(int gx=cx-1;gx<=cx+1;gx++) for(int gz=cz-1;gz<=cz+1;gz++) {
            double x=gx*GRID-camera.x, z=gz*GRID-camera.z;
            if(x*x+z*z>420*420)continue;
            double y=CloudConfig.HEIGHT.get()-camera.y;
            for(int i=0;i<count;i++) for(float[] v:meshes[i]) {
                out.addVertex(matrix,(float)x+v[0],(float)y+v[1],(float)z+v[2]).setColor(v[3],v[3]*1.02f,v[3]*1.06f,1f);
            }
        }
        buffers.endBatch(RenderType.debugQuads());
    }
    private static void prepareMeshes(int n) {
        cachedSegments=n;
        meshes=new float[LOBES.length][][];
        int rings=n/2;
        for(int seed=0;seed<LOBES.length;seed++) {
            float[][] mesh=new float[n*rings*4][];
            int j=0;
            for(int a=0;a<n;a++) for(int b=0;b<rings;b++) {
                float[] v0=vertex(LOBES[seed],a,b,n,rings,seed);
                float[] v1=vertex(LOBES[seed],a+1,b,n,rings,seed);
                float[] v2=vertex(LOBES[seed],a+1,b+1,n,rings,seed);
                float[] v3=vertex(LOBES[seed],a,b+1,n,rings,seed);
                if (insideOther(seed,v0)&&insideOther(seed,v1)&&insideOther(seed,v2)&&insideOther(seed,v3)) continue;
                mesh[j++]=v0;mesh[j++]=v1;mesh[j++]=v2;mesh[j++]=v3;
            }
            meshes[seed]=java.util.Arrays.copyOf(mesh,j);
        }
    }
    private static boolean insideOther(int self,float[] v){
        for(int k=0;k<LOBES.length;k++){
            if(k==self)continue;
            double[] l=LOBES[k];
            double dx=(v[0]-l[0])/l[3],dy=(v[1]-l[1])/l[4],dz=(v[2]-l[2])/l[5];
            if(dx*dx+dy*dy+dz*dz<0.84)return true;
        }
        return false;
    }
    private static float[] vertex(double[] l,int a,int b,int n,int rings,int seed) {
        double theta=2*Math.PI*a/n, phi=Math.PI*b/rings;
        double wave=1+0.095*Math.sin(3*theta+seed)*Math.sin(phi)*Math.sin(phi)+0.055*Math.cos(5*theta+2*phi+seed);
        double sx=Math.sin(phi)*Math.cos(theta), sy=Math.cos(phi), sz=Math.sin(phi)*Math.sin(theta);
        float shade=(float)(0.39+0.19*Math.max(0,sy)+0.035*Math.sin(theta*3+phi*5+seed));
        double lower=sy<0?Math.pow(-sy,2)*(3.5*Math.sin(4*theta+seed)+2.5*Math.cos(7*theta-seed)):0;
        return new float[] {(float)(l[0]+l[3]*sx*wave),(float)(l[1]+l[4]*sy*wave+lower),(float)(l[2]+l[5]*sz*wave),shade,1};
    }
}
