package dev.atmosphere.companion;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** One bounded implicit cloud surface sampled once per quality setting. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class CloudRenderer {
    private static final double GRID=512;
    private static final double[][] LOBES={
        {0,0,0,90,27,72},{-58,3,0,58,24,58},{55,5,0,63,29,57},
        {0,8,48,62,30,51},{5,8,-48,66,31,53},{-35,25,20,50,29,47},
        {35,28,-12,55,34,51},{0,40,0,50,34,50},{-70,-5,25,35,17,32},
        {75,-4,-22,38,18,35},{-18,-12,-44,38,16,31},{28,-13,42,39,17,34},
        {-40,-18,12,32,17,29},{18,-20,-20,34,19,32},{44,-17,24,30,16,27}
    };
    private static final int[][] CORNERS={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    private static final int[][] TETS={{0,5,1,6},{0,1,2,6},{0,2,3,6},{0,3,7,6},{0,7,4,6},{0,4,5,6}};
    private static float[][] mesh;
    private static CloudConfig.Quality cachedQuality;
    private static CloudConfig.CloudType cachedType;
    private static int cachedRoughness;

    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var quality=CloudConfig.QUALITY.get();
        var type=WeatherField.activeType();
        if(mesh==null||cachedQuality!=quality||cachedType!=type||cachedRoughness!=CloudConfig.ROUGHNESS.get())prepare(quality,type);
        var camera=event.getCamera().getPosition();
        boolean layer=isLayer(type);
        double spacingX=layer?300:GRID,spacingZ=layer?280:GRID;
        double[] wind=WeatherField.windOffset();
        int cx=(int)Math.floor((camera.x-wind[0])/spacingX),cz=(int)Math.floor((camera.z-wind[1])/spacingZ);
        var buffers=mc.renderBuffers().bufferSource();
        int opacity=CloudConfig.CLOUD_OPACITY.get();
        var renderType=type==CloudConfig.CloudType.CIRRUS||opacity<100?
            WeatherCurtainRenderer.CURTAIN:RenderType.debugQuads();
        var out=buffers.getBuffer(renderType);
        Matrix4f matrix=event.getPoseStack().last().pose();
        double distance=CloudConfig.RENDER_DISTANCE.get();
        int cells=(int)Math.ceil(distance/Math.min(spacingX,spacingZ))+2;
        double day=Math.floorMod(mc.level.getDayTime(),24000L);
        double solar=(Math.cos((day-6000)*Math.PI*2/24000)+1)*.5;
        float light=(float)(CloudConfig.NIGHT_BRIGHTNESS.get()/100.0+
            (1-CloudConfig.NIGHT_BRIGHTNESS.get()/100.0)*solar);
        float alpha=(float)(opacity/100.0*(type==CloudConfig.CloudType.CIRRUS?.58:1));
        for(int gx=cx-cells;gx<=cx+cells;gx++)for(int gz=cz-cells;gz<=cz+cells;gz++){
            double centerX=gx*spacingX,centerZ=gz*spacingZ,scale=1,rotation=0;
            if(!layer){
                double[] cell=WeatherField.cloudCell(gx,gz);
                if(cell[4]<.5)continue;
                centerX=cell[0];centerZ=cell[1];scale=cell[2]*CloudConfig.CLOUD_SCALE.get()/100.0;rotation=cell[3];
            }
            double x=centerX+wind[0]-camera.x,z=centerZ+wind[1]-camera.z;
            if(x*x+z*z>distance*distance)continue;
            double y=CloudConfig.HEIGHT.get()-camera.y;
            double cos=Math.cos(rotation),sin=Math.sin(rotation);
            for(float[] v:mesh){
                float vx=(float)(x+(v[0]*cos-v[2]*sin)*scale);
                float vz=(float)(z+(v[0]*sin+v[2]*cos)*scale);
                float shade=v[3]*light;
                out.addVertex(matrix,vx,(float)y+(float)(v[1]*scale),vz)
                    .setColor(shade,shade*1.02f,shade*1.06f,alpha);
            }
        }
        buffers.endBatch(renderType);
    }
    private static void prepare(CloudConfig.Quality quality,CloudConfig.CloudType type){
        cachedQuality=quality;
        cachedType=type;
        cachedRoughness=CloudConfig.ROUGHNESS.get();
        int step=quality==CloudConfig.Quality.LOW?10:quality==CloudConfig.Quality.MEDIUM?7:5;
        if(type==CloudConfig.CloudType.CIRRUS)step=Math.min(step,4);
        double minX=-150,maxX=150,minY=-70,maxY=155,minZ=-140,maxZ=140;
        if(type==CloudConfig.CloudType.CUMULONIMBUS_GROSS){minX=-275;maxX=275;maxY=190;minZ=-235;maxZ=235;}
        if(type==CloudConfig.CloudType.CIRRUS){minX=-185;maxX=185;minY=20;maxY=62;minZ=-105;maxZ=105;}
        int nx=(int)Math.ceil((maxX-minX)/step),ny=(int)Math.ceil((maxY-minY)/step),nz=(int)Math.ceil((maxZ-minZ)/step);
        float[][][] values=new float[nx+1][ny+1][nz+1];
        for(int i=0;i<=nx;i++)for(int j=0;j<=ny;j++)for(int k=0;k<=nz;k++)
            values[i][j][k]=(float)field(type,minX+i*step,minY+j*step,minZ+k*step);
        List<float[]> result=new ArrayList<>();
        for(int i=0;i<nx;i++)for(int j=0;j<ny;j++)for(int k=0;k<nz;k++){
            float[][] p=new float[8][4];
            int inside=0;
            for(int c=0;c<8;c++){
                int[] d=CORNERS[c];int ix=i+d[0],iy=j+d[1],iz=k+d[2];
                p[c]=new float[]{(float)(minX+ix*step),(float)(minY+iy*step),(float)(minZ+iz*step),values[ix][iy][iz]};
                if(p[c][3]<0)inside++;
            }
            if(inside==0||inside==8)continue;
            for(int[] t:TETS)polygon(result,p,t);
        }
        mesh=result.toArray(float[][]::new);
    }
    private static void polygon(List<float[]> out,float[][] p,int[] t){
        int[] in=new int[4],outside=new int[4];int ni=0,no=0;
        for(int c:t)if(p[c][3]<0)in[ni++]=c;else outside[no++]=c;
        if(ni==0||ni==4)return;
        if(ni==1){float[] a=edge(p[in[0]],p[outside[0]]),b=edge(p[in[0]],p[outside[1]]),c=edge(p[in[0]],p[outside[2]]);tri(out,a,b,c);}
        else if(ni==3){float[] a=edge(p[outside[0]],p[in[0]]),b=edge(p[outside[0]],p[in[1]]),c=edge(p[outside[0]],p[in[2]]);tri(out,a,b,c);}
        else {float[] a=edge(p[in[0]],p[outside[0]]),b=edge(p[in[0]],p[outside[1]]),c=edge(p[in[1]],p[outside[0]]),d=edge(p[in[1]],p[outside[1]]);tri(out,a,b,c);tri(out,b,c,d);}
    }
    private static float[] edge(float[] a,float[] b){
        float t=a[3]/(a[3]-b[3]);
        float x=a[0]+t*(b[0]-a[0]),y=a[1]+t*(b[1]-a[1]),z=a[2]+t*(b[2]-a[2]);
        float base=cachedType==CloudConfig.CloudType.CUMULUS?.58f:
            cachedType==CloudConfig.CloudType.CIRRUS||cachedType==CloudConfig.CloudType.CIRROSTRATUS?.78f:
            cachedType==CloudConfig.CloudType.NIMBOSTRATUS?.29f:.39f;
        float shade=(float)(base+.20*Math.max(0,Math.min(1,(y+25)/95))+.025*Math.sin(x*.09+z*.06));
        return new float[]{x,y,z,shade};
    }
    private static void tri(List<float[]> out,float[] a,float[] b,float[] c){out.add(a);out.add(b);out.add(c);out.add(c);}
    private static double field(CloudConfig.CloudType type,double x,double y,double z){
        if(type==CloudConfig.CloudType.CIRRUS){
            double shape=1e5;
            for(int i=0;i<5;i++){
                double centerZ=(i-2)*24+x*.10+7*Math.sin(x/58.0+i*.8);
                double width=4.0+1.5*Math.sin(x/75.0+i*1.7);
                double dx=x/(125-i*4.0),dz=(z-centerZ)/width;
                double cy=38+i*2.0+1.5*Math.sin(x/60.0+i);
                double dy=(y-cy)/2.8;
                shape=Math.min(shape,(Math.sqrt(dx*dx+dz*dz+dy*dy)-1)*5);
            }
            return shape;
        }
        if(isLayer(type)){
            double broad=layerBroad(x,z);
            double bottom=layerBottomOffset(type,x,z);
            double top=(type==CloudConfig.CloudType.STRATUS?4:type==CloudConfig.CloudType.NIMBOSTRATUS?7:18)+broad*.35;
            return Math.max(bottom-y,y-top);
        }
        double shape=1e5;
        for(double[] l:LOBES){
            double h=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?2.25:
                type==CloudConfig.CloudType.CUMULONIMBUS?1.8:type==CloudConfig.CloudType.CUMULUS?1.05:
                type==CloudConfig.CloudType.ALTOCUMULUS?.32:type==CloudConfig.CloudType.CIRRUS?.18:.42;
            double spread=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?1.38:
                type==CloudConfig.CloudType.STRATOCUMULUS?1.22:type==CloudConfig.CloudType.CIRRUS?1.55:
                type==CloudConfig.CloudType.ALTOCUMULUS?.75:1;
            double dx=(x-l[0]*spread)/(l[3]*spread),dy=(y-l[1]*h)/(l[4]*h),dz=(z-l[2]*spread)/(l[5]*spread);
            double d=(Math.sqrt(dx*dx+dy*dy+dz*dz)-1)*Math.min(l[3],Math.min(l[4],l[5]));
            double blend=Math.max(0,12-Math.abs(shape-d))/12;
            shape=Math.min(shape,d)-blend*blend*3;
        }
        if(type==CloudConfig.CloudType.CUMULONIMBUS||type==CloudConfig.CloudType.CUMULONIMBUS_GROSS){
            boolean giant=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS;
            double radiusX=giant?175:125,radiusZ=giant?145:105,capY=giant?132:102;
            double cap=Math.sqrt((x/radiusX)*(x/radiusX)+((y-capY)/17)*((y-capY)/17)+(z/radiusZ)*(z/radiusZ))-1;
            shape=Math.min(shape,cap*17);
        }
        double rough=(5.0*noise3(x/38,y/28,z/35,137)
            +2.8*noise3(x/15,y/14,z/17,211)
            +1.3*noise3(x/7,y/8,z/9,311))*CloudConfig.ROUGHNESS.get()/100.0;
        if(y<0)rough*=1.5;
        shape+=rough;
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.CUMULONIMBUS||
            type==CloudConfig.CloudType.CUMULONIMBUS_GROSS)
            shape=Math.max(shape,-y-(type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?32:22));
        return shape;
    }
    static boolean isLayer(CloudConfig.CloudType type){
        return type==CloudConfig.CloudType.STRATUS||type==CloudConfig.CloudType.NIMBOSTRATUS||
            type==CloudConfig.CloudType.ALTOSTRATUS||type==CloudConfig.CloudType.CIRROSTRATUS;
    }
    static double layerBottomOffset(CloudConfig.CloudType type,double x,double z){
        double detail=4.0*noise2(x*23/300,z*21/280,23,21,71)
            +1.4*noise2(x*43/300,z*39/280,43,39,103);
        double scale=type==CloudConfig.CloudType.CIRROSTRATUS?.28:
            type==CloudConfig.CloudType.ALTOSTRATUS?.55:1;
        double base=type==CloudConfig.CloudType.STRATUS?-14:
            type==CloudConfig.CloudType.NIMBOSTRATUS?-27:0;
        return base+(layerBroad(x,z)+detail)*scale;
    }
    private static double layerBroad(double x,double z){
        return 8.0*noise2(x*5/300,z*4/280,5,4,17)
            +4.0*noise2(x*11/300,z*9/280,11,9,41);
    }
    private static double mix(double a,double b,double t){return a+(b-a)*t;}
    private static double smooth(double t){return t*t*(3-2*t);}
    private static double hash(int x,int y,int z,int seed){
        long h=(long)x*374761393L+(long)y*668265263L+(long)z*1442695041L+seed*1274126177L;
        h=(h^(h>>>13))*1274126177L;
        h^=h>>>16;
        return ((h&0xffffL)/32767.5)-1;
    }
    private static double noise2(double x,double z,int periodX,int periodZ,int seed){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);
        double fx=smooth(x-ix),fz=smooth(z-iz);
        int x0=Math.floorMod(ix,periodX),x1=(x0+1)%periodX;
        int z0=Math.floorMod(iz,periodZ),z1=(z0+1)%periodZ;
        return mix(mix(hash(x0,0,z0,seed),hash(x1,0,z0,seed),fx),
            mix(hash(x0,0,z1,seed),hash(x1,0,z1,seed),fx),fz);
    }
    private static double noise3(double x,double y,double z,int seed){
        int ix=(int)Math.floor(x),iy=(int)Math.floor(y),iz=(int)Math.floor(z);
        double fx=smooth(x-ix),fy=smooth(y-iy),fz=smooth(z-iz);
        double a=mix(hash(ix,iy,iz,seed),hash(ix+1,iy,iz,seed),fx);
        double b=mix(hash(ix,iy,iz+1,seed),hash(ix+1,iy,iz+1,seed),fx);
        double c=mix(hash(ix,iy+1,iz,seed),hash(ix+1,iy+1,iz,seed),fx);
        double d=mix(hash(ix,iy+1,iz+1,seed),hash(ix+1,iy+1,iz+1,seed),fx);
        return mix(mix(a,b,fz),mix(c,d,fz),fy);
    }
    private CloudRenderer(){}
}
