package dev.atmosphere.companion;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** One bounded implicit cloud surface sampled once per quality setting. */
public final class CloudRenderer {
    private static final double GRID=512;
    private static final double[][] LOBES={
        {0,0,0,90,27,72},{-58,3,0,58,24,58},{55,5,0,63,29,57},
        {0,8,48,62,30,51},{5,8,-48,66,31,53},{-35,25,20,50,29,47},
        {35,28,-12,55,34,51},{0,40,0,50,34,50},{-70,-5,25,35,17,32},
        {75,-4,-22,38,18,35},{-18,-12,-44,38,16,31},{28,-13,42,39,17,34},
        {-40,-18,12,32,17,29},{18,-20,-20,34,19,32},{44,-17,24,30,16,27}
    };
    private static final int[][] CORNERS={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    private static final int[][] TETS={{0,5,1,6},{0,1,2,6},{0,2,3,6},{0,3,7,6},{0,7,4,6},{0,4,5,6}};
    private static float[][] mesh;
    private static CloudConfig.Quality cachedQuality;
    private static CloudConfig.CloudType cachedType;
    private static int cachedRoughness;
    private static final EnumMap<CloudConfig.CloudType,float[][]> MESH_CACHE=new EnumMap<>(CloudConfig.CloudType.class);

    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        var quality=CloudConfig.QUALITY.get();
        var type=WeatherField.activeType();
        boolean automatic=CloudConfig.CLOUD_TYPE.get()==CloudConfig.CloudType.AUTO;
        var camera=event.getCamera().getPosition();
        boolean layer=isLayer(type);
        if(cachedQuality!=quality||cachedRoughness!=CloudConfig.ROUGHNESS.get()){
            MESH_CACHE.clear();cachedQuality=quality;cachedRoughness=CloudConfig.ROUGHNESS.get();
        }
        if(!layer&&!automatic)mesh=meshFor(quality,type);
        double spacingX=layer?300:GRID,spacingZ=layer?280:GRID;
        double[] wind=WeatherField.windOffset();
        int cx=(int)Math.floor((camera.x-wind[0])/spacingX),cz=(int)Math.floor((camera.z-wind[1])/spacingZ);
        var buffers=mc.renderBuffers().bufferSource();
        int opacity=CloudConfig.CLOUD_OPACITY.get();
        var renderType=opacity<100?WeatherCurtainRenderer.CURTAIN:RenderType.debugQuads();
        var out=buffers.getBuffer(renderType);
        Matrix4f matrix=event.getPoseStack().last().pose();
        double performance=1;
        if(CloudConfig.ADAPTIVE_CLOUDS.get()){
            int fps=Math.max(1,mc.getFps());
            performance=Math.max(.48,Math.min(1,fps/(double)CloudConfig.TARGET_FPS.get()));
        }
        double distance=CloudConfig.RENDER_DISTANCE.get()*(.72+.28*performance);
        int cells=(int)Math.ceil(distance/Math.min(spacingX,spacingZ))+2;
        double day=Math.floorMod(mc.level.getDayTime(),24000L);
        double solar=(Math.cos((day-6000)*Math.PI*2/24000)+1)*.5;
        float light=(float)(CloudConfig.NIGHT_BRIGHTNESS.get()/100.0+
            (1-CloudConfig.NIGHT_BRIGHTNESS.get()/100.0)*solar);
        float alpha=opacity/100f;
        if(layer){
            renderLayer(out,matrix,camera.x,camera.y,camera.z,wind[0],wind[1],distance,type,quality,light,alpha,performance);
            buffers.endBatch(renderType);
            return;
        }
        for(int gx=cx-cells;gx<=cx+cells;gx++)for(int gz=cz-cells;gz<=cz+cells;gz++){
            double centerX=gx*spacingX,centerZ=gz*spacingZ,scale=1,rotation=0;
            CloudConfig.CloudType cellType=type;
            float[][] cellMesh=mesh;
            if(!layer){
                double[] cell=WeatherField.cloudCell(gx,gz);
                if(cell[4]<.5)continue;
                centerX=cell[0];centerZ=cell[1];scale=cell[2]*CloudConfig.CLOUD_SCALE.get()/100.0;rotation=cell[3];
                if(automatic){
                    var weather=WeatherCells.sample(centerX+wind[0],centerZ+wind[1],mc.level.getGameTime());
                    if(weather.type()==WeatherCells.SQUALL||weather.type()==WeatherCells.SEVERE)cellType=CloudConfig.CloudType.CUMULONIMBUS_GROSS;
                    else if(weather.type()==WeatherCells.THUNDER)cellType=CloudConfig.CloudType.CUMULONIMBUS;
                    else{
                        double family=(Math.sin(gx*17.13+gz*9.71)+1)*.5;
                        cellType=family<.58?CloudConfig.CloudType.CUMULUS:
                            family<.82?CloudConfig.CloudType.STRATOCUMULUS:CloudConfig.CloudType.ALTOCUMULUS;
                        scale*=weather.cloud()>.08?1.12:.72+.24*family;
                    }
                    cellMesh=meshFor(quality,cellType);
                }
            }
            double x=centerX+wind[0]-camera.x,z=centerZ+wind[1]-camera.z;
            if(x*x+z*z>distance*distance)continue;
            double far=Math.sqrt(x*x+z*z)/distance;
            if(far>.62){
                double keep=CloudConfig.DISTANT_CLOUD_DETAIL.get()/100.0*(.62+.38*performance);
                double deterministic=(Math.sin(gx*91.17+gz*47.31)+1)*.5;
                if(deterministic>keep)continue;
            }
            double y=CloudConfig.HEIGHT.get()-camera.y;
            double cos=Math.cos(rotation),sin=Math.sin(rotation);
            for(float[] v:cellMesh){
                float vx=(float)(x+(v[0]*cos-v[2]*sin)*scale);
                float vz=(float)(z+(v[0]*sin+v[2]*cos)*scale);
                float shade=v[3]*light;
                out.addVertex(matrix,vx,(float)y+(float)(v[1]*scale),vz)
                    .setColor(shade,shade*1.02f,shade*1.06f,alpha);
            }
        }
        buffers.endBatch(renderType);
    }
    private static float[][] meshFor(CloudConfig.Quality quality,CloudConfig.CloudType type){
        var found=MESH_CACHE.get(type);if(found!=null)return found;
        prepare(quality,type);MESH_CACHE.put(type,mesh);return mesh;
    }
    /**
     * Schichtwolken sind eine einzige weltkoordinatenbasierte Hoehenflaeche.
     * Es gibt absichtlich keine wiederholten Mesh-Kacheln und damit keine inneren Seitenflaechen.
     */
    private static void renderLayer(com.mojang.blaze3d.vertex.VertexConsumer out,Matrix4f matrix,
            double cameraX,double cameraY,double cameraZ,double windX,double windZ,double distance,
            CloudConfig.CloudType type,CloudConfig.Quality quality,float light,float alpha,double performance){
        int step=quality==CloudConfig.Quality.LOW?18:quality==CloudConfig.Quality.MEDIUM?12:8;
        double detail=CloudConfig.DISTANT_CLOUD_DETAIL.get()/100.0;
        step=(int)Math.max(step,Math.round(step/(Math.max(.28,detail*(.68+.32*performance)))));
        double weatherCameraX=cameraX-windX,weatherCameraZ=cameraZ-windZ;
        int minX=(int)Math.floor((weatherCameraX-distance)/step),maxX=(int)Math.ceil((weatherCameraX+distance)/step);
        int minZ=(int)Math.floor((weatherCameraZ-distance)/step),maxZ=(int)Math.ceil((weatherCameraZ+distance)/step);
        double baseY=CloudConfig.HEIGHT.get();
        float base=type==CloudConfig.CloudType.NIMBOSTRATUS?.29f:.39f;
        for(int ix=minX;ix<maxX;ix++)for(int iz=minZ;iz<maxZ;iz++){
            double x0=ix*(double)step,x1=x0+step,z0=iz*(double)step,z1=z0+step;
            double centerX=(x0+x1)*.5,centerZ=(z0+z1)*.5;
            if((centerX-weatherCameraX)*(centerX-weatherCameraX)+(centerZ-weatherCameraZ)*(centerZ-weatherCameraZ)>distance*distance)continue;
            double b00=layerBottomOffset(type,x0,z0),b10=layerBottomOffset(type,x1,z0);
            double b11=layerBottomOffset(type,x1,z1),b01=layerBottomOffset(type,x0,z1);
            float s00=layerShade(base,b00,x0,z0,light),s10=layerShade(base,b10,x1,z0,light);
            float s11=layerShade(base,b11,x1,z1,light),s01=layerShade(base,b01,x0,z1,light);
            float rx0=(float)(x0+windX-cameraX),rx1=(float)(x1+windX-cameraX);
            float rz0=(float)(z0+windZ-cameraZ),rz1=(float)(z1+windZ-cameraZ);
            vertex(out,matrix,rx0,(float)(baseY+b00-cameraY),rz0,s00,alpha);
            vertex(out,matrix,rx0,(float)(baseY+b01-cameraY),rz1,s01,alpha);
            vertex(out,matrix,rx1,(float)(baseY+b11-cameraY),rz1,s11,alpha);
            vertex(out,matrix,rx1,(float)(baseY+b10-cameraY),rz0,s10,alpha);
            double topBase=type==CloudConfig.CloudType.STRATUS?4:type==CloudConfig.CloudType.NIMBOSTRATUS?7:18;
            double t00=topBase+layerBroad(x0,z0)*.35,t10=topBase+layerBroad(x1,z0)*.35;
            double t11=topBase+layerBroad(x1,z1)*.35,t01=topBase+layerBroad(x0,z1)*.35;
            vertex(out,matrix,rx0,(float)(baseY+t00-cameraY),rz0,s00+.10f*light,alpha);
            vertex(out,matrix,rx1,(float)(baseY+t10-cameraY),rz0,s10+.10f*light,alpha);
            vertex(out,matrix,rx1,(float)(baseY+t11-cameraY),rz1,s11+.10f*light,alpha);
            vertex(out,matrix,rx0,(float)(baseY+t01-cameraY),rz1,s01+.10f*light,alpha);
        }
    }
    private static float layerShade(float base,double y,double x,double z,float light){
        double variation=.018*noise2Global(x/96,z/96,601)+.012*noise2Global(x/31,z/31,607);
        return (float)((base+.20*Math.max(0,Math.min(1,(y+25)/95))+variation)*light);
    }
    private static void vertex(com.mojang.blaze3d.vertex.VertexConsumer out,Matrix4f m,float x,float y,float z,float shade,float alpha){
        shade=Math.max(0,Math.min(1,shade));
        out.addVertex(m,x,y,z).setColor(shade,shade*1.02f,shade*1.06f,alpha);
    }
    private static void prepare(CloudConfig.Quality quality,CloudConfig.CloudType type){
        cachedQuality=quality;
        cachedType=type;
        cachedRoughness=CloudConfig.ROUGHNESS.get();
        int step=quality==CloudConfig.Quality.LOW?10:quality==CloudConfig.Quality.MEDIUM?7:5;
        if(type==CloudConfig.CloudType.CIRRUS)step=Math.min(step,4);
        double minX=-150,maxX=150,minY=-70,maxY=155,minZ=-140,maxZ=140;
        if(type==CloudConfig.CloudType.CUMULONIMBUS_GROSS){minX=-275;maxX=275;maxY=190;minZ=-235;maxZ=235;}
        if(type==CloudConfig.CloudType.CIRRUS){minX=-185;maxX=185;minY=20;maxY=62;minZ=-105;maxZ=105;}
        int nx=(int)Math.ceil((maxX-minX)/step),ny=(int)Math.ceil((maxY-minY)/step),nz=(int)Math.ceil((maxZ-minZ)/step);
        float[][][] values=new float[nx+1][ny+1][nz+1];
        for(int i=0;i<=nx;i++)for(int j=0;j<=ny;j++)for(int k=0;k<=nz;k++)
            values[i][j][k]=(float)field(type,minX+i*step,minY+j*step,minZ+k*step);
        List<float[]> result=new ArrayList<>();
        for(int i=0;i<nx;i++)for(int j=0;j<ny;j++)for(int k=0;k<nz;k++){
            float[][] p=new float[8][4];
            int inside=0;
            for(int c=0;c<8;c++){
                int[] d=CORNERS[c];int ix=i+d[0],iy=j+d[1],iz=k+d[2];
                p[c]=new float[]{(float)(minX+ix*step),(float)(minY+iy*step),(float)(minZ+iz*step),values[ix][iy][iz]};
                if(p[c][3]<0)inside++;
            }
            if(inside==0||inside==8)continue;
            for(int[] t:TETS)polygon(result,p,t);
        }
        mesh=result.toArray(float[][]::new);
    }
    private static void polygon(List<float[]> out,float[][] p,int[] t){
        int[] in=new int[4],outside=new int[4];int ni=0,no=0;
        for(int c:t)if(p[c][3]<0)in[ni++]=c;else outside[no++]=c;
        if(ni==0||ni==4)return;
        if(ni==1){float[] a=edge(p[in[0]],p[outside[0]]),b=edge(p[in[0]],p[outside[1]]),c=edge(p[in[0]],p[outside[2]]);tri(out,a,b,c);}
        else if(ni==3){float[] a=edge(p[outside[0]],p[in[0]]),b=edge(p[outside[0]],p[in[1]]),c=edge(p[outside[0]],p[in[2]]);tri(out,a,b,c);}
        else {float[] a=edge(p[in[0]],p[outside[0]]),b=edge(p[in[0]],p[outside[1]]),c=edge(p[in[1]],p[outside[0]]),d=edge(p[in[1]],p[outside[1]]);tri(out,a,b,c);tri(out,b,c,d);}
    }
    private static float[] edge(float[] a,float[] b){
        float t=a[3]/(a[3]-b[3]);
        float x=a[0]+t*(b[0]-a[0]),y=a[1]+t*(b[1]-a[1]),z=a[2]+t*(b[2]-a[2]);
        float base=cachedType==CloudConfig.CloudType.CUMULUS?.58f:
            cachedType==CloudConfig.CloudType.CIRRUS||cachedType==CloudConfig.CloudType.CIRROSTRATUS?.70f:
            cachedType==CloudConfig.CloudType.NIMBOSTRATUS?.29f:.39f;
        float shade=(float)(base+.20*Math.max(0,Math.min(1,(y+25)/95))+.025*Math.sin(x*.09+z*.06));
        return new float[]{x,y,z,shade};
    }
    private static void tri(List<float[]> out,float[] a,float[] b,float[] c){out.add(a);out.add(b);out.add(c);out.add(c);}
    private static double field(CloudConfig.CloudType type,double x,double y,double z){
        if(type==CloudConfig.CloudType.CIRRUS){
            double shape=1e5;
            for(int i=0;i<7;i++){
                double centerZ=(i-3)*18+x*.075+13*Math.sin(x/48.0+i*.9)+4*Math.sin(x/19.0+i*2.1);
            double width=4.4+1.15*Math.sin(x/54.0+i*1.7);
                double dx=x/(145-i*4.0),dz=(z-centerZ)/width;
                double cy=39+i*1.35+2.3*Math.sin(x/46.0+i);
                double dy=(y-cy)/(3.1+.35*Math.sin(x/37.0+i));
                shape=Math.min(shape,(Math.sqrt(dx*dx+dz*dz+dy*dy)-1)*5);
            }
            return shape;
        }
        if(isLayer(type)){
            double broad=layerBroad(x,z);
            double bottom=layerBottomOffset(type,x,z);
            double top=(type==CloudConfig.CloudType.STRATUS?4:type==CloudConfig.CloudType.NIMBOSTRATUS?7:18)+broad*.35;
            return Math.max(bottom-y,y-top);
        }
        if(type==CloudConfig.CloudType.CUMULONIMBUS||type==CloudConfig.CloudType.CUMULONIMBUS_GROSS)
            return stormField(type,x,y,z);
        double shape=1e5;
        for(double[] l:LOBES){
            double h=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?2.25:
                type==CloudConfig.CloudType.CUMULONIMBUS?1.8:type==CloudConfig.CloudType.CUMULUS?1.05:
                type==CloudConfig.CloudType.ALTOCUMULUS?.32:type==CloudConfig.CloudType.CIRRUS?.18:.42;
            double spread=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?1.38:
                type==CloudConfig.CloudType.STRATOCUMULUS?1.22:type==CloudConfig.CloudType.CIRRUS?1.55:
                type==CloudConfig.CloudType.ALTOCUMULUS?.75:1;
            double dx=(x-l[0]*spread)/(l[3]*spread),dy=(y-l[1]*h)/(l[4]*h),dz=(z-l[2]*spread)/(l[5]*spread);
            double d=(Math.sqrt(dx*dx+dy*dy+dz*dz)-1)*Math.min(l[3],Math.min(l[4],l[5]));
            double smoothing=CloudConfig.CLOUD_SMOOTHING.get()/100.0;
            double blendRadius=12+10*smoothing;
            double blend=Math.max(0,blendRadius-Math.abs(shape-d))/blendRadius;
            shape=Math.min(shape,d)-blend*blend*(3+4*smoothing);
        }
        double smoothFactor=1-CloudConfig.CLOUD_SMOOTHING.get()/100.0*.38;
        double rough=(5.0*noise3(x/38,y/28,z/35,137)
            +2.8*noise3(x/15,y/14,z/17,211)
            +1.3*noise3(x/7,y/8,z/9,311))*CloudConfig.ROUGHNESS.get()/100.0*smoothFactor;
        if(y<0)rough*=1.5;
        shape+=rough;
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.CUMULONIMBUS||
            type==CloudConfig.CloudType.CUMULONIMBUS_GROSS)
            shape=Math.max(shape,-y-(type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?32:22));
        return shape;
    }
    /** Multi-tower convective body with a connected base and wind-sheared anvil. */
    private static double stormField(CloudConfig.CloudType type,double x,double y,double z){
        boolean giant=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS;
        double g=giant?1.34:1.0;
        double shape=ellipsoid(x,y,z,0,-4,0,118*g,22,92*g);
        shape=union(shape,ellipsoid(x,y,z,-55*g,18,8,55*g,38,52*g),16);
        shape=union(shape,ellipsoid(x,y,z,-35*g,52,3,49*g,48,47*g),16);
        shape=union(shape,ellipsoid(x,y,z,-12*g,87,-4,45*g,53,44*g),15);
        shape=union(shape,ellipsoid(x,y,z,42*g,25,-18*g,59*g,43,54*g),16);
        shape=union(shape,ellipsoid(x,y,z,55*g,64,-20*g,51*g,52,48*g),15);
        shape=union(shape,ellipsoid(x,y,z,30*g,104,-14*g,48*g,47,47*g),14);
        if(giant)shape=union(shape,ellipsoid(x,y,z,-92*g,46,30*g,47*g,51,45*g),14);
        double anvilY=giant?151:127;
        shape=union(shape,ellipsoid(x,y,z,55*g,anvilY,-13*g,154*g,15,111*g),12);
        shape=union(shape,ellipsoid(x,y,z,125*g,anvilY+2,-8*g,105*g,10,79*g),9);
        double smoothFactor=1-CloudConfig.CLOUD_SMOOTHING.get()/100.0*.46;
        double rough=(4.2*noise3(x/44,y/34,z/41,137)+2.1*noise3(x/19,y/18,z/21,211)+
            .8*noise3(x/9,y/11,z/12,311))*CloudConfig.ROUGHNESS.get()/100.0*smoothFactor;
        shape+=rough*(y<5?1.25:1);
        return Math.max(shape,-y-24);
    }
    private static double ellipsoid(double x,double y,double z,double cx,double cy,double cz,double rx,double ry,double rz){
        double dx=(x-cx)/rx,dy=(y-cy)/ry,dz=(z-cz)/rz;
        return (Math.sqrt(dx*dx+dy*dy+dz*dz)-1)*Math.min(rx,Math.min(ry,rz));
    }
    private static double union(double a,double b,double radius){
        double h=Math.max(0,Math.min(1,.5+.5*(b-a)/radius));
        return mix(b,a,h)-radius*h*(1-h);
    }
    static boolean isLayer(CloudConfig.CloudType type){
        return type==CloudConfig.CloudType.STRATUS||type==CloudConfig.CloudType.NIMBOSTRATUS||
            type==CloudConfig.CloudType.ALTOSTRATUS||type==CloudConfig.CloudType.CIRROSTRATUS;
    }
    static double layerBottomOffset(CloudConfig.CloudType type,double x,double z){
        double detail=4.0*noise2Global(x/13.1,z/13.3,71)
            +1.4*noise2Global(x/6.98,z/7.18,103);
        double scale=type==CloudConfig.CloudType.CIRROSTRATUS?.28:
            type==CloudConfig.CloudType.ALTOSTRATUS?.55:1;
        double base=type==CloudConfig.CloudType.STRATUS?-14:
            type==CloudConfig.CloudType.NIMBOSTRATUS?-27:0;
        return base+(layerBroad(x,z)+detail)*scale;
    }
    private static double layerBroad(double x,double z){
        return 8.0*noise2Global(x/60,z/70,17)
            +4.0*noise2Global(x/27.3,z/31.1,41);
    }
    private static double mix(double a,double b,double t){return a+(b-a)*t;}
    private static double smooth(double t){return t*t*(3-2*t);}
    private static double hash(int x,int y,int z,int seed){
        long h=(long)x*374761393L+(long)y*668265263L+(long)z*1442695041L+seed*1274126177L;
        h=(h^(h>>>13))*1274126177L;
        h^=h>>>16;
        return ((h&0xffffL)/32767.5)-1;
    }
    private static double noise2(double x,double z,int periodX,int periodZ,int seed){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);
        double fx=smooth(x-ix),fz=smooth(z-iz);
        int x0=Math.floorMod(ix,periodX),x1=(x0+1)%periodX;
        int z0=Math.floorMod(iz,periodZ),z1=(z0+1)%periodZ;
        return mix(mix(hash(x0,0,z0,seed),hash(x1,0,z0,seed),fx),
            mix(hash(x0,0,z1,seed),hash(x1,0,z1,seed),fx),fz);
    }
    private static double noise2Global(double x,double z,int seed){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);
        double fx=smooth(x-ix),fz=smooth(z-iz);
        return mix(mix(hash(ix,0,iz,seed),hash(ix+1,0,iz,seed),fx),
            mix(hash(ix,0,iz+1,seed),hash(ix+1,0,iz+1,seed),fx),fz);
    }
    private static double noise3(double x,double y,double z,int seed){
        int ix=(int)Math.floor(x),iy=(int)Math.floor(y),iz=(int)Math.floor(z);
        double fx=smooth(x-ix),fy=smooth(y-iy),fz=smooth(z-iz);
        double a=mix(hash(ix,iy,iz,seed),hash(ix+1,iy,iz,seed),fx);
        double b=mix(hash(ix,iy,iz+1,seed),hash(ix+1,iy,iz+1,seed),fx);
        double c=mix(hash(ix,iy+1,iz,seed),hash(ix+1,iy+1,iz,seed),fx);
        double d=mix(hash(ix,iy+1,iz+1,seed),hash(ix+1,iy+1,iz+1,seed),fx);
        return mix(mix(a,b,fz),mix(c,d,fz),fy);
    }
    private CloudRenderer(){}
}
