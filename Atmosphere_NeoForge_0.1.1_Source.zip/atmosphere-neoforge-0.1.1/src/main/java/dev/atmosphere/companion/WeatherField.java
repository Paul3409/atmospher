package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** One deterministic source for rendered clouds, local precipitation and radar. */
public final class WeatherField {
    public static CloudConfig.CloudType activeType(){
        var type=CloudConfig.CLOUD_TYPE.get();
        var mc=Minecraft.getInstance();
        if(type!=CloudConfig.CloudType.AUTO||mc.level==null)return type;
        CloudConfig.CloudType[] families={CloudConfig.CloudType.CUMULUS,CloudConfig.CloudType.STRATOCUMULUS,
            CloudConfig.CloudType.ALTOCUMULUS,CloudConfig.CloudType.CIRRUS,CloudConfig.CloudType.CIRROSTRATUS,
            CloudConfig.CloudType.ALTOSTRATUS,CloudConfig.CloudType.STRATUS,CloudConfig.CloudType.NIMBOSTRATUS,
            CloudConfig.CloudType.CUMULONIMBUS,CloudConfig.CloudType.CUMULONIMBUS_GROSS};
        return families[(int)Math.floorMod(mc.level.getDayTime()/24000L/2L,families.length)];
    }
    public static float precipitation(double x,double z){
        if(!CloudConfig.CUSTOM_PRECIPITATION.get())return 0;
        var type=activeType();
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.STRATUS||
            type==CloudConfig.CloudType.ALTOCUMULUS||type==CloudConfig.CloudType.CIRRUS||
            type==CloudConfig.CloudType.CIRROSTRATUS||type==CloudConfig.CloudType.AUTO)return 0;
        if(type==CloudConfig.CloudType.NIMBOSTRATUS){
            double modulation=.74+.13*noise(x/70,z/75,13)+.09*noise(x/26,z/31,19);
            return (float)Math.max(.36,Math.min(1,modulation));
        }
        double cx=Math.floor((x+256)/512.0)*512,cz=Math.floor((z+256)/512.0)*512;
        boolean giant=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS;
        boolean storm=type==CloudConfig.CloudType.CUMULONIMBUS||giant;
        double dx=(x-cx)/(giant?170:storm?112:132);
        double dz=(z-cz)/(giant?155:storm?102:120);
        double d=Math.sqrt(dx*dx+dz*dz);
        double edge=Math.max(0,Math.min(1,(1.10-d)*4.0));
        double patch=.82+.12*noise(x/36,z/42,37)+.06*noise(x/13,z/15,53);
        double strength=giant?1:storm?.95:type==CloudConfig.CloudType.ALTOSTRATUS?.16:.28;
        return (float)Math.max(0,Math.min(1,edge*patch*strength));
    }
    public static double cloudBase(){
        return cloudBaseAt(0,0);
    }
    public static double cloudBaseAt(double x,double z){
        var type=activeType();
        if(type==CloudConfig.CloudType.NIMBOSTRATUS||type==CloudConfig.CloudType.STRATUS||
            type==CloudConfig.CloudType.ALTOSTRATUS||type==CloudConfig.CloudType.CIRROSTRATUS)
            return CloudConfig.HEIGHT.get()+CloudRenderer.layerBottomOffset(type,x,z);
        return CloudConfig.HEIGHT.get()+(type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?-32:
            type==CloudConfig.CloudType.CUMULONIMBUS?-22:-28);
    }
    public enum PrecipitationKind { NONE, RAIN, SLEET, SNOW }
    public static PrecipitationKind kind(double temperature){
        if(temperature<0)return PrecipitationKind.SNOW;
        if(temperature<1)return PrecipitationKind.SLEET;
        return PrecipitationKind.RAIN;
    }
    public static double temperature(double x,double y,double z){
        var mc=Minecraft.getInstance();
        double biome=mc.level==null?.8:mc.level.getBiome(BlockPos.containing(x,mc.level.getSeaLevel(),z)).value().getBaseTemperature();
        return 15+(biome-.8)*24-Math.max(0,y-64)*.11+CloudConfig.TEMPERATURE_OFFSET.get();
    }
    public static PrecipitationKind precipitationKind(double x,double y,double z){
        return precipitation(x,z)<=0?PrecipitationKind.NONE:kind(temperature(x,y,z));
    }
    private static double noise(double x,double z,int seed){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);
        double fx=x-ix,fz=z-iz;fx=fx*fx*(3-2*fx);fz=fz*fz*(3-2*fz);
        double a=hash(ix,iz,seed),b=hash(ix+1,iz,seed),c=hash(ix,iz+1,seed),d=hash(ix+1,iz+1,seed);
        return (a+(b-a)*fx)*(1-fz)+(c+(d-c)*fx)*fz;
    }
    private static double hash(int x,int z,int seed){
        long n=(long)x*374761393L+(long)z*668265263L+seed*1442695041L;
        n=(n^(n>>>13))*1274126177L;n^=n>>>16;
        return (n&65535)/32767.5-1;
    }
    private WeatherField(){}
}
