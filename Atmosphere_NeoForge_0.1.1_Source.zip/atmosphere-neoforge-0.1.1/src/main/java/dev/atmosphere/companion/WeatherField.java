package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;

/** One deterministic source for rendered clouds, local precipitation and radar. */
public final class WeatherField {
    public static CloudConfig.CloudType activeType(){
        var type=CloudConfig.CLOUD_TYPE.get();
        var mc=Minecraft.getInstance();
        if(type!=CloudConfig.CloudType.AUTO||mc.level==null)return type;
        CloudConfig.CloudType[] families={CloudConfig.CloudType.CUMULUS,CloudConfig.CloudType.STRATOCUMULUS,
            CloudConfig.CloudType.STRATUS,CloudConfig.CloudType.NIMBOSTRATUS,CloudConfig.CloudType.CUMULONIMBUS};
        return families[(int)Math.floorMod(mc.level.getDayTime()/24000L/2L,families.length)];
    }
    public static float precipitation(double x,double z){
        var type=activeType();
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.STRATUS||type==CloudConfig.CloudType.AUTO)return 0;
        if(type==CloudConfig.CloudType.NIMBOSTRATUS){
            double wave=.78+.14*Math.sin(x*.012+z*.009)+.09*Math.cos(z*.018-x*.007);
            return (float)Math.max(.35,Math.min(1,wave));
        }
        double cx=Math.floor((x+256)/512.0)*512,cz=Math.floor((z+256)/512.0)*512;
        double dx=(x-cx)/(type==CloudConfig.CloudType.CUMULONIMBUS?112:132);
        double dz=(z-cz)/(type==CloudConfig.CloudType.CUMULONIMBUS?102:120);
        double d=Math.sqrt(dx*dx+dz*dz);
        double edge=Math.max(0,Math.min(1,(1.1-d)*3.0));
        double patch=.77+.16*Math.sin(x*.045+z*.021)*Math.cos(z*.032-x*.013);
        double strength=type==CloudConfig.CloudType.CUMULONIMBUS?.95:.28;
        return (float)Math.max(0,Math.min(1,edge*patch*strength));
    }
    public static double cloudBase(){
        return cloudBaseAt(0,0);
    }
    public static double cloudBaseAt(double x,double z){
        var type=activeType();
        if(type==CloudConfig.CloudType.NIMBOSTRATUS||type==CloudConfig.CloudType.STRATUS)
            return CloudConfig.HEIGHT.get()+CloudRenderer.layerBottomOffset(type,x,z);
        return CloudConfig.HEIGHT.get()+(type==CloudConfig.CloudType.CUMULONIMBUS?-22:-28);
    }
    private WeatherField(){}
}
