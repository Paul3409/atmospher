package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.LinkedHashMap;
import java.util.Map;

/** One deterministic source for rendered clouds, local precipitation and radar. */
public final class WeatherField {
    private static Object windLevel;
    private static long windTick=Long.MIN_VALUE;
    private static double windX,windZ;
    private record FogTerrain(int ground,double basin,double water,double humidity){}
    private static Object fogLevel;
    private static final Map<Long,FogTerrain> FOG_TERRAIN=new LinkedHashMap<>(1024,.75f,true){
        @Override protected boolean removeEldestEntry(Map.Entry<Long,FogTerrain> e){return size()>2048;}
    };
    public static CloudConfig.CloudType activeType(){
        var type=CloudConfig.CLOUD_TYPE.get();
        var mc=Minecraft.getInstance();
        if(type!=CloudConfig.CloudType.AUTO||mc.level==null)return type;
        var player=mc.player;
        if(player!=null){
            var cell=WeatherCells.sample(player.getX(),player.getZ(),mc.level.getGameTime());
            if(cell.type()==WeatherCells.SQUALL||cell.type()==WeatherCells.SEVERE)return CloudConfig.CloudType.CUMULONIMBUS_GROSS;
            if(cell.type()==WeatherCells.THUNDER)return CloudConfig.CloudType.CUMULONIMBUS;
            if(cell.cloud()>.13)return CloudConfig.CloudType.CUMULUS;
        }
        CloudConfig.CloudType[] fair={CloudConfig.CloudType.CUMULUS,CloudConfig.CloudType.STRATOCUMULUS,
            CloudConfig.CloudType.ALTOCUMULUS,CloudConfig.CloudType.CIRRUS,CloudConfig.CloudType.CIRROSTRATUS};
        return fair[(int)Math.floorMod(mc.level.getDayTime()/48000L,fair.length)];
    }
    public static float precipitation(double x,double z){
        if(CloudConfig.SIMULATOR_ENABLED.get()){
            var mc=Minecraft.getInstance();
            double y=mc.level==null?64:mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)Math.floor(x),(int)Math.floor(z));
            return precipitation(x,y,z);
        }
        if(!CloudConfig.CUSTOM_PRECIPITATION.get()||CloudConfig.PRECIPITATION_DENSITY.get()==0)return 0;
        var selected=CloudConfig.CLOUD_TYPE.get();
        var type=activeType();
        if(selected==CloudConfig.CloudType.AUTO){
            var mc=Minecraft.getInstance();
            double ticks=mc.level==null?0:mc.level.getGameTime();
            double rain=WeatherCells.sample(x,z,ticks).rain();
            return rain<.015?0:scaled(rain);
        }
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.STRATUS||
            type==CloudConfig.CloudType.ALTOCUMULUS||type==CloudConfig.CloudType.CIRRUS||
            type==CloudConfig.CloudType.CIRROSTRATUS||type==CloudConfig.CloudType.AUTO)return 0;
        double[] wind=windOffset();
        double sx=x-wind[0],sz=z-wind[1];
        if(type==CloudConfig.CloudType.NIMBOSTRATUS){
            double modulation=.74+.13*noise(sx/70,sz/75,13)+.09*noise(sx/26,sz/31,19);
            return scaled(modulation);
        }
        boolean giant=type==CloudConfig.CloudType.CUMULONIMBUS_GROSS;
        boolean storm=type==CloudConfig.CloudType.CUMULONIMBUS||giant;
        int bx=(int)Math.floor(sx/512.0),bz=(int)Math.floor(sz/512.0);
        double best=0;
        for(int gx=bx-1;gx<=bx+1;gx++)for(int gz=bz-1;gz<=bz+1;gz++){
            double[] cell=cloudCell(gx,gz);
            if(cell[4]<.5)continue;
            double scale=cell[2]*CloudConfig.CLOUD_SCALE.get()/100.0;
            double px=sx-cell[0],pz=sz-cell[1],cos=Math.cos(cell[3]),sin=Math.sin(cell[3]);
            double lx=px*cos+pz*sin,lz=-px*sin+pz*cos;
            double radius=(giant?155:storm?112:120)*scale;
            long seed=((long)gx<<32)^(gz&0xffffffffL);
            int cellType=giant?WeatherCells.SEVERE:storm?WeatherCells.THUNDER:WeatherCells.SHOWER;
            best=Math.max(best,StormEvolution.rainProfile(lx,lz,radius,seed,cellType,1));
        }
        double patch=.82+.12*noise(sx/36,sz/42,37)+.06*noise(sx/13,sz/15,53);
        double strength=giant?1.60:storm?1.50:type==CloudConfig.CloudType.ALTOSTRATUS?.16:.28;
        double rain=best*patch*strength;
        return rain<.015?0:scaled(rain);
    }
    public static float precipitation(double x,double y,double z){
        var sample=ManualWeather.sample(x,y,z);
        return sample.enabled()?sample.intensity():0;
    }
    private static float scaled(double intensity){
        return (float)Math.max(0,Math.min(1,intensity*CloudConfig.PRECIPITATION_DENSITY.get()/100.0));
    }
    public static double cloudBase(){
        return cloudBaseAt(0,0);
    }
    public static double cloudBaseAt(double x,double z){
        var type=activeType();
        if(type==CloudConfig.CloudType.NIMBOSTRATUS||type==CloudConfig.CloudType.STRATUS||
            type==CloudConfig.CloudType.ALTOSTRATUS||type==CloudConfig.CloudType.CIRROSTRATUS)
        {
            double[] wind=windOffset();
            return CloudConfig.HEIGHT.get()+CloudRenderer.layerBottomOffset(type,x-wind[0],z-wind[1]);
        }
        return CloudConfig.HEIGHT.get()+(type==CloudConfig.CloudType.CUMULONIMBUS_GROSS?-32:
            type==CloudConfig.CloudType.CUMULONIMBUS?-22:-28);
    }
    public enum PrecipitationKind { NONE, RAIN, SLEET, SNOW }
    public static PrecipitationKind kind(double temperature){
        if(temperature<0)return PrecipitationKind.SNOW;
        if(temperature<1)return PrecipitationKind.SLEET;
        return PrecipitationKind.RAIN;
    }
    public static double temperature(double x,double y,double z){
        if(CloudConfig.SIMULATOR_ENABLED.get()){
            var sample=ManualWeather.sample(x,y,z);
            return sample.temperature()-(y-64)*CloudConfig.HEIGHT_COOLING.get()/100.0;
        }
        var mc=Minecraft.getInstance();
        double biome=mc.level==null?.8:mc.level.getBiome(BlockPos.containing(x,mc.level.getSeaLevel(),z)).value().getBaseTemperature();
        return 15+(biome-.8)*24-Math.max(0,y-64)*.11+CloudConfig.TEMPERATURE_OFFSET.get();
    }
    /** Topography, water proximity, humidity, and night cooling form a stable local fog potential. */
    public static double fogPotential(double x,double z){
        var mc=Minecraft.getInstance();
        if(mc.level==null||!CloudConfig.FOG_ENABLED.get()||CloudConfig.FOG_DENSITY.get()==0)return 0;
        if(fogLevel!=mc.level){fogLevel=mc.level;FOG_TERRAIN.clear();}
        int tx=(int)Math.floor(x/24),tz=(int)Math.floor(z/24);
        long key=((long)tx<<32)^(tz&0xffffffffL);
        FogTerrain terrain=FOG_TERRAIN.computeIfAbsent(key,k->sampleFogTerrain(tx*24+12,tz*24+12));
        if(terrain.ground<=mc.level.getMinBuildHeight()+1)return 0;
        double altitude=Math.max(0,Math.min(1,(112-terrain.ground)/38.0));
        long day=Math.floorMod(mc.level.getDayTime(),24000L);
        double night=Math.max(0,Math.min(1,(1-Math.cos((day-6000)*Math.PI*2/24000))*.5));
        double persistence=CloudConfig.FOG_DURATION.get()/100.0;
        double temporal=.72+.28*Math.sin((mc.level.getGameTime()/Math.max(120.0,900.0*(1.15-persistence)))+x*.0017+z*.0013);
        double weather=CloudConfig.CLOUD_TYPE.get()==CloudConfig.CloudType.AUTO?
            WeatherCells.sample(x,z,mc.level.getGameTime()).cloud()*.28:0;
        double waterInfluence=CloudConfig.FOG_WATER_INFLUENCE.get()/100.0;
        double potential=(.50*terrain.basin+.38*altitude*terrain.water*waterInfluence+
            .34*night*terrain.humidity+.18*weather+.12*terrain.water*night*waterInfluence)*temporal;
        return Math.max(0,Math.min(1,potential*CloudConfig.FOG_DENSITY.get()/100.0));
    }
    private static FogTerrain sampleFogTerrain(int bx,int bz){
        var level=Minecraft.getInstance().level;
        if(level==null)return new FogTerrain(0,0,0,0);
        int ground=level.getHeight(Heightmap.Types.MOTION_BLOCKING,bx,bz);
        double sum=0;int count=0;
        for(int dx=-32;dx<=32;dx+=16)for(int dz=-32;dz<=32;dz+=16){
            sum+=level.getHeight(Heightmap.Types.MOTION_BLOCKING,bx+dx,bz+dz);count++;
        }
        double basin=Math.max(0,Math.min(1,(sum/count-ground-2)/12.0));
        double water=0;
        for(int dx=-24;dx<=24;dx+=8)for(int dz=-24;dz<=24;dz+=8){
            int surface=level.getHeight(Heightmap.Types.MOTION_BLOCKING,bx+dx,bz+dz);
            var p=BlockPos.containing(bx+dx,surface-1,bz+dz);
            if(level.hasChunkAt(p)&&!level.getFluidState(p).isEmpty())
                water=Math.max(water,1-Math.hypot(dx,dz)/42.0);
        }
        double biome=level.getBiome(BlockPos.containing(bx,ground,bz)).value().getBaseTemperature();
        double humidity=Math.max(0,Math.min(1,.62+(0.8-biome)*.36));
        return new FogTerrain(ground,basin,Math.max(.12,water),humidity);
    }
    /** World-time advection. Camera position is deliberately never part of this calculation. */
    public static double[] windOffset(){
        var mc=Minecraft.getInstance();
        double[] base=baseWindOffset();
        var type=activeType();
        double altitudeFactor=type==CloudConfig.CloudType.CIRRUS||type==CloudConfig.CloudType.CIRROSTRATUS?1.45:
            type==CloudConfig.CloudType.ALTOCUMULUS||type==CloudConfig.CloudType.ALTOSTRATUS?1.2:
            type==CloudConfig.CloudType.STRATUS||type==CloudConfig.CloudType.NIMBOSTRATUS?.82:1;
        return new double[]{base[0]*altitudeFactor,base[1]*altitudeFactor};
    }
    static double[] baseWindOffset(){
        var mc=Minecraft.getInstance();
        if(mc.level==null)return new double[]{0,0};
        long tick=mc.level.getGameTime();
        if(windLevel!=mc.level||windTick==Long.MIN_VALUE){windLevel=mc.level;windTick=tick;windX=windZ=0;}
        long elapsed=Math.max(0,tick-windTick);
        var direction=CloudConfig.WIND_DIRECTION.get();
        double blocks=elapsed*CloudConfig.WIND_SPEED.get()/20.0;
        windX+=direction.dx*blocks;windZ+=direction.dz*blocks;windTick=tick;
        return new double[]{windX,windZ};
    }
    public static void captureWindState(){baseWindOffset();}
    /** Stable world cell: x, z, scale, rotation, visible. */
    static double[] cloudCell(int gx,int gz){
        double hx=hash(gx,gz,101),hz=hash(gx,gz,103);
        double scale=.84+(hash(gx,gz,107)+1)*.16;
        double rotation=hash(gx,gz,109)*.42;
        double chance=(hash(gx,gz,117)+1)*50;
        return new double[]{gx*512+hx*82,gz*512+hz*82,scale,rotation,
            chance<=CloudConfig.CLOUD_DENSITY.get()?1:0};
    }
    public static PrecipitationKind precipitationKind(double x,double y,double z){
        if(CloudConfig.SIMULATOR_ENABLED.get())return ManualWeather.sample(x,y,z).kind(y);
        return precipitation(x,z)<=0?PrecipitationKind.NONE:kind(temperature(x,y,z));
    }
    /** Physical display rate shared by radar readout and local weather HUD. */
    public static double precipitationMmH(double x,double z){
        double normalized=precipitation(x,z);
        if(normalized<=0)return 0;
        // Low echoes remain drizzle while severe cores can reach the configured maximum.
        return Math.pow(normalized,1.48)*CloudConfig.MAX_PRECIPITATION.get();
    }
    private static double noise(double x,double z,int seed){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);
        double fx=x-ix,fz=z-iz;fx=fx*fx*(3-2*fx);fz=fz*fz*(3-2*fz);
        double a=hash(ix,iz,seed),b=hash(ix+1,iz,seed),c=hash(ix,iz+1,seed),d=hash(ix+1,iz+1,seed);
        return (a+(b-a)*fx)*(1-fz)+(c+(d-c)*fx)*fz;
    }
    private static double hash(int x,int z,int seed){
        long n=(long)x*374761393L+(long)z*668265263L+seed*1442695041L;
        n=(n^(n>>>13))*1274126177L;n^=n>>>16;
        return (n&65535)/32767.5-1;
    }
    private WeatherField(){}
}
