package dev.atmosphere.companion;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** A world anchored, freely painted weather mask with its own vertical range and weather profile. */
public final class ManualWeatherZone {
    public String id=UUID.randomUUID().toString();
    public String name="Neue Wetterzone";
    public String dimension="minecraft:overworld";
    public int cellSize=4;
    public int minY=-64;
    public int maxY=384;
    public boolean enabled=true;
    public CloudConfig.PrecipitationSelection precipitation=CloudConfig.PrecipitationSelection.AUTOMATISCH;
    public int intensity=55;
    public double temperature=8;
    public int snowLine=128;
    public int snowTransition=8;
    public int fogDensity=0;
    public int fogStart=32;
    public int fogEnd=128;
    public CloudConfig.WindDirection windDirection=CloudConfig.WindDirection.WEST;
    public double windSpeed=1;
    public int lightning=0;
    public Set<Long> cells=new HashSet<>();

    public boolean contains(double x,double y,double z){
        if(!enabled||y<minY||y>maxY)return false;
        int cx=Math.floorDiv((int)Math.floor(x),cellSize);
        int cz=Math.floorDiv((int)Math.floor(z),cellSize);
        return cells.contains(key(cx,cz));
    }
    public boolean containsXZ(double x,double z){
        int cx=Math.floorDiv((int)Math.floor(x),cellSize);
        int cz=Math.floorDiv((int)Math.floor(z),cellSize);
        return cells.contains(key(cx,cz));
    }
    public void paint(double worldX,double worldZ,double radius,boolean erase){
        int centerX=Math.floorDiv((int)Math.floor(worldX),cellSize);
        int centerZ=Math.floorDiv((int)Math.floor(worldZ),cellSize);
        int reach=Math.max(0,(int)Math.ceil(radius/cellSize));
        double r=Math.max(cellSize*.55,radius);
        for(int dx=-reach;dx<=reach;dx++)for(int dz=-reach;dz<=reach;dz++){
            double px=(centerX+dx+.5)*cellSize-worldX;
            double pz=(centerZ+dz+.5)*cellSize-worldZ;
            if(px*px+pz*pz>r*r)continue;
            long key=key(centerX+dx,centerZ+dz);
            if(erase)cells.remove(key);else cells.add(key);
        }
    }
    public static long key(int x,int z){return ((long)x<<32)^(z&0xffffffffL);}
    public static int keyX(long key){return (int)(key>>32);}
    public static int keyZ(long key){return (int)key;}
}
