package dev.atmosphere.companion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Only options that already affect this build are exposed here. */
public final class CloudMenuScreen extends Screen {
    public CloudMenuScreen(){super(Component.literal("Atmosphere – Einstellungen"));}
    @Override protected void init(){
        int x=width/2-105,y=height/2-86;
        addRenderableWidget(Button.builder(Component.literal("Wolkenart: "+CloudConfig.CLOUD_TYPE.get()),b->{
            var values=CloudConfig.CloudType.values();var current=CloudConfig.CLOUD_TYPE.get();
            CloudConfig.CLOUD_TYPE.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Qualitaet: "+CloudConfig.QUALITY.get()),b->{
            var values=CloudConfig.Quality.values();var current=CloudConfig.QUALITY.get();
            CloudConfig.QUALITY.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y+24,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Wolkenhoehe: "+CloudConfig.HEIGHT.get()),b->{
            int next=CloudConfig.HEIGHT.get()+8;CloudConfig.HEIGHT.set(next>256?96:next);rebuildWidgets();
        }).bounds(x,y+48,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Vanilla-Wolken: "+(CloudConfig.HIDE_VANILLA_CLOUDS.get()?"AUS":"AN")),b->{
            CloudConfig.HIDE_VANILLA_CLOUDS.set(!CloudConfig.HIDE_VANILLA_CLOUDS.get());rebuildWidgets();
        }).bounds(x,y+72,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Radar oeffnen (R)"),b->minecraft.setScreen(new RadarScreen()))
            .bounds(x,y+106,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(x,y+130,210,20).build());
    }
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        gui.drawCenteredString(font,title,width/2,height/2-104,0xFFFFFF);
        gui.drawCenteredString(font,"Vanilla-Niederschlag: immer AUS | Eigener Regen nur unter Regenwolken",width/2,height/2+76,0xAAAAAA);
    }
    @Override public boolean isPauseScreen(){return false;}
}
