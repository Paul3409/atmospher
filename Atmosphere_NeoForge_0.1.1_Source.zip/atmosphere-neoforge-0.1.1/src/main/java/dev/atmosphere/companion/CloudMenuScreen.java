package dev.atmosphere.companion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Only options that already affect this build are exposed here. */
public final class CloudMenuScreen extends Screen {
    private int page;
    public CloudMenuScreen(){super(Component.literal("Atmosphere – Einstellungen"));}
    CloudMenuScreen(int page){this();this.page=page;}
    @Override protected void init(){
        int x=width/2-120,y=height/2-116,w=240;
        if(page==0){
        addRenderableWidget(Button.builder(Component.literal("Wolkenart: "+CloudConfig.CLOUD_TYPE.get()),b->{
            var values=CloudConfig.CloudType.values();var current=CloudConfig.CLOUD_TYPE.get();
            CloudConfig.CLOUD_TYPE.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y,w,20).build());
        addRenderableWidget(Button.builder(Component.literal("Wind aus: "+CloudConfig.WIND_DIRECTION.get()),b->{
            WeatherField.captureWindState();
            var values=CloudConfig.WindDirection.values();var current=CloudConfig.WIND_DIRECTION.get();
            CloudConfig.WIND_DIRECTION.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y+24,w,20).build());
        addRenderableWidget(new AtmosphereSlider(x,y+48,w,0,5,CloudConfig.WIND_SPEED::get,v->{WeatherField.captureWindState();CloudConfig.WIND_SPEED.set(v);},
            v->String.format(java.util.Locale.ROOT,"Windgeschwindigkeit: %.2f",v)));
        addRenderableWidget(AtmosphereSlider.integer(x,y+72,w,96,256,CloudConfig.HEIGHT::get,CloudConfig.HEIGHT::set,
            v->"Wolkenhoehe: "+v));
        addRenderableWidget(Button.builder(Component.literal("Vanilla-Wolken: "+(CloudConfig.HIDE_VANILLA_CLOUDS.get()?"AUS":"AN")),b->{
            CloudConfig.HIDE_VANILLA_CLOUDS.set(!CloudConfig.HIDE_VANILLA_CLOUDS.get());rebuildWidgets();
        }).bounds(x,y+96,w,20).build());
        }else if(page==1){
            addRenderableWidget(Button.builder(Component.literal("Eigener Niederschlag: "+on(CloudConfig.CUSTOM_PRECIPITATION.get())),b->{
                CloudConfig.CUSTOM_PRECIPITATION.set(!CloudConfig.CUSTOM_PRECIPITATION.get());rebuildWidgets();
            }).bounds(x,y,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,0,200,CloudConfig.PRECIPITATION_DENSITY::get,CloudConfig.PRECIPITATION_DENSITY::set,
                v->"Niederschlagsdichte: "+v+"%"));
            addRenderableWidget(new AtmosphereSlider(x,y+48,w,-30,30,CloudConfig.TEMPERATURE_OFFSET::get,CloudConfig.TEMPERATURE_OFFSET::set,
                v->String.format(java.util.Locale.ROOT,"Temperatur-Korrektur: %.1f °C",v)));
            addRenderableWidget(Button.builder(Component.literal("Niederschlagswand: "+on(CloudConfig.RAIN_CURTAIN.get())),b->{
                CloudConfig.RAIN_CURTAIN.set(!CloudConfig.RAIN_CURTAIN.get());rebuildWidgets();
            }).bounds(x,y+72,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,0,200,CloudConfig.CURTAIN_OPACITY::get,CloudConfig.CURTAIN_OPACITY::set,
                v->"Wandstaerke: "+v+"%"));
            addRenderableWidget(Button.builder(Component.literal("Optischer Schneefall: "+on(CloudConfig.OPTICAL_SNOW.get())),b->{
                CloudConfig.OPTICAL_SNOW.set(!CloudConfig.OPTICAL_SNOW.get());rebuildWidgets();
            }).bounds(x,y+120,w,20).build());
            addRenderableWidget(Button.builder(Component.literal("Eigene Blitze: "+on(CloudConfig.LIGHTNING.get())),b->{
                CloudConfig.LIGHTNING.set(!CloudConfig.LIGHTNING.get());rebuildWidgets();
            }).bounds(x,y+144,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+168,w,0,200,CloudConfig.LIGHTNING_FREQUENCY::get,CloudConfig.LIGHTNING_FREQUENCY::set,
                v->"Blitzhaeufigkeit: "+v+"%"));
        }else if(page==2){
        addRenderableWidget(Button.builder(Component.literal("Qualitaet: "+CloudConfig.QUALITY.get()),b->{
            var values=CloudConfig.Quality.values();var current=CloudConfig.QUALITY.get();
            CloudConfig.QUALITY.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,256,1024,CloudConfig.RENDER_DISTANCE::get,CloudConfig.RENDER_DISTANCE::set,
                v->"Sichtweite: "+v+" Bloecke"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,20,100,CloudConfig.CLOUD_DENSITY::get,CloudConfig.CLOUD_DENSITY::set,
                v->"Wolkendichte: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+72,w,60,160,CloudConfig.CLOUD_SCALE::get,CloudConfig.CLOUD_SCALE::set,
                v->"Wolkengroesse: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,20,100,CloudConfig.CLOUD_OPACITY::get,CloudConfig.CLOUD_OPACITY::set,
                v->"Deckkraft: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+120,w,0,180,CloudConfig.ROUGHNESS::get,CloudConfig.ROUGHNESS::set,
                v->"Formdetail: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+144,w,8,100,CloudConfig.NIGHT_BRIGHTNESS::get,CloudConfig.NIGHT_BRIGHTNESS::set,
                v->"Nachthelligkeit: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+168,w,2,24,CloudConfig.RADAR_ZOOM::get,CloudConfig.RADAR_ZOOM::set,
                v->"Radar-Zoom: "+v+" Bloecke/Pixel"));
        }else if(page==3){
            addRenderableWidget(AtmosphereSlider.integer(x,y,w,20,200,CloudConfig.WEATHER_CELL_DENSITY::get,CloudConfig.WEATHER_CELL_DENSITY::set,
                v->"Wetterzellendichte: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,50,200,CloudConfig.WEATHER_LIFETIME::get,CloudConfig.WEATHER_LIFETIME::set,
                v->"Zelllebensdauer: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,0,200,CloudConfig.FRONT_STRENGTH::get,CloudConfig.FRONT_STRENGTH::set,
                v->"Niederschlagsfront: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+72,w,0,100,CloudConfig.VIRGA_AMOUNT::get,CloudConfig.VIRGA_AMOUNT::set,
                v->"Virga-Anteil: "+v+"%"));
            addRenderableWidget(Button.builder(Component.literal("Natuerliches Wetter: "+(CloudConfig.CLOUD_TYPE.get()==CloudConfig.CloudType.AUTO?"AKTIV":"AUTO waehlen")),b->{
                CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.AUTO);rebuildWidgets();
            }).bounds(x,y+96,w,20).build());
        }else if(page==4){
            addRenderableWidget(Button.builder(Component.literal("Terrainnebel: "+on(CloudConfig.FOG_ENABLED.get())),b->{
                CloudConfig.FOG_ENABLED.set(!CloudConfig.FOG_ENABLED.get());rebuildWidgets();
            }).bounds(x,y,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,0,100,CloudConfig.FOG_DENSITY::get,CloudConfig.FOG_DENSITY::set,
                v->"Nebeldichte: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,0,100,CloudConfig.FOG_DURATION::get,CloudConfig.FOG_DURATION::set,
                v->"Nebeldauer: "+v+"%"));
            if(minecraft!=null&&minecraft.player!=null){
                var p=minecraft.player;
                addRenderableWidget(Button.builder(Component.literal(String.format(java.util.Locale.ROOT,"Lokal: Hoehe %d | Nebel %.0f%%",
                    minecraft.level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,p.blockPosition().getX(),p.blockPosition().getZ()),
                    WeatherField.fogPotential(p.getX(),p.getZ())*100)),b->{}).bounds(x,y+72,w,20).build());
            }
            addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,0,150,CloudConfig.FOG_WATER_INFLUENCE::get,CloudConfig.FOG_WATER_INFLUENCE::set,
                v->"Wassereinfluss: "+v+"%"));
        }else if(page==5){
            addRenderableWidget(AtmosphereSlider.integer(x,y,w,40,220,CloudConfig.RAIN_PARTICLE_SIZE::get,CloudConfig.RAIN_PARTICLE_SIZE::set,
                v->"Regentropfen-Groesse: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,40,220,CloudConfig.SNOW_PARTICLE_SIZE::get,CloudConfig.SNOW_PARTICLE_SIZE::set,
                v->"Schneeflocken-Groesse: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,40,220,CloudConfig.SLEET_PARTICLE_SIZE::get,CloudConfig.SLEET_PARTICLE_SIZE::set,
                v->"Schneeregen-Groesse: "+v+"%"));
            addRenderableWidget(Button.builder(Component.literal("Boden-/Wasserspritzer: "+on(CloudConfig.SPLASHES.get())),b->{
                CloudConfig.SPLASHES.set(!CloudConfig.SPLASHES.get());rebuildWidgets();
            }).bounds(x,y+72,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,0,100,CloudConfig.CLOUD_SMOOTHING::get,CloudConfig.CLOUD_SMOOTHING::set,
                v->"Wolken-Verschmelzung: "+v+"%"));
        }else{
            addRenderableWidget(Button.builder(Component.literal("Wettersounds: "+on(CloudConfig.WEATHER_SOUNDS.get())),b->{
                CloudConfig.WEATHER_SOUNDS.set(!CloudConfig.WEATHER_SOUNDS.get());rebuildWidgets();
            }).bounds(x,y,w,20).build());
            addRenderableWidget(AtmosphereSlider.integer(x,y+24,w,0,100,CloudConfig.SOUND_VOLUME::get,CloudConfig.SOUND_VOLUME::set,
                v->"Gesamtlautstaerke: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+48,w,0,100,CloudConfig.RAIN_VOLUME::get,CloudConfig.RAIN_VOLUME::set,
                v->"Regenlautstaerke: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+72,w,0,100,CloudConfig.WIND_VOLUME::get,CloudConfig.WIND_VOLUME::set,
                v->"Windlautstaerke: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+96,w,0,100,CloudConfig.THUNDER_VOLUME::get,CloudConfig.THUNDER_VOLUME::set,
                v->"Donnerlautstaerke: "+v+"%"));
            addRenderableWidget(AtmosphereSlider.integer(x,y+120,w,0,100,CloudConfig.INDOOR_DAMPING::get,CloudConfig.INDOOR_DAMPING::set,
                v->"Innenraumdaempfung: "+v+"%"));
        }
        addRenderableWidget(Button.builder(Component.literal("<"),b->{page=(page+6)%7;rebuildWidgets();}).bounds(x,y+196,36,20).build());
        addRenderableWidget(Button.builder(Component.literal(page==0?"Wolken & Wind":page==1?"Niederschlag":page==2?"Grafik":page==3?"Wetterzellen":page==4?"Nebel":page==5?"Partikel":"Sounds"),b->{})
            .bounds(x+40,y+196,160,20).build());
        addRenderableWidget(Button.builder(Component.literal(">"),b->{page=(page+1)%7;rebuildWidgets();}).bounds(x+204,y+196,36,20).build());
        addRenderableWidget(Button.builder(Component.literal("Radar (R)"),b->minecraft.setScreen(new RadarScreen()))
            .bounds(x,y+220,116,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(x+124,y+220,116,20).build());
    }
    private static String on(boolean value){return value?"AN":"AUS";}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        gui.drawCenteredString(font,title,width/2,height/2-136,0xFFFFFF);
        if(page==1&&minecraft!=null&&minecraft.player!=null){
            var p=minecraft.player;
            double t=WeatherField.temperature(p.getX(),p.getY(),p.getZ());
            gui.drawCenteredString(font,String.format(java.util.Locale.ROOT,"Lokal: %.1f °C | %s",t,WeatherField.kind(t)),
                width/2,height/2+126,0xDDDDDD);
        }
    }
    @Override public boolean isPauseScreen(){return false;}
}
