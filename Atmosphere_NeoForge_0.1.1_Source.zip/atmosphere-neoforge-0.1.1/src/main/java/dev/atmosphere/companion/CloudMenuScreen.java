package dev.atmosphere.companion;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Only options that already affect this build are exposed here. */
public final class CloudMenuScreen extends Screen {
    private int page;
    public CloudMenuScreen(){super(Component.literal("Atmosphere – Einstellungen"));}
    CloudMenuScreen(int page){this();this.page=page;}
    @Override protected void init(){
        int x=width/2-105,y=height/2-105;
        if(page==0){
        addRenderableWidget(Button.builder(Component.literal("Wolkenart: "+CloudConfig.CLOUD_TYPE.get()),b->{
            var values=CloudConfig.CloudType.values();var current=CloudConfig.CLOUD_TYPE.get();
            CloudConfig.CLOUD_TYPE.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Qualitaet: "+CloudConfig.QUALITY.get()),b->{
            var values=CloudConfig.Quality.values();var current=CloudConfig.QUALITY.get();
            CloudConfig.QUALITY.set(values[(current.ordinal()+1)%values.length]);rebuildWidgets();
        }).bounds(x,y+24,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Wolkenhoehe: "+CloudConfig.HEIGHT.get()),b->{
            int next=CloudConfig.HEIGHT.get()+8;CloudConfig.HEIGHT.set(next>256?96:next);rebuildWidgets();
        }).bounds(x,y+48,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Vanilla-Wolken: "+(CloudConfig.HIDE_VANILLA_CLOUDS.get()?"AUS":"AN")),b->{
            CloudConfig.HIDE_VANILLA_CLOUDS.set(!CloudConfig.HIDE_VANILLA_CLOUDS.get());rebuildWidgets();
        }).bounds(x,y+72,210,20).build());
        }else{
            addRenderableWidget(Button.builder(Component.literal("Eigener Niederschlag: "+on(CloudConfig.CUSTOM_PRECIPITATION.get())),b->{
                CloudConfig.CUSTOM_PRECIPITATION.set(!CloudConfig.CUSTOM_PRECIPITATION.get());rebuildWidgets();
            }).bounds(x,y,210,20).build());
            addRenderableWidget(Button.builder(Component.literal("Dichte: "+CloudConfig.PRECIPITATION_DENSITY.get()+"%"),b->{
                CloudConfig.PRECIPITATION_DENSITY.set((CloudConfig.PRECIPITATION_DENSITY.get()+25)%225);rebuildWidgets();
            }).bounds(x,y+24,210,20).build());
            addRenderableWidget(Button.builder(Component.literal("Niederschlagswand: "+on(CloudConfig.RAIN_CURTAIN.get())),b->{
                CloudConfig.RAIN_CURTAIN.set(!CloudConfig.RAIN_CURTAIN.get());rebuildWidgets();
            }).bounds(x,y+48,210,20).build());
            addRenderableWidget(Button.builder(Component.literal("Optischer Schneefall: "+on(CloudConfig.OPTICAL_SNOW.get())),b->{
                CloudConfig.OPTICAL_SNOW.set(!CloudConfig.OPTICAL_SNOW.get());rebuildWidgets();
            }).bounds(x,y+72,210,20).build());
            addRenderableWidget(Button.builder(Component.literal("Temperatur-Korrektur: "+CloudConfig.TEMPERATURE_OFFSET.get()+" °C"),b->{
                int next=CloudConfig.TEMPERATURE_OFFSET.get()+2;
                CloudConfig.TEMPERATURE_OFFSET.set(next>30?-30:next);rebuildWidgets();
            }).bounds(x,y+96,210,20).build());
            addRenderableWidget(Button.builder(Component.literal("Eigene Blitze: "+on(CloudConfig.LIGHTNING.get())),b->{
                CloudConfig.LIGHTNING.set(!CloudConfig.LIGHTNING.get());rebuildWidgets();
            }).bounds(x,y+120,210,20).build());
            addRenderableWidget(Button.builder(Component.literal("Blitzhaeufigkeit: "+CloudConfig.LIGHTNING_FREQUENCY.get()+"%"),b->{
                CloudConfig.LIGHTNING_FREQUENCY.set((CloudConfig.LIGHTNING_FREQUENCY.get()+25)%225);rebuildWidgets();
            }).bounds(x,y+144,210,20).build());
        }
        addRenderableWidget(Button.builder(Component.literal(page==0?"Weiter: Wetter >":"< Zurueck: Wolken"),b->{
            page=1-page;rebuildWidgets();
        }).bounds(x,y+168,210,20).build());
        addRenderableWidget(Button.builder(Component.literal("Radar (R)"),b->minecraft.setScreen(new RadarScreen()))
            .bounds(x,y+192,102,20).build());
        addRenderableWidget(Button.builder(Component.literal("Fertig"),b->onClose()).bounds(x+108,y+192,102,20).build());
    }
    private static String on(boolean value){return value?"AN":"AUS";}
    @Override public void render(GuiGraphics gui,int mouseX,int mouseY,float partialTick){
        super.render(gui,mouseX,mouseY,partialTick);
        gui.drawCenteredString(font,title,width/2,height/2-124,0xFFFFFF);
        if(page==1&&minecraft!=null&&minecraft.player!=null){
            var p=minecraft.player;
            double t=WeatherField.temperature(p.getX(),p.getY(),p.getZ());
            gui.drawCenteredString(font,String.format(java.util.Locale.ROOT,"Lokal: %.1f °C | %s",t,WeatherField.kind(t)),
                width/2,height/2+126,0xDDDDDD);
        }
    }
    @Override public boolean isPauseScreen(){return false;}
}
