package dev.atmosphere.companion;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

/** Small NeoForge/Minecraft-native slider used by the in-game configuration pages. */
final class AtmosphereSlider extends AbstractSliderButton {
    private final double min,max;
    private final Supplier<Double> getter;
    private final Consumer<Double> setter;
    private final Function<Double,String> text;

    AtmosphereSlider(int x,int y,int width,double min,double max,Supplier<Double> getter,
                     Consumer<Double> setter,Function<Double,String> text){
        super(x,y,width,20,Component.empty(),normalise(getter.get(),min,max));
        this.min=min;this.max=max;this.getter=getter;this.setter=setter;this.text=text;
        updateMessage();
    }
    static AtmosphereSlider integer(int x,int y,int width,int min,int max,
                                    Supplier<Integer> getter,Consumer<Integer> setter,
                                    Function<Integer,String> text){
        return new AtmosphereSlider(x,y,width,min,max,()->getter.get().doubleValue(),
            value->setter.accept((int)Math.round(value)),value->text.apply((int)Math.round(value)));
    }
    private static double normalise(double value,double min,double max){
        return Math.max(0,Math.min(1,(value-min)/(max-min)));
    }
    private double actual(){return min+(max-min)*value;}
    @Override protected void updateMessage(){setMessage(Component.literal(text.apply(actual())));}
    @Override protected void applyValue(){setter.accept(actual());}
}
