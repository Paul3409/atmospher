package dev.atmosphere.companion;

/** Slow world-bound pressure waves. They steer and favour cells, fronts and precipitation. */
public final class SynopticSystems {
    public record Sample(double pressure,double humidity,double lift,double windX,double windZ,double front){ }
    private SynopticSystems(){}

    public static Sample sample(double x,double z,double ticks){
        if(!CloudConfig.NATURAL_WEATHER.get())return new Sample(1013,.62,.5,0,0,0);
        double days=ticks/24000.0*CloudConfig.WEATHER_SPEED.get()/100.0;
        double strength=CloudConfig.PRESSURE_STRENGTH.get()/100.0;
        double px=x-days*92,pz=z-days*31;
        double a=Math.sin(px/1550+pz/2380+days*.17);
        double b=Math.cos(px/3100-pz/1280-days*.11);
        double c=Math.sin((px+pz)/720+days*.07)*.28;
        double wave=(a*.58+b*.42+c)*strength;
        double pressure=1013+wave*19;
        double gx=(Math.cos(px/1550+pz/2380+days*.17)/1550*.58-
            Math.sin(px/3100-pz/1280-days*.11)/3100*.42)*strength;
        double gz=(Math.cos(px/1550+pz/2380+days*.17)/2380*.58+
            Math.sin(px/3100-pz/1280-days*.11)/1280*.42)*strength;
        double grad=Math.min(1,Math.hypot(gx,gz)*18500);
        double low=clamp((1015-pressure)/27,0,1);
        double lift=clamp(.12+low*.58+grad*.55,0,1);
        double humidity=clamp(.42+low*.38+.10*Math.sin((px-pz)/940),.15,.98);
        double norm=Math.max(1e-8,Math.hypot(gx,gz));
        double speed=8+grad*38;
        return new Sample(pressure,humidity,lift,-gz/norm*speed,gx/norm*speed,grad);
    }
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
}
