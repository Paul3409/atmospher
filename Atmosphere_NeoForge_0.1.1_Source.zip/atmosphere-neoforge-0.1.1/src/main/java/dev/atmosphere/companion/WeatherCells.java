package dev.atmosphere.companion;

/** Finite-lived, world-bound mesoscale cells. No loaded chunks or frame RNG are used. */
public final class WeatherCells {
    public static final int NONE=0,SHOWER=1,THUNDER=2,SEVERE=3,SQUALL=4;
    private static final double SPACING=760.0;
    public record Sample(double rain,double cloud,double development,int type,double centerX,double centerZ,long id,
                         double phase,double velocityX,double velocityZ,double pressure,double humidity){
        public String stage(){return phase<.25?"Entstehung":phase<.63?"Reifephase":phase<.86?"Abschwaechung":"Aufloesung";}
        public String typeName(){return switch(type){case SHOWER->"Schauer";case THUNDER->"Gewitter";
            case SEVERE->"Superzelle";case SQUALL->"Squall Line";default->"Trockene Wolke";};}
    }
    private WeatherCells(){}

    public static Sample sample(double x,double z,double ticks){
        double days=ticks/24000.0*CloudConfig.WEATHER_SPEED.get()/100.0;
        int gx=(int)Math.floor(x/SPACING),gz=(int)Math.floor(z/SPACING);
        double bestRain=0,bestCloud=0,bestDev=0,cx=x,cz=z,bestPhase=0,bestVx=0,bestVz=0;
        int bestType=NONE;long bestId=0;
        var syn=SynopticSystems.sample(x,z,ticks);
        long epoch=(long)Math.floor(days/.92);
        for(long ep=epoch-2;ep<=epoch;ep++)for(int dz=-2;dz<=2;dz++)for(int dx=-2;dx<=2;dx++){
            long id=mix((gx+dx)*341873128712L^(gz+dz)*132897987541L^ep*0x632be59bd9b4e019L);
            double chance=hash(id,0,71)*200;
            double synopticChance=.58+.78*syn.lift();
            if(chance>CloudConfig.WEATHER_CELL_DENSITY.get()*synopticChance)continue;
            double born=ep*.92+hash(id,0,43)*.36;
            double life=(.52+hash(id,0,41)*.86)*CloudConfig.WEATHER_LIFETIME.get()/100.0;
            double phase=(days-born)/life;
            if(phase<=0||phase>=1)continue;
            double growth=StormEvolution.lifecycle(phase);
            double organization=hash(id,0,37);
            boolean dry=hash(id,0,31)<CloudConfig.DRY_CLOUD_SHARE.get()/100.0;
            double shower=.43*CloudConfig.SHOWER_FREQUENCY.get()/100.0;
            double thunder=.27*CloudConfig.THUNDER_FREQUENCY.get()/100.0;
            double severe=.10*CloudConfig.SUPERCELL_FREQUENCY.get()/35.0;
            double squall=.06*CloudConfig.SQUALL_FREQUENCY.get()/30.0;
            double weighted=shower+thunder+severe+squall;
            if(weighted<=0)dry=true;
            double pick=hash(id,0,137)*Math.max(.001,weighted);
            int type=dry?NONE:pick<shower?SHOWER:pick<shower+thunder?THUNDER:
                pick<shower+thunder+severe?SEVERE:SQUALL;
            double radius=(type==SQUALL?170:type==SEVERE?145:type==THUNDER?112:88)*(0.78+.44*hash(id,0,47));
            radius*=CloudConfig.CELL_SIZE.get()/100.0;
            double startX=(gx+dx+.12+.76*hash(id,0,11))*SPACING;
            double startZ=(gz+dz+.12+.76*hash(id,0,13))*SPACING;
            double angle=hash(id,0,19)*Math.PI*2;
            double randomX=Math.cos(angle),randomZ=Math.sin(angle);
            double synLen=Math.max(1,Math.hypot(syn.windX(),syn.windZ()));
            double dirX=randomX*.28+syn.windX()/synLen*.72,dirZ=randomZ*.28+syn.windZ()/synLen*.72;
            double dirLen=Math.max(.001,Math.hypot(dirX,dirZ));dirX/=dirLen;dirZ/=dirLen;
            double age=days-born;
            double travel=age*(78+hash(id,0,17)*86+synLen*.9);
            // A weak, slowly varying steering flow gives each cell a curved, individual track.
            double bend=(hash(id,0,23)-.5)*.9*Math.sin(phase*Math.PI);
            double cellX=startX+dirX*travel-dirZ*travel*bend*.16;
            double cellZ=startZ+dirZ*travel+dirX*travel*bend*.16;
            double px=x-cellX,pz=z-cellZ;
            double along=px*dirX+pz*dirZ,across=-px*dirZ+pz*dirX;
            if(Math.abs(along)>radius*3||Math.abs(across)>radius*3)continue;
            double profile=dry?0:StormEvolution.rainProfile(along,across,radius,id,type,growth);
            double pulse=.88+.12*Math.sin(phase*Math.PI*6+hash(id,0,59)*Math.PI*2);
            double intensity=growth*pulse*(.48+.52*hash(id,0,53))*(.68+.42*syn.humidity());
            double rain=profile*intensity*(type==SHOWER?.62:type==THUNDER?.82:1);
            double cloudEnvelope=Math.exp(-Math.pow(along/(radius*(dry?1.9:1.55)),4)-Math.pow(across/(radius*(dry?1.25:1.05)),4));
            double cloud=cloudEnvelope*growth*(dry?.72:1);
            bestCloud=Math.max(bestCloud,cloud);
            if(rain>bestRain){bestRain=rain;bestDev=growth;bestType=type;cx=cellX;cz=cellZ;bestId=id;
                bestPhase=phase;bestVx=dirX*(78+hash(id,0,17)*86+synLen*.9)/24000.0;
                bestVz=dirZ*(78+hash(id,0,17)*86+synLen*.9)/24000.0;}
        }
        return new Sample(bestRain,bestCloud,bestDev,bestType,cx,cz,bestId,bestPhase,bestVx,bestVz,syn.pressure(),syn.humidity());
    }
    static double hash(long x,long z,int salt){
        long h=x*341873128712L^z*132897987541L^salt*2177342783L;
        h=mix(h);return (h>>>11)*0x1.0p-53;
    }
    private static long mix(long h){h^=h>>>30;h*=-4658895280553007687L;h^=h>>>27;h*=-7723592293110705685L;return h^(h>>>31);}
}
