package dev.atmosphere.companion;

/** Finite-lived, world-bound mesoscale cells. No loaded chunks or frame RNG are used. */
public final class WeatherCells {
    public static final int NONE=0,SHOWER=1,THUNDER=2,SEVERE=3,SQUALL=4;
    private static final double SPACING=620.0;
    public record Sample(double rain,double cloud,double development,int type,double centerX,double centerZ,long id){}
    private WeatherCells(){}

    public static Sample sample(double x,double z,double ticks){
        double days=ticks/24000.0;
        int gx=(int)Math.floor(x/SPACING),gz=(int)Math.floor(z/SPACING);
        double bestRain=0,bestCloud=0,bestDev=0,cx=x,cz=z;int bestType=NONE;long bestId=0;
        long epoch=(long)Math.floor(days/.92);
        for(long ep=epoch-2;ep<=epoch;ep++)for(int dz=-2;dz<=2;dz++)for(int dx=-2;dx<=2;dx++){
            long id=mix((gx+dx)*341873128712L^(gz+dz)*132897987541L^ep*0x632be59bd9b4e019L);
            double chance=hash(id,0,71)*200;
            if(chance>CloudConfig.WEATHER_CELL_DENSITY.get())continue;
            double born=ep*.92+hash(id,0,43)*.36;
            double life=(.52+hash(id,0,41)*.86)*CloudConfig.WEATHER_LIFETIME.get()/100.0;
            double phase=(days-born)/life;
            if(phase<=0||phase>=1)continue;
            double growth=StormEvolution.lifecycle(phase);
            int type=hash(id,0,37)>.91?SQUALL:hash(id,0,37)>.73?SEVERE:hash(id,0,37)>.43?THUNDER:SHOWER;
            double radius=(type==SQUALL?170:type==SEVERE?145:type==THUNDER?112:88)*(0.78+.44*hash(id,0,47));
            double startX=(gx+dx+.12+.76*hash(id,0,11))*SPACING;
            double startZ=(gz+dz+.12+.76*hash(id,0,13))*SPACING;
            var dir=CloudConfig.WIND_DIRECTION.get();
            double travel=(days-born)*CloudConfig.WIND_SPEED.get()*112;
            double cellX=startX+dir.dx*travel,cellZ=startZ+dir.dz*travel;
            double px=x-cellX,pz=z-cellZ;
            double along=px*dir.dx+pz*dir.dz,across=-px*dir.dz+pz*dir.dx;
            if(Math.abs(along)>radius*3||Math.abs(across)>radius*3)continue;
            double profile=StormEvolution.rainProfile(along,across,radius,id,type,growth);
            double intensity=growth*(.48+.52*hash(id,0,53));
            double rain=profile*intensity*(type==SHOWER?.62:type==THUNDER?.82:1);
            double cloud=Math.exp(-(px*px+pz*pz)/(radius*radius*2.7))*growth;
            bestCloud=Math.max(bestCloud,cloud);
            if(rain>bestRain){bestRain=rain;bestDev=growth;bestType=type;cx=cellX;cz=cellZ;bestId=id;}
        }
        return new Sample(bestRain,bestCloud,bestDev,bestType,cx,cz,bestId);
    }
    static double hash(long x,long z,int salt){
        long h=x*341873128712L^z*132897987541L^salt*2177342783L;
        h=mix(h);return (h>>>11)*0x1.0p-53;
    }
    private static long mix(long h){h^=h>>>30;h*=-4658895280553007687L;h^=h>>>27;h*=-7723592293110705685L;return h^(h>>>31);}
}
