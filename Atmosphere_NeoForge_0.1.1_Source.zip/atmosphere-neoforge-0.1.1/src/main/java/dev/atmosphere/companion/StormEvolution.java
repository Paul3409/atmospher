package dev.atmosphere.companion;

/** Deterministic, continuous storm shapes shared by particles, curtains and radar. */
public final class StormEvolution {
    private StormEvolution() {}
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static double smooth(double a,double b,double x){double t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);}
    static double lifecycle(double phase){
        return smooth(.02,.27,phase)*(1-smooth(.68,.98,phase));
    }
    static double structure(double along,double across,double radius,long seed,boolean line){
        double phase=WeatherCells.hash(seed,0,733)*Math.PI*2;
        double broad=Math.sin(along/(radius*.52)+across/(radius*.41)+phase);
        double fine=Math.sin(along/(radius*.19)-across/(radius*.31)+phase*1.71);
        double broken=line?.55+.45*smooth(-.72,.48,Math.sin(across/(radius*.43)+phase)):1;
        return clamp((.58+.28*broad+.14*fine)*broken,.05,1);
    }
    static double rainProfile(double along,double across,double radius,long seed,int type,double growth){
        radius=Math.max(45,radius);
        double texture=structure(along,across,radius,seed,type==WeatherCells.SQUALL);
        if(type==WeatherCells.SQUALL){
            double bow=.20*radius*Math.cos(across/(radius*.83)+WeatherCells.hash(seed,0,913)*6.283);
            double band=Math.exp(-Math.pow((along-bow)/(radius*.31),2)-Math.pow(across/(radius*2.35),4));
            return clamp(band*(.20+.80*texture),0,1);
        }
        if(type>=WeatherCells.SEVERE){
            double u=along/radius,v=across/radius;
            double shield=Math.exp(-Math.pow((u+.12+.28*v)/1.08,2)-Math.pow((v-.42)/.72,2));
            double core=Math.exp(-Math.pow((u+.38)/.37,2)-Math.pow((v-.18)/.29,2));
            double hook=Math.exp(-Math.pow((u-.42)/.31,2)-Math.pow((v+.54)/.24,2))*smooth(.42,.78,growth);
            double notch=Math.exp(-Math.pow((u-.05)/.24,2)-Math.pow((v+.23)/.27,2));
            return clamp((shield*.64+core*.69+hook*.48)*(1-.73*notch)*(.42+.58*texture),0,1);
        }
        double main=Math.exp(-Math.pow((along+.16*radius)/(.79*radius),2)-Math.pow(across/(.70*radius),2));
        double side=Math.exp(-Math.pow((along-.43*radius)/(.39*radius),2)-Math.pow((across+.67*radius)/(.42*radius),2));
        return clamp(Math.max(main,side*.71)*(.34+.66*texture),0,1);
    }
}
