package dev.atmosphere.companion;

/** Deterministic, continuous storm shapes shared by particles, curtains and radar. */
public final class StormEvolution {
    private StormEvolution() {}
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static double smooth(double a,double b,double x){double t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);}
    static double lifecycle(double phase){
        return smooth(.02,.27,phase)*(1-smooth(.68,.98,phase));
    }
    static double structure(double along,double across,double radius,long seed,boolean line){
        double phase=WeatherCells.hash(seed,0,733)*Math.PI*2;
        double broad=Math.sin(along/(radius*.52)+across/(radius*.41)+phase);
        double fine=Math.sin(along/(radius*.19)-across/(radius*.31)+phase*1.71);
        double broken=line?.55+.45*smooth(-.72,.48,Math.sin(across/(radius*.43)+phase)):1;
        return clamp((.58+.28*broad+.14*fine)*broken,.05,1);
    }
    static double rainProfile(double along,double across,double radius,long seed,int type,double growth){
        radius=Math.max(45,radius);
        double texture=structure(along,across,radius,seed,type==WeatherCells.SQUALL);
        if(type==WeatherCells.SQUALL){
            double bow=.20*radius*Math.cos(across/(radius*.83)+WeatherCells.hash(seed,0,913)*6.283);
            double band=Math.exp(-Math.pow((along-bow)/(radius*.31),2)-Math.pow(across/(radius*2.35),4));
            return clamp(band*(.20+.80*texture),0,1);
        }
        if(type>=WeatherCells.SEVERE){
            double u=along/radius,v=across/radius;
            double warp=.18*Math.sin(v*4.1+WeatherCells.hash(seed,0,901)*6.283);
            double shield=Math.exp(-Math.pow((u+.18+.34*v+warp)/1.23,2)-Math.pow((v-.38)/.78,2));
            double core=Math.exp(-Math.pow((u+.46+warp)/.34,2)-Math.pow((v-.13)/.25,2));
            double hookAngle=Math.atan2(v+.28,u-.12),hookRadius=Math.hypot((u-.12)*1.06,v+.28);
            double hook=Math.exp(-Math.pow((hookRadius-.55)/.15,2))*smooth(-2.7,.65,hookAngle)*smooth(.35,.72,growth);
            double notch=Math.exp(-Math.pow((u+.02)/.25,2)-Math.pow((v+.18)/.22,2));
            double forward=Math.exp(-Math.pow((u+.92)/.48,2)-Math.pow((v-.42)/.34,2));
            return clamp((shield*.49+core*.82+hook*.58+forward*.33)*(1-.78*notch)*(.30+.70*texture),0,1);
        }
        // Ordinary showers are clusters of displaced, anisotropic cores, never radial discs.
        int cores=type==WeatherCells.THUNDER?5:3;
        double best=0,weak=0;
        for(int i=0;i<cores;i++){
            double ca=(WeatherCells.hash(seed,i,101)-.5)*radius*1.45;
            double cc=(WeatherCells.hash(seed,i,103)-.5)*radius*1.55;
            double ra=radius*(.19+.34*WeatherCells.hash(seed,i,107));
            double rc=radius*(.15+.31*WeatherCells.hash(seed,i,109));
            double bend=.22*radius*Math.sin((across-cc)/(radius*.46)+i);
            double q=Math.pow((along-ca-bend)/ra,2)+Math.pow((across-cc)/rc,2);
            double cell=Math.exp(-q)*( .42+.58*WeatherCells.hash(seed,i,113));
            best=Math.max(best,cell);weak+=cell*.20;
        }
        double band=Math.exp(-Math.pow((along+.18*across)/(radius*1.34),4)-Math.pow(across/(radius*.82),4));
        return clamp((best+weak+band*.12)*(.24+.76*texture),0,1);
    }
}
