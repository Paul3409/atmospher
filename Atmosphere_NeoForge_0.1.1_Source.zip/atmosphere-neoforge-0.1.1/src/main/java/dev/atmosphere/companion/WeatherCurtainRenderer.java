package dev.atmosphere.companion;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** Distant, translucent rain volume beneath the same footprint used by rain and radar. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class WeatherCurtainRenderer {
    static final RenderType CURTAIN=RenderType.create(
        "atmosphere_weather_curtain",DefaultVertexFormat.POSITION_COLOR,VertexFormat.Mode.QUADS,4096,false,true,
        RenderType.CompositeState.builder()
            .setShaderState(RenderStateShard.POSITION_COLOR_SHADER)
            .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
            .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
            .setWriteMaskState(RenderStateShard.COLOR_WRITE)
            .setCullState(RenderStateShard.NO_CULL)
            .createCompositeState(false));

    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        if(!CloudConfig.RAIN_CURTAIN.get()||!CloudConfig.CUSTOM_PRECIPITATION.get())return;
        var type=WeatherField.activeType();
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.STRATUS||
            type==CloudConfig.CloudType.ALTOCUMULUS||type==CloudConfig.CloudType.CIRRUS||
            type==CloudConfig.CloudType.CIRROSTRATUS)return;
        var camera=event.getCamera().getPosition();
        int cx=(int)Math.floor(camera.x/16),cz=(int)Math.floor(camera.z/16);
        var buffers=mc.renderBuffers().bufferSource();
        var out=buffers.getBuffer(CURTAIN);
        Matrix4f mat=event.getPoseStack().last().pose();
        for(int gx=cx-25;gx<=cx+25;gx++)for(int gz=cz-25;gz<=cz+25;gz++){
            double wx=gx*16.0,wz=gz*16.0;
            double rx=wx-camera.x,rz=wz-camera.z,dist=Math.sqrt(rx*rx+rz*rz);
            if(dist<48||dist>410)continue;
            float intensity=WeatherField.precipitation(wx,wz);
            if(intensity<.025f)continue;
            int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)wx,(int)wz);
            if(ground<mc.level.getMinBuildHeight()+2)ground=mc.level.getSeaLevel();
            double top=WeatherField.cloudBaseAt(wx,wz)+2,bottom=ground;
            if(top<bottom+8)continue;
            double sideX=-rz/dist*31,sideZ=rx/dist*31;
            float x=(float)rx,z=(float)rz,sx=(float)sideX,sz=(float)sideZ;
            float lo=(float)(bottom-camera.y),hi=(float)(top-camera.y);
            float distanceFade=(float)Math.max(0,Math.min(1,(dist-65)/115));
            float a=Math.min(.085f,intensity*.052f)*distanceFade;
            quad(out,mat,x,z,sx,sz,lo,lo+(hi-lo)*.35f,a*.72f,a);
            quad(out,mat,x,z,sx,sz,lo+(hi-lo)*.35f,hi,a,a*.18f);
        }
        buffers.endBatch(CURTAIN);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,Matrix4f mat,
                             float x,float z,float sx,float sz,float y0,float y1,float a0,float a1){
        out.addVertex(mat,x-sx,y0,z-sz).setColor(.20f,.24f,.27f,a0);
        out.addVertex(mat,x+sx,y0,z+sz).setColor(.20f,.24f,.27f,a0);
        out.addVertex(mat,x+sx,y1,z+sz).setColor(.20f,.24f,.27f,a1);
        out.addVertex(mat,x-sx,y1,z-sz).setColor(.20f,.24f,.27f,a1);
    }
    private WeatherCurtainRenderer(){}
}
