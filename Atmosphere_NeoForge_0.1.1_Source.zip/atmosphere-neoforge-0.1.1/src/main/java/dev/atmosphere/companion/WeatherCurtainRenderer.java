package dev.atmosphere.companion;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/** Distant, translucent rain volume beneath the same footprint used by rain and radar. */
public final class WeatherCurtainRenderer {
    static final RenderType CURTAIN=RenderType.create(
        "atmosphere_weather_curtain",DefaultVertexFormat.POSITION_COLOR,VertexFormat.Mode.QUADS,4096,false,true,
        RenderType.CompositeState.builder()
            .setShaderState(RenderStateShard.POSITION_COLOR_SHADER)
            .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
            .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
            .setWriteMaskState(RenderStateShard.COLOR_WRITE)
            .setCullState(RenderStateShard.NO_CULL)
            .createCompositeState(false));

    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.level.dimension()!=Level.OVERWORLD)return;
        if(!CloudConfig.RAIN_CURTAIN.get()||!CloudConfig.CUSTOM_PRECIPITATION.get())return;
        var type=WeatherField.activeType();
        if(type==CloudConfig.CloudType.CUMULUS||type==CloudConfig.CloudType.STRATUS||
            type==CloudConfig.CloudType.ALTOCUMULUS||type==CloudConfig.CloudType.CIRRUS||
            type==CloudConfig.CloudType.CIRROSTRATUS)return;
        var camera=event.getCamera().getPosition();
        int cx=(int)Math.floor(camera.x/8),cz=(int)Math.floor(camera.z/8);
        var buffers=mc.renderBuffers().bufferSource();
        var out=buffers.getBuffer(CURTAIN);
        Matrix4f mat=event.getPoseStack().last().pose();
        for(int gx=cx-50;gx<=cx+50;gx++)for(int gz=cz-50;gz<=cz+50;gz++){
            long seed=((long)gx*73428767L)^((long)gz*912931L);
            double jitterX=((seed&1023)/1023.0-.5)*5.5,jitterZ=(((seed>>>10)&1023)/1023.0-.5)*5.5;
            double wx=gx*8.0+jitterX,wz=gz*8.0+jitterZ;
            double rx=wx-camera.x,rz=wz-camera.z,dist=Math.sqrt(rx*rx+rz*rz);
            if(dist<48||dist>410)continue;
            float intensity=WeatherField.precipitation(wx,wz);
            if(intensity<.025f)continue;
            int ground=mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING,(int)wx,(int)wz);
            if(ground<mc.level.getMinBuildHeight()+2)ground=mc.level.getSeaLevel();
            double top=WeatherField.cloudBaseAt(wx,wz)+2,bottom=ground;
            double virgaChance=((seed>>>20)&1023)/1023.0;
            if(virgaChance<CloudConfig.VIRGA_AMOUNT.get()/100.0){
                double fraction=.18+.48*((seed>>>30)&1023)/1023.0;
                bottom=ground+(top-ground)*fraction;
            }
            if(top<bottom+8)continue;
            double width=18+intensity*22+(((seed>>>40)&255)/255.0)*10;
            double sideX=-rz/dist*width,sideZ=rx/dist*width;
            float x=(float)rx,z=(float)rz,sx=(float)sideX,sz=(float)sideZ;
            float lo=(float)(bottom-camera.y),hi=(float)(top-camera.y);
            float distanceFade=(float)Math.max(0,Math.min(1,(dist-65)/115));
            float texture=(float)(.62+.38*Math.sin(wx*.071+wz*.043+seed*.0000001));
            float a=Math.min(.19f,intensity*.125f)*distanceFade*texture
                *CloudConfig.CURTAIN_OPACITY.get()/100f*CloudConfig.FRONT_STRENGTH.get()/100f;
            quad(out,mat,x,z,sx,sz,lo,lo+(hi-lo)*.30f,a*.66f,a);
            quad(out,mat,x,z,sx,sz,lo+(hi-lo)*.30f,lo+(hi-lo)*.72f,a,a*.72f);
            quad(out,mat,x,z,sx,sz,lo+(hi-lo)*.72f,hi,a*.72f,a*.12f);
        }
        buffers.endBatch(CURTAIN);
    }
    private static void quad(com.mojang.blaze3d.vertex.VertexConsumer out,Matrix4f mat,
                             float x,float z,float sx,float sz,float y0,float y1,float a0,float a1){
        // Neutral grey: especially at night there must be no artificial blue cast.
        out.addVertex(mat,x-sx,y0,z-sz).setColor(.185f,.183f,.178f,a0);
        out.addVertex(mat,x+sx,y0,z+sz).setColor(.185f,.183f,.178f,a0);
        out.addVertex(mat,x+sx,y1,z+sz).setColor(.185f,.183f,.178f,a1);
        out.addVertex(mat,x-sx,y1,z-sz).setColor(.185f,.183f,.178f,a1);
    }
    private WeatherCurtainRenderer(){}
}
