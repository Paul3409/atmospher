package dev.atmosphere.companion;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client-only options: each one affects the renderer immediately. */
public final class CloudConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue HEIGHT;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;
    public static final ModConfigSpec.EnumValue<CloudType> CLOUD_TYPE;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_CLOUDS;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_PRECIPITATION;
    public static final ModConfigSpec.IntValue TEMPERATURE_OFFSET;
    public static final ModConfigSpec.BooleanValue CUSTOM_PRECIPITATION;
    public static final ModConfigSpec.BooleanValue RAIN_CURTAIN;
    public static final ModConfigSpec.BooleanValue OPTICAL_SNOW;
    public static final ModConfigSpec.BooleanValue LIGHTNING;
    public static final ModConfigSpec.IntValue LIGHTNING_FREQUENCY;
    public static final ModConfigSpec.IntValue PRECIPITATION_DENSITY;
    public enum Quality { LOW, MEDIUM, HIGH }
    public enum CloudType { AUTO, CUMULUS, STRATOCUMULUS, STRATUS, NIMBOSTRATUS, CUMULONIMBUS,
        ALTOCUMULUS, ALTOSTRATUS, CIRRUS, CIRROSTRATUS, CUMULONIMBUS_GROSS }
    static {
        var builder = new ModConfigSpec.Builder();
        builder.push("clouds");
        HEIGHT = builder.comment("Cloud base height in world coordinates (blocks).").defineInRange("height", 160, 96, 256);
        QUALITY = builder.comment("Cloud surface detail and number of lobes.").defineEnum("quality", Quality.MEDIUM);
        CLOUD_TYPE = builder.comment("Cloud family shown in the sky; AUTO follows the world time.").defineEnum("cloudType", CloudType.AUTO);
        builder.pop();
        builder.push("vanilla_weather");
        HIDE_VANILLA_CLOUDS=builder.translation("atmosphere_companion.config.hide_vanilla_clouds")
            .comment("Hide vanilla clouds on this client. Atmosphere clouds remain visible.").define("hideVanillaClouds",false);
        HIDE_VANILLA_PRECIPITATION=builder.translation("atmosphere_companion.config.hide_vanilla_precipitation")
            .comment("Always hide vanilla rain and snow. Custom cloud-bound precipitation replaces its visuals.").define("hideVanillaPrecipitation",true);
        builder.pop();
        builder.push("custom_weather");
        CUSTOM_PRECIPITATION=builder.define("precipitation",true);
        PRECIPITATION_DENSITY=builder.defineInRange("precipitationDensity",100,0,200);
        RAIN_CURTAIN=builder.define("rainCurtain",true);
        OPTICAL_SNOW=builder.comment("Visual snow particles only; never places snow blocks.").define("opticalSnow",true);
        TEMPERATURE_OFFSET=builder.comment("Degrees Celsius added to biome and altitude temperature.").defineInRange("temperatureOffset",0,-30,30);
        LIGHTNING=builder.define("lightning",true);
        LIGHTNING_FREQUENCY=builder.comment("Relative lightning rate, 0 to 200 percent.").defineInRange("lightningFrequency",100,0,200);
        builder.pop();
        SPEC = builder.build();
    }
    private CloudConfig() {}
}
