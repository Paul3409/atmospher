package dev.atmosphere.companion;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client-only options: each one affects the renderer immediately. */
public final class CloudConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue HEIGHT;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;
    public static final ModConfigSpec.EnumValue<CloudType> CLOUD_TYPE;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_CLOUDS;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_PRECIPITATION;
    public static final ModConfigSpec.DoubleValue TEMPERATURE_OFFSET;
    public static final ModConfigSpec.BooleanValue CUSTOM_PRECIPITATION;
    public static final ModConfigSpec.BooleanValue RAIN_CURTAIN;
    public static final ModConfigSpec.BooleanValue OPTICAL_SNOW;
    public static final ModConfigSpec.BooleanValue LIGHTNING;
    public static final ModConfigSpec.IntValue LIGHTNING_FREQUENCY;
    public static final ModConfigSpec.IntValue PRECIPITATION_DENSITY;
    public static final ModConfigSpec.EnumValue<WindDirection> WIND_DIRECTION;
    public static final ModConfigSpec.DoubleValue WIND_SPEED;
    public static final ModConfigSpec.IntValue RENDER_DISTANCE;
    public static final ModConfigSpec.IntValue CLOUD_DENSITY;
    public static final ModConfigSpec.IntValue CLOUD_SCALE;
    public static final ModConfigSpec.IntValue CLOUD_OPACITY;
    public static final ModConfigSpec.IntValue ROUGHNESS;
    public static final ModConfigSpec.IntValue NIGHT_BRIGHTNESS;
    public static final ModConfigSpec.IntValue CURTAIN_OPACITY;
    public static final ModConfigSpec.IntValue RADAR_ZOOM;
    public static final ModConfigSpec.IntValue WEATHER_CELL_DENSITY;
    public static final ModConfigSpec.IntValue WEATHER_LIFETIME;
    public static final ModConfigSpec.IntValue FRONT_STRENGTH;
    public static final ModConfigSpec.IntValue VIRGA_AMOUNT;
    public static final ModConfigSpec.BooleanValue FOG_ENABLED;
    public static final ModConfigSpec.IntValue FOG_DENSITY;
    public static final ModConfigSpec.IntValue FOG_DURATION;
    public static final ModConfigSpec.IntValue RAIN_PARTICLE_SIZE;
    public static final ModConfigSpec.IntValue SNOW_PARTICLE_SIZE;
    public static final ModConfigSpec.IntValue SLEET_PARTICLE_SIZE;
    public static final ModConfigSpec.BooleanValue SPLASHES;
    public static final ModConfigSpec.BooleanValue WEATHER_SOUNDS;
    public static final ModConfigSpec.IntValue SOUND_VOLUME;
    public static final ModConfigSpec.IntValue RAIN_VOLUME;
    public static final ModConfigSpec.IntValue WIND_VOLUME;
    public static final ModConfigSpec.IntValue THUNDER_VOLUME;
    public static final ModConfigSpec.IntValue INDOOR_DAMPING;
    public static final ModConfigSpec.IntValue FOG_WATER_INFLUENCE;
    public static final ModConfigSpec.IntValue CLOUD_SMOOTHING;
    public static final ModConfigSpec.EnumValue<ParticleMode> PARTICLE_MODE;
    public static final ModConfigSpec.EnumValue<RadarView> RADAR_VIEW;
    public static final ModConfigSpec.EnumValue<RadarQuality> RADAR_QUALITY;
    public static final ModConfigSpec.IntValue RADAR_RANGE;
    public static final ModConfigSpec.BooleanValue RADAR_TOOLTIPS;
    public static final ModConfigSpec.BooleanValue RADAR_FRONTS;
    public static final ModConfigSpec.BooleanValue RADAR_ISOBARS;
    public static final ModConfigSpec.BooleanValue RADAR_LIGHTNING;
    public static final ModConfigSpec.BooleanValue NATURAL_WEATHER;
    public static final ModConfigSpec.IntValue WEATHER_SPEED;
    public static final ModConfigSpec.IntValue SHOWER_FREQUENCY;
    public static final ModConfigSpec.IntValue THUNDER_FREQUENCY;
    public static final ModConfigSpec.IntValue SUPERCELL_FREQUENCY;
    public static final ModConfigSpec.IntValue SQUALL_FREQUENCY;
    public static final ModConfigSpec.IntValue PRESSURE_STRENGTH;
    public static final ModConfigSpec.IntValue DRY_CLOUD_SHARE;
    public static final ModConfigSpec.IntValue CELL_SIZE;
    public static final ModConfigSpec.IntValue MAX_PRECIPITATION;
    public static final ModConfigSpec.BooleanValue ADAPTIVE_CLOUDS;
    public static final ModConfigSpec.IntValue TARGET_FPS;
    public static final ModConfigSpec.IntValue DISTANT_CLOUD_DETAIL;
    public static final ModConfigSpec.BooleanValue SIMULATOR_ENABLED;
    public static final ModConfigSpec.EnumValue<PrecipitationSelection> MANUAL_PRECIPITATION;
    public static final ModConfigSpec.IntValue MANUAL_INTENSITY;
    public static final ModConfigSpec.DoubleValue MANUAL_TEMPERATURE;
    public static final ModConfigSpec.DoubleValue HEIGHT_COOLING;
    public static final ModConfigSpec.IntValue SNOW_LINE;
    public static final ModConfigSpec.IntValue SNOW_TRANSITION;
    public static final ModConfigSpec.IntValue MANUAL_FOG_START;
    public static final ModConfigSpec.IntValue MANUAL_FOG_END;
    public static final ModConfigSpec.IntValue MANUAL_FOG_DENSITY;
    public static final ModConfigSpec.IntValue MANUAL_LIGHTNING;
    public enum Quality { LOW, MEDIUM, HIGH }
    public enum ParticleMode { TWO_D, THREE_D, THREE_D_HIGH }
    public enum RadarView { DBZ, ZELLEN, DOPPLER, LUFTDRUCK }
    public enum RadarQuality { SCHNELL, MITTEL, HOCH, ULTRA }
    public enum PrecipitationSelection { AUS, AUTOMATISCH, REGEN, SCHNEEREGEN, SCHNEE }
    public enum WindDirection {
        NORD("Nord",0,1), NORDOST("Nordost",-.707,.707), OST("Ost",-1,0),
        SUEDOST("Südost",-.707,-.707), SUED("Süd",0,-1), SUEDWEST("Südwest",.707,-.707),
        WEST("West",1,0), NORDWEST("Nordwest",.707,.707);
        public final String label; public final double dx,dz;
        WindDirection(String label,double dx,double dz){this.label=label;this.dx=dx;this.dz=dz;}
        @Override public String toString(){return label;}
    }
    public enum CloudType { AUTO, CUMULUS, STRATOCUMULUS, STRATUS, NIMBOSTRATUS, CUMULONIMBUS,
        ALTOCUMULUS, ALTOSTRATUS, CIRRUS, CIRROSTRATUS, CUMULONIMBUS_GROSS }
    static {
        var builder = new ModConfigSpec.Builder();
        builder.push("manual_simulator");
        SIMULATOR_ENABLED=builder.comment("Master switch for the manual weather simulator.").define("enabled",true);
        MANUAL_PRECIPITATION=builder.comment("Global precipitation selection. AUTOMATISCH uses snow line and transition band.")
            .defineEnum("precipitation",PrecipitationSelection.AUS);
        MANUAL_INTENSITY=builder.defineInRange("intensity",55,0,100);
        MANUAL_TEMPERATURE=builder.comment("Reference temperature at sea level in degrees Celsius.")
            .defineInRange("temperatureC",8.0,-40.0,45.0);
        HEIGHT_COOLING=builder.comment("Temperature decrease per 100 blocks of altitude.")
            .defineInRange("heightCoolingPer100",6.5,0.0,20.0);
        SNOW_LINE=builder.comment("Manual altitude at which automatic precipitation changes to snow.")
            .defineInRange("snowLine",128,-64,384);
        SNOW_TRANSITION=builder.comment("Half-width of the sleet transition around the snow line.")
            .defineInRange("snowTransition",8,0,48);
        MANUAL_FOG_DENSITY=builder.defineInRange("fogDensity",0,0,100);
        MANUAL_FOG_START=builder.comment("Distance in blocks where distance fog begins.").defineInRange("fogStart",32,0,384);
        MANUAL_FOG_END=builder.comment("Distance in blocks where distance fog becomes opaque.").defineInRange("fogEnd",128,8,512);
        MANUAL_LIGHTNING=builder.defineInRange("lightningFrequency",0,0,100);
        builder.pop();
        builder.push("clouds");
        HEIGHT = builder.comment("Cloud base height in world coordinates (blocks).").defineInRange("height", 160, 96, 256);
        QUALITY = builder.comment("Cloud surface detail and number of lobes.").defineEnum("quality", Quality.MEDIUM);
        CLOUD_TYPE = builder.comment("Cloud family shown in the sky; AUTO follows the world time.").defineEnum("cloudType", CloudType.AUTO);
        WIND_DIRECTION=builder.comment("Meteorological direction the clouds come from.").defineEnum("windDirection",WindDirection.WEST);
        WIND_SPEED=builder.defineInRange("windSpeed",1.0,0.0,5.0);
        RENDER_DISTANCE=builder.defineInRange("renderDistance",560,256,1024);
        CLOUD_DENSITY=builder.defineInRange("density",75,20,100);
        CLOUD_SCALE=builder.defineInRange("scale",100,60,160);
        CLOUD_OPACITY=builder.defineInRange("opacity",100,20,100);
        ROUGHNESS=builder.defineInRange("roughness",100,0,180);
        NIGHT_BRIGHTNESS=builder.comment("Cloud brightness at midnight, percent.").defineInRange("nightBrightness",32,8,100);
        builder.pop();
        builder.push("vanilla_weather");
        HIDE_VANILLA_CLOUDS=builder.translation("atmosphere_companion.config.hide_vanilla_clouds")
            .comment("Hide vanilla clouds on this client. Atmosphere clouds remain visible.").define("hideVanillaClouds",false);
        HIDE_VANILLA_PRECIPITATION=builder.translation("atmosphere_companion.config.hide_vanilla_precipitation")
            .comment("Always hide vanilla rain and snow. Custom cloud-bound precipitation replaces its visuals.").define("hideVanillaPrecipitation",true);
        builder.pop();
        builder.push("custom_weather");
        CUSTOM_PRECIPITATION=builder.define("precipitation",true);
        PRECIPITATION_DENSITY=builder.defineInRange("precipitationDensity",100,0,200);
        CURTAIN_OPACITY=builder.defineInRange("curtainOpacity",100,0,200);
        RAIN_CURTAIN=builder.define("rainCurtain",true);
        OPTICAL_SNOW=builder.comment("Visual snow particles only; never places snow blocks.").define("opticalSnow",true);
        TEMPERATURE_OFFSET=builder.comment("Degrees Celsius added to biome and altitude temperature.").defineInRange("temperatureOffset",0.0,-30.0,30.0);
        LIGHTNING=builder.define("lightning",true);
        LIGHTNING_FREQUENCY=builder.comment("Relative lightning rate, 0 to 200 percent.").defineInRange("lightningFrequency",100,0,200);
        RADAR_ZOOM=builder.defineInRange("radarZoom",8,2,24);
        WEATHER_CELL_DENSITY=builder.comment("Number of naturally developing showers and thunderstorms.")
            .defineInRange("weatherCellDensity",100,20,200);
        WEATHER_LIFETIME=builder.comment("Relative lifetime of naturally developing weather cells.")
            .defineInRange("weatherLifetime",100,50,200);
        FRONT_STRENGTH=builder.comment("Visual density of distant precipitation fronts.")
            .defineInRange("frontStrength",125,0,200);
        VIRGA_AMOUNT=builder.comment("Fraction of precipitation streaks that evaporate before reaching the ground.")
            .defineInRange("virgaAmount",35,0,100);
        FOG_ENABLED=builder.comment("Local terrain and water influenced low fog.").define("terrainFog",true);
        FOG_DENSITY=builder.defineInRange("fogDensity",65,0,100);
        FOG_DURATION=builder.defineInRange("fogPersistence",70,0,100);
        FOG_WATER_INFLUENCE=builder.defineInRange("fogWaterInfluence",80,0,150);
        builder.pop();
        builder.push("weather_model");
        NATURAL_WEATHER=builder.comment("Persistent natural pressure systems and evolving cells.").define("naturalWeather",true);
        WEATHER_SPEED=builder.defineInRange("weatherSpeed",100,25,300);
        SHOWER_FREQUENCY=builder.defineInRange("showerFrequency",100,0,250);
        THUNDER_FREQUENCY=builder.defineInRange("thunderFrequency",100,0,250);
        SUPERCELL_FREQUENCY=builder.defineInRange("supercellFrequency",35,0,200);
        SQUALL_FREQUENCY=builder.defineInRange("squallFrequency",30,0,200);
        PRESSURE_STRENGTH=builder.defineInRange("pressureSystemStrength",100,0,200);
        DRY_CLOUD_SHARE=builder.defineInRange("dryCloudShare",32,0,80);
        CELL_SIZE=builder.defineInRange("cellSize",100,50,200);
        MAX_PRECIPITATION=builder.comment("Maximum model rain rate in millimetres per hour.").defineInRange("maximumPrecipitationMmH",90,5,250);
        builder.pop();
        builder.push("radar");
        RADAR_VIEW=builder.defineEnum("defaultView",RadarView.DBZ);
        RADAR_QUALITY=builder.defineEnum("quality",RadarQuality.HOCH);
        RADAR_RANGE=builder.defineInRange("rangeBlocks",1500,500,5000);
        RADAR_TOOLTIPS=builder.define("tooltips",true);
        RADAR_FRONTS=builder.define("showFronts",true);
        RADAR_ISOBARS=builder.define("showIsobars",false);
        RADAR_LIGHTNING=builder.define("showLightning",true);
        builder.pop();
        builder.push("precipitation_graphics");
        RAIN_PARTICLE_SIZE=builder.defineInRange("rainParticleSize",100,40,220);
        SNOW_PARTICLE_SIZE=builder.defineInRange("snowParticleSize",100,40,220);
        SLEET_PARTICLE_SIZE=builder.defineInRange("sleetParticleSize",100,40,220);
        SPLASHES=builder.define("groundAndWaterSplashes",true);
        PARTICLE_MODE=builder.defineEnum("particleMode",ParticleMode.THREE_D_HIGH);
        builder.pop();
        builder.push("sound");
        WEATHER_SOUNDS=builder.define("weatherSounds",true);
        SOUND_VOLUME=builder.defineInRange("masterVolume",80,0,100);
        RAIN_VOLUME=builder.defineInRange("rainVolume",90,0,100);
        WIND_VOLUME=builder.defineInRange("windVolume",65,0,100);
        THUNDER_VOLUME=builder.defineInRange("thunderVolume",100,0,100);
        INDOOR_DAMPING=builder.defineInRange("indoorDamping",75,0,100);
        builder.pop();
        builder.push("cloud_optics");
        CLOUD_SMOOTHING=builder.comment("Reduces hard holes and repetitive scalloping without changing brightness.")
            .defineInRange("shapeSmoothing",70,0,100);
        ADAPTIVE_CLOUDS=builder.comment("Reduce distant cloud geometry when frame rate falls below the target.").define("adaptiveCloudPerformance",true);
        TARGET_FPS=builder.defineInRange("targetFps",60,30,165);
        DISTANT_CLOUD_DETAIL=builder.comment("Far cloud tessellation in percent; lower values save GPU time.").defineInRange("distantDetail",55,20,100);
        builder.pop();
        SPEC = builder.build();
    }
    private CloudConfig() {}
}
