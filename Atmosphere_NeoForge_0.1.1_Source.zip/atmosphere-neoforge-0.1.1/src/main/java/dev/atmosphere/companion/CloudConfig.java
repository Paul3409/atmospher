package dev.atmosphere.companion;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client-only options: each one affects the renderer immediately. */
public final class CloudConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue HEIGHT;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;
    public static final ModConfigSpec.EnumValue<CloudType> CLOUD_TYPE;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_CLOUDS;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_PRECIPITATION;
    public static final ModConfigSpec.DoubleValue TEMPERATURE_OFFSET;
    public static final ModConfigSpec.BooleanValue CUSTOM_PRECIPITATION;
    public static final ModConfigSpec.BooleanValue RAIN_CURTAIN;
    public static final ModConfigSpec.BooleanValue OPTICAL_SNOW;
    public static final ModConfigSpec.BooleanValue LIGHTNING;
    public static final ModConfigSpec.IntValue LIGHTNING_FREQUENCY;
    public static final ModConfigSpec.IntValue PRECIPITATION_DENSITY;
    public static final ModConfigSpec.EnumValue<WindDirection> WIND_DIRECTION;
    public static final ModConfigSpec.DoubleValue WIND_SPEED;
    public static final ModConfigSpec.IntValue RENDER_DISTANCE;
    public static final ModConfigSpec.IntValue CLOUD_DENSITY;
    public static final ModConfigSpec.IntValue CLOUD_SCALE;
    public static final ModConfigSpec.IntValue CLOUD_OPACITY;
    public static final ModConfigSpec.IntValue ROUGHNESS;
    public static final ModConfigSpec.IntValue NIGHT_BRIGHTNESS;
    public static final ModConfigSpec.IntValue CURTAIN_OPACITY;
    public static final ModConfigSpec.IntValue RADAR_ZOOM;
    public static final ModConfigSpec.IntValue WEATHER_CELL_DENSITY;
    public static final ModConfigSpec.IntValue WEATHER_LIFETIME;
    public static final ModConfigSpec.IntValue FRONT_STRENGTH;
    public static final ModConfigSpec.IntValue VIRGA_AMOUNT;
    public enum Quality { LOW, MEDIUM, HIGH }
    public enum WindDirection {
        NORD("Nord",0,1), NORDOST("Nordost",-.707,.707), OST("Ost",-1,0),
        SUEDOST("Südost",-.707,-.707), SUED("Süd",0,-1), SUEDWEST("Südwest",.707,-.707),
        WEST("West",1,0), NORDWEST("Nordwest",.707,.707);
        public final String label; public final double dx,dz;
        WindDirection(String label,double dx,double dz){this.label=label;this.dx=dx;this.dz=dz;}
        @Override public String toString(){return label;}
    }
    public enum CloudType { AUTO, CUMULUS, STRATOCUMULUS, STRATUS, NIMBOSTRATUS, CUMULONIMBUS,
        ALTOCUMULUS, ALTOSTRATUS, CIRRUS, CIRROSTRATUS, CUMULONIMBUS_GROSS }
    static {
        var builder = new ModConfigSpec.Builder();
        builder.push("clouds");
        HEIGHT = builder.comment("Cloud base height in world coordinates (blocks).").defineInRange("height", 160, 96, 256);
        QUALITY = builder.comment("Cloud surface detail and number of lobes.").defineEnum("quality", Quality.MEDIUM);
        CLOUD_TYPE = builder.comment("Cloud family shown in the sky; AUTO follows the world time.").defineEnum("cloudType", CloudType.AUTO);
        WIND_DIRECTION=builder.comment("Meteorological direction the clouds come from.").defineEnum("windDirection",WindDirection.WEST);
        WIND_SPEED=builder.defineInRange("windSpeed",1.0,0.0,5.0);
        RENDER_DISTANCE=builder.defineInRange("renderDistance",560,256,1024);
        CLOUD_DENSITY=builder.defineInRange("density",75,20,100);
        CLOUD_SCALE=builder.defineInRange("scale",100,60,160);
        CLOUD_OPACITY=builder.defineInRange("opacity",100,20,100);
        ROUGHNESS=builder.defineInRange("roughness",100,0,180);
        NIGHT_BRIGHTNESS=builder.comment("Cloud brightness at midnight, percent.").defineInRange("nightBrightness",32,8,100);
        builder.pop();
        builder.push("vanilla_weather");
        HIDE_VANILLA_CLOUDS=builder.translation("atmosphere_companion.config.hide_vanilla_clouds")
            .comment("Hide vanilla clouds on this client. Atmosphere clouds remain visible.").define("hideVanillaClouds",false);
        HIDE_VANILLA_PRECIPITATION=builder.translation("atmosphere_companion.config.hide_vanilla_precipitation")
            .comment("Always hide vanilla rain and snow. Custom cloud-bound precipitation replaces its visuals.").define("hideVanillaPrecipitation",true);
        builder.pop();
        builder.push("custom_weather");
        CUSTOM_PRECIPITATION=builder.define("precipitation",true);
        PRECIPITATION_DENSITY=builder.defineInRange("precipitationDensity",100,0,200);
        CURTAIN_OPACITY=builder.defineInRange("curtainOpacity",100,0,200);
        RAIN_CURTAIN=builder.define("rainCurtain",true);
        OPTICAL_SNOW=builder.comment("Visual snow particles only; never places snow blocks.").define("opticalSnow",true);
        TEMPERATURE_OFFSET=builder.comment("Degrees Celsius added to biome and altitude temperature.").defineInRange("temperatureOffset",0.0,-30.0,30.0);
        LIGHTNING=builder.define("lightning",true);
        LIGHTNING_FREQUENCY=builder.comment("Relative lightning rate, 0 to 200 percent.").defineInRange("lightningFrequency",100,0,200);
        RADAR_ZOOM=builder.defineInRange("radarZoom",8,2,24);
        WEATHER_CELL_DENSITY=builder.comment("Number of naturally developing showers and thunderstorms.")
            .defineInRange("weatherCellDensity",100,20,200);
        WEATHER_LIFETIME=builder.comment("Relative lifetime of naturally developing weather cells.")
            .defineInRange("weatherLifetime",100,50,200);
        FRONT_STRENGTH=builder.comment("Visual density of distant precipitation fronts.")
            .defineInRange("frontStrength",125,0,200);
        VIRGA_AMOUNT=builder.comment("Fraction of precipitation streaks that evaporate before reaching the ground.")
            .defineInRange("virgaAmount",35,0,100);
        builder.pop();
        SPEC = builder.build();
    }
    private CloudConfig() {}
}
