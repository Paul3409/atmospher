package dev.atmosphere.companion;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client-only options: each one affects the renderer immediately. */
public final class CloudConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.IntValue HEIGHT;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_CLOUDS;
    public static final ModConfigSpec.BooleanValue HIDE_VANILLA_PRECIPITATION;
    public enum Quality { LOW, MEDIUM, HIGH }
    static {
        var builder = new ModConfigSpec.Builder();
        builder.push("clouds");
        HEIGHT = builder.comment("Cloud base height in world coordinates (blocks).").defineInRange("height", 160, 96, 256);
        QUALITY = builder.comment("Cloud surface detail and number of lobes.").defineEnum("quality", Quality.MEDIUM);
        builder.pop();
        builder.push("vanilla_weather");
        HIDE_VANILLA_CLOUDS=builder.translation("atmosphere_companion.config.hide_vanilla_clouds")
            .comment("Hide vanilla clouds on this client. Atmosphere clouds remain visible.").define("hideVanillaClouds",false);
        HIDE_VANILLA_PRECIPITATION=builder.translation("atmosphere_companion.config.hide_vanilla_precipitation")
            .comment("Hide vanilla rain and snow and suppress vanilla rain splashes and rain ambience on this client. Does not change server weather, thunder, or gameplay.").define("hideVanillaPrecipitation",false);
        builder.pop();
        SPEC = builder.build();
    }
    private CloudConfig() {}
}
