# Atmosphere 0.5.0 – NeoForge 21.1.259

Zehn experimentelle Wolkenprofile für Minecraft 1.21.1 und Java 21: Cumulus, Stratocumulus, Stratus, Nimbostratus, Cumulonimbus, Altocumulus, Altostratus, Cirrus, Cirrostratus und großer Cumulonimbus. Die Wolkenart ist im Ingame-Menü (M) wählbar; AUTO wechselt sie derzeit nach Weltzeit.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Im Ingame-Menü (M) sind Wolkenart, Höhe, Qualität, Vanilla-Wolken, eigener Niederschlag und dessen Dichte, Niederschlagswand, optischer Schneefall, Temperaturkorrektur, visuelle Blitze und Blitzhäufigkeit einstellbar. Das Radar (R) zeigt genau das Niederschlagsfeld, aus dem Partikel und Niederschlagswand erzeugt werden. Trockene Wolken bleiben trocken. Nur die Oberwelt enthält diese Effekte.

Unter 0 °C fällt eigener Schnee, von 0 °C bis unter 1 °C Schneeregen, ab 1 °C Regen. Die lokale Temperatur basiert auf Biom und Höhe plus einstellbarer Korrektur. Vanilla-Regen und -Schnee werden clientseitig immer ausgeblendet. Schnee und Blitze sind rein optisch: keine Schneeblöcke, kein Schaden, kein Feuer. Serverwetter und Spielmechanik bleiben unverändert. Es gibt noch keine dynamische Wettersteuerung, synchronisierte Mehrspieler-Wetterdaten oder eigene Regengeräusche.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
