# Atmosphere 0.4.0 – NeoForge 21.1.259

Fünf experimentelle Wolkenprofile für Minecraft 1.21.1 und Java 21: Cumulus, Stratocumulus, Stratus, Nimbostratus und Cumulonimbus. Stratus und Nimbostratus verwenden jetzt ungleichmäßige, mehrskalige Strukturen statt regelmäßiger Sinuswellen. Die Wolkenart ist im Ingame-Menü (M) wählbar; AUTO wechselt sie derzeit nach Weltzeit.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Im Ingame-Menü (M) sind Wolkenart, Höhe, Qualität und Vanilla-Wolken einstellbar. Das Radar (R) zeigt genau das Niederschlagsfeld, aus dem die eigenen Regenstreifen und der neue dunkle Fernvorhang erzeugt werden. Cumulus und Stratus sind trocken, Stratocumulus hat schwachen, Nimbostratus flächigen und Cumulonimbus starken Regen. Außerhalb des Wolkenbereichs einer Einzelwolke bleibt es trocken. Nur die Oberwelt enthält diese Effekte.

Vanilla-Regen und -Schnee werden clientseitig immer ausgeblendet. Der eigene Niederschlag ist bislang rein visuell; Serverwetter, Blitze und Spielmechanik bleiben unverändert. Es gibt noch keine dynamische Wettersteuerung, synchronisierte Mehrspieler-Wetterdaten oder eigene Regengeräusche.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
