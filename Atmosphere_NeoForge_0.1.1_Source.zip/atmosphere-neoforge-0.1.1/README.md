# Atmosphere 0.8.0 – NeoForge 21.1.259

Zehn experimentelle Wolkenprofile für Minecraft 1.21.1 und Java 21. Einzelwolken liegen in stabilen, unregelmäßig versetzten Weltzellen und werden durch Weltzeit und Wind bewegt – niemals durch die Kamera. Schichtwolken werden als eine kontinuierliche weltkoordinatenbasierte Fläche erzeugt: Es gibt keine wiederholten 300×280-Meshes und keine inneren Kachelwände mehr. Die eingestellte Wolken- und Nachthelligkeit wurde nicht verändert.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Das Ingame-Menü (M) hat fünf Seiten. Schieberegler steuern Wetterzellendichte, Zelllebensdauer, Niederschlagsfront, Virga-Anteil und Terrainnebel. Im AUTO-Modus entstehen endliche Schauer-, Gewitter-, Schwergewitter- und Squall-Line-Zellen, wachsen, ziehen mit einer stabilen eigenen Zugrichtung und zerfallen. Niederschlag besitzt asymmetrische Kerne, Nebenkerne, Lücken und gebogene Bänder statt Kreisflächen. Radar, Partikel und Niederschlagsfront lesen exakt dasselbe Feld.

Version 0.8.0 ergänzt einen fünften Menübereich für Terrainnebel. Die lokale Nebelwahrscheinlichkeit wird aus Höhe, umgebendem Relief, Wasser, Biom, Tageszeit und Wetterzellen berechnet. Feuchte Senken und Ufer erhalten dichtere, niedrige Schwaden; Anhöhen bleiben häufiger frei. Dichte und zeitliche Beständigkeit sind einstellbar. Geländedaten werden zwischengespeichert, damit die Abfrage nicht in jedem Bild neu durchgeführt wird.

Ein Wechsel der Windrichtung versetzt vorhandene Wolken nicht mehr. Der Weltwind wird fortlaufend integriert, und natürliche Wetterzellen besitzen eine stabile eigene Zugrichtung. Regen fällt schneller und dichter. Schnee sinkt langsam mit zwei überlagerten Seitwärtsbewegungen; Schneeregen liegt in Geschwindigkeit und Fallbild zwischen Schnee und Regen.

Unter 0 °C fällt eigener Schnee, von 0 °C bis unter 1 °C Schneeregen, ab 1 °C Regen. Niederschlagsfronten bestehen aus unregelmäßigen, kräftigeren Fallstreifen und können als Virga vor dem Boden enden. Ihre Farbe ist neutralgrau und erhält nachts keinen Blaustich. Vanilla-Regen und -Schnee werden clientseitig immer ausgeblendet. Schnee und Blitze sind rein optisch: keine Schneeblöcke, kein Schaden, kein Feuer. Serverwetter und Spielmechanik bleiben unverändert.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
