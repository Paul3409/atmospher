# Atmosphere Weather Simulator 2.0.0

Manueller Wettersimulator für Minecraft 1.21.1, NeoForge 21.1.259 und Java 21.

## Bedienung

- `M`: Wettersimulator öffnen
- `R`: Wetterkarte direkt öffnen
- Die Minecraft-Standardwolken bleiben aktiv. Atmosphere erzeugt keine eigenen Wolken.
- Globale Werte gelten überall, wo keine Wetterzone liegt.
- Auf der Wetterkarte erzeugt **Neue Zone** eine frei malbare Zone. Linksklick malt, **Radieren** entfernt Rasterfelder, Rechtsziehen verschiebt die Karte und das Mausrad zoomt.
- Neuere beziehungsweise zuletzt angelegte Zonen haben Vorrang. Dadurch kann eine kleine Zone mit `Niederschlag: AUS` ein Haus oder einen Hof aus einer größeren Schneezone aussparen.
- Jede Zone besitzt einen eigenen Höhenbereich. So kann Wetter nur unterhalb, oberhalb oder zwischen zwei Y-Höhen wirken.

## Manuell einstellbar

Global sowie je Zone: Niederschlagsart, Stärke, Temperatur, Schneefallgrenze, Schneeregenband, Nebeldichte, Nebelbeginn, Nebelende, Windrichtung, Windstärke und Blitzhäufigkeit. Global sind zusätzlich Partikeldichte, getrennte Größen für Regen, Schnee und Schneeregen, Spritzer, Wettersounds und Lautstärke einstellbar.

`AUTOMATISCH` bezieht sich nur auf die manuell festgelegte Schneefallgrenze: unterhalb fällt Regen, im Übergangsband Schneeregen und oberhalb Schnee. Es erzeugt keine selbstständigen Wetterwechsel.

Der Nebel verwendet Minecrafts Entfernungsnebel. Es werden keine Nebelflächen oder Nebelpolygone gerendert.

Wetterzonen werden in `config/atmosphere-weather-zones.json` gespeichert. Ihre Masken verwenden ein 4-Block-Raster, damit unregelmäßige Konturen und kleine Aussparungen möglich sind.

## Installation

Die JAR in den `mods`-Ordner einer Minecraft-1.21.1-Installation mit NeoForge 21.1.259 legen. Java 21 wird benötigt.
