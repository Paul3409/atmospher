# Atmosphere – unabhängiger Neustart 0.1.0

Eigenständiges experimentelles Wolkenmodell für Minecraft 1.21.1, NeoForge 21.1.259 und Java 21. Keine Abhängigkeit von Simple Clouds oder einer anderen Wettermod. Das Modell ist ein technischer Prototyp und simuliert kein Wetter.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Die Einstellungen für Wolkenhöhe und Qualität liegen im NeoForge-Modmenü bei Atmosphere Companion unter Konfiguration. Nur die Oberwelt enthält experimentelle Wolken. Das Modell ist derzeit statisch und ersetzt nicht die Vanilla-Wolken.

Unter vanilla_weather lassen sich Vanilla-Wolken und Vanilla-Niederschlag separat ausblenden. Der Niederschlagsschalter unterdrückt auch Vanilla-Regenpartikel und -Regengeräusche. Beide Schalter sind standardmäßig aus und wirken nur auf diesem Client: Serverwetter, Blitze und Spielmechanik bleiben unverändert. Wolken und Niederschlag anderer Mods werden damit nicht allgemein abgeschaltet.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
