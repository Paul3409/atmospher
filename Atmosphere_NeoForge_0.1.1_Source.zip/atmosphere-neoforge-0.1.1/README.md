# Atmosphere 0.6.0 – NeoForge 21.1.259

Zehn experimentelle Wolkenprofile für Minecraft 1.21.1 und Java 21. Einzelwolken liegen in stabilen, unregelmäßig versetzten Weltzellen und werden durch Weltzeit und Wind bewegt – niemals durch die Kamera. Windrichtung wird als meteorologische Himmelsrichtung gewählt. Große Cumulonimbus-Meshes besitzen einen erweiterten, geschlossenen Berechnungsraum; Cirrus verwendet feinere, halbtransparente Faserzüge.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Das Ingame-Menü (M) hat drei Seiten. Schieberegler steuern unter anderem Windgeschwindigkeit, Höhe, Temperaturkorrektur, Niederschlagsdichte, Sichtweite, Wolkendichte, Größe, Deckkraft, Formdetail, Nachthelligkeit und Radar-Zoom. Das geglättete Radar (R) unterscheidet Regen, Schneeregen und Schnee. Niederschlag und Radar bewegen sich mit demselben weltgebundenen Feld.

Unter 0 °C fällt eigener Schnee, von 0 °C bis unter 1 °C Schneeregen, ab 1 °C Regen. Die lokale Temperatur basiert auf Biom und Höhe plus einstellbarer Korrektur. Vanilla-Regen und -Schnee werden clientseitig immer ausgeblendet. Schnee und Blitze sind rein optisch: keine Schneeblöcke, kein Schaden, kein Feuer. Serverwetter und Spielmechanik bleiben unverändert. Es gibt noch keine dynamische Wettersteuerung, synchronisierte Mehrspieler-Wetterdaten oder eigene Regengeräusche.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
