# Atmosphere 1.0.0 – NeoForge 21.1.259

Zehn experimentelle Wolkenprofile für Minecraft 1.21.1 und Java 21. Einzelwolken liegen in stabilen, unregelmäßig versetzten Weltzellen und werden durch Weltzeit und Wind bewegt – niemals durch die Kamera. Schichtwolken werden als eine kontinuierliche weltkoordinatenbasierte Fläche erzeugt: Es gibt keine wiederholten 300×280-Meshes und keine inneren Kachelwände mehr. Die eingestellte Wolken- und Nachthelligkeit wurde nicht verändert.

Mit Gradle 8.14.3 und Java 21: `gradle clean build`. `gradle runClient` startet eine separate Entwicklungsinstallation. Der optionale Test `-PsmokeTest` ergänzt eine Testklasse, die nicht im regulären Build enthalten ist.

Das Ingame-Menü (M) hat sieben Seiten. Schieberegler steuern Wetterzellendichte, Zelllebensdauer, Niederschlagsfront, Virga-Anteil, Terrainnebel, getrennte Partikelgrößen sowie Regen-, Wind- und Donnerlautstärken. Im AUTO-Modus entstehen endliche Schauer-, Gewitter-, Schwergewitter- und Squall-Line-Zellen, wachsen, pulsieren, ziehen auf leicht gekrümmten eigenen Bahnen und zerfallen. Niederschlag besitzt asymmetrische Kerne, Nebenkerne, Lücken und gebogene Bänder statt Kreisflächen. Radar, Partikel und Niederschlagsfront lesen exakt dasselbe Feld.

Version 1.0.0 ersetzt die radiale Zellform durch ein mehrskaliges Wetterfeld aus schwachen Flaechen, gebogenen Baendern, versetzten Schauerteilkernen, Gewitterlinien und asymmetrischen Superzellen mit Einströmnische und Hook-Echo. Trockene Cumulusfelder existieren unabhängig von Niederschlagszellen. Radar, Wolken, Partikel und Vorhaenge lesen dieselben Weltfelder.

Niederschlag besitzt kontinuierliche Weltkoordinaten statt einer kamerabezogenen Hoehe. Laufen, Springen und Fliegen verschieben die Tropfen nicht. Die Fallbahn wird mit Teilbildern interpoliert. Der einstellbare Partikelmodus bietet 2D, gekreuztes 3D und hochwertiges dreiflaechiges 3D. Regen, Schnee und Schneeregen behalten getrennte Größenregler, Wind- und Boeeneinfluss, Dachabschirmung und Spritzer.

Leichter, mittlerer und schwerer Fabric-Regen sowie Wind laufen als dauerhafte Ebenen. Ihre Lautstaerken werden in jedem Tick weich ineinander überblendet; Innenraumdaempfung ist ebenfalls kontinuierlich. Nur Donner bleibt ein räumlich beziehungsweise zeitlich einzelnes Ereignis.

Der Cumulonimbus ist kein zentraler Pilzkörper mehr: mehrere versetzte Aufwindtürme wachsen aus einer breiten gemeinsamen Basis und gehen weich in einen seitlich versetzten, flachen Amboss über. Im AUTO-Modus werden trockene Cumulus, Stratocumulus und Altocumulus mit aktiven Gewitterwolken gemischt. Wolkenhelligkeit und weltgebundene Bewegung bleiben unverändert. Das Nebelmodell berücksichtigt Wasser weiterhin mit separat einstellbarer Stärke.

Version 0.8.0 ergänzt einen fünften Menübereich für Terrainnebel. Die lokale Nebelwahrscheinlichkeit wird aus Höhe, umgebendem Relief, Wasser, Biom, Tageszeit und Wetterzellen berechnet. Feuchte Senken und Ufer erhalten dichtere, niedrige Schwaden; Anhöhen bleiben häufiger frei. Dichte und zeitliche Beständigkeit sind einstellbar. Geländedaten werden zwischengespeichert, damit die Abfrage nicht in jedem Bild neu durchgeführt wird.

Ein Wechsel der Windrichtung versetzt vorhandene Wolken nicht mehr. Der Weltwind wird fortlaufend integriert, und natürliche Wetterzellen besitzen eine stabile eigene Zugrichtung. Regen fällt schneller und dichter. Schnee sinkt langsam mit zwei überlagerten Seitwärtsbewegungen; Schneeregen liegt in Geschwindigkeit und Fallbild zwischen Schnee und Regen.

Unter 0 °C fällt eigener Schnee, von 0 °C bis unter 1 °C Schneeregen, ab 1 °C Regen. Niederschlagsfronten bestehen aus unregelmäßigen, kräftigeren Fallstreifen und können als Virga vor dem Boden enden. Ihre Farbe ist neutralgrau und erhält nachts keinen Blaustich. Vanilla-Regen und -Schnee werden clientseitig immer ausgeblendet. Schnee und Blitze sind rein optisch: keine Schneeblöcke, kein Schaden, kein Feuer. Serverwetter und Spielmechanik bleiben unverändert.

Alte Fabric-Projekte und Welten werden nicht verändert. Bestehende Welten nicht ohne Migrationsplanung mit der neuen Mod öffnen. Die frühere Chrome-Sicherheitswarnung ist ungeklärt; ein Build ist keine Malwareprüfung.
