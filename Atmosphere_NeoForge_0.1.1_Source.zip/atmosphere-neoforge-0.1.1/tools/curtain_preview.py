"""Schematic cross-section of cloud-bound rain curtain; not an in-game screenshot."""
import pathlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=pathlib.Path(__file__).resolve().parents[1]
x=np.linspace(-220,220,601)
y=np.linspace(60,208,350)
xx,yy=np.meshgrid(x,y)
edge=np.clip((1.1-np.abs(xx)/112)*3,0,1)
patch=.77+.16*np.sin(xx*.045)*np.cos(-xx*.013)
intensity=np.clip(edge*patch*.95,0,1)
cloud_bottom=138+2*np.sin(xx*.012)
ground=64+2*np.sin(xx*.018)
height_mask=(yy>=ground)&(yy<=cloud_bottom)
top_fade=np.clip((cloud_bottom-yy)/25,0,1)
curtain=intensity*height_mask*(.55+.45*top_fade)
fig,ax=plt.subplots(figsize=(11,4),facecolor='#bbcee9')
ax.set_facecolor('#bbcee9')
ax.imshow(curtain,extent=[x.min(),x.max(),y.min(),y.max()],origin='lower',
          cmap='Greys',vmin=0,vmax=1,alpha=np.clip(curtain*.72,0,.75),aspect='auto')
ax.fill_between(x,ground[0],60,color='#49632e')
top=cloud_bottom[0]
ax.fill_between(x,top,top+30*np.exp(-(x/88)**2),where=np.abs(x)<170,
                color='#626b76',alpha=.9)
ax.set_xlim(-220,220);ax.set_ylim(60,205)
ax.set_xlabel('Position relativ zur Gewitterwolke (Bloecke)')
ax.set_ylabel('Welthoehe (Bloecke)')
ax.set_title('Atmosphere 0.4.0: Niederschlagsvorhang bis zum Boden (mathematische Vorschau)')
fig.tight_layout()
fig.savefig(root/'curtain-math-preview-0.4.0.png',dpi=150)
