import numpy as np
import matplotlib.pyplot as plt

n=420;x=np.linspace(-3.2,3.2,n);z=np.linspace(-2.2,2.2,n);X,Z=np.meshgrid(x,z)
field=np.zeros_like(X)
def core(cx,cz,rx,rz,a=1):
    return a*np.exp(-((X-cx)/rx)**2-((Z-cz)/rz)**2)
# weak stratiform shield, broken bands, scattered showers
field+=.17*np.exp(-((X+1.35+.18*Z)/1.85)**4-(Z/.92)**4)
field+=core(-2.35,.72,.28,.19,.52)+core(-1.75,.48,.18,.31,.67)+core(-1.32,.18,.42,.19,.76)
field+=core(2.35,-.95,.19,.16,.42)+core(2.72,-.72,.31,.18,.58)
# idealised asymmetric supercell with notch and hook
u=(X-.72);v=(Z+.05)
shield=.49*np.exp(-((u+.22+.34*v)/1.18)**2-((v-.34)/.72)**2)
strong=.88*np.exp(-((u+.52)/.31)**2-((v-.06)/.23)**2)
r=np.hypot((u-.12)*1.06,v+.27);ang=np.arctan2(v+.27,u-.12)
hook=.63*np.exp(-((r-.54)/.13)**2)*(ang<.75)*(ang>-2.7)
notch=np.exp(-((u+.02)/.23)**2-((v+.18)/.20)**2)
field+=np.clip((shield+strong+hook)*(1-.78*notch),0,1)
texture=.84+.10*np.sin(X*8+Z*5)+.06*np.sin(X*19-Z*11)
field=np.clip(field*texture,0,1)
fig,ax=plt.subplots(figsize=(14,8),facecolor='#b8cae2');ax.set_facecolor('#202a31')
levels=[.02,.08,.18,.32,.48,.66,.82,1.01]
colors=['#27bfd0','#1474d4','#2fc55b','#9bd63a','#f2d33d','#ef7c24','#df3030']
ax.contourf(X*180,Z*180,field,levels=levels,colors=colors)
ax.contour(X*180,Z*180,field,levels=[.08,.32,.66],colors='#d8e6e8',linewidths=.4,alpha=.45)
ax.set_title('Atmosphere 1.0.0 – mehrskaliges Niederschlagsfeld mit Superzelle (kein Ingame-Bild)',fontsize=18)
ax.set_xlabel('West–Ost (Blöcke)');ax.set_ylabel('Süd–Nord (Blöcke)');ax.set_aspect('equal')
fig.tight_layout();fig.savefig('weather-field-supercell-preview-1.0.0.png',dpi=130)
