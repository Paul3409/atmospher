import numpy as np
import matplotlib.pyplot as plt

rng=np.random.default_rng(9)
fig,axs=plt.subplots(1,3,figsize=(16,6),facecolor='#b8cae2')
fig.suptitle('Atmosphere 0.9.0 – mathematisches Partikel- und Böenmodell (kein Ingame-Bild)',fontsize=20)
for ax,title,speed,color in zip(axs,['Regen','Schneeregen','Schnee'],[2.35,.34,.085],['#707b88','#d6dbe0','#f3f3ee']):
    ax.set_facecolor('#6c7990');ax.set_xlim(-8,8);ax.set_ylim(0,26);ax.set_title(title,fontsize=17)
    for i in range(75):
        phase=rng.uniform(0,26);x=rng.uniform(-7.5,7.5)
        if title=='Schnee':
            y=phase;drift=.8*np.sin(y*.55+rng.uniform(0,6.28))
            ax.scatter(x+drift,y,s=rng.uniform(18,55),c=color,alpha=.75,marker='*')
        else:
            y=phase;gust=.3*np.sin(y*.25+rng.uniform(0,6.28))
            length=1.8 if title=='Regen' else .75
            ax.plot([x,x+gust],[y,y-length],color=color,alpha=.72,lw=1.2 if title=='Regen' else 1.6)
    ax.text(0,1.1,f'Fallfaktor {speed:g}',ha='center',color='white',fontsize=12)
    ax.set_xlabel('Winddrift');ax.set_ylabel('Höhe')
fig.tight_layout(rect=(0,0,1,.92));fig.savefig('precipitation-particle-preview-0.9.0.png',dpi=120)
