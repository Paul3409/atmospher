"""Mathematical preview of the exact rain-field formulas, not an in-game image."""
import pathlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

root=pathlib.Path(__file__).resolve().parents[1]
v=np.linspace(-256,256,257)
x,z=np.meshgrid(v,v)
fig,axes=plt.subplots(1,3,figsize=(12,4.2),facecolor='#bbcee9')
for ax,kind in zip(axes,['Stratocumulus','Nimbostratus','Cumulonimbus']):
    if kind=='Nimbostratus':
        rain=np.clip(.78+.14*np.sin(x*.012+z*.009)+.09*np.cos(z*.018-x*.007),.35,1)
    else:
        dx=x/(112 if kind=='Cumulonimbus' else 132)
        dz=z/(102 if kind=='Cumulonimbus' else 120)
        edge=np.clip((1.1-np.sqrt(dx*dx+dz*dz))*3,0,1)
        patch=.77+.16*np.sin(x*.045+z*.021)*np.cos(z*.032-x*.013)
        rain=np.clip(edge*patch*(.95 if kind=='Cumulonimbus' else .28),0,1)
    ax.imshow(rain,origin='lower',extent=[-256,256,-256,256],vmin=0,vmax=1,cmap='turbo')
    ax.scatter([0],[0],c='white',s=12,marker='+')
    ax.set_title(kind)
    ax.set_xlabel('X relativ zur Wolke (Bloecke)')
    ax.set_ylabel('Z relativ zur Wolke (Bloecke)')
    ax.set_aspect('equal')
fig.suptitle('Atmosphere 0.4.0 – berechnete Niederschlagsintensitaet, kein Ingame-Bild')
fig.tight_layout()
fig.savefig(root/'precipitation-math-preview-0.4.0.png',dpi=150)
