import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(-500,500,700)
terrain=72+19*np.sin(x/145)+8*np.sin(x/57+.8)+3*np.sin(x/23)
water=np.exp(-((x+115)/95)**2)+.7*np.exp(-((x-270)/70)**2)
mean=np.convolve(terrain,np.ones(85)/85,mode='same')
basin=np.clip((mean-terrain-2)/12,0,1)
altitude=np.clip((112-terrain)/38,0,1)
fog=np.clip(.50*basin+.38*altitude*np.clip(water,0,1)+.22,0,1)

fig,ax=plt.subplots(figsize=(12,5),facecolor='#b7cbe6')
ax.set_facecolor('#8394aa')
ax.fill_between(x,40,terrain,color='#43523e',label='Gelände')
ax.fill_between(x,terrain,terrain+fog*18,color='#d9dedc',alpha=.18+.5*fog,label='berechneter Bodennebel')
ax.plot(x,terrain+fog*18,color='#eef1ef',alpha=.8,linewidth=1)
ax.set_xlim(-500,500);ax.set_ylim(40,130)
ax.set_xlabel('Weltkoordinate (Blöcke)');ax.set_ylabel('Höhe')
ax.set_title('Atmosphere 0.8.0 – mathematisches Relief- und Wassermodell (kein Ingame-Bild)')
ax.legend(loc='upper right');fig.tight_layout()
fig.savefig('terrain-fog-math-preview-0.8.0.png',dpi=150)
