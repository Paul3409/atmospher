package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Included only with -PsmokeTest; never included in the published foundation JAR. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class NeoSmoke {
    private static int ticks,boot;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("atmosphere.smokeTest"))return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null){
            if(++boot%200==0)System.out.println("ATMOSPHERE_NEO_WAIT screen="+(mc.screen==null?"none":mc.screen.getClass().getName()));
            if(boot>1800)mc.stop();
            return;
        }
        ticks++;
        if(ticks==30){
            mc.options.hideGui=true;
            mc.player.connection.sendCommand("gamemode spectator");
            mc.player.connection.sendCommand("tp @s 0 110 0 0 -15");
            mc.player.connection.sendCommand("weather rain");
            if(CloudConfig.HIDE_VANILLA_CLOUDS.get() || CloudConfig.HIDE_VANILLA_PRECIPITATION.get())
                throw new IllegalStateException("Fresh test config must default to vanilla on");
            System.out.println("ATMOSPHERE_NEO_WORLD_READY");
        }
        if(ticks==100)Screenshot.grab(mc.gameDirectory,"neo-underside.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==150)mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
        if(ticks==170)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULUS);
        if(ticks==210)Screenshot.grab(mc.gameDirectory,"cumulus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==230)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATOCUMULUS);
        if(ticks==270)Screenshot.grab(mc.gameDirectory,"stratocumulus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==300)Screenshot.grab(mc.gameDirectory,"01-vanilla-an.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==310)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATUS);
        if(ticks==340){
            CloudConfig.HIDE_VANILLA_CLOUDS.set(true);
            CloudConfig.HIDE_VANILLA_PRECIPITATION.set(true);
            System.out.println("ATMOSPHERE_TEST_OPTIONS_DISABLED");
        }
        if(ticks==380)Screenshot.grab(mc.gameDirectory,"stratus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==400)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.NIMBOSTRATUS);
        if(ticks==440)Screenshot.grab(mc.gameDirectory,"nimbostratus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==460)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS);
        if(ticks==500)Screenshot.grab(mc.gameDirectory,"cumulonimbus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==540)Screenshot.grab(mc.gameDirectory,"02-vanilla-aus.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==620){
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.AUTO);
            CloudConfig.HIDE_VANILLA_CLOUDS.set(false);
            CloudConfig.HIDE_VANILLA_PRECIPITATION.set(false);
            System.out.println("ATMOSPHERE_TEST_OPTIONS_RESTORED");
        }
        if(ticks==700)mc.stop();
    }
}
