package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Included only with -PsmokeTest; never included in the published foundation JAR. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class NeoSmoke {
    private static int ticks,boot;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("atmosphere.smokeTest"))return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null){
            if(++boot%200==0)System.out.println("ATMOSPHERE_NEO_WAIT screen="+(mc.screen==null?"none":mc.screen.getClass().getName()));
            if(boot>1800)mc.stop();
            return;
        }
        ticks++;
        if(ticks==30){
            mc.options.hideGui=true;
            mc.player.connection.sendCommand("gamemode spectator");
            mc.player.connection.sendCommand("tp @s 0 110 0 0 -15");
            mc.player.connection.sendCommand("weather rain");
            if(CloudConfig.HIDE_VANILLA_CLOUDS.get() || !CloudConfig.HIDE_VANILLA_PRECIPITATION.get())
                throw new IllegalStateException("Vanilla precipitation must default off");
            double[] before=WeatherField.windOffset();
            mc.player.setPos(mc.player.getX()+17,mc.player.getY(),mc.player.getZ()-9);
            double[] after=WeatherField.windOffset();
            if(Math.abs(before[0]-after[0])>.0001||Math.abs(before[1]-after[1])>.0001)
                throw new IllegalStateException("Wind field must not depend on camera/player position");
            CloudConfig.WIND_SPEED.set(0.0);
            System.out.println("ATMOSPHERE_TEST_WORLD_ANCHORED_WIND");
            System.out.println("ATMOSPHERE_NEO_WORLD_READY");
        }
        if(ticks==100)Screenshot.grab(mc.gameDirectory,"neo-underside.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==150)mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
        if(ticks==170)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULUS);
        if(ticks==180){
            if(WeatherField.precipitation(0,0)!=0)throw new IllegalStateException("Cumulus must be dry");
            System.out.println("ATMOSPHERE_TEST_DRY_CLOUD");
        }
        if(ticks==210)Screenshot.grab(mc.gameDirectory,"cumulus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==230)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATOCUMULUS);
        if(ticks==270)Screenshot.grab(mc.gameDirectory,"stratocumulus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==300)Screenshot.grab(mc.gameDirectory,"01-vanilla-an.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==310)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATUS);
        if(ticks==320){
            double a=CloudRenderer.layerBottomOffset(CloudConfig.CloudType.STRATUS,27,41);
            double b=CloudRenderer.layerBottomOffset(CloudConfig.CloudType.STRATUS,327,321);
            if(Math.abs(a-b)>.0001)throw new IllegalStateException("Stratus tile seam");
            System.out.println("ATMOSPHERE_TEST_CLOUD_TILE_CONTINUITY");
        }
        if(ticks==340){
            CloudConfig.HIDE_VANILLA_CLOUDS.set(true);
            CloudConfig.HIDE_VANILLA_PRECIPITATION.set(true);
            System.out.println("ATMOSPHERE_TEST_OPTIONS_DISABLED");
        }
        if(ticks==380)Screenshot.grab(mc.gameDirectory,"stratus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==400)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.NIMBOSTRATUS);
        if(ticks==410){
            if(WeatherField.precipitation(0,0)<.3)throw new IllegalStateException("Nimbostratus rain missing");
            System.out.println("ATMOSPHERE_TEST_RAIN_FIELD");
        }
        if(ticks==440)Screenshot.grab(mc.gameDirectory,"nimbostratus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==460)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS);
        if(ticks==470){
            if(WeatherField.precipitation(0,0)<.3||WeatherField.precipitation(250,250)!=0)
                throw new IllegalStateException("Rain must stay beneath storm footprint");
            System.out.println("ATMOSPHERE_TEST_CLOUD_LOCAL_RAIN");
        }
        if(ticks==500)Screenshot.grab(mc.gameDirectory,"cumulonimbus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==520)Screenshot.grab(mc.gameDirectory,"vorhang-ferne.png",mc.getMainRenderTarget(),text->{});
        if(ticks==540)Screenshot.grab(mc.gameDirectory,"02-vanilla-aus.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==550)mc.setScreen(new RadarScreen());
        if(ticks==570)Screenshot.grab(mc.gameDirectory,"radar.png",mc.getMainRenderTarget(),text->{});
        if(ticks==575)mc.setScreen(new CloudMenuScreen());
        if(ticks==595)Screenshot.grab(mc.gameDirectory,"menu.png",mc.getMainRenderTarget(),text->{});
        if(ticks==620){
            mc.setScreen(null);
            CloudConfig.HIDE_VANILLA_CLOUDS.set(false);
            System.out.println("ATMOSPHERE_TEST_OPTIONS_RESTORED");
        }
        if(ticks==630)mc.player.connection.sendCommand("tp @s 0 85 0 0 -10");
        if(ticks==700)Screenshot.grab(mc.gameDirectory,"eigener-regen.png",mc.getMainRenderTarget(),text->{});
        if(ticks==710)Screenshot.grab(mc.gameDirectory,"vorhang-nah.png",mc.getMainRenderTarget(),text->{});
        if(ticks==730){
            if(WeatherField.kind(-.01)!=WeatherField.PrecipitationKind.SNOW||
               WeatherField.kind(0)!=WeatherField.PrecipitationKind.SLEET||
               WeatherField.kind(.999)!=WeatherField.PrecipitationKind.SLEET||
               WeatherField.kind(1)!=WeatherField.PrecipitationKind.RAIN)
                throw new IllegalStateException("Temperature boundaries are incorrect");
            System.out.println("ATMOSPHERE_TEST_TEMPERATURE_BOUNDARIES");
            CloudConfig.PRECIPITATION_DENSITY.set(0);
            if(WeatherField.precipitation(0,0)!=0)throw new IllegalStateException("Zero density must clear radar field");
            CloudConfig.PRECIPITATION_DENSITY.set(100);
            System.out.println("ATMOSPHERE_TEST_RADAR_DENSITY");
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS_GROSS);
            mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
        }
        if(ticks==760){
            if(WeatherField.precipitation(0,0)<.3||WeatherField.precipitation(250,250)!=0)
                throw new IllegalStateException("Giant storm precipitation footprint");
            Screenshot.grab(mc.gameDirectory,"riesen-cumulonimbus.png",mc.getMainRenderTarget(),text->{});
            System.out.println("ATMOSPHERE_TEST_GIANT_STORM");
        }
        if(ticks==780)CloudConfig.TEMPERATURE_OFFSET.set(-30.0);
        if(ticks==810){
            if(WeatherField.precipitationKind(0,mc.player.getY(),0)!=WeatherField.PrecipitationKind.SNOW)
                throw new IllegalStateException("Snow preset did not produce snow");
            Screenshot.grab(mc.gameDirectory,"eigener-schnee.png",mc.getMainRenderTarget(),text->{});
            System.out.println("ATMOSPHERE_TEST_SNOW");
        }
        if(ticks==820){
            mc.player.connection.sendCommand("time set midnight");
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS_GROSS);
        }
        if(ticks==850)Screenshot.grab(mc.gameDirectory,"nachtwolken.png",mc.getMainRenderTarget(),text->{});
        if(ticks==860){
            mc.player.connection.sendCommand("time set noon");
            CloudConfig.TEMPERATURE_OFFSET.set(0.0);
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CIRRUS);
            CloudConfig.HIDE_VANILLA_CLOUDS.set(true);
            mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
            if(WeatherField.precipitation(0,0)!=0)throw new IllegalStateException("Cirrus must be dry");
        }
        if(ticks==920)Screenshot.grab(mc.gameDirectory,"cirrus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==930){
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS_GROSS);
            mc.setScreen(new CloudMenuScreen(1));
        }
        if(ticks==950)Screenshot.grab(mc.gameDirectory,"menu-wetter.png",mc.getMainRenderTarget(),text->{});
        if(ticks==960)mc.setScreen(new CloudMenuScreen(2));
        if(ticks==980)Screenshot.grab(mc.gameDirectory,"menu-grafik.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1000){mc.setScreen(null);CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.AUTO);mc.stop();}
    }
}
