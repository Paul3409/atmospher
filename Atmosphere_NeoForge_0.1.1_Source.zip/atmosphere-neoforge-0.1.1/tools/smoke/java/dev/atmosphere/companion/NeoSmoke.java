package dev.atmosphere.companion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Included only with -PsmokeTest; never included in the published foundation JAR. */
@EventBusSubscriber(modid=AtmosphereCompanion.MOD_ID,value=Dist.CLIENT)
public final class NeoSmoke {
    private static int ticks,boot;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("atmosphere.smokeTest"))return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null){
            if(++boot%200==0)System.out.println("ATMOSPHERE_NEO_WAIT screen="+(mc.screen==null?"none":mc.screen.getClass().getName()));
            if(boot>1800)mc.stop();
            return;
        }
        ticks++;
        if(ticks==30){
            mc.options.hideGui=true;
            mc.player.connection.sendCommand("gamemode spectator");
            mc.player.connection.sendCommand("tp @s 0 110 0 0 -15");
            mc.player.connection.sendCommand("weather rain");
            if(CloudConfig.HIDE_VANILLA_CLOUDS.get() || !CloudConfig.HIDE_VANILLA_PRECIPITATION.get())
                throw new IllegalStateException("Vanilla precipitation must default off");
            double[] before=WeatherField.windOffset();
            mc.player.setPos(mc.player.getX()+17,mc.player.getY(),mc.player.getZ()-9);
            double[] after=WeatherField.windOffset();
            if(Math.abs(before[0]-after[0])>.0001||Math.abs(before[1]-after[1])>.0001)
                throw new IllegalStateException("Wind field must not depend on camera/player position");
            var oldDirection=CloudConfig.WIND_DIRECTION.get();
            WeatherField.captureWindState();
            double[] turnBefore=WeatherField.windOffset();
            CloudConfig.WIND_DIRECTION.set(CloudConfig.WindDirection.NORD);
            double[] turnAfter=WeatherField.windOffset();
            if(Math.abs(turnBefore[0]-turnAfter[0])>.0001||Math.abs(turnBefore[1]-turnAfter[1])>.0001)
                throw new IllegalStateException("Changing wind direction moved existing clouds");
            CloudConfig.WIND_DIRECTION.set(oldDirection);
            System.out.println("ATMOSPHERE_TEST_WIND_TURN_CONTINUITY");
            CloudConfig.WIND_SPEED.set(0.0);
            System.out.println("ATMOSPHERE_TEST_WORLD_ANCHORED_WIND");
            double py0=PrecipitationRenderer.worldY(.43,100.0,64,160,2.35);
            double py1=PrecipitationRenderer.worldY(.43,100.1,64,160,2.35);
            if(Math.abs(py1-py0)<.05||Math.abs(py1-py0)>1)
                throw new IllegalStateException("Precipitation trajectory is quantized instead of interpolated");
            System.out.println("ATMOSPHERE_TEST_WORLD_ANCHORED_PARTICLES");
            System.out.println("ATMOSPHERE_NEO_WORLD_READY");
        }
        if(ticks==100)Screenshot.grab(mc.gameDirectory,"neo-underside.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==150)mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
        if(ticks==170)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULUS);
        if(ticks==180){
            if(WeatherField.precipitation(0,0)!=0)throw new IllegalStateException("Cumulus must be dry");
            System.out.println("ATMOSPHERE_TEST_DRY_CLOUD");
        }
        if(ticks==210)Screenshot.grab(mc.gameDirectory,"cumulus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==230)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATOCUMULUS);
        if(ticks==270)Screenshot.grab(mc.gameDirectory,"stratocumulus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==300)Screenshot.grab(mc.gameDirectory,"01-vanilla-an.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==310)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATUS);
        if(ticks==320){
            double a=CloudRenderer.layerBottomOffset(CloudConfig.CloudType.STRATUS,300-.001,41);
            double b=CloudRenderer.layerBottomOffset(CloudConfig.CloudType.STRATUS,300+.001,41);
            double repeated=CloudRenderer.layerBottomOffset(CloudConfig.CloudType.STRATUS,600,41);
            if(Math.abs(a-b)>.02)throw new IllegalStateException("Stratus field discontinuity");
            if(Math.abs(a-repeated)<.01)throw new IllegalStateException("Stratus still repeats as tiles");
            System.out.println("ATMOSPHERE_TEST_CLOUD_TILE_CONTINUITY");
            System.out.println("ATMOSPHERE_TEST_CONTINUOUS_LAYER");
        }
        if(ticks==340){
            CloudConfig.HIDE_VANILLA_CLOUDS.set(true);
            CloudConfig.HIDE_VANILLA_PRECIPITATION.set(true);
            System.out.println("ATMOSPHERE_TEST_OPTIONS_DISABLED");
        }
        if(ticks==380)Screenshot.grab(mc.gameDirectory,"stratus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==400)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.NIMBOSTRATUS);
        if(ticks==410){
            if(WeatherField.precipitation(0,0)<.3)throw new IllegalStateException("Nimbostratus rain missing");
            System.out.println("ATMOSPHERE_TEST_RAIN_FIELD");
        }
        if(ticks==440)Screenshot.grab(mc.gameDirectory,"nimbostratus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==460)CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS);
        if(ticks==470){
            if(WeatherField.precipitation(0,0)<.3||WeatherField.precipitation(250,250)>.22)
                throw new IllegalStateException("Rain must stay beneath storm footprint");
            System.out.println("ATMOSPHERE_TEST_CLOUD_LOCAL_RAIN");
        }
        if(ticks==500)Screenshot.grab(mc.gameDirectory,"cumulonimbus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==520)Screenshot.grab(mc.gameDirectory,"vorhang-ferne.png",mc.getMainRenderTarget(),text->{});
        if(ticks==540)Screenshot.grab(mc.gameDirectory,"02-vanilla-aus.png",mc.getMainRenderTarget(),
            text->System.out.println("ATMOSPHERE_NEO_SCREENSHOT "+text.getString()));
        if(ticks==550)mc.setScreen(new RadarScreen());
        if(ticks==570)Screenshot.grab(mc.gameDirectory,"radar.png",mc.getMainRenderTarget(),text->{});
        if(ticks==575)mc.setScreen(new CloudMenuScreen());
        if(ticks==595)Screenshot.grab(mc.gameDirectory,"menu.png",mc.getMainRenderTarget(),text->{});
        if(ticks==620){
            mc.setScreen(null);
            CloudConfig.HIDE_VANILLA_CLOUDS.set(false);
            System.out.println("ATMOSPHERE_TEST_OPTIONS_RESTORED");
        }
        if(ticks==630)mc.player.connection.sendCommand("tp @s 0 85 0 0 -10");
        if(ticks==700)Screenshot.grab(mc.gameDirectory,"eigener-regen.png",mc.getMainRenderTarget(),text->{});
        if(ticks==710)Screenshot.grab(mc.gameDirectory,"vorhang-nah.png",mc.getMainRenderTarget(),text->{});
        if(ticks==730){
            if(WeatherField.kind(-.01)!=WeatherField.PrecipitationKind.SNOW||
               WeatherField.kind(0)!=WeatherField.PrecipitationKind.SLEET||
               WeatherField.kind(.999)!=WeatherField.PrecipitationKind.SLEET||
               WeatherField.kind(1)!=WeatherField.PrecipitationKind.RAIN)
                throw new IllegalStateException("Temperature boundaries are incorrect");
            System.out.println("ATMOSPHERE_TEST_TEMPERATURE_BOUNDARIES");
            CloudConfig.PRECIPITATION_DENSITY.set(0);
            if(WeatherField.precipitation(0,0)!=0)throw new IllegalStateException("Zero density must clear radar field");
            CloudConfig.PRECIPITATION_DENSITY.set(100);
            System.out.println("ATMOSPHERE_TEST_RADAR_DENSITY");
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS_GROSS);
            mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
        }
        if(ticks==760){
            if(WeatherField.precipitation(0,0)<.3||WeatherField.precipitation(250,250)>.22)
                throw new IllegalStateException("Giant storm precipitation footprint");
            Screenshot.grab(mc.gameDirectory,"riesen-cumulonimbus.png",mc.getMainRenderTarget(),text->{});
            System.out.println("ATMOSPHERE_TEST_GIANT_STORM");
        }
        if(ticks==780)CloudConfig.TEMPERATURE_OFFSET.set(-30.0);
        if(ticks==810){
            if(WeatherField.precipitationKind(0,mc.player.getY(),0)!=WeatherField.PrecipitationKind.SNOW)
                throw new IllegalStateException("Snow preset did not produce snow");
            Screenshot.grab(mc.gameDirectory,"eigener-schnee.png",mc.getMainRenderTarget(),text->{});
            System.out.println("ATMOSPHERE_TEST_SNOW");
        }
        if(ticks==820){
            mc.player.connection.sendCommand("time set midnight");
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS_GROSS);
        }
        if(ticks==850)Screenshot.grab(mc.gameDirectory,"nachtwolken.png",mc.getMainRenderTarget(),text->{});
        if(ticks==860){
            mc.player.connection.sendCommand("time set noon");
            CloudConfig.TEMPERATURE_OFFSET.set(0.0);
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CIRRUS);
            CloudConfig.HIDE_VANILLA_CLOUDS.set(true);
            mc.player.connection.sendCommand("tp @s 0 85 -200 0 -12");
            if(WeatherField.precipitation(0,0)!=0)throw new IllegalStateException("Cirrus must be dry");
        }
        if(ticks==920)Screenshot.grab(mc.gameDirectory,"cirrus.png",mc.getMainRenderTarget(),text->{});
        if(ticks==930){
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.CUMULONIMBUS_GROSS);
            mc.setScreen(new CloudMenuScreen(1));
        }
        if(ticks==950)Screenshot.grab(mc.gameDirectory,"menu-wetter.png",mc.getMainRenderTarget(),text->{});
        if(ticks==960)mc.setScreen(new CloudMenuScreen(2));
        if(ticks==980)Screenshot.grab(mc.gameDirectory,"menu-grafik.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1000){
            mc.setScreen(null);CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.AUTO);
            var center=WeatherCells.sample(0,0,mc.level.getGameTime());
            double best=0,bx=0,bz=0;
            for(int z=-1800;z<=1800;z+=60)for(int x=-1800;x<=1800;x+=60){
                var s=WeatherCells.sample(x,z,mc.level.getGameTime());
                if(s.rain()>best){best=s.rain();bx=x;bz=z;}
            }
            if(best<.05)throw new IllegalStateException("No naturally developing weather cell found");
            var east=WeatherCells.sample(bx+90,bz,mc.level.getGameTime()).rain();
            var north=WeatherCells.sample(bx,bz+90,mc.level.getGameTime()).rain();
            if(Math.abs(east-north)<.0001)throw new IllegalStateException("Natural precipitation is still radial");
            mc.player.connection.sendCommand("tp @s "+(int)bx+" 95 "+(int)bz+" 0 -8");
            System.out.println("ATMOSPHERE_TEST_NATURAL_CELLS");
            System.out.println("ATMOSPHERE_TEST_NON_CIRCULAR_RAIN");
        }
        if(ticks==1060)Screenshot.grab(mc.gameDirectory,"natuerliche-wetterzelle.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1080){mc.setScreen(new CloudMenuScreen(3));}
        if(ticks==1100)Screenshot.grab(mc.gameDirectory,"menu-wetterzellen.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1120){
            mc.setScreen(null);
            mc.player.connection.sendCommand("time set midnight");
            CloudConfig.FOG_DENSITY.set(100);
            CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.STRATUS);
        }
        if(ticks==1160){
            double bestFog=0,fx=mc.player.getX(),fz=mc.player.getZ();
            for(int z=-192;z<=192;z+=24)for(int x=-192;x<=192;x+=24){
                double wx=mc.player.getX()+x,wz=mc.player.getZ()+z;
                double fog=WeatherField.fogPotential(wx,wz);
                if(fog>bestFog){bestFog=fog;fx=wx;fz=wz;}
            }
            if(bestFog<.05)throw new IllegalStateException("Terrain fog model produced no local fog");
            mc.player.connection.sendCommand("tp @s "+(int)fx+" 78 "+(int)(fz-45)+" 0 3");
            System.out.println("ATMOSPHERE_TEST_TERRAIN_FOG");
        }
        if(ticks==1210)Screenshot.grab(mc.gameDirectory,"terrainnebel.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1220)mc.setScreen(new CloudMenuScreen(4));
        if(ticks==1240)Screenshot.grab(mc.gameDirectory,"menu-nebel.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1250){
            if(CloudConfig.RAIN_PARTICLE_SIZE.get()!=100||CloudConfig.SNOW_PARTICLE_SIZE.get()!=100)
                throw new IllegalStateException("Particle scale defaults changed");
            System.out.println("ATMOSPHERE_TEST_TEXTURED_PRECIPITATION");
            mc.setScreen(new CloudMenuScreen(5));
        }
        if(ticks==1270)Screenshot.grab(mc.gameDirectory,"menu-partikel.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1280)mc.setScreen(new CloudMenuScreen(6));
        if(ticks==1300)Screenshot.grab(mc.gameDirectory,"menu-sounds.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1310){
            if(!CloudConfig.WEATHER_SOUNDS.get())throw new IllegalStateException("Weather sounds must default on");
            System.out.println("ATMOSPHERE_TEST_WEATHER_SOUNDS");
        }
        if(ticks==1320){
            mc.setScreen(null);CloudConfig.CLOUD_TYPE.set(CloudConfig.CloudType.AUTO);
            double best=-1,bx=0,bz=0;boolean dryFound=false;
            for(int z=-3200;z<=3200;z+=100)for(int x=-3200;x<=3200;x+=100){
                var s=WeatherCells.sample(x,z,mc.level.getGameTime());
                if(s.type()==WeatherCells.NONE&&s.cloud()>.08&&s.rain()==0)dryFound=true;
                if(s.type()>=WeatherCells.SEVERE&&s.rain()>best){best=s.rain();bx=x;bz=z;}
            }
            if(!dryFound)throw new IllegalStateException("No dry clouds between precipitation cells");
            System.out.println("ATMOSPHERE_TEST_DRY_INTERCELL_CLOUDS");
            if(best>0)mc.player.connection.sendCommand("tp @s "+(int)bx+" 105 "+(int)(bz-220)+" 0 -8");
        }
        if(ticks==1380)Screenshot.grab(mc.gameDirectory,"gemischtes-wolkenfeld.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1390)mc.setScreen(new RadarScreen());
        if(ticks==1410)Screenshot.grab(mc.gameDirectory,"radar-superzelle.png",mc.getMainRenderTarget(),text->{});
        if(ticks==1430){mc.setScreen(null);mc.stop();}
    }
}
