import math
import matplotlib.pyplot as plt
import numpy as np

def smooth(a,b,x):
    t=np.clip((x-a)/(b-a),0,1)
    return t*t*(3-2*t)

def structure(along,across,r,phase,line=False):
    broad=np.sin(along/(r*.52)+across/(r*.41)+phase)
    fine=np.sin(along/(r*.19)-across/(r*.31)+phase*1.71)
    broken=.55+.45*smooth(-.72,.48,np.sin(across/(r*.43)+phase)) if line else 1
    return np.clip((.58+.28*broad+.14*fine)*broken,.05,1)

def rain(along,across,r,kind,phase):
    texture=structure(along,across,r,phase,kind=='Squall Line')
    if kind=='Squall Line':
        bow=.20*r*np.cos(across/(r*.83)+phase)
        band=np.exp(-((along-bow)/(r*.31))**2-(across/(r*2.35))**4)
        return np.clip(band*(.20+.80*texture),0,1)
    if kind=='Schwergewitter':
        u,v=along/r,across/r
        shield=np.exp(-((u+.12+.28*v)/1.08)**2-((v-.42)/.72)**2)
        core=np.exp(-((u+.38)/.37)**2-((v-.18)/.29)**2)
        hook=np.exp(-((u-.42)/.31)**2-((v+.54)/.24)**2)*.75
        notch=np.exp(-((u-.05)/.24)**2-((v+.23)/.27)**2)
        return np.clip((shield*.64+core*.69+hook*.48)*(1-.73*notch)*(.42+.58*texture),0,1)
    main=np.exp(-((along+.16*r)/(.79*r))**2-(across/(.70*r))**2)
    side=np.exp(-((along-.43*r)/(.39*r))**2-((across+.67*r)/(.42*r))**2)
    return np.clip(np.maximum(main,side*.71)*(.34+.66*texture),0,1)

x=np.linspace(-430,430,440); z=np.linspace(-430,430,440); X,Z=np.meshgrid(x,z)
fig,axes=plt.subplots(2,2,figsize=(12,9),facecolor='#b7cbe6')
for ax,(name,r,p) in zip(axes.flat,[('Schauer',100,.7),('Gewitter',125,2.0),('Schwergewitter',155,3.4),('Squall Line',145,4.8)]):
    data=rain(X,Z,r,name,p)
    ax.imshow(data,extent=[x.min(),x.max(),z.min(),z.max()],origin='lower',cmap='turbo',vmin=0,vmax=1)
    ax.contour(X,Z,data,[.08,.25,.5,.75],colors='white',linewidths=.45,alpha=.7)
    ax.set_title(name); ax.set_xlabel('West–Ost (Blöcke)'); ax.set_ylabel('Süd–Nord (Blöcke)')
fig.suptitle('Atmosphere 0.7.0 – mathematische Niederschlagsfelder (keine Ingame-Bilder)',fontsize=16)
fig.tight_layout(rect=[0,0,1,.96])
fig.savefig('weather-cells-math-preview-0.7.0.png',dpi=150)

xx=np.linspace(-640,640,700)
def noise_line(v): return 5*np.sin(v/71)+2.2*np.sin(v/29+.8)+.8*np.sin(v/11+2.1)
bottom=-25+noise_line(xx)
fig,ax=plt.subplots(figsize=(12,4),facecolor='#b7cbe6')
ax.set_facecolor('#91a8c7')
ax.fill_between(xx,bottom,85,color='#3c424c')
for p in np.linspace(-560,560,34):
    width=10+7*(.5+.5*math.sin(p*.071))
    end=-88-52*(.5+.5*math.sin(p*.043+1.7))
    ax.fill_between([p-width,p+width],[bottom[np.argmin(abs(xx-p))]]*2,[end,end],color='#3e3e3b',alpha=.18)
ax.axvline(0,color='white',alpha=.3,linestyle='--',label='frühere Kachelgrenze – jetzt ohne Naht')
ax.set_xlim(-640,640); ax.set_ylim(-165,95); ax.set_title('Kontinuierliche Wolkenunterseite und strukturierte neutrale Fallstreifen')
ax.set_xlabel('absolute Weltkoordinate (Blöcke)'); ax.set_ylabel('relative Höhe'); ax.legend(loc='lower right')
fig.tight_layout(); fig.savefig('layer-front-math-preview-0.7.0.png',dpi=150)
