import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;

public final class WeatherSimulatorPreview {
    public static void main(String[] args)throws Exception{
        var image=new BufferedImage(1400,900,BufferedImage.TYPE_INT_ARGB);var g=image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(238,242,240));g.fillRect(0,0,1400,900);
        g.setFont(new Font("SansSerif",Font.BOLD,38));g.setColor(new Color(23,35,44));center(g,"Atmosphere 2.0 – mathematisches Wettermodell",700,55);
        panel(g,45,90,630,730,new Color(180,207,216));g.setFont(new Font("SansSerif",Font.BOLD,25));center(g,"Schneefallgrenze und Höhenprofil",360,130);
        g.setStroke(new BasicStroke(3));g.drawLine(120,740,610,740);g.drawLine(120,740,120,175);
        g.setColor(new Color(104,119,91));var mountain=new Path2D.Double();mountain.moveTo(120,740);mountain.curveTo(230,700,280,625,350,575);mountain.curveTo(430,515,470,405,610,330);mountain.lineTo(610,740);mountain.closePath();g.fill(mountain);
        g.setColor(new Color(245,248,250));g.setStroke(new BasicStroke(7,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10,new float[]{14,9},0));g.drawLine(120,500,610,500);
        g.setColor(new Color(170,184,194,150));g.fillRect(120,470,490,60);g.setStroke(new BasicStroke(2));
        g.setColor(new Color(23,35,44));g.setFont(new Font("SansSerif",Font.PLAIN,19));center(g,"Schnee: y > S + B",365,458);center(g,"Schneeregen: S − B ≤ y ≤ S + B",365,507);center(g,"Regen: y < S − B",365,558);
        g.setFont(new Font("SansSerif",Font.PLAIN,16));center(g,"S = Schneefallgrenze, B = Übergangsbreite",360,785);
        panel(g,725,90,630,340,new Color(38,52,61));g.setColor(Color.WHITE);g.setFont(new Font("SansSerif",Font.BOLD,25));center(g,"Freihand-Wetterzonen",1040,130);
        var mask=new Path2D.Double();mask.moveTo(790,270);mask.curveTo(840,180,940,190,980,235);mask.curveTo(1030,182,1160,200,1240,285);mask.curveTo(1200,380,1105,380,1030,348);mask.curveTo(955,395,835,370,790,270);mask.closePath();g.setColor(new Color(94,196,230,185));g.fill(mask);
        var hole=new Polygon(new int[]{976,1046,1077,1045,977,953},new int[]{271,260,302,344,333,298},6);g.setColor(new Color(38,52,61));g.fill(hole);g.setColor(Color.WHITE);g.setStroke(new BasicStroke(4));g.draw(hole);
        g.setColor(new Color(139,101,71));g.fillRect(994,284,48,36);g.setColor(new Color(91,61,46));g.fillPolygon(new int[]{988,1018,1049},new int[]{284,260,284},3);
        g.setColor(Color.WHITE);g.setFont(new Font("SansSerif",Font.PLAIN,19));center(g,"Schneezone + kleine Zone AUS über dem Haus",1040,407);
        panel(g,725,470,630,350,new Color(248,250,249));g.setColor(new Color(23,35,44));g.setFont(new Font("SansSerif",Font.BOLD,25));center(g,"Minecraft-Entfernungsnebel",1040,510);
        g.setStroke(new BasicStroke(3));g.drawLine(790,750,1300,750);g.drawLine(790,750,790,555);
        var fog=new Path2D.Double();fog.moveTo(790,750);fog.lineTo(900,750);fog.curveTo(995,750,1005,735,1070,650);fog.curveTo(1130,575,1190,555,1300,555);fog.lineTo(1300,750);fog.closePath();g.setColor(new Color(205,216,217,190));g.fill(fog);g.setColor(new Color(113,132,139));g.draw(fog);
        g.setFont(new Font("SansSerif",Font.PLAIN,16));g.setColor(new Color(23,35,44));center(g,"Nebelbeginn",990,780);center(g,"Nebelende",1215,780);center(g,"Start, Ende und Stärke steuern Minecrafts Sichtweitennebel.",1040,805);
        g.dispose();ImageIO.write(image,"png",new File(args.length==0?"weather-simulator-math-preview.png":args[0]));
    }
    private static void panel(Graphics2D g,int x,int y,int w,int h,Color color){g.setColor(color);g.fillRoundRect(x,y,w,h,24,24);g.setColor(new Color(83,104,114));g.setStroke(new BasicStroke(3));g.drawRoundRect(x,y,w,h,24,24);}
    private static void center(Graphics2D g,String text,int x,int y){var m=g.getFontMetrics();g.drawString(text,x-m.stringWidth(text)/2,y);}
}
