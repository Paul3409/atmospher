"""World-space cloud motion and lighting preview; explicitly not an in-game image."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(117)
grid=np.arange(-2,3)*512
cells=[]
for x in grid:
    for z in grid:
        if rng.random()<.75:
            cells.append((x+rng.uniform(-82,82),z+rng.uniform(-82,82),rng.uniform(55,100)))

fig,axes=plt.subplots(1,3,figsize=(14,4.5),facecolor='#b9cce8')
for ax,offset,title in zip(axes[:2],[0,180],['Weltzeit t₀','Weltzeit t₁ – Westwind verschiebt nach Osten']):
    ax.set_facecolor('#b9cce8')
    for x,z,s in cells:
        ax.add_patch(plt.Circle((x+offset,z),s,color='#68717d',alpha=.76))
    ax.scatter([0],[0],marker='+',s=80,c='red',label='feste Weltposition')
    ax.set(xlim=(-1200,1200),ylim=(-1200,1200),title=title,xlabel='Welt-X',ylabel='Welt-Z')
    ax.set_aspect('equal');ax.grid(alpha=.18);ax.legend(loc='upper left',fontsize=8)

hours=np.linspace(0,24,500)
solar=(np.cos((hours-6)*2*np.pi/24)+1)/2
brightness=.32+.68*solar
axes[2].plot(hours,brightness,color='#46576d',lw=3)
axes[2].fill_between(hours,0,brightness,color='#879ab5',alpha=.6)
axes[2].set(xlim=(0,24),ylim=(0,1.05),xlabel='Tageszeit (Stunden)',ylabel='Wolkenhelligkeit',
            title='Tag-/Nacht-Abdunklung (32 % bei Mitternacht)')
axes[2].grid(alpha=.2)
fig.suptitle('Atmosphere 0.6.0 – mathematische Vorschau, kein Ingame-Bild')
fig.tight_layout()
fig.savefig(root/'cloud-motion-math-preview-0.6.0.png',dpi=150)
