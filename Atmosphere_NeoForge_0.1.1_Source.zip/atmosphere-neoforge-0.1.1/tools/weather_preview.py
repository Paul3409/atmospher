"""Mathematical concept previews, explicitly not Minecraft screenshots."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
sky='#bbcee9'
fig,axes=plt.subplots(3,1,figsize=(10,8),facecolor=sky)
x=np.linspace(-240,240,1200)
profiles=[
    ('Cirrus',155,5,150,'#ecf0f4'),
    ('Altocumulus',129,10,125,'#b7bdc7'),
    ('Stratus',106,11,240,'#787e88'),
    ('Grosser Cumulonimbus',69,91,165,'#50555d'),
]
for name,base,height,radius,color in profiles:
    # Broad profiles plus non-periodic-looking small-scale distortion; labels are illustrative.
    p=np.clip(1-(x/radius)**2,0,1)
    rough=2.2*np.sin(x*.079+2.1)*np.sin(x*.037+.6)
    if name=='Stratus':
        lo=base+2*np.sin(x*.017)+rough*.4
        hi=lo+11+2*np.sin(x*.013+1)
    else:
        lo=base-3*p+rough*p*.4
        hi=lo+height*p**.75+rough*p
    axes[0].fill_between(x,lo,hi,where=hi>lo,color=color,alpha=.9,label=name)
axes[0].set_xlim(-240,240);axes[0].set_ylim(50,165)
axes[0].set_ylabel('schematische Hoehe');axes[0].legend(loc='upper left',ncol=2,fontsize=8)
axes[0].set_title('Neue Wolkenprofile (vereinfachtes mathematisches Modell)')

xx,yy=np.meshgrid(np.linspace(-210,210,700),np.linspace(60,180,300))
foot=np.clip((1.1-np.abs(xx)/170)*4,0,1)
detail=.82+.08*np.sin(xx*.065)*np.sin(xx*.021+.4)
top=126+4*np.sin(xx*.011)
mask=(yy>=64)&(yy<=top)
density=foot*detail*mask
axes[1].imshow(density,extent=[-210,210,60,180],origin='lower',cmap='Greys',
               vmin=0,vmax=1,alpha=density*.82,aspect='auto')
axes[1].fill_between(np.linspace(-210,210,700),60,64,color='#49632e')
axes[1].fill_between(np.linspace(-210,210,700),top[0],top[0]+27*foot[0],color='#59616b')
axes[1].set_xlim(-210,210);axes[1].set_ylim(60,175)
axes[1].set_title('Geschlossener Niederschlagsvorhang unter der Regenwolke')
axes[1].set_ylabel('Welthoehe')

temp=np.linspace(-12,12,500)
axes[2].axvspan(-12,0,color='#e7f3ff',label='Schnee')
axes[2].axvspan(0,1,color='#aeccdd',label='Schneeregen')
axes[2].axvspan(1,12,color='#668fb6',label='Regen')
axes[2].axvline(0,color='#333');axes[2].axvline(1,color='#333')
axes[2].set_yticks([]);axes[2].set_xlim(-12,12)
axes[2].set_xlabel('lokale Temperatur (°C)');axes[2].legend(loc='upper center',ncol=3)
axes[2].set_title('Niederschlagsart: 0 °C gehoert zu Schneeregen, 1 °C zu Regen')
for ax in axes:ax.set_facecolor(sky)
fig.suptitle('Atmosphere 0.5.0 – mathematische Vorschau, kein Ingame-Bild',fontsize=14)
fig.tight_layout()
fig.savefig(root/'weather-math-preview-0.5.0.png',dpi=150)
