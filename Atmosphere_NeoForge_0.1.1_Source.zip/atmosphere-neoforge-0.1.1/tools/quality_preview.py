"""Shape-control preview for 0.6.0; explicitly not an in-game screenshot."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
x=np.linspace(-180,180,1000)
fig,axes=plt.subplots(2,2,figsize=(11,7),facecolor='#b9cce8')
for ax,detail in zip(axes.flat[:3],[0,.55,1.0]):
    base=np.clip(1-(x/155)**2,0,1)
    rough=detail*(4*np.sin(x*.071)+2*np.sin(x*.157+1.3))*base
    lower=72+rough*.25
    upper=72+80*base**.72+rough
    ax.fill_between(x,lower,upper,color='#626a75')
    ax.set(xlim=(-180,180),ylim=(55,165),title=f'Formdetail {int(detail*100)} %')
    ax.set_facecolor('#b9cce8');ax.set_xticks([]);ax.set_yticks([])

ax=axes.flat[3]
ax.set_facecolor('#b9cce8')
for i in range(7):
    center=(i-3)*9+7*np.sin(x/48+i*.9)+2*np.sin(x/19+i*2.1)
    taper=np.clip(1-(x/(145-i*4))**2,0,1)
    width=(2.4+.8*np.sin(x/54+i*1.7))*taper
    ax.fill_between(x,center-width,center+width,color='#e3e7ed',alpha=.9)
ax.set(xlim=(-180,180),ylim=(-52,52),title='Gekruemmte Cirrus-Faserzuege')
ax.set_xticks([]);ax.set_yticks([])
fig.suptitle('Atmosphere 0.6.0 – Formregler und Cirrus-Modell (kein Ingame-Bild)')
fig.tight_layout()
fig.savefig(root/'cloud-quality-math-preview-0.6.0.png',dpi=150)
