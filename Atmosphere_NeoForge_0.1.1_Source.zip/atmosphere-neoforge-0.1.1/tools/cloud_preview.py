"""Five mathematical cloud cross sections; not Minecraft screenshots."""
import pathlib,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=pathlib.Path(__file__).resolve().parents[1]
source=(root/'src/main/java/dev/atmosphere/companion/CloudRenderer.java').read_text()
table=source.split('private static final double[][] LOBES={',1)[1].split('};',1)[0]
lobes=np.array([[float(v) for v in row.split(',')] for row in re.findall(r'\{([^{}]+)\}',table)])
xs=np.arange(-150,151,3)[None,:]
ys=np.arange(-70,156,3)[:,None]
fig,axes=plt.subplots(5,1,figsize=(12,12),facecolor='#bbcee9')
types=['Cumulus','Stratocumulus','Stratus','Nimbostratus','Cumulonimbus']
for ax,kind in zip(axes,types):
    x=xs;y=ys;z=0
    if kind in ('Stratus','Nimbostratus'):
        broad=6*np.sin(x*.027)+4*np.cos(-x*.015)
        detail=2.4*np.sin(x*.12)*np.cos(-x*.04)+1.2*np.sin(x*.23)
        low=(-14 if kind=='Stratus' else -27)+broad+detail
        high=(4 if kind=='Stratus' else 5)+broad*.45
        field=np.maximum(low-y,y-high)
    else:
        field=np.full(np.broadcast_shapes(x.shape,y.shape),1e5)
        height=1.8 if kind=='Cumulonimbus' else 1.05 if kind=='Cumulus' else .42
        spread=1.22 if kind=='Stratocumulus' else 1
        for l in lobes:
            dx=(x-l[0]*spread)/(l[3]*spread);dy=(y-l[1]*height)/(l[4]*height);dz=(-l[2]*spread)/(l[5]*spread)
            d=(np.sqrt(dx*dx+dy*dy+dz*dz)-1)*min(l[3],l[4],l[5])
            b=np.maximum(0,12-np.abs(field-d))/12
            field=np.minimum(field,d)-b*b*3
        rough=2*np.sin(.11*x)*np.cos(-.08*y)+1.5*np.sin(.21*x-.17*y)
        field+=rough*np.where(y<0,1.5,1)
    ax.set_facecolor('#bbcee9')
    ax.contourf(xs.ravel(),ys.ravel(),field,levels=[-1000,0],colors=['#4d535d'])
    ax.set_xlim(-150,150);ax.set_ylim(-70,155);ax.set_aspect('equal');ax.axis('off')
    ax.set_title(kind,loc='left')
fig.suptitle('Atmosphere 0.2.0: mathematische Wolkenprofile (keine Ingame-Bilder)')
fig.tight_layout()
fig.savefig(root/'cloud-types-math-preview.png',dpi=150,bbox_inches='tight')
