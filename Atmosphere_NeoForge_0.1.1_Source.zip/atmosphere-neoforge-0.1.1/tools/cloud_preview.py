"""Five mathematical cloud cross sections; not Minecraft screenshots."""
import pathlib,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=pathlib.Path(__file__).resolve().parents[1]
source=(root/'src/main/java/dev/atmosphere/companion/CloudRenderer.java').read_text()
table=source.split('private static final double[][] LOBES={',1)[1].split('};',1)[0]
lobes=np.array([[float(v) for v in row.split(',')] for row in re.findall(r'\{([^{}]+)\}',table)])
def hval(x,y,z,seed):
    x=np.asarray(x,dtype=np.int64).astype(np.uint64)
    y=np.asarray(y,dtype=np.int64).astype(np.uint64)
    z=np.asarray(z,dtype=np.int64).astype(np.uint64)
    h=x*np.uint64(374761393)+y*np.uint64(668265263)+z*np.uint64(1442695041)+np.uint64(seed*1274126177)
    h=(h^(h>>np.uint64(13)))*np.uint64(1274126177)
    h=h^(h>>np.uint64(16))
    return (h&np.uint64(65535)).astype(float)/32767.5-1
def smooth(t): return t*t*(3-2*t)
def noise2(x,z,px,pz,seed):
    ix=np.floor(x).astype(int);iz=np.floor(z).astype(int)
    fx=smooth(x-ix);fz=smooth(z-iz)
    x0=ix%px;x1=(x0+1)%px;z0=iz%pz;z1=(z0+1)%pz
    a=hval(x0,0,z0,seed)*(1-fx)+hval(x1,0,z0,seed)*fx
    b=hval(x0,0,z1,seed)*(1-fx)+hval(x1,0,z1,seed)*fx
    return a*(1-fz)+b*fz
def noise_xy(x,y,seed):
    ix=np.floor(x).astype(int);iy=np.floor(y).astype(int)
    fx=smooth(x-ix);fy=smooth(y-iy)
    a=hval(ix,iy,0,seed)*(1-fx)+hval(ix+1,iy,0,seed)*fx
    b=hval(ix,iy+1,0,seed)*(1-fx)+hval(ix+1,iy+1,0,seed)*fx
    return a*(1-fy)+b*fy
xs=np.arange(-150,151,3)[None,:]
ys=np.arange(-70,156,3)[:,None]
fig,axes=plt.subplots(5,1,figsize=(12,12),facecolor='#bbcee9')
types=['Cumulus','Stratocumulus','Stratus','Nimbostratus','Cumulonimbus']
for ax,kind in zip(axes,types):
    x=xs;y=ys;z=0
    if kind in ('Stratus','Nimbostratus'):
        broad=8*noise2(x*5/300,0,5,4,17)+4*noise2(x*11/300,0,11,9,41)
        detail=4*noise2(x*23/300,0,23,21,71)+1.4*noise2(x*43/300,0,43,39,103)
        low=(-14 if kind=='Stratus' else -27)+broad+detail
        high=(4 if kind=='Stratus' else 7)+broad*.35
        field=np.maximum(low-y,y-high)
    else:
        field=np.full(np.broadcast_shapes(x.shape,y.shape),1e5)
        height=1.8 if kind=='Cumulonimbus' else 1.05 if kind=='Cumulus' else .42
        spread=1.22 if kind=='Stratocumulus' else 1
        for l in lobes:
            dx=(x-l[0]*spread)/(l[3]*spread);dy=(y-l[1]*height)/(l[4]*height);dz=(-l[2]*spread)/(l[5]*spread)
            d=(np.sqrt(dx*dx+dy*dy+dz*dz)-1)*min(l[3],l[4],l[5])
            b=np.maximum(0,12-np.abs(field-d))/12
            field=np.minimum(field,d)-b*b*3
        if kind=='Cumulonimbus':
            cap=np.sqrt((x/125)**2+((y-102)/17)**2)-1
            field=np.minimum(field,cap*17)
        rough=5*noise_xy(x/38,y/28,137)+2.8*noise_xy(x/15,y/14,211)+1.3*noise_xy(x/7,y/8,311)
        field+=rough*np.where(y<0,1.5,1)
        if kind in ('Cumulus','Cumulonimbus'):
            field=np.maximum(field,-y-22)
    ax.set_facecolor('#bbcee9')
    ax.contourf(xs.ravel(),ys.ravel(),field,levels=[-1000,0],colors=['#4d535d'])
    ax.set_xlim(-150,150);ax.set_ylim(-70,155);ax.set_aspect('equal');ax.axis('off')
    ax.set_title(kind,loc='left')
fig.suptitle('Atmosphere 0.4.0: mathematische Wolkenprofile (keine Ingame-Bilder)')
fig.tight_layout()
fig.savefig(root/'cloud-types-math-preview-0.4.0.png',dpi=150,bbox_inches='tight')
