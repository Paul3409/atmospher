"""Cross sections of the same implicit surface as CloudRenderer; not an ingame image."""
import pathlib,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=pathlib.Path(__file__).resolve().parents[1]
source=(root/'src/main/java/dev/atmosphere/companion/CloudRenderer.java').read_text()
table=source.split('private static final double[][] LOBES={',1)[1].split('};',1)[0]
lobes=np.array([[float(v) for v in row.split(',')] for row in re.findall(r'\{([^{}]+)\}',table)])
xs=np.arange(-150,151,2);ys=np.arange(-55,91,2);zs=np.arange(-140,141,2)
fig,axes=plt.subplots(1,2,figsize=(12,5),facecolor='#b7c9e2')
for ax,(xx,yy,zz),title in zip(axes,
    ((xs[None,:],ys[:,None],0),(xs[None,:],-10,zs[:,None])),
    ('Querschnitt von der Seite','Querschnitt durch die Unterseite')):
    shape=np.full(np.broadcast_shapes(np.shape(xx),np.shape(yy),np.shape(zz)),1e5)
    for l in lobes:
        d=(np.sqrt(((xx-l[0])/l[3])**2+((yy-l[1])/l[4])**2+((zz-l[2])/l[5])**2)-1)*min(l[3],l[4],l[5])
        h=np.maximum(0,12-np.abs(shape-d))/12
        shape=np.minimum(shape,d)-h*h*3
    rough=2*np.sin(.11*xx+.07*zz)*np.cos(.13*zz-.08*yy)+1.5*np.sin(.21*xx-.17*yy+.16*zz)
    shape=shape+rough*np.where(yy<0,1.5,1)
    ax.set_facecolor('#b7c9e2');ax.contourf(shape,levels=[-1000,0],colors=['#4b525d'])
    ax.contour(shape,levels=[0],colors=['#343a43'],linewidths=1)
    ax.set_title(title);ax.set_aspect('equal');ax.axis('off')
fig.suptitle('Atmosphere 0.1.2 – mathematische Schnittbilder, keine Ingame-Aufnahmen')
fig.savefig(root/'cloud-math-preview.png',dpi=150,bbox_inches='tight')
