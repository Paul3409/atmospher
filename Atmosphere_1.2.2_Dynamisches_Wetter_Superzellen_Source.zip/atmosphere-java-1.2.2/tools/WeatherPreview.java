import dev.atmosphere.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import javax.imageio.ImageIO;

/** Mathematical field preview only, not a screenshot or renderer verification. */
public final class WeatherPreview {
 public static void main(String[] args)throws Exception{
  BufferedImage image=new BufferedImage(660,690,BufferedImage.TYPE_INT_RGB);
  Graphics2D g=image.createGraphics();g.setColor(Color.BLACK);g.fillRect(0,0,660,690);
  int[] colors={0x061017,0x1933b7,0x057ae2,0x00ad61,0x31c444,0x9dd32f,0xefe632,0xffac28,0xf35e21,0xdb1827,0xa31850};
  for(int y=0;y<640;y+=4)for(int x=0;x<640;x+=4){
   double u=(x/640.0*3.2-1.6),v=1.6-y/640.0*3.2;
   double rain=StormEvolution.rainProfile(u*100,v*100,100,42,WeatherCells.SUPERCELL);
   int c=rain<.025?0:Math.min(colors.length-1,1+(int)(rain*11));
   g.setColor(new Color(colors[c]));g.fillRect(10+x,30+y,4,4);
  }
  g.setColor(Color.WHITE);g.drawString("1.2.2: shared rain profile - mathematical preview, NOT in-game",10,18);
  g.dispose();ImageIO.write(image,"png",Path.of(args[0]).toFile());
 }
}
