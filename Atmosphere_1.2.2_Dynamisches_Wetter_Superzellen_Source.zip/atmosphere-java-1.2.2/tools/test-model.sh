#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/model-test build/persistence-test
java com.sun.tools.javac.Main -d build/model-test \
  tools/stubs/dev/atmosphere/{AtmosphereSettings,ManualPressureSystems,StormEvents}.java \
  tools/stubs/net/minecraft/{util/math/BlockPos,world/World}.java \
  src/main/java/dev/atmosphere/{ClimateClock,WeatherRegimes,WeatherCells,StormEvolution,GustFront,ShelfCloudGeometry,TornadoGeometry,WeatherModel,WeatherTuning,SoftCloudMath,SynopticSystems,SupercellGeometry,SettingsStorage}.java \
  src/main/java/dev/atmosphere/siren/{SirenProgram,SirenEngine,SirenGain}.java \
  tools/{WeatherEvolutionSmokeTest,WeatherVarietyTest,TornadoGeometryTest,GustFrontTest,ManualGustFrontTest,WeatherModelRevolutionTest,SupercellGeometryTest,SettingsStorageTest,SirenEngineTest,SirenScheduleTest}.java
for test in WeatherEvolutionSmokeTest WeatherVarietyTest TornadoGeometryTest GustFrontTest ManualGustFrontTest WeatherModelRevolutionTest SupercellGeometryTest SettingsStorageTest SirenEngineTest SirenScheduleTest; do
  java -cp build/model-test "$test"
done
java com.sun.tools.javac.Main -d build/persistence-test \
  $(find tools/persistence-stubs -name '*.java' -print) tools/stubs/dev/atmosphere/AtmosphereSettings.java \
  src/main/java/dev/atmosphere/{ClimateClock,ClimateState,WeatherRegimes,WeatherCells,StormEvents,ManualPressureSystems,StormEvolution,GustFront}.java \
  tools/ClimatePersistenceTest.java
java -cp build/persistence-test ClimatePersistenceTest
