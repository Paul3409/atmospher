import dev.atmosphere.SupercellGeometry;
public final class SupercellGeometryTest {
    public static void main(String[] args) {
        for(double height:new double[]{20,160,355,540})for(int j=0;j<=100;j++) {
            double t=j/100.0;
            var a=SupercellGeometry.point(42,t,0,270,130,height,1,0,.8,.6);
            var b=SupercellGeometry.point(42,t,Math.PI*2,270,130,height,1,0,.8,.6);
            require(Math.hypot(a.x()-b.x(),a.z()-b.z())<1e-8,"Open mesh seam");
            require(Double.isFinite(a.x())&&Double.isFinite(a.y())&&Double.isFinite(a.nz()),"Invalid mesh");
            require(a.y()>=138&&a.y()<=138+height,"Invalid vertical range");
        }
        var top=SupercellGeometry.point(42,1,0,270,130,355,1,0,1,0);
        require(Math.abs(top.x()-(.05*270+355*.32))<1e-8,"Anvil disconnected from tilted updraft");
        var calm=SupercellGeometry.point(42,.7,1,270,130,355,1,0,0,0);
        require(Double.isFinite(calm.x()),"Zero upper wind causes NaN");
        var young=SupercellGeometry.point(42,.90,0,270,130,355,1,0,1,0,.2);
        var mature=SupercellGeometry.point(42,.90,0,270,130,355,1,0,1,0,1);
        require(mature.x()>young.x()+250,"Anvil is fully expanded before the storm matures");
        System.out.println("PASS: connected supercell mesh, seams, height limits and upper-wind tilt");
    }
    private static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
}
