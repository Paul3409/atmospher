package dev.atmosphere;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Small, bounded near-ground particle budget around active hook tornadoes. */
public final class TornadoDust {
    private TornadoDust() {}
    public static void tick(MinecraftClient client,AtmosphereSettings s) {
        if(!s.customClouds||s.tornadoChance==0||client.world==null||client.player==null
                ||client.world.getRegistryKey()!=World.OVERWORLD||client.world.getTime()%2!=0)return;
        long time=client.world.getTimeOfDay();
        double days=time/24000.0*s.weatherSpeed;
        int gx=(int)Math.floor((client.player.getX()-days*80)/690);
        int gz=(int)Math.floor((client.player.getZ()-days*170)/690);
        for(int j=-2;j<=2;j++)for(int i=-2;i<=2;i++) {
            var c=WeatherCells.cell(gx+i,gz+j,days);
            if(c.type()==WeatherCells.SUPERCELL&&c.rotation()>.22)
                emit(client,s,c.x(),c.z(),c.radius(),c.growth(),c.phase(),c.id(),c.windX(),c.windZ());
        }
        for(var e:StormEvents.events())if(e.type()==WeatherCells.SUPERCELL) {
            double phase=.28+Math.min(.999,e.ageDays(time,s)/e.lifeDays())*.72;
            long seed=StormEvolution.manualSeed(e.started(),e.x(),e.z());
            double angle=StormEvolution.manualAngle(seed);
            emit(client,s,e.x(),e.z(),e.radius(),WeatherCells.lifecycle(phase),phase,seed,Math.cos(angle),Math.sin(angle));
        }
    }
    private static void emit(MinecraftClient client,AtmosphereSettings s,double x,double z,double radius,
                             double growth,double phase,long seed,double wx,double wz) {
        if(StormEvolution.tornadoActivity(seed,growth,phase,s.tornadoChance)<.65)return;
        double cx=x+.05*radius*wx+.35*radius*wz;
        double cz=z+.05*radius*wz-.35*radius*wx;
        if(Math.hypot(cx-client.player.getX(),cz-client.player.getZ())>180)return;
        long tick=client.world.getTime();
        for(int i=0;i<6;i++) {
            double angle=WeatherCells.hash(seed,tick*6+i,943)*Math.PI*2;
            double r=radius*(.05+.07*WeatherCells.hash(seed,tick*6+i,947));
            double px=cx+Math.cos(angle)*r,pz=cz+Math.sin(angle)*r;
            BlockPos pos=BlockPos.ofFloored(px,client.player.getY(),pz);
            if(!client.world.isChunkLoaded(pos))continue;
            double y=client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,pos.getX(),pos.getZ())+.25;
            client.world.addParticle(ParticleTypes.POOF,px,y,pz,-Math.sin(angle)*.30,.055,Math.cos(angle)*.30);
        }
    }
}
