package dev.atmosphere;

/** Continuous storm-relative geometry. No world access and no cloud height clamp. */
public final class TornadoGeometry {
    private TornadoGeometry() {}
    public record Point(double x,double y,double z,double nx,double nz) {}
    public static int type(long seed) { return (int)(WeatherCells.hash(seed,0,821)*3); }
    /** t=0 at the wall cloud, t=1 at the descending tip. */
    public static Point point(long seed,double t,double azimuth,double ticks,
                              double top,double bottom,double scale,int type) {
        double spin=ticks*.045;
        double angle=azimuth+spin;
        double profile=switch(type) {
            case 0 -> .10+.90*Math.pow(1-t,2.5); // rope
            case 2 -> .64+.36*(1-t); // wedge
            default -> .16+.84*Math.pow(1-t,.8); // cone
        };
        double ripple=1+.06*Math.sin(azimuth*5+t*10+seed*.001)
                +.025*Math.sin(azimuth*9-t*6);
        double radius=scale*profile*ripple;
        double lean=type==0?scale*.35:scale*.08;
        return new Point(Math.cos(angle)*radius+lean*t*t,
                top+(bottom-top)*t,Math.sin(angle)*radius,
                Math.cos(angle),Math.sin(angle));
    }
}
