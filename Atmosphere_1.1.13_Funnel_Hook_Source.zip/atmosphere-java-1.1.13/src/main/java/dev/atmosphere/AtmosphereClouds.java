package dev.atmosphere;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.Heightmap;
import java.util.ArrayList;
import java.util.List;

/**
 * Real three-dimensional tessellated, textured cloud masses. These are NOT
 * camera-facing sprites: the ellipsoid shells have depth and can be viewed from
 * the side, beneath or above. Lightweight alternative to full GPU raymarching,
 * suitable for integrated graphics. Light/shadow are artistic approximations.
 * Cloud ellipsoids stay above Y=100; independent vortex meshes can reach terrain.
 */
public final class AtmosphereClouds {
    private static final Identifier CLOUD = Identifier.of("atmosphere", "textures/environment/cloud_surface.png");
    private static final Identifier SHADOW = Identifier.of("atmosphere", "textures/environment/cloud_shadow.png");
    /** Black alpha mask: translucent blending then always darkens the ground. */
    private static final RenderLayer SHADOW_LAYER = RenderLayer.getEntityTranslucentCull(SHADOW);
    /** 1.1.7: current sun azimuth for cloud self-shadowing, updated per frame. */
    private static double RENDER_SUN_AZIMUTH = 0;
    private static int adaptiveDrop=0;
    private static long lastAdaptiveTick=Long.MIN_VALUE;
    private AtmosphereClouds() {}
    private static int effectiveDetail(AtmosphereSettings s, MinecraftClient client) {
        int desired=s.cloudDetail<0?s.quality:s.cloudDetail;
        if(!s.adaptiveGraphics){adaptiveDrop=0;return desired;}
        if(client.world!=null && (lastAdaptiveTick==Long.MIN_VALUE
                || client.world.getTime()<lastAdaptiveTick
                || client.world.getTime()-lastAdaptiveTick>=80)) {
            lastAdaptiveTick=client.world.getTime();
            int fps=client.getCurrentFps();
            if(fps>0 && fps<29) adaptiveDrop=Math.min(2,adaptiveDrop+1);
            else if(fps>46) adaptiveDrop=Math.max(0,adaptiveDrop-1);
        }
        return Math.max(0,desired-adaptiveDrop);
    }

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(AtmosphereClouds::render); }

    private static void render(WorldRenderContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        AtmosphereSettings s = AtmosphereSettings.get();
        if (!s.customClouds || client.world == null || client.player == null || ctx.consumers() == null
                || ctx.matrixStack() == null || client.world.getRegistryKey() != World.OVERWORLD) return;
        VertexConsumerProvider consumers = ctx.consumers();
        VertexConsumer v = consumers.getBuffer(RenderLayer.getEntityTranslucent(CLOUD));
        List<double[]> shadows = new ArrayList<>();
        MatrixStack matrix = ctx.matrixStack();
        Vec3d cam = ctx.camera().getPos();
        long time = client.world.getTimeOfDay();
        WeatherModel.Weather local = WeatherModel.sample(cam.x, cam.z, time, s);
        double days = (time / 24000.0) * s.weatherSpeed;
        // The field must move independently of the viewer. Using local wind at
        // camera.x/z here made ALL clouds teleport as the player crossed wind gradients.
        double driftX = CloudField.driftX(days), driftZ = CloudField.driftZ(days);
        int cloudQuality = effectiveDetail(s,client);
        int radius = switch (cloudQuality) { case 0 -> 3; case 2 -> 6; case 3 -> 8; default -> 5; };
        int longitudes = switch (cloudQuality) { case 0 -> 9; case 2 -> 18; case 3 -> 22; default -> 14; };
        int latitudes = switch (cloudQuality) { case 0 -> 6; case 2 -> 11; case 3 -> 14; default -> 9; };
        double spacing = CloudField.SPACING;
        int gx = (int)Math.floor((cam.x - driftX) / spacing);
        int gz = (int)Math.floor((cam.z - driftZ) / spacing);
        double dayCycle = Math.floorMod(time, 24000L) / 24000.0;
        RENDER_SUN_AZIMUTH = dayCycle * Math.PI * 2.0;
        double daylight = Math.max(.20, .55 + .45 * Math.cos(2 * Math.PI * (dayCycle - .25)));
        double sunset = Math.max(Math.exp(-Math.pow(dayCycle / .075, 2)), Math.exp(-Math.pow((dayCycle - .5) / .075, 2)));
        int shadowCount = 0;
        for (int iz = -radius; iz <= radius; iz++) for (int ix = -radius; ix <= radius; ix++) {
            int cx = gx + ix, cz = gz + iz;
            double x = CloudField.centerX(cx, cz, days);
            double z = CloudField.centerZ(cx, cz, days);
            double distance = Math.hypot(x - cam.x, z - cam.z);
            double viewFade = CloudField.viewFade(distance, (radius + .4) * spacing);
            if (viewFade < .008) continue;
            WeatherModel.Weather w = WeatherModel.sample(x, z, time, s);
            double coverage = CloudField.coverage(cx, cz, w.cloudiness());
            // Thin high cloud layer exists independently of the lower cumulus deck.
            // Low mesh counts protect integrated GPUs.
            double cirrusCover = WeatherCells.smooth(-.12,.12,
                    (.24+.54*w.cloudiness()) - rand(cx,cz,309));
            if (cloudQuality >= 1 && rand(cx,cz,307)<.29 && cirrusCover>.01) {
                double[] highWind = StormEvolution.altitudeWind(w.windX(),w.windZ(),420,cx*1039L+cz,days);
                double hx=x + highWind[0]*20*Math.sin(days*.33+cx*.2);
                double hz=z + highWind[1]*20*Math.sin(days*.33+cz*.2);
                double span=72+rand(cx,cz,311)*95;
                double thin=2.2+rand(cx,cz,312)*3.4;
                shell(v,matrix,cam,hx,397+rand(cx,cz,313)*38,hz,span,thin,span*.40,
                        7,3,cx,cz,310,218*daylight+26,226*daylight+24,237*daylight+18,111*viewFade*cirrusCover);
                if(cloudQuality>=2) shell(v,matrix,cam,hx+span*.48,403+rand(cx,cz,314)*32,hz-span*.26,
                        span*.70,thin*.55,span*.25,7,3,cx,cz,315,
                        218*daylight+23,226*daylight+20,236*daylight+15,87*viewFade*cirrusCover);
            }
            // Continuous coverage: individual masses fade over changing weather
            // rather than being created/destroyed abruptly at a boolean threshold.
            if (coverage < .012) continue;
            // Independent lifetime phase: formation, convection, mature, decay.
            double phase = days / (.85 + rand(cx, cz, 81) * 1.45) + rand(cx, cz, 83);
            double development = WeatherCells.lifecycle(phase);
            double phase01=phase-Math.floor(phase);
            if (development < .045 && phase01<.77) continue;
            boolean dissipating=phase01>.68;
            double storm = w.storm();
            double width = (84 + 44 * rand(cx, cz, 31) + storm * 75)
                    * (.50 + development * .70 + (dissipating?.07:0));
            double depth = width * (.84 + rand(cx, cz, 34) * .43);
            double bottom = Math.max(101, w.cloudBase() + (rand(cx, cz, 35) - .5) * 25);
            double height = width * (.38 + .28 * rand(cx, cz, 36)) * (.25 + development * 1.40) * (1 + storm * 1.3);
            double opacity = coverage * viewFade;
            // Distance LOD protects laptops while keeping the nearest 3-D forms detailed.
            int meshLon = distance > spacing*3 ? Math.max(7,longitudes/2) : longitudes;
            int meshLat = distance > spacing*3 ? Math.max(4,latitudes/2) : latitudes;
            // A broad unified lower deck comes first. This closes the holes between
            // individual rising cauliflower turrets and defines the cloud base.
            double deckThickness = 10 + 12 * development + 8 * storm;
            double deckR = width * (.76 + .10*development);
            double deckD = depth * (.78 + .10*development);
            double deckTint = .69 + .29*daylight;
            shell(v,matrix,cam,x,bottom+deckThickness,z,deckR,deckThickness,deckD,
                    meshLon,meshLat,cx,cz,800,
                    191*deckTint-34*storm,199*deckTint-32*storm,214*deckTint-27*storm,
                    224*opacity);
            int basal = cloudQuality == 0 ? 2 : cloudQuality == 3 ? 6 : 4;
            for(int q=0;q<basal;q++) {
                double a=q*2*Math.PI/basal + rand(cx,cz,812)*Math.PI*2;
                double ex=x+Math.cos(a)*deckR*.54;
                double ez=z+Math.sin(a)*deckD*.54;
                double size=.39+.13*rand(cx,cz,820+q);
                shell(v,matrix,cam,ex,bottom+deckThickness*(1.14+.20*rand(cx,cz,826+q)),ez,
                        deckR*size,deckThickness*(.86+.40*development),deckD*size,
                        meshLon,meshLat,cx,cz,830+q,
                        210*deckTint-22*storm,217*deckTint-23*storm,229*deckTint-22*storm,
                        197*opacity);
            }
            int lobes = switch (cloudQuality) { case 0 -> 2; case 2 -> 6; case 3 -> 8; default -> 4; };
            for (int l = 0; l < lobes; l++) {
                double rx = width * (.33 + rand(cx, cz, l+53) * .12);
                double rz = depth * (.35 + rand(cx, cz, l+69) * .13);
                double ry = (height / (1.1 + lobes*.11)) * (.75 + rand(cx, cz, l+74)*.44);
                double localGrowth = StormEvolution.localTower(development,l,lobes,cx*1000003L+cz);
                ry *= (.68+.32*localGrowth);
                double cy = bottom + deckThickness*.90 + ry*.66
                        + (l == 0 ? 0 : height * .76 * rand(cx, cz, l+96)*localGrowth);
                // Bottom of mesh must never be below Y=100.
                cy = Math.max(101 + ry, cy);
                double[] upperWind = StormEvolution.altitudeWind(w.windX(),w.windZ(),cy,cx*1000003L+cz,days);
                double shear=(cy-bottom)*.11;
                double breakup=dissipating?1+Math.max(0,phase01-.68)*2.5:1;
                double ox = (rand(cx, cz, l+102) - .5) * width * .67 * breakup + upperWind[0]*shear;
                double oz = (rand(cx, cz, l+120) - .5) * depth * .61 * breakup + upperWind[1]*shear;
                double r = 169 + 74 * daylight + 23 * sunset - storm * 51;
                double g = 172 + 72 * daylight + 7 * sunset - storm * 48;
                double b = 177 + 70 * daylight - storm * 42;
                if (!s.sunsetLighting) r = g = b = (r + g + b)/3;
                double flash = AtmosphereAudioLightning.flashNear(x, z, time);
                shell(v, matrix, cam, x + ox, cy, z + oz, rx, ry, rz,
                        meshLon, meshLat, cx, cz, l, r + flash * 86, g + flash * 95, b + flash * 105,
                        Math.min(242, (184 + 55 * w.cloudiness())
                            * (dissipating?Math.max(.26,1-(phase01-.68)*1.9):1))*opacity);
                // A handful of overlapping smaller puffs soften the outline without
                // a costly full raymarcher. Fixed cell seeds prevent camera jitter.
                double detailReach = cloudQuality>=3?3.2:2.5;
                double puffFade = 1 - WeatherCells.smooth(spacing*(detailReach-.6),spacing*detailReach,distance);
                if(cloudQuality>=1 && puffFade>.01) {
                    // Fixed local count: unlike a global budget, this cannot
                    // reshuffle cloud details when a camera crosses a grid edge.
                    int puffs=cloudQuality>=3?3:cloudQuality>=2?2:1;
                    for(int f=0;f<puffs;f++) {
                        double pa=f*2.39996+rand(cx,cz,201+l)*6.283;
                        double pr=.52+.22*rand(cx,cz,230+l*13+f);
                        double fx=x+ox+Math.cos(pa)*rx*.72;
                        double fz=z+oz+Math.sin(pa)*rz*.70;
                        double fy=cy+ry*(.33+.43*rand(cx,cz,249+l*13+f));
                        double size=(.21+.12*rand(cx,cz,276+l*13+f))*pr;
                        shell(v,matrix,cam,fx,fy,fz,rx*size,ry*(.24+.09*pr),rz*size,
                                Math.max(8,meshLon-3),Math.max(5,meshLat-2),cx,cz,370+l*9+f,
                                r+flash*48,g+flash*48,b+flash*52,158*opacity*development*puffFade);
                    }
                }
            }
            if (s.cloudShadows && opacity>.15 && daylight > .29 && distance < 410 && shadowCount < 12) {
                shadowCount++;
                double azimuth = dayCycle * Math.PI * 2;
                double offset = Math.min(108, (bottom - 65) * .23);
                shadows.add(new double[]{x - Math.cos(azimuth)*offset, z - Math.sin(azimuth)*offset,
                        width * 1.5, clamp((int)((14 + 62 * w.cloudiness() + 15 * storm)*opacity))});
            }
        }
        // Distinct storm towers share the EXACT cell field used by precipitation and radar.
        // Their upper lobes grow independently, anvils widen late in the lifecycle,
        // and specialised wall/shelf/mammatus structures only occur on strong cells.
        int stormRange = switch(cloudQuality) { case 0 -> 1; case 2 -> 3; case 3 -> 4; default -> 2; };
        double invX = cam.x - days * 80, invZ = cam.z - days * 170;
        int cellX = (int)Math.floor(invX/690.0), cellZ = (int)Math.floor(invZ/690.0);
        List<WeatherCells.Cell> visibleStorms = new ArrayList<>();
        for(int j=-stormRange;j<=stormRange;j++) for(int i=-stormRange;i<=stormRange;i++) {
            WeatherCells.Cell c = WeatherCells.cell(cellX+i,cellZ+j,days);
            if(c.growth() < .035 || Math.hypot(c.x()-cam.x,c.z()-cam.z)>2400) continue;
            WeatherModel.Weather w = WeatherModel.sample(c.x(),c.z(),time,s);
            visibleStorms.add(c);
            renderStormTower(v,matrix,cam,c,w,s,cloudQuality,daylight,sunset,time);
        }
        // Where active anvils touch, render a narrow bridging cloud band. This
        // is optical coalescence, not a destructive/unstable fluid simulation.
        if (cloudQuality>=1) {
            int bridges=0;
            for(int i=0;i<visibleStorms.size() && bridges<12;i++) {
                WeatherCells.Cell a=visibleStorms.get(i);
                if(a.type()<WeatherCells.THUNDER || a.growth()<.50)continue;
                for(int j=i+1;j<visibleStorms.size() && bridges<12;j++) {
                    WeatherCells.Cell b=visibleStorms.get(j);
                    double d=Math.hypot(a.x()-b.x(),a.z()-b.z());
                    if(b.type()<WeatherCells.THUNDER || b.growth()<.50 || d>510 || d<75)continue;
                    double link=Math.min(a.growth(),b.growth());
                    double mx=(a.x()+b.x())*.5,mz=(a.z()+b.z())*.5;
                    double ay=Math.max(110,WeatherModel.sample(mx,mz,time,s).cloudBase());
                    double loft=100+190*link;
                    shell(v,matrix,cam,mx,ay+loft,mz,d*.57,11+12*link,34+22*link,
                            8,4,a.id(),b.id(),801,
                            166*daylight+35,173*daylight+35,190*daylight+37,150*link);
                    bridges++;
                }
            }
        }
        for (StormEvents.Event event : StormEvents.events()) {
            double phase = WeatherCells.lifecycle(.28+event.ageDays(time,s)/event.lifeDays()*.72);
            if(phase>.02 && Math.hypot(event.x()-cam.x,event.z()-cam.z)<2400) {
                WeatherModel.Weather ew = WeatherModel.sample(event.x(),event.z(),time,s);
                long seed=StormEvolution.manualSeed(event.started(),event.x(),event.z());
                double angle=StormEvolution.manualAngle(seed);
                WeatherCells.Cell manual = new WeatherCells.Cell(event.type(),event.x(),event.z(),event.radius(),
                        phase,phase,WeatherCells.smooth(.35,.85,phase),phase*.85,
                        Math.cos(angle),Math.sin(angle),seed,
                        .28+Math.min(.999,event.ageDays(time,s)/event.lifeDays())*.72,0,event.lifeDays());
                renderStormTower(v,matrix,cam,manual,ew,s,cloudQuality,daylight,sunset,time);
            }
        }
        // 0.9.1: cold-front shelf follows the SAME ONE curved polyline as radar.
        // Bounded low-poly spans; rare and heavier near mature powerful fronts.
        if (cloudQuality>=1) {
            int frontalMeshes=0;
            for(SynopticSystems.SystemInfo low:SynopticSystems.systems(cam.x,cam.z,days,1900)) {
                if(!low.low() || low.strength()<.52 || frontalMeshes>=36)continue;
                for(int i=1;i<=30 && frontalMeshes<36;i++) {
                    double t=i/31.0;
                    SynopticSystems.FrontPoint pos=SynopticSystems.frontPoint(low,0,t);
                    double dist=Math.hypot(pos.x()-cam.x,pos.z()-cam.z);
                    if(dist>1450)continue;
                    WeatherModel.Weather fw=WeatherModel.sample(pos.x(),pos.z(),time,s);
                    double active=Math.min(1,fw.front()*2.0);
                    if(active<.09)continue;
                    double base=Math.max(103,fw.cloudBase());
                    // Scalloped base, broad dark leading edge, uneven height.
                    double bow=Math.sin(t*19+low.id()*.001)*15;
                    double shelfWidth=94+82*active;
                    shell(v,matrix,cam,pos.x(),base+17+bow*.20,pos.z(),
                        shelfWidth,16+11*active,83+26*active,9,4,low.id(),i,951,
                        94+63*daylight,105+60*daylight,118+55*daylight,145+85*active);
                    if(cloudQuality>=1) shell(v,matrix,cam,pos.x()-24,base+37+bow*.20,pos.z()+15,
                        shelfWidth*.69,13+12*active,36+28*active,7,3,low.id(),i,952,
                        100+72*daylight,110+68*daylight,123+58*daylight,133+85*active);
                    frontalMeshes++;
                }
            }
        }
        if (!shadows.isEmpty()) {
            VertexConsumer shadowVertices = consumers.getBuffer(SHADOW_LAYER);
            for (double[] sh : shadows) drawShadow(client, shadowVertices, matrix, cam, sh[0], sh[1], sh[2], (int)sh[3]);
        }
    }

    private static void renderStormTower(VertexConsumer v, MatrixStack matrix, Vec3d cam,
                                         WeatherCells.Cell c, WeatherModel.Weather w,
                                         AtmosphereSettings s, int cloudQuality,
                                         double daylight, double sunset, long time) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        double g = c.growth();
        double flash = AtmosphereAudioLightning.flashNear(c.x(), c.z(), time);
        double rx = c.radius() * (.22 + .36*g);
        double rz = rx * (c.type() == WeatherCells.SQUALL ? 1.3 : .83);
        double base = Math.max(104,w.cloudBase());
        double rareGiant=(c.type()>=WeatherCells.SEVERE && WeatherCells.hash(c.id(),44,991)>.965)?1.52:1;
        double height = (c.type() == WeatherCells.SHOWER ? 95 : c.type() == WeatherCells.THUNDER ? 185 :
                c.type() == WeatherCells.SEVERE ? 275 : 355) * WeatherCells.smooth(.04,.9,g)*rareGiant;
        if(height<8) return;
        int rings = switch(cloudQuality) { case 0 -> 8; case 2 -> 16; case 3 -> 20; default -> 12; };
        int stacks = switch(cloudQuality) { case 0 -> 5; case 2 -> 10; case 3 -> 12; default -> 8; };
        int towers = switch(cloudQuality) { case 0 -> 3; case 2 -> 8; case 3 -> 10; default -> 5; };
        if (Math.hypot(c.x()-cam.x,c.z()-cam.z) > 950) {
            rings = Math.max(7,rings/2);
            stacks = Math.max(4,stacks/2);
            towers = Math.max(3,towers/2);
        }
        double dark = c.type() >= WeatherCells.SEVERE ? 38 : c.type()>=WeatherCells.THUNDER ? 22 : 0;
        double brightness = .58+.42*daylight;
        // 1.0: continuous storm cloud base. Rounded overlapping decks make the
        // updraft a unified cumulonimbus instead of isolated floating boulders.
        // The broad, slightly scalloped underside grows before the tall turrets.
        double baseGrowth=WeatherCells.smooth(.06,.43,g);
        if(baseGrowth>.025) {
            double baseRX=rx*(1.10+.26*g), baseRZ=rz*(1.11+.24*g);
            double baseThickness=13+Math.min(21,height*.095);
            shell(v,matrix,cam,c.x(),base+baseThickness,c.z(),
                baseRX,baseThickness,baseRZ,rings+2,stacks,c.id(),181,
                150*brightness-dark*.48+flash*77,
                158*brightness-dark*.47+flash*87,
                174*brightness-dark*.45+flash*91, (193+48*baseGrowth));
            // Interlocking lobes along the base prevent gaps while leaving
            // a distinctly cauliflower-shaped boundary at the sides.
            int basalLobes=cloudQuality>=2?6:4;
            for(int b=0;b<basalLobes;b++) {
                double phi=b*(Math.PI*2/basalLobes)+c.id()*.007;
                double bx=c.x()+Math.cos(phi)*baseRX*.52;
                double bz=c.z()+Math.sin(phi)*baseRZ*.52;
                double r=(.43+.09*WeatherCells.hash(c.id(),b,188));
                shell(v,matrix,cam,bx,base+baseThickness*1.55,bz,
                    baseRX*r,baseThickness*(1.12+.23*g),baseRZ*r,
                    rings,stacks,c.id(),185+b,
                    173*brightness-dark*.42+flash*87,
                    182*brightness-dark*.42+flash*94,
                    198*brightness-dark*.40+flash*103,204*baseGrowth);
            }
        }
        // Shared, tapering updraft spine prevents isolated stacked balls. The
        // lobes below add the irregular cauliflower silhouette over this body.
        if(g>.20 && cloudQuality>=1) {
            int bridges=cloudQuality>=2?5:3;
            for(int q=0;q<bridges;q++) {
                double t=(q+.5)/bridges;
                double growth=WeatherCells.smooth(t*.76,t*.76+.19,g);
                if(growth<.04)continue;
                double yy=base+height*t*.78;
                double dx=Math.sin(q*.81+c.id()*.001)*rx*.10*t;
                double dz=Math.cos(q*.91+c.id()*.001)*rz*.10*t;
                double taper=1-.48*t;
                shell(v,matrix,cam,c.x()+dx,yy,c.z()+dz,
                        rx*.65*taper*growth,height*(.15+.09/bridges),rz*.66*taper*growth,
                        rings,stacks,c.id(),610+q,
                        176*brightness-dark*.74+flash*87,
                        185*brightness-dark*.71+flash*96,
                        201*brightness-dark*.67+flash*102,184+35*g);
            }
        }
        for(int k=0;k<towers;k++) {
            double part = k/(double)Math.max(1,towers-1);
            // Offset high turrets with altitude and wind shear, not a scaled static sprite.
            double progress = WeatherCells.smooth(part*.72,part*.72+.22,g)
                    * StormEvolution.localTower(g,k,towers,c.id());
            if(progress<.025) continue;
            double shift = (part-.3)*c.rotation()*height*.28;
            double[] higherWind=StormEvolution.altitudeWind(c.windX(),c.windZ(),lyBase(base,height,part),c.id(),time/24000.0);
            shift += part*height*.11;
            double lobeX = c.x()+Math.sin(k*2.81+c.id()*.07)*rx*.48 + shift*higherWind[0];
            double lobeZ = c.z()+Math.cos(k*2.27+c.id()*.11)*rz*.48 + shift*higherWind[1];
            double ly = base + height*(.13+.80*part);
            double yr = Math.max(7,height*(.18+.08*WeatherCells.hash(c.id(),k,71))*progress);
            double lx=rx*(.50+.21*WeatherCells.hash(c.id(),k,73))*progress;
            double lz=rz*(.49+.25*WeatherCells.hash(c.id(),k,79))*progress;
            shell(v,matrix,cam,lobeX,Math.max(101+yr,ly),lobeZ,lx,yr,lz,
                    rings,stacks,c.id(),k,200*brightness-dark+15*sunset+flash*100,
                    204*brightness-dark+flash*105,212*brightness-dark+flash*113,201+28*g);
            double towerDistance=Math.hypot(lobeX-cam.x,lobeZ-cam.z);
            double towerDetailFade=1-WeatherCells.smooth(490,640,towerDistance);
            if(cloudQuality>=2 && towerDetailFade>.01) {
                for(int f=0;f<3;f++) {
                    double angle=k*2.1+f*2.4+c.id()*.0007;
                    double size=.23+.08*WeatherCells.hash(c.id(),k*5+f,191);
                    shell(v,matrix,cam,lobeX+Math.cos(angle)*lx*.67,
                            Math.max(106,ly+yr*(.27+.21*f)),lobeZ+Math.sin(angle)*lz*.64,
                            lx*size,yr*(.26+.07*f),lz*size,9,6,c.id(),440+k*3+f,
                            209*brightness-dark*.72+flash*90,
                            212*brightness-dark*.72+flash*94,
                            222*brightness-dark*.72+flash*98,147*g*towerDetailFade);
                }
            }
        }
        if (c.type() >= WeatherCells.THUNDER && c.anvil()>.05) {
            // The wide, flattened anvil unfolds after vertical growth peaks.
            double expand = c.anvil();
            double[] jet=s.manualWind ? new double[]{w.windX()*w.windKmh()*1.6,w.windZ()*w.windKmh()*1.6}
                    : SynopticSystems.upperWind(c.x(),c.z(),time/24000.0*s.weatherSpeed,.9);
            double jetNorm=Math.max(1,Math.hypot(jet[0],jet[1]));
            double ax=c.x()+height*.24*jet[0]/jetNorm;
            double az=c.z()+height*.24*jet[1]/jetNorm;
            double ay = base+height+16;
            double anvilScale=1.0+Math.min(.9,jetNorm/90.0);
            shell(v,matrix,cam,ax,ay,az,rx*(1.1+2.8*expand)*anvilScale,
                    13+24*expand,rz*(1.1+2.4*expand)*anvilScale,rings+2,stacks,c.id(),21,
                    212*brightness-dark*.6+flash*95,217*brightness-dark*.6+flash*100,
                    224*brightness-dark*.6+flash*110,218);
            // Cirrus-like thin feather bands along the upper-air wind. The
            // opacity and thickness decrease outward; no massive triangles.
            if(cloudQuality>=1 && expand>.24) {
                double ux=jet[0]/jetNorm,uz=jet[1]/jetNorm;
                double px=-uz,pz=ux;
                int streaks=cloudQuality>=2?9:5;
                for(int q=0;q<streaks;q++) {
                    double side=(q-(streaks-1)*.5)/(double)Math.max(1,streaks-1);
                    double length=rx*(1.3+2.6*expand)*(1-.28*Math.abs(side))
                            *(.86+.24*WeatherCells.hash(c.id(),q,419));
                    double fx=ax+ux*length*.58+px*side*rz*1.35;
                    double fz=az+uz*length*.58+pz*side*rz*1.35;
                    double fade=1-.45*Math.abs(side);
                    shell(v,matrix,cam,fx,ay+3+q*.45,fz,
                        length*.90,Math.max(1.1,4.1-2.1*Math.abs(side)),
                        rz*(.11+.05*expand),9,4,c.id(),381+q,
                        219*brightness+flash*64,224*brightness+flash*72,
                        234*brightness+flash*78, (48+37*expand)*fade);
                }
            }
            // A brief overshooting dome appears only on vigorous mature cells.
            if(c.type()>=WeatherCells.SEVERE && g>.69 && c.rotation()>.26) {
                double pulse=.72+.28*Math.sin(time*.007+c.id());
                shell(v,matrix,cam,c.x(),ay+19+8*pulse,c.z(),
                    rx*.30,16+12*pulse,rz*.26,rings,stacks,c.id(),398,
                    216*brightness+flash*92,219*brightness+flash*99,
                    226*brightness+flash*106,195);
            }
        }
        if(c.type()==WeatherCells.SUPERCELL && g>.36) {
            // The wall cloud sits over the rear-flank hook instead of orbiting the cell.
            double hookAlong=.05*c.radius(),hookAcross=-.35*c.radius();
            double wx=c.x()+hookAlong*c.windX()-hookAcross*c.windZ();
            double wz=c.z()+hookAlong*c.windZ()+hookAcross*c.windX();
            double wr=rx*.36*g;
            BlockPos groundPos=BlockPos.ofFloored(wx,cam.y,wz);
            boolean groundLoaded=client.world.isChunkLoaded(groundPos);
            double ground=groundLoaded?client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                    groundPos.getX(),groundPos.getZ()):base-80;
            double mesoBottom=Math.max(ground+14,base-24*g);
            double mesoTop=Math.max(mesoBottom+12,base+18);
            drawVortex(v,matrix,cam,wx,wz,mesoTop,mesoBottom,wr,2,c.id(),time,
                    cloudQuality,brightness,220);
            double activity=StormEvolution.tornadoActivity(c.id(),g,c.phase(),s.tornadoChance);
            if(activity>.02 && c.rotation()>.22 && groundLoaded) {
                double bottom=mesoBottom+(ground-.5-mesoBottom)*StormEvolution.smooth(.02,.85,activity);
                drawVortex(v,matrix,cam,wx,wz,mesoBottom+2,bottom,wr*.50,
                        TornadoGeometry.type(c.id()),c.id(),time,cloudQuality,brightness,
                        225*StormEvolution.smooth(0,.20,activity));
                if(activity>.60)drawDust(v,matrix,cam,wx,wz,ground,wr*.70,c.id(),time,
                        cloudQuality,brightness,StormEvolution.smooth(.60,.88,activity));
            }
        }
        if(c.type()==WeatherCells.SUPERCELL && g>.43 && cloudQuality>=1) {
            // Curved inflow bands feed visually into the rotating updraft.
            for(int band=0;band<3;band++) {
                double angle=time*.0017 + c.id()*.004 + band*2*Math.PI/3;
                double radius=rx*(1.28+.23*Math.sin(g*4+band));
                double bx=c.x()+Math.cos(angle)*radius;
                double bz=c.z()+Math.sin(angle)*radius;
                shell(v,matrix,cam,bx,base+16+band*10,bz,
                        rx*.55,11,rx*.17,rings,3,c.id(),320+band,
                        148*brightness+flash*100,161*brightness+flash*100,
                        181*brightness+flash*105,164);
            }
        }
        if(c.type()==WeatherCells.SQUALL && g>.35) {
            // A horizontally elongated, bowed shelf cloud ahead of the frontal line.
            double shelf = rx*1.25*g;
            double ox=c.x()+c.windX()*rx*.9, oz=c.z()+c.windZ()*rz*.9;
            shell(v,matrix,cam,ox,base+9,oz,shelf,14+g*7,shelf*3.0,
                    rings+2,stacks,c.id(),64,138*brightness,147*brightness,163*brightness,204);
        }
        // Visual gust boundary / shelf ahead of powerful cells. No simulated
        // cold-pool physics, forces or world damage are involved.
        if(c.type()>=WeatherCells.SEVERE && g>.42 && cloudQuality>=1) {
            double lead=rx*(.66+.22*Math.sin(g*3));
            double fx=c.x()+c.windX()*lead;
            double fz=c.z()+c.windZ()*lead;
            double side=rx*(c.type()==WeatherCells.SQUALL?1.8:.84);
            shell(v,matrix,cam,fx,base+12,fz,side*.43,10+g*7,side,
                    rings,stacks,c.id(),83,
                    132*brightness+flash*88,145*brightness+flash*93,
                    158*brightness+flash*99,149+45*g);
        }
        // Visual downburst / microburst: lateral outflow cloudlets underneath a
        // severe rain core. There is NO force applied to players or blocks.
        if(c.type()>=WeatherCells.SEVERE && g>.70 && c.rotation()>.48 && cloudQuality>=1) {
            double pulse = .55+.45*Math.sin(time*.026+c.id());
            for(int side=0;side<4;side++) {
                double angle=side*Math.PI*.5+time*.004;
                double ox=c.x()+Math.cos(angle)*rx*.86;
                double oz=c.z()+Math.sin(angle)*rz*.86;
                shell(v,matrix,cam,ox,base+13,oz,16+11*pulse,11,17+10*pulse,
                        7,4,c.id(),79+side,151*brightness,161*brightness,178*brightness,142);
            }
        }
        // Remote shafts follow the storm and humidity field. Dry air produces virga:
        // a shaft hanging below the cloud but stopping noticeably above the ground.
        if(g>.27 && c.type()>=WeatherCells.THUNDER && cloudQuality>=1) {
            double virga = StormEvolution.virga(w.storm(),w.cloudiness(),w.humidity());
            double wet = StormEvolution.rainCurtain(w.storm(),w.cloudiness(),w.humidity());
            double lower = Math.max(100.4,base-(virga>.19?27:100));
            double drop=base-lower;
            int curtains=cloudQuality>=2?3:2;
            for(int j=0;j<curtains && drop>9;j++) {
                double dx=(j-(curtains-1)*.5)*rx*.47;
                double dz=rx*.23*Math.sin(j*2.4+c.id());
                double jitter=.75+.25*WeatherCells.hash(c.id(),j,198);
                shell(v,matrix,cam,c.x()+dx,lower+drop*jitter*.48,c.z()+dz,
                        rx*(.21+.12*g),drop*jitter*.5,rz*.34,7,3,c.id(),95+j,
                        100+flash*90,126+flash*90,151+flash*100,
                        (int)(18+60*Math.max(wet,virga)*g));
                if(wet>.28 && w.rainMmH()>5 && cloudQuality>=1)
                    drawRainVeil(v,matrix,cam,c.x()+dx,c.z()+dz,
                            Math.max(66,base-95),base,rx*(.20+.13*g),
                            (int)(19+48*wet*g));
            }
        }
        // Storm-scale squall line: adjacent independently evolving updraft columns,
        // not a single inflated blob. A mild arc follows the front direction.
        if(c.type()==WeatherCells.SQUALL && g>.17) {
            int columns=cloudQuality==0?2:cloudQuality>=2?5:3;
            for(int i=0;i<columns;i++) {
                double t=(i-(columns-1)/2.0);
                double along=t*rx*.67;
                double bow=rx*.15*Math.cos(t*1.1);
                double x=c.x()-c.windZ()*along+c.windX()*bow;
                double z=c.z()+c.windX()*along+c.windZ()*bow;
                double localG=g*(.68+.32*Math.sin(1.6*i+c.id()*.001+g*4));
                double towerH=height*(.48+.36*localG);
                double yy=Math.max(103+towerH*.44,base+towerH*.56);
                shell(v,matrix,cam,x,yy,z,rx*.34,towerH*.43,rx*.33,
                        rings,stacks,c.id(),125+i,
                        165*brightness+flash*92,174*brightness+flash*95,
                        191*brightness+flash*102,207);
                // Squall line stratification: a mid-level dense band and a
                // thin upper outflow deck; the storm base is rendered above.
                shell(v,matrix,cam,x,base+44+localG*19,z,
                        rx*.46,8+4*localG,rx*.45,rings,stacks,c.id(),145+i,
                        137*brightness+flash*86,151*brightness+flash*94,
                        172*brightness+flash*105,185);
                shell(v,matrix,cam,x,base+96+localG*28,z,
                        rx*.50,6+3*localG,rx*.43,rings,stacks,c.id(),165+i,
                        180*brightness+flash*92,190*brightness+flash*98,
                        209*brightness+flash*110,132);
            }
        }
    }

    private static double lyBase(double base,double height,double part) {
        return base+height*(.13+.80*part);
    }

    /** A continuous rotating tube, independent of the cloud ellipsoid height clamp. */
    private static void drawVortex(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                   double top,double bottom,double scale,int type,long seed,long time,
                                   int quality,double light,double alpha) {
        int sides=quality>=2?32:quality==0?16:24, levels=quality>=2?20:12;
        for(int j=0;j<levels;j++)for(int i=0;i<sides;i++) {
            double t0=j/(double)levels,t1=(j+1.0)/levels;
            double a0=i*Math.PI*2/sides,a1=(i+1.0)*Math.PI*2/sides;
            TornadoGeometry.Point p0=TornadoGeometry.point(seed,t0,a0,time,top,bottom,scale,type);
            TornadoGeometry.Point p1=TornadoGeometry.point(seed,t1,a0,time,top,bottom,scale,type);
            TornadoGeometry.Point p2=TornadoGeometry.point(seed,t1,a1,time,top,bottom,scale,type);
            TornadoGeometry.Point p3=TornadoGeometry.point(seed,t0,a1,time,top,bottom,scale,type);
            vortexQuad(v,m,cam,x,z,p0,p1,p2,p3,(float)i/sides,(float)(i+1)/sides,
                    (float)t0,(float)t1,light,alpha,false);
        }
    }
    private static void drawDust(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                 double ground,double scale,long seed,long time,int quality,double light,double alpha) {
        int sides=quality>=2?32:16;
        for(int j=0;j<3;j++)for(int i=0;i<sides;i++) {
            TornadoGeometry.Point[] p=new TornadoGeometry.Point[4];
            for(int k=0;k<4;k++) {
                double ring=(j+(k==1||k==2?1:0))/3.0;
                double a=(i+(k>=2?1:0))*Math.PI*2/sides+time*.025;
                double radius=scale*(.28+ring)*(1+.07*Math.sin(a*5+seed*.001));
                double y=ground+.15+Math.sin(ring*Math.PI)*7;
                p[k]=new TornadoGeometry.Point(Math.cos(a)*radius,y,Math.sin(a)*radius,Math.cos(a),Math.sin(a));
            }
            vortexQuad(v,m,cam,x,z,p[0],p[1],p[2],p[3],0,1,0,1,light,150*alpha,true);
        }
    }
    private static void vortexQuad(VertexConsumer v,MatrixStack m,Vec3d cam,double x,double z,
                                    TornadoGeometry.Point p0,TornadoGeometry.Point p1,TornadoGeometry.Point p2,TornadoGeometry.Point p3,
                                    float u0,float u1,float t0,float t1,double light,double alpha,boolean dust) {
        TornadoGeometry.Point[] points={p0,p1,p2,p3};
        for(int k=0;k<4;k++) {
            var p=points[k];
            double shade=.70+.25*Math.max(0,p.nx()*Math.cos(RENDER_SUN_AZIMUTH)+p.nz()*Math.sin(RENDER_SUN_AZIMUTH));
            int r=clamp((int)((dust?118:112)*light*shade));
            int g=clamp((int)((dust?108:119)*light*shade));
            int b=clamp((int)((dust?94:128)*light*shade));
            put(v,m,(float)(x+p.x()-cam.x),(float)(p.y()-cam.y),(float)(z+p.z()-cam.z),
                    k<2?u0:u1,k==0||k==3?t0:t1,r,g,b,clamp((int)alpha),(float)p.nx(),0,(float)p.nz());
        }
    }

    // Storm cells have a single stable id plus a lobe index, while the older
    // cloud grid supplies two coordinates plus a lobe index. Accept both forms.
    // This overload fixes the Alpha 0.6 build without changing cloud geometry.
    private static void shell(VertexConsumer v, MatrixStack m, Vec3d cam,
                              double x, double y, double z, double rx, double ry, double rz,
                              int lon, int lat, long cellId, int lobe,
                              double red, double green, double blue, double alpha) {
        shell(v, m, cam, x, y, z, rx, ry, rz,
                lon, lat, cellId, 0L, lobe, red, green, blue, alpha);
    }

    private static void shell(VertexConsumer v, MatrixStack m, Vec3d cam,
                              double x, double y, double z, double rx, double ry, double rz,
                              int lon, int lat, long ix, long iz, int l,
                              double red, double green, double blue, double alpha) {
        double seed = rand(ix, iz, 271 + l) * Math.PI * 2;
        // 1.1.7: shade per quad from the real face normal plus a cheap sun occlusion,
        // instead of per vertex from the smooth sphere normal. That is what removes
        // the hard faceted blocks and gives the cloud an underside.
        double sunAzimuth = RENDER_SUN_AZIMUTH;
        for (int j = 0; j < lat; j++) {
            double a0 = Math.PI * j/lat, a1 = Math.PI * (j+1)/lat;
            for (int i = 0; i < lon; i++) {
                double b0 = Math.PI * 2 * i/lon, b1 = Math.PI * 2 * (i+1)/lon;
                Point p0 = surface(x,y,z,rx,ry,rz,a0,b0,seed);
                Point p1 = surface(x,y,z,rx,ry,rz,a0,b1,seed);
                Point p2 = surface(x,y,z,rx,ry,rz,a1,b1,seed);
                Point p3 = surface(x,y,z,rx,ry,rz,a1,b0,seed);
                quad(v,m,cam,p0,p1,p2,p3,x,y,z,rx,ry,rz,seed,sunAzimuth,
                        red,green,blue,alpha,
                        i/(float)lon, j/(float)lat, (i+1f)/lon, (j+1f)/lat);
            }
        }
    }

    /** One displaced surface point of a cloud shell. */
    private record Point(double x, double y, double z, double nx, double ny, double nz) { }

    /** Displaces the unit sphere point (polar, azimuth) onto the shell surface. */
    private static Point surface(double x,double y,double z,double rx,double ry,double rz,
                                 double polar,double azimuth,double seed) {
        double nx = Math.sin(polar) * Math.cos(azimuth);
        double ny = Math.cos(polar);
        double nz = Math.sin(polar) * Math.sin(azimuth);
        // Seam-continuous, multi-scale cauliflower displacement; stable per cloud id.
        double noise = SoftCloudMath.billow(polar,azimuth,seed);
        return new Point(x + rx * nx * noise,
                Math.max(100.2, y + ry * ny * noise),
                z + rz * nz * noise,
                nx, ny, nz);
    }

    /**
     * 1.1.7 cloud shading.
     * Variant 1: the face normal is derived from the three actual displaced corners,
     *            so every quad is lit from its own orientation instead of the shell
     *            normal - this removes the hard blocky facets of the old build.
     * Variant 2: a Beer-Lambert style self-shadow term walks a few steps towards the
     *            sun through the shell; points whose path stays inside the ellipsoid
     *            are darkened, which gives the underside real volume.
     */
    private static void quad(VertexConsumer v, MatrixStack m, Vec3d cam,
                             Point p0, Point p1, Point p2, Point p3,
                             double x,double y,double z,double rx,double ry,double rz,
                             double seed,double sunAzimuth,
                             double red,double green,double blue,double alpha,
                             float u0,float v0,float u1,float v1) {
        // Face normal from the displaced quad diagonal, oriented outwards.
        double e1x = p2.x - p0.x, e1y = p2.y - p0.y, e1z = p2.z - p0.z;
        double e2x = p3.x - p1.x, e2y = p3.y - p1.y, e2z = p3.z - p1.z;
        double fnx = e1y * e2z - e1z * e2y;
        double fny = e1z * e2x - e1x * e2z;
        double fnz = e1x * e2y - e1y * e2x;
        double flen = Math.sqrt(fnx*fnx + fny*fny + fnz*fnz);
        if (flen < 1e-9) { fnx = p0.nx; fny = p0.ny; fnz = p0.nz; }
        else { fnx /= flen; fny /= flen; fnz /= flen; }
        // Keep the face normal pointing away from the cloud centre.
        double ox = p0.x - x, oy = p0.y - y, oz = p0.z - z;
        if (fnx*ox + fny*oy + fnz*oz < 0) { fnx = -fnx; fny = -fny; fnz = -fnz; }

        // Sun direction: rises in the east, sets in the west, fixed elevation weight.
        double sx = Math.cos(sunAzimuth) * .72, sy = .62, sz = Math.sin(sunAzimuth) * .72;
        double facing = fnx*sx + fny*sy + fnz*sz;
        // Self-shadow: sample the ellipsoid a few steps towards the sun.
        double occlusion = 0;
        for (int k = 1; k <= 3; k++) {
            double t = k / 4.0;
            double qx = (p0.x + sx*t*rx*.55 - x) / (rx*.95);
            double qy = (p0.y + sy*t*ry*.55 - y) / (ry*.95);
            double qz = (p0.z + sz*t*rz*.55 - z) / (rz*.95);
            double r2 = qx*qx + qy*qy + qz*qz;
            if (r2 < 1.0) occlusion += (1.0 - r2) * .33;
        }
        occlusion = Math.min(.85, occlusion);
        // Combine: soft lambert on the face normal, minus the self-shadow.
        double lit = .52 + .46 * Math.max(0, facing) - .38 * occlusion;
        lit = Math.max(.14, Math.min(1.15, lit));
        // Gentle variation so neighbouring quads do not form identical blocks.
        lit *= .965 + .035 * Math.sin(p0.nx*7.3 + p0.nz*5.1 + seed);
        // Fresnel-like translucent silhouette: soft, woolly rather than a hard mesh edge.
        double edge = SoftCloudMath.rim(fnx, fny, fnz, cam.x-p0.x, cam.y-p0.y, cam.z-p0.z);
        int a = clamp((int)(alpha * edge * (.91+.09*Math.max(0, fny))));
        put(v,m,(float)(p0.x-cam.x),(float)(p0.y-cam.y),(float)(p0.z-cam.z),u0,v0,
                clamp((int)(red*lit)),clamp((int)(green*lit)),clamp((int)(blue*lit)),a,
                (float)fnx,(float)fny,(float)fnz);
        put(v,m,(float)(p1.x-cam.x),(float)(p1.y-cam.y),(float)(p1.z-cam.z),u0,v1,
                clamp((int)(red*lit)),clamp((int)(green*lit)),clamp((int)(blue*lit)),a,
                (float)fnx,(float)fny,(float)fnz);
        put(v,m,(float)(p2.x-cam.x),(float)(p2.y-cam.y),(float)(p2.z-cam.z),u1,v1,
                clamp((int)(red*lit)),clamp((int)(green*lit)),clamp((int)(blue*lit)),a,
                (float)fnx,(float)fny,(float)fnz);
        put(v,m,(float)(p3.x-cam.x),(float)(p3.y-cam.y),(float)(p3.z-cam.z),u1,v0,
                clamp((int)(red*lit)),clamp((int)(green*lit)),clamp((int)(blue*lit)),a,
                (float)fnx,(float)fny,(float)fnz);
    }

    private static void drawShadow(MinecraftClient client, VertexConsumer v, MatrixStack m, Vec3d cam,
                                   double centerX, double centerZ, double size, int opacity) {
        // The shadow texture carries its own soft cloud-shaped alpha mask, so one
        // quad per cloud is enough; the old 4x4 grid only re-tiled the same blur.
        int cells = 1;
        for (int iz = 0; iz < cells; iz++) for (int ix = 0; ix < cells; ix++) {
            double x0 = centerX - size*.5 + size*ix/cells;
            double x1 = centerX - size*.5 + size*(ix+1)/cells;
            double z0 = centerZ - size*.5 + size*iz/cells;
            double z1 = centerZ - size*.5 + size*(iz+1)/cells;
            BlockPos at = BlockPos.ofFloored((x0+x1)*.5, cam.y, (z0+z1)*.5);
            if (!client.world.isChunkLoaded(at)) continue;
            int y = client.world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                    (int)((x0+x1)*.5), (int)((z0+z1)*.5));
            if (y <= client.world.getBottomY() || y >= client.world.getTopY() - 1) continue;
            float fy = (float)(y - cam.y + .045);
            float ax = (float)(x0 - cam.x), bx = (float)(x1 - cam.x);
            float az = (float)(z0 - cam.z), bz = (float)(z1 - cam.z);
            float u0 = ix/(float)cells, u1 = (ix+1)/(float)cells;
            float v0 = iz/(float)cells, v1 = (iz+1)/(float)cells;
            // 1.1.5: the old 12/18/28 tint on a white texture washed the grass out.
            // The mask is black now, so a neutral tint always stays a shadow.
            put(v,m,ax,fy,az,u0,v0, 255,255,255,opacity,0,1,0);
            put(v,m,ax,fy,bz,u0,v1, 255,255,255,opacity,0,1,0);
            put(v,m,bx,fy,bz,u1,v1, 255,255,255,opacity,0,1,0);
            put(v,m,bx,fy,az,u1,v0, 255,255,255,opacity,0,1,0);
        }
    }
    /** Translucent rain shaft. Unlike cloud shells, rain may extend below Y=100.
     * Pure client geometry: no world modification or rain entity is involved.
     */
    private static void drawRainVeil(VertexConsumer v,MatrixStack m,Vec3d cam,
                                     double x,double z,double bottom,double top,double radius,int alpha) {
        for(int segment=0;segment<5;segment++) {
            double angle=segment*Math.PI*2/5;
            double ex=Math.cos(angle)*radius,ez=Math.sin(angle)*radius;
            double bx=Math.cos(angle+.7)*radius,bz=Math.sin(angle+.7)*radius;
            put(v,m,(float)(x+ex-cam.x),(float)(top-cam.y),(float)(z+ez-cam.z),
                    0,0,122,153,187,alpha,0,1,0);
            put(v,m,(float)(x+bx-cam.x),(float)(top-cam.y),(float)(z+bz-cam.z),
                    1,0,122,153,187,alpha,0,1,0);
            put(v,m,(float)(x+bx-cam.x),(float)(bottom-cam.y),(float)(z+bz-cam.z),
                    1,1,97,124,159,Math.max(5,alpha/3),0,1,0);
            put(v,m,(float)(x+ex-cam.x),(float)(bottom-cam.y),(float)(z+ez-cam.z),
                    0,1,97,124,159,Math.max(5,alpha/3),0,1,0);
        }
    }

    private static void put(VertexConsumer v, MatrixStack m, float x, float y, float z, float u, float texV,
                            int r, int g, int b, int a, float nx, float ny, float nz) {
        v.vertex(m.peek().getPositionMatrix(), x,y,z).color(r,g,b,a).texture(u,texV)
                .overlay(OverlayTexture.DEFAULT_UV).light(0xF000F0).normal(nx,ny,nz);
    }
    private static int clamp(int n) { return Math.max(0, Math.min(255, n)); }
    private static double rand(long x, long z, long salt) {
        long h = x * 341873128712L ^ z * 132897987541L ^ salt * 2177342783L;
        h ^= h >>> 30; h *= -4658895280553007687L;
        h ^= h >>> 27; h *= -7723592293110705685L;
        h ^= h >>> 31;
        return (h >>> 11) * 0x1.0p-53;
    }
}
