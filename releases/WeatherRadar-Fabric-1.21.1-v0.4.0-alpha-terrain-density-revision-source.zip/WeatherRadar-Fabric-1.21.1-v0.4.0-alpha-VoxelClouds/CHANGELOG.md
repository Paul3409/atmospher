# WeatherRadar – Änderungsprotokoll

## 0.4.0-alpha: Voxel Clouds

- `CloudVoxelModel.java`: Eigenständiges mehrschichtiges 3D-Dichtefeld mit oberflächenbegrenztem Detailnoise, zusammenhängenden Wolkenkörpern und Greedy-Meshing.
- `WeatherCloudClient.java`: Opaque, weiß-graues Wolkenrendering (keine ineinanderliegenden transparenten Würfel), clientseitiges Mesh-Caching, zwei Detailstufen und asynchrone Meshberechnung nach sicherer Weltabtastung.
- Orografische Höhenabtastung: pro horizontaler Voxelspalte eine immutable Terrain-Clearance-Karte plus Windrichtung. Hochgebirge formt/entfernt lokale untere Wolkenvoxel statt den ganzen Körper zu verschieben.
- `RadarMonitorRenderer.java`: Radarfarben werden explizit als RGBA auf die GPU übertragen.
- Keine Änderungen an Radarnetzwerk, Wetterformeln, Welt-Speicherkennung und Block-IDs.
- Keine Mixin-Rückkehr, kein Gradle Wrapper.
- Terrain-Clearance-Fall zum vorhandenen Java-Geometrietest ergänzt. Vollständiger Minecraft-Test steht noch aus.
- `settings.gradle`: explizite Loom-Modulauflösung für Installation ohne Gradle Wrapper.

## 0.3.2-alpha
- Erste Weiß-Grau-Umstellung und einfache Höhenermittlung, optisch noch stark überlappende Quader.

## 0.3.1-alpha
- Absturzverursachenden VanillaCloudMixin entfernt.

## 0.3.0-alpha
- Wassergetriebenes WDWS mit Tw/T850, Lake-Effect, Serverzellen und 3D-Wolken-Prototyp.

## 0.2.0-alpha
- Regionale Testniederschläge und Radarankopplung.

## 0.1.0-alpha
- 2×2-Radar-Monitor, Sensoren und Netzwerk.
