import de.weatheradar.WeatherMath;
public class TestWeatherMath {
    static void check(boolean ok, String what) { if (!ok) throw new AssertionError(what); }
    public static void main(String[] args) {
        check(WeatherMath.activity(50,1)==0, "small pool cannot trigger");
        check(WeatherMath.activity(10,12)==0, "medium lake requires higher DeltaT");
        check(WeatherMath.activity(22,12)>0, "medium lake can activate");
        check(WeatherMath.activity(12,45)>0, "large lake activates easier");
        check(WeatherMath.activity(0,200)==0, "no T contrast, no cells");
        check(WeatherMath.inlandEnergy(1,230) < 0.38, "land weakens rain");
        check(WeatherMath.coastMultiplier(20,0.8,0) > 2, "coast boost active");
        check(WeatherMath.coastMultiplier(5,0.8,0)==1, "no lake effect without DeltaT");
        check(WeatherMath.coastMultiplier(20,0.8,500) < 1.01, "coast boost fades");
        check(WeatherMath.noise(10,20,42)==WeatherMath.noise(10,20,42), "seed stable");
        for(int i=0;i<200;i++) check(Math.abs(WeatherMath.noise(i/11.0,i/8.0,543))<=1,"noise bound");
        System.out.println("WeatherMath: 11 tests passed");
    }
}
