import de.weatheradar.client.CloudVoxelModel;

public final class TestCloudVoxelModel {
    public static void main(String[] args) {
        int cases = 0;
        for (long seed : new long[]{1, 5, 29, 987654321}) {
            for (boolean distant : new boolean[]{false, true}) {
                for (float coverage : new float[]{0.15f, 0.5f, 0.95f}) {
                    CloudVoxelModel.Model model = CloudVoxelModel.generate(seed, 165f, coverage,
                            distant, 0.5f, 0.25f);
                    if (model.filledVoxels() <= 0 || model.exposedFaces() <= 0
                            || model.quads().size() <= 0 || model.quads().size() > model.exposedFaces())
                        throw new AssertionError("empty/invalid model " + seed + "/" + distant + "/" + coverage);
                    CloudVoxelModel.Model copy = CloudVoxelModel.generate(seed, 165f, coverage,
                            distant, 0.5f, 0.25f);
                    if (!model.equals(copy)) throw new AssertionError("nondeterministic output");
                    for (CloudVoxelModel.Quad q : model.quads()) {
                        if (q.x1() < q.x0() || q.y1() < q.y0() || q.z1() < q.z0())
                            throw new AssertionError("bad coordinates");
                        if (q.face() < 0 || q.face() > 5) throw new AssertionError("bad face");
                        int plane = (q.x0() == q.x1() ? 1 : 0)
                                + (q.y0() == q.y1() ? 1 : 0)
                                + (q.z0() == q.z1() ? 1 : 0);
                        if (plane != 1) throw new AssertionError("nonplanar quad");
                    }
                    cases++;
                    System.out.printf("seed=%d distant=%s cov=%.2f voxels=%d faces=%d merged=%d%n",
                            seed, distant, coverage, model.filledVoxels(),
                            model.exposedFaces(), model.quads().size());
                }
            }
        }
        CloudVoxelModel.TerrainProfile ridge = new CloudVoxelModel.TerrainProfile(26, 22, new float[26 * 22]);
        ridge.clearance()[11 * 26 + 13] = 500f;
        CloudVoxelModel.Model blocked = CloudVoxelModel.generate(7, 165f, 0.9f, false, 0.7f, 0f, ridge);
        for (CloudVoxelModel.Quad q : blocked.quads()) {
            if (q.x0() <= 0 && q.x1() >= 0 && q.z0() <= 0 && q.z1() >= 0 && q.y0() < 500f)
                throw new AssertionError("terrain clearance was not applied");
        }
        System.out.println("PASS: " + cases + " deterministic cloud volume/mesh test cases");
    }
}
