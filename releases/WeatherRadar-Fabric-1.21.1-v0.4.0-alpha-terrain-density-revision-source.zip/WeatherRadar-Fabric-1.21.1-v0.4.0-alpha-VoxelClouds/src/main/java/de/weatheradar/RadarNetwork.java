package de.weatheradar;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

import java.util.HashSet;
import java.util.Set;

/** Persisted per dimension; no forced chunk loading. */
public final class RadarNetwork extends PersistentState {
    private static final Type<RadarNetwork> TYPE = new Type<>(RadarNetwork::new, RadarNetwork::fromNbt, null);
    private final Set<BlockPos> stations = new HashSet<>();

    private static RadarNetwork fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        RadarNetwork state = new RadarNetwork();
        for (long packed : nbt.getLongArray("stations")) {
            state.stations.add(BlockPos.fromLong(packed));
        }
        return state;
    }

    public static RadarNetwork get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE, "weatheradar_stations");
    }

    public void add(BlockPos pos) {
        if (stations.add(pos.toImmutable())) {
            markDirty();
        }
    }

    public void remove(BlockPos pos) {
        if (stations.remove(pos)) {
            markDirty();
        }
    }

    public Set<BlockPos> nearby(BlockPos monitor, double maxDistance) {
        double maxSq = maxDistance * maxDistance;
        Set<BlockPos> found = new HashSet<>();
        for (BlockPos station : stations) {
            if (station.getSquaredDistance(monitor) <= maxSq) {
                found.add(station);
            }
        }
        return found;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        nbt.putLongArray("stations", stations.stream().mapToLong(BlockPos::asLong).toArray());
        return nbt;
    }
}
