package de.weatheradar;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

import java.util.ArrayList;
import java.util.List;

/** Lightweight cloud positions, every 4 seconds; only nearby server-owned cells. */
public record CloudStatePayload(List<CloudStatePayload.Cloud> clouds) implements CustomPayload {
    public record Cloud(long id, double x, double z, float radius, float coverage, float windX, float windZ) {}
    public static final Id<CloudStatePayload> ID = new Id<>(WeatherRadar.id("cloud_state"));
    public static final PacketCodec<RegistryByteBuf, CloudStatePayload> CODEC = PacketCodec.of(
            (payload, buffer) -> {
                buffer.writeVarInt(payload.clouds.size());
                for (Cloud c : payload.clouds) {
                    buffer.writeLong(c.id);
                    buffer.writeDouble(c.x); buffer.writeDouble(c.z);
                    buffer.writeFloat(c.radius); buffer.writeFloat(c.coverage);
                    buffer.writeFloat(c.windX); buffer.writeFloat(c.windZ);
                }
            },
            buffer -> {
                int count = Math.min(48, buffer.readVarInt());
                List<Cloud> list = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                    list.add(new Cloud(buffer.readLong(), buffer.readDouble(), buffer.readDouble(),
                            buffer.readFloat(), buffer.readFloat(), buffer.readFloat(), buffer.readFloat()));
                }
                return new CloudStatePayload(list);
            });
    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
