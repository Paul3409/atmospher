package de.weatheradar;

/**
 * Intentionally game-designed weather mathematics, NOT thermodynamics.
 * Coordinates are Minecraft X/Z blocks, durations in seconds, velocities in blocks/second.
 * This class has no Minecraft dependencies and can be tested with plain javac.
 */
public final class WeatherMath {
    private WeatherMath() {}

    public static final double CLOUD_THRESHOLD = 6.0;
    public static final double MEDIUM_LAKE_THRESHOLD = 14.0;
    public static final double LAKE_EFFECT_THRESHOLD = 12.0;
    public static final double INLAND_DECAY_BLOCKS = 230.0;

    public static double clamp(double x, double min, double max) {
        return Math.max(min, Math.min(max, x));
    }

    public static double smooth(double edge0, double edge1, double x) {
        double t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
        return t * t * (3 - 2 * t);
    }

    /** Seasonal gameplay cycle of 48 Minecraft days, independent of real time. */
    public static double season(long worldTicks) {
        return Math.sin(2 * Math.PI * worldTicks / (48.0 * 24000.0));
    }

    /** Stable coarse spatial fluctuations. [-1,+1] and smooth across grid boundaries. */
    public static double noise(double x, double z, long seed) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        double fx = smooth(0, 1, x - ix), fz = smooth(0, 1, z - iz);
        double a = hash(ix, iz, seed), b = hash(ix + 1, iz, seed);
        double c = hash(ix, iz + 1, seed), d = hash(ix + 1, iz + 1, seed);
        return ((a * (1 - fx) + b * fx) * (1 - fz)
                + (c * (1 - fx) + d * fx) * fz) * 2 - 1;
    }

    private static double hash(long x, long z, long seed) {
        long n = seed ^ (x * 0x9E3779B97F4A7C15L) ^ (z * 0xC2B2AE3D27D4EB4FL);
        n ^= n >>> 30; n *= 0xBF58476D1CE4E5B9L;
        n ^= n >>> 27; n *= 0x94D049BB133111EBL;
        n ^= n >>> 31;
        return (n >>> 11) * 0x1.0p-53;
    }

    public static double waterTemperature(double biomeBase, double x, double z, long time, long seed) {
        return biomeBase + 3.0 * season(time) + 1.2 * noise(x / 380.0, z / 380.0, seed + 14);
    }

    public static double upperAirTemperature(double x, double z, long time, long seed, double offset) {
        return 5.5 + 5.0 * season(time + 120000)
                + 3.5 * noise(x / 1100.0 + time / 950000.0, z / 1100.0, seed + 52)
                + offset;
    }

    /** Large connected water areas activate at ΔT > 6; medium lakes at ΔT > 14. */
    public static double activity(double deltaT, int connectedWaterTiles) {
        if (connectedWaterTiles < 9) return 0;
        double threshold = connectedWaterTiles < 24 ? MEDIUM_LAKE_THRESHOLD : CLOUD_THRESHOLD;
        double areaFactor = smooth(8, 48, connectedWaterTiles);
        return smooth(threshold, threshold + 12.0, deltaT) * (0.45 + 0.55 * areaFactor);
    }

    public static double windX(long time, double x, double z, long seed) {
        double variation = noise(x / 1400.0 + time / 220000.0, z / 1400.0, seed + 92);
        return 1.15 + 0.35 * variation;
    }

    public static double windZ(long time, double x, double z, long seed) {
        double variation = noise(x / 1400.0, z / 1400.0 + time / 260000.0, seed + 120);
        return 0.22 + 0.50 * variation;
    }

    /** Energy loss after traveling a distance inland: E=E0 * exp(-distance / lambda). */
    public static double inlandEnergy(double energy, double distance) {
        return clamp(energy * Math.exp(-Math.max(0, distance) / INLAND_DECAY_BLOCKS), 0, 1);
    }

    /** Temporary intensity boost for a water-origin cell crossing the coast. */
    public static double coastMultiplier(double deltaT, double energyAtCoast, double distanceInland) {
        if (deltaT < LAKE_EFFECT_THRESHOLD || energyAtCoast < 0.22) return 1.0;
        return 1.0 + 1.6 * energyAtCoast * Math.exp(-Math.max(0, distanceInland) / 85.0);
    }

    /** Organic edge distortion, tied to a cell's seed and evolving slowly over time. */
    public static double outline(double localX, double localZ, long id, double ageSeconds) {
        double t = ageSeconds / 80.0;
        return 0.18 * noise(localX * 2.4 + t, localZ * 2.4, id)
                + 0.06 * noise(localX * 6.4, localZ * 6.4 + t * 0.5, id + 19);
    }
}
