package de.weatheradar;

import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Only inspects chunks ALREADY loaded around players. Never force-loads chunks.
 * Raster cells represent 16x16 blocks. Four sampled surface-water probes per tile.
 * Flood-fill finds connected bodies (4-neighbor adjacency). River strips are excluded
 * unless both their width and total area pass the minimums.
 */
public final class WaterSourceScanner {
    public static final int TILE = 16;
    private static final int RADIUS = 256;
    private static final int SIDE = RADIUS * 2 / TILE + 1;
    private WaterSourceScanner() {}

    public record Source(int x, int z, int tiles, double coverage, int minX, int maxX, int minZ, int maxZ) {}

    public record Scan(List<Source> sources, int anchorX, int anchorZ, boolean[] eligibleTiles) {
        /** Qualified water used for recharging. A 3x3 player pool can't qualify. */
        public boolean eligible(double x, double z) {
            int ix = (int) Math.floor((x - anchorX) / TILE) + SIDE / 2;
            int iz = (int) Math.floor((z - anchorZ) / TILE) + SIDE / 2;
            return ix >= 0 && ix < SIDE && iz >= 0 && iz < SIDE && eligibleTiles[iz * SIDE + ix];
        }
    }

    public static Scan around(ServerWorld world, int playerX, int playerZ) {
        int anchorX = Math.floorDiv(playerX, TILE) * TILE;
        int anchorZ = Math.floorDiv(playerZ, TILE) * TILE;
        boolean[] water = new boolean[SIDE * SIDE];
        for (int z = 0; z < SIDE; z++) {
            for (int x = 0; x < SIDE; x++) {
                int wx = anchorX + (x - SIDE / 2) * TILE;
                int wz = anchorZ + (z - SIDE / 2) * TILE;
                int hits = 0;
                for (int ox : new int[]{4, 12}) {
                    for (int oz : new int[]{4, 12}) {
                        if (isSurfaceWater(world, wx + ox, wz + oz)) hits++;
                    }
                }
                water[z * SIDE + x] = hits >= 3;
            }
        }

        boolean[] seen = new boolean[water.length];
        boolean[] eligible = new boolean[water.length];
        List<Source> sources = new ArrayList<>();
        for (int start = 0; start < water.length; start++) {
            if (!water[start] || seen[start]) continue;
            ArrayDeque<Integer> queue = new ArrayDeque<>();
            ArrayList<Integer> component = new ArrayList<>();
            queue.add(start);
            seen[start] = true;
            int minX = SIDE, maxX = -1, minZ = SIDE, maxZ = -1;
            while (!queue.isEmpty()) {
                int tile = queue.removeFirst();
                component.add(tile);
                int ix = tile % SIDE, iz = tile / SIDE;
                minX = Math.min(minX, ix); maxX = Math.max(maxX, ix);
                minZ = Math.min(minZ, iz); maxZ = Math.max(maxZ, iz);
                if (ix > 0) visit(tile - 1, water, seen, queue);
                if (ix + 1 < SIDE) visit(tile + 1, water, seen, queue);
                if (iz > 0) visit(tile - SIDE, water, seen, queue);
                if (iz + 1 < SIDE) visit(tile + SIDE, water, seen, queue);
            }
            // Medium-sized (>= roughly 48x48 blocks) wide lakes are accepted.
            if (component.size() < 9 || maxX - minX < 2 || maxZ - minZ < 2) continue;
            for (int tile : component) eligible[tile] = true;
            // Pick a REAL water tile nearest the geometric center, never a land hole.
            double cx = (minX + maxX) / 2.0, cz = (minZ + maxZ) / 2.0;
            int chosen = component.get(0);
            double closest = Double.MAX_VALUE;
            for (int tile : component) {
                double dx = tile % SIDE - cx, dz = tile / SIDE - cz;
                double d = dx * dx + dz * dz;
                if (d < closest) { closest = d; chosen = tile; }
            }
            int tileX = anchorX + (chosen % SIDE - SIDE / 2) * TILE;
            int tileZ = anchorZ + (chosen / SIDE - SIDE / 2) * TILE;
            int mx = tileX + 8, mz = tileZ + 8;
            if (!isSurfaceWater(world, mx, mz)) {
                // A mostly-water tile can still have a tiny land island at its center.
                outer: for (int ox : new int[]{4, 12}) {
                    for (int oz : new int[]{4, 12}) {
                        if (isSurfaceWater(world, tileX + ox, tileZ + oz)) {
                            mx = tileX + ox; mz = tileZ + oz;
                            break outer;
                        }
                    }
                }
            }
            double coverage = Math.min(1.0, component.size() / 48.0);
            sources.add(new Source(mx, mz, component.size(), coverage,
                    anchorX + (minX - SIDE / 2) * TILE,
                    anchorX + (maxX - SIDE / 2 + 1) * TILE,
                    anchorZ + (minZ - SIDE / 2) * TILE,
                    anchorZ + (maxZ - SIDE / 2 + 1) * TILE));
        }
        return new Scan(sources, anchorX, anchorZ, eligible);
    }

    private static void visit(int index, boolean[] water, boolean[] seen, ArrayDeque<Integer> queue) {
        if (water[index] && !seen[index]) {
            seen[index] = true;
            queue.addLast(index);
        }
    }

    public static boolean isSurfaceWater(ServerWorld world, int x, int z) {
        BlockPos check = new BlockPos(x, 80, z);
        if (!world.isChunkLoaded(check)) return false;
        int y = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
        if (y < world.getBottomY()) return false;
        return world.getFluidState(new BlockPos(x, y, z)).isIn(FluidTags.WATER);
    }

    public static int surfaceHeight(ServerWorld world, int x, int z) {
        if (!world.isChunkLoaded(new BlockPos(x, 80, z))) return Integer.MIN_VALUE;
        return world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
    }
}
