package de.weatheradar;

import net.minecraft.util.StringIdentifiable;

public enum ScreenPart implements StringIdentifiable {
    BOTTOM_LEFT("bottom_left", 0, 0),
    BOTTOM_RIGHT("bottom_right", 1, 0),
    TOP_LEFT("top_left", 0, 1),
    TOP_RIGHT("top_right", 1, 1);

    private final String name;
    public final int right;
    public final int up;

    ScreenPart(String name, int right, int up) {
        this.name = name;
        this.right = right;
        this.up = up;
    }

    @Override
    public String asString() {
        return name;
    }
}
