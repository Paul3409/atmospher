package de.weatheradar;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

/** Server weather at the player's location; independent of global vanilla rain. */
public record LocalRainPayload(float intensity, boolean snow) implements CustomPayload {
    public static final Id<LocalRainPayload> ID = new Id<>(WeatherRadar.id("local_rain"));
    public static final PacketCodec<RegistryByteBuf, LocalRainPayload> CODEC = PacketCodec.of(
            (payload, buffer) -> {
                buffer.writeFloat(payload.intensity());
                buffer.writeBoolean(payload.snow());
            },
            buffer -> new LocalRainPayload(buffer.readFloat(), buffer.readBoolean()));
    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
