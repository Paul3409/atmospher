package de.weatheradar;

import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public final class RadarMonitorBlock extends Block implements BlockEntityProvider {
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;
    public static final EnumProperty<ScreenPart> PART = EnumProperty.of("part", ScreenPart.class);
    private static boolean dismantling = false;

    public RadarMonitorBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState()
                .with(FACING, Direction.NORTH).with(PART, ScreenPart.BOTTOM_LEFT));
    }

    public static BlockPos masterPos(BlockPos pos, BlockState state) {
        ScreenPart part = state.get(PART);
        Direction right = state.get(FACING).rotateYClockwise();
        return pos.offset(right.getOpposite(), part.right).down(part.up);
    }

    private static BlockPos piecePos(BlockPos master, Direction facing, ScreenPart part) {
        return master.offset(facing.rotateYClockwise(), part.right).up(part.up);
    }

    @Nullable
    @Override
    public BlockState getPlacementState(ItemPlacementContext context) {
        BlockPos base = context.getBlockPos();
        Direction facing = context.getHorizontalPlayerFacing().getOpposite();
        for (ScreenPart part : ScreenPart.values()) {
            BlockPos target = piecePos(base, facing, part);
            if (!context.getWorld().getBlockState(target).isReplaceable()) {
                return null;
            }
        }
        return getDefaultState().with(FACING, facing).with(PART, ScreenPart.BOTTOM_LEFT);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state,
                         @Nullable LivingEntity placer, ItemStack stack) {
        super.onPlaced(world, pos, state, placer, stack);
        if (world.isClient) return;
        Direction facing = state.get(FACING);
        for (ScreenPart part : ScreenPart.values()) {
            if (part == ScreenPart.BOTTOM_LEFT) continue;
            world.setBlockState(piecePos(pos, facing, part), state.with(PART, part), Block.NOTIFY_ALL);
        }
    }

    @Override
    public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        // The monitor has intentionally no loot table, so exactly one item drops whichever part was mined.
        if (!world.isClient && !player.isCreative()) {
            dropStack(world, pos, new ItemStack(WeatherRadar.RADAR_MONITOR));
        }
        return super.onBreak(world, pos, state, player);
    }

    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos,
                                   BlockState newState, boolean moved) {
        if (!state.isOf(newState.getBlock()) && !world.isClient && !dismantling) {
            dismantling = true;
            try {
                BlockPos base = masterPos(pos, state);
                Direction facing = state.get(FACING);
                for (ScreenPart part : ScreenPart.values()) {
                    BlockPos target = piecePos(base, facing, part);
                    if (target.equals(pos)) continue;
                    BlockState other = world.getBlockState(target);
                    if (other.isOf(this) && other.get(FACING) == facing && other.get(PART) == part) {
                        world.setBlockState(target, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                    }
                }
            } finally {
                dismantling = false;
            }
        }
        super.onStateReplaced(state, world, pos, newState, moved);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos,
                                 PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient) {
            BlockEntity be = world.getBlockEntity(masterPos(pos, state));
            if (be instanceof RadarMonitorBlockEntity monitor) {
                if (player.isSneaking()) {
                    monitor.toggleRangeCircles();
                    player.sendMessage(Text.translatable("message.weatheradar.ranges",
                            monitor.showRanges() ? "AN" : "AUS"), true);
                } else {
                    monitor.toggleMode();
                    player.sendMessage(Text.translatable("message.weatheradar.mode",
                            monitor.advancedMode() ? "Erweiterte Analyse" : "Niederschlag"), true);
                }
            }
        }
        return ActionResult.SUCCESS;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return state.get(PART) == ScreenPart.BOTTOM_LEFT ? new RadarMonitorBlockEntity(pos, state) : null;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state,
                                                                   BlockEntityType<T> type) {
        if (world.isClient || type != WeatherRadar.MONITOR_ENTITY) return null;
        return (w, p, s, entity) -> {
            if (entity instanceof RadarMonitorBlockEntity monitor) {
                RadarMonitorBlockEntity.tick(w, p, s, monitor);
            }
        };
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PART);
    }
}
