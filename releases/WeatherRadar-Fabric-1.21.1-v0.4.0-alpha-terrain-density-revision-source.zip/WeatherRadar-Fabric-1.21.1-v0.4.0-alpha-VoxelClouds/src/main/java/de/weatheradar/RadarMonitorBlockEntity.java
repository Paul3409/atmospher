package de.weatheradar;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public final class RadarMonitorBlockEntity extends BlockEntity {
    public static final int GRID = 40;
    public static final int RANGE = 200;
    public static final int LINK_DISTANCE = 1000;
    public static final int INTERVAL_TICKS = 400;

    private boolean advanced = false;
    private boolean showRanges = true;
    private int centerX;
    private int centerZ;
    private int span = RANGE * 2;
    private int[] picture = new int[GRID * GRID];
    private long[] stationPositions = new long[0];
    private long lastScan = -1;

    public RadarMonitorBlockEntity(BlockPos pos, BlockState state) {
        super(WeatherRadar.MONITOR_ENTITY, pos, state);
        centerX = pos.getX();
        centerZ = pos.getZ();
    }

    public boolean advancedMode() { return advanced; }
    public boolean showRanges() { return showRanges; }
    public int[] picture() { return picture; }
    public long[] stations() { return stationPositions; }
    public int mapCenterX() { return centerX; }
    public int mapCenterZ() { return centerZ; }
    public int mapSpan() { return span; }

    public void toggleMode() {
        advanced = !advanced;
        publish();
    }

    public void toggleRangeCircles() {
        showRanges = !showRanges;
        publish();
    }

    private void publish() {
        markDirty();
        if (world instanceof ServerWorld serverWorld) {
            serverWorld.getChunkManager().markForUpdate(pos);
        }
    }

    public static void tick(World world, BlockPos pos, BlockState state, RadarMonitorBlockEntity entity) {
        if (!(world instanceof ServerWorld serverWorld)) return;
        if (entity.lastScan >= 0 && world.getTime() - entity.lastScan < INTERVAL_TICKS) return;
        entity.lastScan = world.getTime();
        entity.scan(serverWorld);
        entity.publish();
    }

    private void scan(ServerWorld world) {
        List<BlockPos> stations = RadarNetwork.get(world).nearby(pos, LINK_DISTANCE).stream()
                .sorted(Comparator.comparingLong(BlockPos::asLong)).toList();
        stationPositions = stations.stream().mapToLong(BlockPos::asLong).toArray();
        Arrays.fill(picture, 0);
        if (stations.isEmpty()) {
            centerX = pos.getX();
            centerZ = pos.getZ();
            span = RANGE * 2;
            return;
        }

        int minX = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (BlockPos station : stations) {
            minX = Math.min(minX, station.getX() - RANGE);
            maxX = Math.max(maxX, station.getX() + RANGE);
            minZ = Math.min(minZ, station.getZ() - RANGE);
            maxZ = Math.max(maxZ, station.getZ() + RANGE);
        }
        centerX = (int) (((long) minX + maxX) / 2);
        centerZ = (int) (((long) minZ + maxZ) / 2);
        span = Math.max(RANGE * 2, Math.max(maxX - minX, maxZ - minZ));
        final double left = centerX - span / 2.0;
        final double top = centerZ - span / 2.0;
        final double cell = span / (double) GRID;
        final double radiusSquared = RANGE * RANGE;
        WeatherSystem weather = WeatherSystem.get(world);
        for (int row = 0; row < GRID; row++) {
            double z = top + (row + 0.5) * cell;
            for (int col = 0; col < GRID; col++) {
                double x = left + (col + 0.5) * cell;
                boolean covered = false;
                for (BlockPos station : stations) {
                    double dx = station.getX() - x;
                    double dz = station.getZ() - z;
                    if (dx * dx + dz * dz <= radiusSquared) {
                        covered = true;
                        break;
                    }
                }
                picture[row * GRID + col] = covered
                        ? 1 + Math.min(5, (int) Math.ceil(weather.precipitation(x, z) * 5)) : 0;
            }
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.writeNbt(nbt, registries);
        nbt.putBoolean("advanced", advanced);
        nbt.putBoolean("showRanges", showRanges);
        nbt.putInt("centerX", centerX);
        nbt.putInt("centerZ", centerZ);
        nbt.putInt("span", span);
        nbt.putIntArray("picture", picture);
        nbt.putLongArray("stations", stationPositions);
        nbt.putLong("lastScan", lastScan);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.readNbt(nbt, registries);
        advanced = nbt.getBoolean("advanced");
        showRanges = !nbt.contains("showRanges") || nbt.getBoolean("showRanges");
        centerX = nbt.getInt("centerX");
        centerZ = nbt.getInt("centerZ");
        span = Math.max(RANGE * 2, nbt.getInt("span"));
        int[] values = nbt.getIntArray("picture");
        picture = values.length == GRID * GRID ? values : new int[GRID * GRID];
        stationPositions = nbt.getLongArray("stations");
        lastScan = nbt.contains("lastScan") ? nbt.getLong("lastScan") : -1;
    }

    @Nullable
    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registries) {
        return createNbt(registries);
    }
}
