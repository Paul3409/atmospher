package de.weatheradar;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * WeatherRadar WDWS: fictional water-driven weather. Birth only over qualified
 * connected water; recharge while over that water; motion by fictional wind;
 * lake-effect on coast crossing; exponential inland exhaustion; terrain boosts.
 * One server simulation step per second. All radar/rain calculations use these cells.
 */
public final class WeatherSystem extends PersistentState {
    private static final Type<WeatherSystem> TYPE = new Type<>(WeatherSystem::new, WeatherSystem::fromNbt, null);
    private static final int STEP_TICKS = 20;
    private static final int SCAN_TICKS = 20 * 20;
    private static final int MAX_CELLS = 36;
    private static final int CLEAR_PAUSE = 20 * 60 * 5;
    private static final double MAX_PLAYER_DISTANCE = 3000.0;
    private static final double NEARBY_SOURCE_DISTANCE = 180.0;

    private final List<Cell> cells = new ArrayList<>();
    private final Map<UUID, CachedScan> scans = new HashMap<>();
    private long lastStep = -1;
    private long nextId = 1;
    private long suppressUntil = 0;
    private double airOffset = 0;

    private record CachedScan(WaterSourceScanner.Scan scan, int x, int z, long createdTick) {}
    public record Climate(double waterTemp, double upperAirTemp, double delta, double activity) {}
    public record CloudSnapshot(long id, double x, double z, double radius, double coverage) {}

    public static WeatherSystem get(ServerWorld world) {
        // v3 key deliberately leaves v2 random-on-land weather behind, preserving blocks/radar.
        return world.getPersistentStateManager().getOrCreate(TYPE, "weatheradar_weather_v3");
    }

    public static void tick(ServerWorld world) {
        if (!world.getRegistryKey().equals(World.OVERWORLD)) return;
        WeatherSystem sys = get(world);
        long now = world.getTime();
        if (sys.lastStep >= 0 && now >= sys.lastStep && now - sys.lastStep < STEP_TICKS) return;
        int dtTicks = sys.lastStep < 0 || now < sys.lastStep
                ? STEP_TICKS : (int) Math.min(200, now - sys.lastStep);
        sys.lastStep = now;
        sys.step(world, dtTicks / 20.0);
    }

    private void step(ServerWorld world, double dtSeconds) {
        long now = world.getTime();
        scans.keySet().removeIf(id -> world.getPlayers().stream().noneMatch(p -> p.getUuid().equals(id)));
        if (now >= suppressUntil) {
            for (ServerPlayerEntity player : world.getPlayers()) {
                CachedScan previous = scans.get(player.getUuid());
                boolean rescan = previous == null || now < previous.createdTick
                        || now - previous.createdTick > SCAN_TICKS
                        || Math.hypot(player.getX() - previous.x, player.getZ() - previous.z) > 96;
                if (rescan) {
                    WaterSourceScanner.Scan scan = WaterSourceScanner.around(world,
                            player.getBlockX(), player.getBlockZ());
                    scans.put(player.getUuid(), new CachedScan(scan, player.getBlockX(), player.getBlockZ(), now));
                    autoSpawn(world, scan);
                }
            }
        }

        Iterator<Cell> it = cells.iterator();
        while (it.hasNext()) {
            Cell cell = it.next();
            cell.age += dtSeconds;
            double wx = WeatherMath.windX(now, cell.x, cell.z, world.getSeed());
            double wz = WeatherMath.windZ(now, cell.x, cell.z, world.getSeed());
            double oldX = cell.x, oldZ = cell.z;
            cell.x += wx * dtSeconds;
            cell.z += wz * dtSeconds;
            double traveled = Math.hypot(cell.x - oldX, cell.z - oldZ);
            boolean onQualifiedWater = qualifiedWater(cell.x, cell.z);
            if (onQualifiedWater) {
                double added = (0.004 + 0.014 * cell.activation) * dtSeconds;
                cell.energy = WeatherMath.clamp(cell.energy + added, 0, 1);
                cell.inlandDistance = 0;
                cell.coastEnergy = 0;
                cell.lastWater = true;
                cell.slopeBoost = 1;
            } else {
                if (cell.lastWater) {
                    cell.coastEnergy = cell.deltaT >= WeatherMath.LAKE_EFFECT_THRESHOLD
                            ? cell.energy : 0;
                    cell.inlandDistance = 0;
                }
                cell.lastWater = false;
                cell.inlandDistance += traveled;
                cell.energy = WeatherMath.inlandEnergy(cell.energy, traveled);
                // Sampling is cheap: 2 topY reads PER CELL per step, not per radar pixel.
                int previousHeight = WaterSourceScanner.surfaceHeight(world, (int) oldX, (int) oldZ);
                int aheadHeight = WaterSourceScanner.surfaceHeight(world,
                        (int) (cell.x + wx * 16), (int) (cell.z + wz * 16));
                if (previousHeight != Integer.MIN_VALUE && aheadHeight != Integer.MIN_VALUE) {
                    int uphill = aheadHeight - previousHeight;
                    if (uphill > 0) cell.slopeBoost = 1 + 0.5 * WeatherMath.clamp(uphill / 36.0, 0, 1);
                    else cell.slopeBoost = 1 - 0.25 * WeatherMath.clamp(-uphill / 36.0, 0, 1);
                } else {
                    cell.slopeBoost = 1;
                }
            }
            // Long-lived cells require water recharge, but never last forever.
            cell.energy = Math.max(0, cell.energy - 0.0004 * dtSeconds);
            if (cell.energy < 0.025 || cell.age > cell.lifetime
                    || tooFarFromPlayers(world, cell.x, cell.z)) it.remove();
        }
        markDirty();
    }

    private boolean qualifiedWater(double x, double z) {
        for (CachedScan cached : scans.values()) {
            if (cached.scan.eligible(x, z)) return true;
        }
        return false;
    }

    private boolean tooFarFromPlayers(ServerWorld world, double x, double z) {
        if (world.getPlayers().isEmpty()) return false;
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (Math.hypot(x - p.getX(), z - p.getZ()) <= MAX_PLAYER_DISTANCE) return false;
        }
        return true;
    }

    private void autoSpawn(ServerWorld world, WaterSourceScanner.Scan scan) {
        if (cells.size() >= MAX_CELLS) return;
        for (WaterSourceScanner.Source source : scan.sources()) {
            if (cells.size() >= MAX_CELLS) break;
            Climate climate = climate(world, source.x(), source.z(), source.tiles());
            if (climate.activity <= 0.02) continue;
            int nearby = 0;
            for (Cell c : cells) {
                if (Math.hypot(c.x - source.x(), c.z - source.z()) < NEARBY_SOURCE_DISTANCE) nearby++;
            }
            if (nearby >= 2) continue;
            if (world.getRandom().nextDouble() > 0.3 + 0.55 * climate.activity) continue;
            addCell(world, source, climate, false);
        }
    }

    private void addCell(ServerWorld world, WaterSourceScanner.Source source, Climate climate, boolean test) {
        Cell c = new Cell();
        c.id = nextId++;
        c.x = source.x();
        c.z = source.z();
        c.radiusX = test ? 170 : (80 + world.getRandom().nextInt(90));
        c.radiusZ = test ? 125 : (60 + world.getRandom().nextInt(110));
        c.activation = Math.max(0.16, climate.activity);
        c.deltaT = climate.delta;
        c.energy = test ? 0.94 : 0.24 + 0.30 * c.activation;
        c.age = test ? 90 : 0;
        c.lifetime = test ? 850 : (650 + world.getRandom().nextInt(800));
        c.lastWater = true;
        c.slopeBoost = 1;
        cells.add(c);
        markDirty();
    }

    /** Biome-based game temperatures in degrees, not physical climate data. */
    public Climate climate(ServerWorld world, int x, int z, int connectedWaterTiles) {
        BlockPos pos = new BlockPos(x, Math.max(world.getBottomY(), 64), z);
        RegistryEntry<Biome> biome = world.getBiome(pos);
        double base;
        if (biome.matchesKey(BiomeKeys.FROZEN_OCEAN) || biome.matchesKey(BiomeKeys.DEEP_FROZEN_OCEAN)) base = 0;
        else if (biome.matchesKey(BiomeKeys.COLD_OCEAN) || biome.matchesKey(BiomeKeys.DEEP_COLD_OCEAN)) base = 6;
        else if (biome.matchesKey(BiomeKeys.WARM_OCEAN)) base = 27;
        else if (biome.matchesKey(BiomeKeys.LUKEWARM_OCEAN) || biome.matchesKey(BiomeKeys.DEEP_LUKEWARM_OCEAN)) base = 21;
        else if (biome.matchesKey(BiomeKeys.OCEAN) || biome.matchesKey(BiomeKeys.DEEP_OCEAN)) base = 14;
        else base = WeatherMath.clamp(6 + biome.value().getTemperature() * 12, 0, 26);
        double tw = WeatherMath.waterTemperature(base, x, z, world.getTime(), world.getSeed());
        double t850 = WeatherMath.upperAirTemperature(x, z, world.getTime(), world.getSeed(), airOffset);
        double delta = tw - t850;
        return new Climate(tw, t850, delta, WeatherMath.activity(delta, connectedWaterTiles));
    }

    /** Common radar & local-rain intensity field from the ACTUAL persisted cells. */
    public float precipitation(double x, double z) {
        double combined = 0;
        for (Cell c : cells) {
            double dx = (x - c.x) / c.radiusX;
            double dz = (z - c.z) / c.radiusZ;
            if (Math.abs(dx) > 1.5 || Math.abs(dz) > 1.5) continue;
            double d = Math.hypot(dx, dz) + WeatherMath.outline(dx, dz, c.id, c.age);
            if (d >= 1.06) continue;
            double shape = 1 - WeatherMath.smooth(0.48, 1.03, d);
            double core = 0.84 + 0.16 * WeatherMath.noise(dx * 5 + c.age / 120, dz * 5, c.id + 37);
            double growth = WeatherMath.smooth(0, 65, c.age);
            double rainThreshold = WeatherMath.smooth(0.18, 0.55, c.energy);
            double shore = c.coastEnergy > 0
                    ? WeatherMath.coastMultiplier(c.deltaT, c.coastEnergy, c.inlandDistance) : 1;
            double value = WeatherMath.clamp(shape * core * c.energy * growth
                    * rainThreshold * shore * c.slopeBoost, 0, 1);
            combined = 1 - (1 - combined) * (1 - value);
        }
        return (float) WeatherMath.clamp(combined, 0, 1);
    }

    /** Cloud coverage may be >0 even before the rain threshold. */
    public float cloudCoverage(double x, double z) {
        double total = 0;
        for (Cell c : cells) {
            double nx = (x - c.x) / (c.radiusX * 1.25);
            double nz = (z - c.z) / (c.radiusZ * 1.25);
            double d = Math.hypot(nx, nz) + WeatherMath.outline(nx, nz, c.id, c.age);
            if (d >= 1.1) continue;
            total = Math.max(total, (1 - WeatherMath.smooth(0.52, 1.1, d))
                    * c.energy * WeatherMath.smooth(0, 35, c.age));
        }
        return (float) WeatherMath.clamp(total, 0, 1);
    }

    public List<CloudSnapshot> visibleClouds(double x, double z, double range) {
        List<CloudSnapshot> result = new ArrayList<>();
        for (Cell c : cells) {
            if (Math.hypot(x - c.x, z - c.z) <= range + Math.max(c.radiusX, c.radiusZ)) {
                result.add(new CloudSnapshot(c.id, c.x, c.z, Math.max(c.radiusX, c.radiusZ),
                        c.energy * WeatherMath.smooth(0, 40, c.age)));
            }
        }
        return result;
    }

    public int cellCount() { return cells.size(); }
    public double airOffset() { return airOffset; }
    public void setAirOffset(double offset) {
        this.airOffset = WeatherMath.clamp(offset, -30, 20);
        markDirty();
    }

    /** Debug-spawn still respects the water-only birth rule AND Delta-T threshold. */
    public String testRain(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        int x = player.getBlockX(), z = player.getBlockZ();
        if (!world.getRegistryKey().equals(World.OVERWORLD)) return "Nur in der Oberwelt verfuegbar.";
        WaterSourceScanner.Scan scan = WaterSourceScanner.around(world, x, z);
        scans.put(player.getUuid(),
                new CachedScan(scan, x, z, world.getTime()));
        WaterSourceScanner.Source best = null;
        Climate bestClimate = null;
        double bestDistance = Double.MAX_VALUE;
        for (WaterSourceScanner.Source source : scan.sources()) {
            Climate climate = climate(world, source.x(), source.z(), source.tiles());
            if (climate.activity <= 0.02) continue;
            double distance = Math.hypot(source.x() - x, source.z() - z);
            if (distance < bestDistance) {
                best = source; bestClimate = climate; bestDistance = distance;
            }
        }
        if (best == null) return "Keine aktive grosse/mittelgrosse Wasserflaeche in geladenen Chunks. "
                + "Suche einen See/Ozean oder nutze /weatheradar coldair (danach erneut rain).";
        if (cells.size() >= MAX_CELLS) cells.remove(0);
        addCell(world, best, bestClimate, true);
        return String.format(java.util.Locale.ROOT,
                "Neue Zelle nur ueber Wasser bei X=%d Z=%d (Wassertiles=%d; DeltaT=%.1f C).",
                best.x(), best.z(), best.tiles(), bestClimate.delta);
    }

    public int clearNearby(ServerWorld world, double x, double z) {
        int old = cells.size();
        cells.removeIf(c -> Math.hypot(x - c.x, z - c.z) < 1200);
        suppressUntil = world.getTime() + CLEAR_PAUSE;
        markDirty();
        return old - cells.size();
    }

    public String nearbyWaterInfo(ServerWorld world, int x, int z) {
        WaterSourceScanner.Scan scan = WaterSourceScanner.around(world, x, z);
        if (scan.sources().isEmpty()) return "Keine ausreichend grosse zusammenhaengende Wasserflaeche in geladenen Chunks gefunden.";
        WaterSourceScanner.Source closest = null;
        double best = Double.MAX_VALUE;
        for (WaterSourceScanner.Source s : scan.sources()) {
            double distance = Math.hypot(s.x() - x, s.z() - z);
            if (distance < best) { best = distance; closest = s; }
        }
        Climate t = climate(world, closest.x(), closest.z(), closest.tiles());
        return String.format(java.util.Locale.ROOT,
                "Wasser X=%d Z=%d | ~%d Bloecke² | Tw=%.1f C | T850=%.1f C | DeltaT=%.1f C | Aktivitaet=%.0f%%",
                closest.x(), closest.z(), closest.tiles() * 256,
                t.waterTemp, t.upperAirTemp, t.delta, t.activity * 100);
    }

    private static WeatherSystem fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        WeatherSystem s = new WeatherSystem();
        s.lastStep = nbt.contains("lastStep") ? nbt.getLong("lastStep") : -1;
        s.nextId = Math.max(1, nbt.getLong("nextId"));
        s.suppressUntil = nbt.getLong("suppressUntil");
        s.airOffset = nbt.getDouble("airOffset");
        NbtList list = nbt.getList("cells", 10);
        for (int i = 0; i < list.size() && i < MAX_CELLS; i++) {
            NbtCompound tag = list.getCompound(i);
            Cell c = new Cell();
            c.id = tag.getLong("id");
            c.x = tag.getDouble("x"); c.z = tag.getDouble("z");
            c.radiusX = tag.getInt("radiusX"); c.radiusZ = tag.getInt("radiusZ");
            c.deltaT = tag.getDouble("deltaT"); c.activation = tag.getDouble("activation");
            c.energy = tag.getDouble("energy"); c.coastEnergy = tag.getDouble("coastEnergy");
            c.inlandDistance = tag.getDouble("inlandDistance"); c.slopeBoost = tag.getDouble("slopeBoost");
            c.age = tag.getDouble("age"); c.lifetime = tag.getDouble("lifetime");
            c.lastWater = tag.getBoolean("lastWater");
            if (c.radiusX > 0 && c.radiusZ > 0 && c.lifetime > 0) {
                s.cells.add(c); s.nextId = Math.max(s.nextId, c.id + 1);
            }
        }
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        nbt.putLong("lastStep", lastStep);
        nbt.putLong("nextId", nextId);
        nbt.putLong("suppressUntil", suppressUntil);
        nbt.putDouble("airOffset", airOffset);
        NbtList list = new NbtList();
        for (Cell c : cells) {
            NbtCompound tag = new NbtCompound();
            tag.putLong("id", c.id);
            tag.putDouble("x", c.x); tag.putDouble("z", c.z);
            tag.putInt("radiusX", c.radiusX); tag.putInt("radiusZ", c.radiusZ);
            tag.putDouble("deltaT", c.deltaT); tag.putDouble("activation", c.activation);
            tag.putDouble("energy", c.energy); tag.putDouble("coastEnergy", c.coastEnergy);
            tag.putDouble("inlandDistance", c.inlandDistance); tag.putDouble("slopeBoost", c.slopeBoost);
            tag.putDouble("age", c.age); tag.putDouble("lifetime", c.lifetime);
            tag.putBoolean("lastWater", c.lastWater);
            list.add(tag);
        }
        nbt.put("cells", list);
        return nbt;
    }

    private static final class Cell {
        long id;
        double x, z;
        int radiusX, radiusZ;
        double energy, activation, deltaT, coastEnergy, inlandDistance, slopeBoost;
        double age, lifetime;
        boolean lastWater;
    }
}
