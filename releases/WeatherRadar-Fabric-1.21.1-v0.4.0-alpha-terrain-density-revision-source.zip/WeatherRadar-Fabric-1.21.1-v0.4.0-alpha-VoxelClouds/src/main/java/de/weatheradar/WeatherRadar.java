package de.weatheradar;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static net.minecraft.server.command.CommandManager.literal;

public class WeatherRadar implements ModInitializer {
    public static final String MOD_ID = "weatheradar";

    public static final Block RADAR_STATION = new RadarStationBlock(AbstractBlock.Settings.create()
            .strength(3.5F).requiresTool());
    public static final Block RADAR_MONITOR = new RadarMonitorBlock(AbstractBlock.Settings.create()
            .strength(3.5F).requiresTool().nonOpaque());
    public static final SimpleParticleType RAIN_DROP = FabricParticleTypes.simple();
    public static BlockEntityType<RadarMonitorBlockEntity> MONITOR_ENTITY;

    public static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    @Override
    public void onInitialize() {
        Registry.register(Registries.BLOCK, id("radar_station"), RADAR_STATION);
        Registry.register(Registries.BLOCK, id("radar_monitor"), RADAR_MONITOR);
        Registry.register(Registries.ITEM, id("radar_station"), new BlockItem(RADAR_STATION, new Item.Settings()));
        Registry.register(Registries.ITEM, id("radar_monitor"), new BlockItem(RADAR_MONITOR, new Item.Settings()));
        Registry.register(Registries.PARTICLE_TYPE, id("rain_drop"), RAIN_DROP);
        MONITOR_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE, id("radar_monitor"),
                BlockEntityType.Builder.create(RadarMonitorBlockEntity::new, RADAR_MONITOR).build(null));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(RADAR_STATION);
            entries.add(RADAR_MONITOR);
        });

        PayloadTypeRegistry.playS2C().register(LocalRainPayload.ID, LocalRainPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CloudStatePayload.ID, CloudStatePayload.CODEC);

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            WeatherSystem.tick(world);
            if (world.getTime() % 20 != 0) return;
            boolean overworld = world.getRegistryKey().equals(World.OVERWORLD);
            WeatherSystem weather = overworld ? WeatherSystem.get(world) : null;
            for (ServerPlayerEntity player : world.getPlayers()) {
                float rain = overworld ? weather.precipitation(player.getX(), player.getZ()) : 0;
                boolean snow = overworld && world.getBiome(player.getBlockPos())
                        .value().getTemperature() < 0.2F;
                ServerPlayNetworking.send(player, new LocalRainPayload(rain, snow));
                if (world.getTime() % 80 == 0) {
                    List<CloudStatePayload.Cloud> clouds = new ArrayList<>();
                    if (overworld) {
                        for (WeatherSystem.CloudSnapshot cloud : weather.visibleClouds(
                                player.getX(), player.getZ(), 510)) {
                            if (clouds.size() >= 36) break;
                            float vx = (float) WeatherMath.windX(world.getTime(), cloud.x(), cloud.z(), world.getSeed());
                            float vz = (float) WeatherMath.windZ(world.getTime(), cloud.x(), cloud.z(), world.getSeed());
                            clouds.add(new CloudStatePayload.Cloud(cloud.id(), cloud.x(), cloud.z(),
                                    (float) cloud.radius(), (float) cloud.coverage(), vx, vz));
                        }
                    }
                    ServerPlayNetworking.send(player, new CloudStatePayload(clouds));
                }
            }
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(literal("weatheradar")
                        .then(literal("status").executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            ServerWorld world = player.getServerWorld();
                            WeatherSystem sys = WeatherSystem.get(world);
                            String msg = String.format(Locale.ROOT,
                                    "WDWS: %d Zellen | Regen %.0f%% | Wolken %.0f%% | Wind O:%.2f S:%.2f Block/s | T850-Offset %.0f C",
                                    sys.cellCount(), sys.precipitation(player.getX(), player.getZ()) * 100,
                                    sys.cloudCoverage(player.getX(), player.getZ()) * 100,
                                    WeatherMath.windX(world.getTime(), player.getX(), player.getZ(), world.getSeed()),
                                    WeatherMath.windZ(world.getTime(), player.getX(), player.getZ(), world.getSeed()),
                                    sys.airOffset());
                            ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(literal("water").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            String msg = WeatherSystem.get(p.getServerWorld()).nearbyWaterInfo(
                                    p.getServerWorld(), p.getBlockX(), p.getBlockZ());
                            ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(literal("rain").requires(source -> source.hasPermissionLevel(2)).executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            String msg = WeatherSystem.get(p.getServerWorld()).testRain(p);
                            ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(literal("coldair").requires(source -> source.hasPermissionLevel(2)).executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            WeatherSystem.get(p.getServerWorld()).setAirOffset(-22);
                            ctx.getSource().sendFeedback(() -> Text.literal("Testklima: T850 um 22 C gesenkt. /weatheradar rain am See/Ozean testen."), false);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(literal("normalair").requires(source -> source.hasPermissionLevel(2)).executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            WeatherSystem.get(p.getServerWorld()).setAirOffset(0);
                            ctx.getSource().sendFeedback(() -> Text.literal("Normales fiktives T850-Feld wieder aktiv."), false);
                            return Command.SINGLE_SUCCESS;
                        }))
                        .then(literal("clear").requires(source -> source.hasPermissionLevel(2)).executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            int removed = WeatherSystem.get(p.getServerWorld()).clearNearby(
                                    p.getServerWorld(), p.getX(), p.getZ());
                            ctx.getSource().sendFeedback(() -> Text.literal("Entfernte Wetterzellen: " + removed
                                    + ". Automatische Neubildung fuer 5 Minuten pausiert."), false);
                            return Command.SINGLE_SUCCESS;
                        }))));
    }
}
