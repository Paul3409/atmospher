package de.weatheradar.client;

import de.weatheradar.RadarMonitorBlock;
import de.weatheradar.RadarMonitorBlockEntity;
import de.weatheradar.WeatherRadar;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.joml.Matrix4f;

/** A true in-world 2x2 pixel display: no GUI and no mouse click required. */
public final class RadarMonitorRenderer implements BlockEntityRenderer<RadarMonitorBlockEntity> {
    private static final int[] PALETTE = {
            0xFF101A20, // outside coverage
            0xFF183D3B, // scanned and clear
            0xFF39B968, // light
            0xFFE2DA4D, // moderate
            0xFFF4A347, // strong
            0xFFDD4E4F, // very strong
            0xFFBB5FB5  // extreme
    };
    private static final int FRAME = 0xFF394643;
    private static final int CYAN = 0xFF74DCCC;
    private static final int LIGHT = 0xFFF1E9B5;
    private static final int EMISSIVE = 0xF000F0;
    private static final float MARGIN = 0.13F;
    private static final float BOARD = 1.74F;
    private static final float PIXEL = BOARD / RadarMonitorBlockEntity.GRID;

    public RadarMonitorRenderer(BlockEntityRendererFactory.Context context) {}

    @Override
    public int getRenderDistance() {
        return 96;
    }

    @Override
    public void render(RadarMonitorBlockEntity monitor, float tickDelta,
                       MatrixStack matrices, VertexConsumerProvider consumers, int light, int overlay) {
        if (monitor.getWorld() == null) return;
        BlockState state = monitor.getCachedState();
        Direction front = state.get(RadarMonitorBlock.FACING);
        Direction right = front.rotateYClockwise();
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        VertexConsumer v = consumers.getBuffer(RenderLayer.getEntityTranslucent(
                WeatherRadar.id("textures/misc/radar_pixel.png")));

        // In local block coordinates: front plane of the master quadrant, two blocks wide/high.
        float x0 = (right.getOffsetX() < 0 ? 1F : 0F)
                + (front.getOffsetX() > 0 ? 1F : 0F) + (front.getOffsetX() < 0 ? 0F : 0F);
        float z0 = (right.getOffsetZ() < 0 ? 1F : 0F)
                + (front.getOffsetZ() > 0 ? 1F : 0F);
        float off = 0.027F;
        x0 += front.getOffsetX() * off;
        z0 += front.getOffsetZ() * off;
        Plane plane = new Plane(matrix, v, x0, z0,
                right.getOffsetX(), right.getOffsetZ(), front.getOffsetX(), front.getOffsetZ());

        // Background and display border sit in front of the block model.
        plane.rect(0.055F, 0.055F, 1.945F, 1.945F, FRAME, 0.000F);
        plane.rect(MARGIN - 0.02F, MARGIN - 0.02F, 2F - MARGIN + 0.02F,
                2F - MARGIN + 0.02F, 0xFF071416, 0.002F);
        int[] samples = monitor.picture();
        for (int row = 0; row < RadarMonitorBlockEntity.GRID; row++) {
            for (int col = 0; col < RadarMonitorBlockEntity.GRID; col++) {
                int value = samples[row * RadarMonitorBlockEntity.GRID + col];
                value = Math.max(0, Math.min(PALETTE.length - 1, value));
                float left = MARGIN + col * PIXEL;
                float bottom = MARGIN + (RadarMonitorBlockEntity.GRID - 1 - row) * PIXEL;
                plane.rect(left, bottom, left + PIXEL + 0.0005F, bottom + PIXEL + 0.0005F,
                        PALETTE[value], 0.006F);
            }
        }

        // Subtle fixed coordinate lines give the map a classic meteorological appearance.
        for (int i = 0; i <= 8; i++) {
            float p = MARGIN + BOARD * i / 8F;
            plane.rect(p - 0.0014F, MARGIN, p + 0.0014F, 2 - MARGIN, 0x55619E94, 0.009F);
            plane.rect(MARGIN, p - 0.0014F, 2 - MARGIN, p + 0.0014F, 0x55619E94, 0.009F);
        }

        // Accurate radius outlines for every connected radar, even when circles overlap.
        int mapSpan = monitor.mapSpan();
        double mapLeft = monitor.mapCenterX() - mapSpan / 2.0;
        double mapTop = monitor.mapCenterZ() - mapSpan / 2.0;
        if (monitor.showRanges()) {
            for (long packed : monitor.stations()) {
                BlockPos station = BlockPos.fromLong(packed);
                double sx = (station.getX() - mapLeft) / mapSpan;
                double sz = (station.getZ() - mapTop) / mapSpan;
                double radius = (double) RadarMonitorBlockEntity.RANGE / mapSpan;
                for (int a = 0; a < 90; a++) {
                    double angle = 2 * Math.PI * a / 90.0;
                    double u = sx + radius * Math.cos(angle);
                    double w = sz + radius * Math.sin(angle);
                    int ix = (int) Math.floor(u * RadarMonitorBlockEntity.GRID);
                    int iz = (int) Math.floor(w * RadarMonitorBlockEntity.GRID);
                    if (ix >= 0 && ix < RadarMonitorBlockEntity.GRID
                            && iz >= 0 && iz < RadarMonitorBlockEntity.GRID) {
                        float px = MARGIN + (ix + 0.5F) * PIXEL;
                        float py = MARGIN + (RadarMonitorBlockEntity.GRID - iz - 0.5F) * PIXEL;
                        plane.rect(px - 0.007F, py - 0.007F, px + 0.007F, py + 0.007F,
                                CYAN, 0.015F);
                    }
                }
            }
        }

        // Sensor location indicators; display includes all stations within link range.
        for (long packed : monitor.stations()) {
            BlockPos station = BlockPos.fromLong(packed);
            float px = MARGIN + (float) ((station.getX() - mapLeft) / mapSpan) * BOARD;
            float py = MARGIN + (1F - (float) ((station.getZ() - mapTop) / mapSpan)) * BOARD;
            plane.rect(px - 0.018F, py - 0.018F, px + 0.018F, py + 0.018F, LIGHT, 0.018F);
            plane.rect(px - 0.009F, py - 0.009F, px + 0.009F, py + 0.009F,
                    0xFF103B39, 0.021F);
        }

        if (monitor.advancedMode()) {
            // Advanced mode: a directional arrow and a highlighted high-reflectivity core.
            plane.rect(1.58F, 1.88F, 1.81F, 1.90F, CYAN, 0.026F);
            plane.rect(1.77F, 1.84F, 1.81F, 1.95F, CYAN, 0.027F);
            for (int row = 1; row < RadarMonitorBlockEntity.GRID - 1; row += 3) {
                for (int col = 1; col < RadarMonitorBlockEntity.GRID - 1; col += 3) {
                    if (samples[row * RadarMonitorBlockEntity.GRID + col] < 5) continue;
                    float px = MARGIN + col * PIXEL;
                    float py = MARGIN + (RadarMonitorBlockEntity.GRID - 1 - row) * PIXEL;
                    plane.rect(px, py, px + 2F * PIXEL, py + 0.005F, LIGHT, 0.019F);
                    plane.rect(px, py, px + 0.005F, py + 2F * PIXEL, LIGHT, 0.019F);
                }
            }
        }

        // Status lamps above map: green = live sensors, amber = expanded analysis.
        plane.rect(0.17F, 1.89F, 0.24F, 1.94F,
                monitor.stations().length > 0 ? 0xFF56E8A4 : 0xFF9B6661, 0.025F);
        plane.rect(0.27F, 1.89F, 0.34F, 1.94F,
                monitor.advancedMode() ? 0xFFFFC05F : 0xFF38605D, 0.025F);
    }

    private static final class Plane {
        private final Matrix4f matrix;
        private final VertexConsumer consumer;
        private final float originX, originZ;
        private final int rightX, rightZ, normalX, normalZ;

        private Plane(Matrix4f matrix, VertexConsumer consumer, float originX, float originZ,
                      int rightX, int rightZ, int normalX, int normalZ) {
            this.matrix = matrix;
            this.consumer = consumer;
            this.originX = originX;
            this.originZ = originZ;
            this.rightX = rightX;
            this.rightZ = rightZ;
            this.normalX = normalX;
            this.normalZ = normalZ;
        }

        private void rect(float u0, float v0, float u1, float v1, int argb, float depth) {
            vertex(u0, v0, argb, depth);
            vertex(u1, v0, argb, depth);
            vertex(u1, v1, argb, depth);
            vertex(u0, v1, argb, depth);
        }

        private void vertex(float u, float height, int argb, float depth) {
            float x = originX + rightX * u + normalX * depth;
            float z = originZ + rightZ * u + normalZ * depth;
            consumer.vertex(matrix, x, height, z)
                    .color((argb >>> 16) & 255, (argb >>> 8) & 255, argb & 255, (argb >>> 24) & 255).texture(0.5F, 0.5F)
                    .overlay(0).light(EMISSIVE).normal(normalX, 0F, normalZ);
        }
    }
}
