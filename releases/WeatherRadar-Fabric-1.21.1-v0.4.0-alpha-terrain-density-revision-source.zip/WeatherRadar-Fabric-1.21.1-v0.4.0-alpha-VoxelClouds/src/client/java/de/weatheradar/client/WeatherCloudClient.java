package de.weatheradar.client;

import de.weatheradar.CloudStatePayload;
import de.weatheradar.WeatherRadar;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * CPU-generated opaque voxel-cloud meshes. This is an original, low-end-GPU
 * oriented technique inspired by the general density-to-voxel-surface idea.
 * Only a modest number of weather cells are shown. Meshes are cached on the client.
 *
 * Weather cell origin/spawning/radar/rain remain owned by the server's WDWS.
 */
public final class WeatherCloudClient {
    private static final double DEFAULT_BASE = 156.0;
    private static final double CLEARANCE = 15.0;
    private static final int MAX_VISIBLE = 12;
    private static final int REBUILD_INTERVAL = 20 * 10;
    private static final Map<Long, CachedCloud> cache = new HashMap<>();
    private static final Set<Long> pending = ConcurrentHashMap.newKeySet();
    private static final ExecutorService MESH_WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "WeatherRadar cloud mesher");
        thread.setDaemon(true);
        return thread;
    });

    private static List<CloudStatePayload.Cloud> clouds = List.of();
    private static long receivedAt;
    private static Object worldAtReceive;

    private record CachedCloud(CloudVoxelModel.Model mesh, float coverage, float radius,
                               boolean distant, double anchorX, double anchorZ,
                               double base, long builtAt) {}

    private WeatherCloudClient() {}

    public static void receive(MinecraftClient client, CloudStatePayload payload) {
        if (worldAtReceive != client.world) {
            cache.clear();
            pending.clear();
        }
        clouds = List.copyOf(payload.clouds());
        receivedAt = client.world == null ? 0 : client.world.getTime();
        worldAtReceive = client.world;
        cache.keySet().removeIf(id -> clouds.stream().noneMatch(c -> c.id() == id));
    }

    public static void render(WorldRenderContext context) {
        if (context.world() == null || context.consumers() == null || context.matrixStack() == null) return;
        if (worldAtReceive != context.world() || clouds.isEmpty()) return;
        Vec3d camera = context.camera().getPos();
        double seconds = Math.min(5.0, Math.max(0.0,
                (context.world().getTime() - receivedAt) / 20.0));
        VertexConsumerProvider consumers = context.consumers();
        // Cutout and opaque white texture: no translucent overlapping cubes or pink alpha artifacts.
        VertexConsumer vertex = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(
                WeatherRadar.id("textures/misc/cloud_white.png")));
        Matrix4f matrix = context.matrixStack().peek().getPositionMatrix();
        long now = context.world().getTime();
        int visible = 0;
        int buildsRemaining = 2; // limit CPU work within one render frame

        // Render the closest weather systems first so distant clouds do not hide nearby ones.
        List<CloudStatePayload.Cloud> nearby = new ArrayList<>(clouds);
        nearby.sort(Comparator.comparingDouble(c -> Math.hypot(c.x() - camera.x, c.z() - camera.z)));
        for (CloudStatePayload.Cloud cloud : nearby) {
            if (visible >= MAX_VISIBLE) break;
            double x = cloud.x() + cloud.windX() * seconds;
            double z = cloud.z() + cloud.windZ() * seconds;
            double dist = Math.hypot(x - camera.x, z - camera.z);
            if (dist > 490.0 || cloud.coverage() < 0.055f) continue;
            visible++;

            boolean distant = dist > 240.0;
            CachedCloud stored = cache.get(cloud.id());
            boolean rebuild = stored == null || stored.distant != distant
                    || Math.abs(stored.coverage - cloud.coverage()) > 0.16f
                    || Math.abs(stored.radius - cloud.radius()) > 15.0f
                    || Math.hypot(x - stored.anchorX, z - stored.anchorZ) > 35.0
                    || now < stored.builtAt || now - stored.builtAt > REBUILD_INTERVAL;
            if (rebuild && buildsRemaining > 0 && pending.add(cloud.id())) {
                // World access stays on the render thread. The immutable profile is
                // then meshed in the worker, so no density/greedy-mesh work blocks frames.
                Terrain t = inspectTerrain(context, x, z, cloud.radius(), cloud.windX(), cloud.windZ(), distant);
                long id = cloud.id();
                float coverage = cloud.coverage();
                float radius = cloud.radius();
                MESH_WORKER.execute(() -> {
                    CloudVoxelModel.Model mesh;
                    try {
                        mesh = CloudVoxelModel.generate(id, radius, coverage,
                                distant, t.stau(), t.lee(), t.profile());
                    } catch (RuntimeException ignored) {
                        MinecraftClient.getInstance().execute(() -> pending.remove(id));
                        return;
                    }
                    MinecraftClient.getInstance().execute(() -> {
                        if (worldAtReceive == context.world()) {
                            cache.put(id, new CachedCloud(mesh, coverage, radius, distant,
                                    x, z, t.base(), now));
                        }
                        pending.remove(id);
                    });
                });
                buildsRemaining--;
            }
            if (stored == null) continue;
            float originX = (float) (x - camera.x);
            float originY = (float) (stored.base - camera.y);
            float originZ = (float) (z - camera.z);
            float storm = MathHelper.clamp(cloud.coverage(), 0.0f, 1.0f);
            for (CloudVoxelModel.Quad face : stored.mesh.quads()) {
                drawFace(vertex, matrix, originX, originY, originZ, face, storm);
            }
        }
    }

    /**
     * The base follows the centre and every voxel column receives its own
     * clearance. Stau enlarges the profile; Lee thins it behind descending terrain.
     */
    private record Terrain(double base, float stau, float lee, CloudVoxelModel.TerrainProfile profile) {}

    private static Terrain inspectTerrain(WorldRenderContext context, double cx, double cz,
                                          float radius, float windX, float windZ, boolean distant) {
        double length = Math.max(0.001, Math.hypot(windX, windZ));
        double dx = windX / length, dz = windZ / length;
        double ahead = height(context, cx + dx * 40, cz + dz * 40);
        double behind = height(context, cx - dx * 40, cz - dz * 40);
        double center = height(context, cx, cz);
        double rise = Math.max(0.0, ahead - behind);
        double descent = Math.max(0.0, behind - ahead);
        double halfX = Math.min(265, Math.max(72, radius * 1.55f)) * 0.55;
        double halfZ = halfX * 0.78;
        // Every horizontal voxel column gets its own terrain clearance. This stops
        // clouds crossing high ridges without lifting an entire cell like a slab.
        int nx = CloudVoxelModel.xResolution(distant), nz = CloudVoxelModel.zResolution(distant);
        float[] clearance = new float[nx * nz];
        double base = Math.max(DEFAULT_BASE, center + CLEARANCE);
        for (int iz = 0; iz < nz; iz++) for (int ix = 0; ix < nx; ix++) {
            double sx = cx + halfX * (2.0 * (ix + 0.5) / nx - 1.0) + dx * 12;
            double sz = cz + halfZ * (2.0 * (iz + 0.5) / nz - 1.0) + dz * 12;
            clearance[iz * nx + ix] = (float) Math.max(0, height(context, sx, sz) + CLEARANCE - base);
        }
        float stau = (float) MathHelper.clamp(rise / 65.0, 0.0, 1.0);
        float lee = (float) MathHelper.clamp(descent / 70.0, 0.0, 1.0);
        return new Terrain(base, stau, lee, new CloudVoxelModel.TerrainProfile(nx, nz, clearance));
    }

    private static int height(WorldRenderContext context, double x, double z) {
        return context.world().getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                MathHelper.floor(x), MathHelper.floor(z));
    }

    private static void drawFace(VertexConsumer v, Matrix4f m, float ox, float oy, float oz,
                                 CloudVoxelModel.Quad q, float storm) {
        float x0 = ox + q.x0(), x1 = ox + q.x1();
        float y0 = oy + q.y0(), y1 = oy + q.y1();
        float z0 = oz + q.z0(), z1 = oz + q.z1();
        int red, green, blue;
        float nx = 0, ny = 0, nz = 0;
        switch (q.face()) {
            case CloudVoxelModel.POS_Y -> { red = 251; green = 251; blue = 250; ny = 1; }
            case CloudVoxelModel.NEG_Y -> {
                red = 185 - (int) (storm * 40); green = 193 - (int) (storm * 43);
                blue = 205 - (int) (storm * 47); ny = -1;
            }
            case CloudVoxelModel.POS_X -> { red = 230; green = 235; blue = 239; nx = 1; }
            case CloudVoxelModel.NEG_X -> { red = 212; green = 218; blue = 226; nx = -1; }
            case CloudVoxelModel.POS_Z -> { red = 224; green = 230; blue = 236; nz = 1; }
            default -> { red = 207; green = 215; blue = 225; nz = -1; }
        }
        // Face vertices are deliberately wound as two triangles-compatible quads,
        // using a no-cull render layer to avoid losing faces at all camera angles.
        switch (q.face()) {
            case CloudVoxelModel.NEG_X, CloudVoxelModel.POS_X -> {
                vertex(v,m,x0,y0,z0,red,green,blue,nx,ny,nz);
                vertex(v,m,x0,y0,z1,red,green,blue,nx,ny,nz);
                vertex(v,m,x0,y1,z1,red,green,blue,nx,ny,nz);
                vertex(v,m,x0,y1,z0,red,green,blue,nx,ny,nz);
            }
            case CloudVoxelModel.NEG_Y, CloudVoxelModel.POS_Y -> {
                vertex(v,m,x0,y0,z0,red,green,blue,nx,ny,nz);
                vertex(v,m,x1,y0,z0,red,green,blue,nx,ny,nz);
                vertex(v,m,x1,y0,z1,red,green,blue,nx,ny,nz);
                vertex(v,m,x0,y0,z1,red,green,blue,nx,ny,nz);
            }
            default -> {
                vertex(v,m,x0,y0,z0,red,green,blue,nx,ny,nz);
                vertex(v,m,x1,y0,z0,red,green,blue,nx,ny,nz);
                vertex(v,m,x1,y1,z0,red,green,blue,nx,ny,nz);
                vertex(v,m,x0,y1,z0,red,green,blue,nx,ny,nz);
            }
        }
    }

    private static void vertex(VertexConsumer v, Matrix4f m, float x, float y, float z,
                               int r, int g, int b, float nx, float ny, float nz) {
        v.vertex(m, x, y, z).color(r, g, b, 255).texture(0.5f, 0.5f)
                .overlay(0).light(0x00F000F0).normal(nx, ny, nz);
    }
}
