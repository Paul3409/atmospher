package de.weatheradar.client;

import de.weatheradar.LocalRainPayload;
import de.weatheradar.CloudStatePayload;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import de.weatheradar.WeatherRadar;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;

public final class WeatherRadarClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockEntityRendererFactories.register(WeatherRadar.MONITOR_ENTITY, RadarMonitorRenderer::new);
        ParticleFactoryRegistry.getInstance().register(WeatherRadar.RAIN_DROP, RegionalRainParticle.Factory::new);
        ClientPlayNetworking.registerGlobalReceiver(LocalRainPayload.ID,
                (payload, context) -> context.client().execute(() -> RegionalRainClient.receive(payload.intensity(), payload.snow())));
        ClientPlayNetworking.registerGlobalReceiver(CloudStatePayload.ID,
                (payload, context) -> context.client().execute(() -> WeatherCloudClient.receive(context.client(), payload)));
        WorldRenderEvents.AFTER_ENTITIES.register(WeatherCloudClient::render);
        ClientTickEvents.END_CLIENT_TICK.register(RegionalRainClient::tick);
    }
}
