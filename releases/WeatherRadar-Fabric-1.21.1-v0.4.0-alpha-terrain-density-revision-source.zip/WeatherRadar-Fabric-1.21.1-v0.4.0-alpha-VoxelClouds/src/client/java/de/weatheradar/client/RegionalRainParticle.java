package de.weatheradar.client;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.SimpleParticleType;

/** Small streak rendered only on clients that receive rain from the server. */
public final class RegionalRainParticle extends SpriteBillboardParticle {
    private RegionalRainParticle(ClientWorld world, double x, double y, double z,
                                 double windX, double windZ, SpriteProvider sprites) {
        super(world, x, y, z);
        this.velocityX = windX;
        this.velocityY = -0.87 - this.random.nextDouble() * 0.33;
        this.velocityZ = windZ;
        this.scale = 0.18F;
        this.maxAge = 12 + this.random.nextInt(10);
        this.gravityStrength = 0F;
        this.collidesWithWorld = true;
        this.setSprite(sprites);
        this.setColor(0.72F, 0.83F, 0.98F);
        this.setAlpha(0.80F);
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;
        if (this.age++ >= this.maxAge) {
            this.markDead();
            return;
        }
        this.move(this.velocityX, this.velocityY, this.velocityZ);
        if (this.onGround) this.markDead();
    }

    public static final class Factory implements ParticleFactory<SimpleParticleType> {
        private final SpriteProvider sprites;

        public Factory(SpriteProvider sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientWorld world,
                                       double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ) {
            return new RegionalRainParticle(world, x, y, z, velocityX, velocityZ, sprites);
        }
    }
}
