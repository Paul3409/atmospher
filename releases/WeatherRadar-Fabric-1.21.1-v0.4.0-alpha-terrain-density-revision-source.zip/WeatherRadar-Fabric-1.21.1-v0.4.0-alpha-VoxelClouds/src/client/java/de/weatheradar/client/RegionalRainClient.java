package de.weatheradar.client;

import de.weatheradar.WeatherRadar;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

/**
 * Local-only rain particles. No global rain flag or biome alteration.
 * The server supplies the true intensity at the player's coordinates once per second.
 */
public final class RegionalRainClient {
    private static final Random RANDOM = new Random();
    private static ClientWorld activeWorld;
    private static float targetIntensity;
    private static boolean snow;
    private static float smoothedIntensity;

    private RegionalRainClient() {}

    public static void receive(float intensity, boolean isSnow) {
        snow = isSnow;
        targetIntensity = MathHelper.clamp(intensity, 0F, 1F);
    }

    public static void tick(MinecraftClient client) {
        if (client.world != activeWorld) {
            activeWorld = client.world;
            targetIntensity = 0F;
            snow = false;
            smoothedIntensity = 0F;
            return;
        }
        if (client.world == null || client.player == null || client.isPaused()) return;
        smoothedIntensity += (targetIntensity - smoothedIntensity) * 0.13F;
        if (smoothedIntensity < 0.025F) return;
        // Keep this bounded on weaker computers (at most 18 new particles per tick).
        int drops = Math.min(18, (int) (smoothedIntensity * 14 + RANDOM.nextFloat() * 4));
        for (int i = 0; i < drops; i++) {
            double dx = (RANDOM.nextDouble() - 0.5) * 22;
            double dz = (RANDOM.nextDouble() - 0.5) * 22;
            double x = client.player.getX() + dx;
            double z = client.player.getZ() + dz;
            // Sample sky access near ground/player so rain never goes through indoor roofs.
            BlockPos beneath = BlockPos.ofFloored(x, client.player.getY() + 1.0, z);
            if (!client.world.isSkyVisible(beneath)) continue;
            double y = client.player.getY() + 4.0 + RANDOM.nextDouble() * 7.0;
            if (snow) client.world.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 0.008, -0.01, 0.004);
            else client.world.addParticle(WeatherRadar.RAIN_DROP, x, y, z, 0.025, 0, 0.012);
        }
    }
}
