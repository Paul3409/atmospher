package de.weatheradar.client;

import java.util.ArrayList;
import java.util.List;

/**
 * Independent original voxel geometry generator. No Minecraft API dependencies.
 * A coherent 3D density field describes each cloud. Only exposed voxel faces
 * are emitted and adjacent coplanar faces are greedily merged.
 * No source code is taken from Simple Clouds.
 */
public final class CloudVoxelModel {
    private CloudVoxelModel() {}

    /** Local-space quad with one axis-aligned normal; min/max are its bounds. */
    public record Quad(float x0, float y0, float z0, float x1, float y1, float z1, int face) {}
    public record Model(List<Quad> quads, int filledVoxels, int exposedFaces, int nx, int ny, int nz) {}
    /** Immutable terrain clearance expressed in local cloud-space blocks. */
    public record TerrainProfile(int nx, int nz, float[] clearance) {
        public TerrainProfile {
            if (clearance.length != nx * nz) throw new IllegalArgumentException("Invalid terrain profile");
        }
        float at(int x, int z) { return clearance[z * nx + x]; }
    }

    // -X +X -Y +Y -Z +Z
    public static final int NEG_X = 0, POS_X = 1, NEG_Y = 2, POS_Y = 3, NEG_Z = 4, POS_Z = 5;

    public static Model generate(long seed, float radius, float coverage, boolean distant,
                                 float stau, float lee) {
        int nx = xResolution(distant);
        int nz = zResolution(distant);
        return generate(seed, radius, coverage, distant, stau, lee,
                new TerrainProfile(nx, nz, new float[nx * nz]));
    }

    /**
     * Builds an opaque surface from a continuous 3-D density field.  Terrain is
     * supplied as a sampled clearance map so this CPU-only class remains safe
     * to execute away from the Minecraft render and world threads.
     */
    public static Model generate(long seed, float radius, float coverage, boolean distant,
                                 float stau, float lee, TerrainProfile terrain) {
        int nx = xResolution(distant);
        int nz = zResolution(distant);
        int ny = distant ? 8 : 12;
        if (terrain.nx != nx || terrain.nz != nz) throw new IllegalArgumentException("Wrong terrain resolution");
        // A cloud's displayed footprint follows its server-owned storm cell.
        float widthX = Math.min(265, Math.max(72, radius * 1.55f));
        float widthZ = widthX * 0.78f;
        float height = 27f + Math.max(0f, coverage) * 20f + stau * 11f;
        float sx = widthX / nx, sy = height / ny, sz = widthZ / nz;
        boolean[][][] filled = new boolean[nx][ny][nz];
        int voxelCount = 0;
        double seedX = ((seed & 0xffffL) / 65535.0) * 65.0;
        double seedZ = (((seed >>> 16) & 0xffffL) / 65535.0) * 65.0;
        double rain = clamp(coverage, 0, 1);
        double leeFactor = 1.0 - 0.30 * clamp(lee, 0, 1);
        for (int ix = 0; ix < nx; ix++) {
            double x = 2.0 * (ix + 0.5) / nx - 1.0;
            for (int iz = 0; iz < nz; iz++) {
                double z = 2.0 * (iz + 0.5) / nz - 1.0;
                double edgeNoise = fbm(x * 3.2 + seedX, z * 3.2 + seedZ, 0.4, seed);
                double edgeWarp = 0.09 * edgeNoise
                        + 0.065 * fbm(x * 7.0 + seedX, z * 7.0 + seedZ, 4.1, seed + 19);
                double distance = Math.hypot(x / 0.92, z / 0.95);
                double boundary = 0.93 + edgeWarp;
                // Separate softly-shaped rising towers built into ONE solid volume.
                double towerA = Math.exp(-square((x + 0.30) / 0.29) - square((z + 0.04) / 0.38));
                double towerB = Math.exp(-square((x - 0.23) / 0.34) - square((z - 0.18) / 0.32));
                double towerC = Math.exp(-square((x - 0.05) / 0.46) - square((z + 0.35) / 0.28));
                double terrainBottom = Math.max(0.0, terrain.at(ix, iz)) / height;
                double topFraction = (0.29 + (1.0 - Math.min(1.0, distance)) * 0.14
                        + towerA * (0.43 + rain * 0.18)
                        + towerB * (0.27 + rain * 0.10) + towerC * 0.17
                        + 0.055 * edgeNoise + 0.065 * stau) * leeFactor;
                double bottomFraction = 0.055 + 0.018 * edgeNoise + terrainBottom;
                for (int iy = 0; iy < ny; iy++) {
                    double y = (iy + 0.5) / ny;
                    double volNoise = fbm(x * 4.8 + seedX, z * 4.8 + seedZ,
                            y * 4.7 + 11.7, seed + 41);
                    double detail = fbm(x * 12.0 + seedX, z * 12.0 + seedZ,
                            y * 10.0 + 3.1, seed + 97);
                    // Delicate 3D noise distorts visible edges and cloud-tops,
                    // but doesn't drill holes through the middle of the volume.
                    double edgeAtHeight = boundary - 0.115 * y + 0.045 * volNoise + 0.018 * detail;
                    double top = topFraction + 0.052 * volNoise + 0.020 * detail;
                    // Detail only erodes the outer shell; it cannot turn the cloud into
                    // transparent intersecting boxes or tunnel through its dense core.
                    double density = (edgeAtHeight - distance) * 2.3 + (top - y) * 1.8
                            + (y - bottomFraction) * 1.25 + detail * 0.10;
                    boolean opaque = y >= bottomFraction && y <= top && density > 0.12;
                    filled[ix][iy][iz] = opaque;
                    if (opaque) voxelCount++;
                }
            }
        }
        ArrayList<Quad> mesh = new ArrayList<>();
        int exposed = 0;
        // Each normal plane is greedy-meshed independently; no interior faces.
        for (int face = 0; face < 6; face++) {
            int layers = face < 2 ? nx : face < 4 ? ny : nz;
            int nu = face < 2 ? nz : nx;
            int nv = face < 2 ? ny : face < 4 ? nz : ny;
            for (int layer = 0; layer < layers; layer++) {
                boolean[][] mask = new boolean[nu][nv];
                for (int u = 0; u < nu; u++) {
                    for (int v = 0; v < nv; v++) {
                        int x, y, z;
                        if (face < 2) { x = layer; y = v; z = u; }
                        else if (face < 4) { x = u; y = layer; z = v; }
                        else { x = u; y = v; z = layer; }
                        int dx = face == NEG_X ? -1 : face == POS_X ? 1 : 0;
                        int dy = face == NEG_Y ? -1 : face == POS_Y ? 1 : 0;
                        int dz = face == NEG_Z ? -1 : face == POS_Z ? 1 : 0;
                        mask[u][v] = occupied(filled, x, y, z)
                                && !occupied(filled, x + dx, y + dy, z + dz);
                        if (mask[u][v]) exposed++;
                    }
                }
                for (int v = 0; v < nv; v++) {
                    for (int u = 0; u < nu; u++) {
                        if (!mask[u][v]) continue;
                        int uw = 1, vh = 1;
                        while (u + uw < nu && mask[u + uw][v]) uw++;
                        outer: while (v + vh < nv) {
                            for (int q = 0; q < uw; q++) if (!mask[u + q][v + vh]) break outer;
                            vh++;
                        }
                        for (int qq = u; qq < u + uw; qq++)
                            for (int rr = v; rr < v + vh; rr++) mask[qq][rr] = false;
                        mesh.add(quad(face, layer, u, v, uw, vh, nx, nz, sx, sy, sz));
                    }
                }
            }
        }
        return new Model(List.copyOf(mesh), voxelCount, exposed, nx, ny, nz);
    }

    public static int xResolution(boolean distant) { return distant ? 16 : 26; }
    public static int zResolution(boolean distant) { return distant ? 14 : 22; }

    private static Quad quad(int face, int layer, int u, int v, int uw, int vh,
                             int nx, int nz, float sx, float sy, float sz) {
        if (face == NEG_X || face == POS_X) {
            float x = (layer + (face == POS_X ? 1 : 0) - nx / 2f) * sx;
            float z0 = (u - nz / 2f) * sz, z1 = (u + uw - nz / 2f) * sz;
            return new Quad(x, v * sy, z0, x, (v + vh) * sy, z1, face);
        }
        if (face == NEG_Y || face == POS_Y) {
            float y = (layer + (face == POS_Y ? 1 : 0)) * sy;
            float x0 = (u - nx / 2f) * sx, x1 = (u + uw - nx / 2f) * sx;
            float z0 = (v - nz / 2f) * sz, z1 = (v + vh - nz / 2f) * sz;
            return new Quad(x0, y, z0, x1, y, z1, face);
        }
        float z = (layer + (face == POS_Z ? 1 : 0) - nz / 2f) * sz;
        return new Quad((u - nx / 2f) * sx, v * sy, z,
                (u + uw - nx / 2f) * sx, (v + vh) * sy, z, face);
    }

    private static boolean occupied(boolean[][][] map, int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < map.length
                && y < map[0].length && z < map[0][0].length && map[x][y][z];
    }

    // Deterministic smooth trilinear value noise in 3D.
    private static double fbm(double x, double z, double y, long seed) {
        return (valueNoise(x, z, y, seed) * 0.69
                + valueNoise(x * 2.07, z * 2.07, y * 2.07, seed + 13) * 0.31);
    }

    private static double valueNoise(double x, double z, double y, long seed) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z), iy = (int) Math.floor(y);
        double fx = smooth(x - ix), fz = smooth(z - iz), fy = smooth(y - iy);
        double l = lerp(lerp(hash(ix, iz, iy, seed), hash(ix + 1, iz, iy, seed), fx),
                lerp(hash(ix, iz + 1, iy, seed), hash(ix + 1, iz + 1, iy, seed), fx), fz);
        double r = lerp(lerp(hash(ix, iz, iy + 1, seed), hash(ix + 1, iz, iy + 1, seed), fx),
                lerp(hash(ix, iz + 1, iy + 1, seed), hash(ix + 1, iz + 1, iy + 1, seed), fx), fz);
        return lerp(l, r, fy);
    }

    private static double hash(long x, long z, long y, long seed) {
        long n = seed ^ (x * 0x9E3779B97F4A7C15L) ^ (z * 0xC2B2AE3D27D4EB4FL)
                ^ (y * 0x165667B19E3779F9L);
        n ^= n >>> 30; n *= 0xBF58476D1CE4E5B9L;
        n ^= n >>> 27; n *= 0x94D049BB133111EBL;
        n ^= n >>> 31;
        return ((n >>> 11) * 0x1.0p-53) * 2.0 - 1.0;
    }

    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }
    private static double smooth(double t) { return t * t * (3.0 - 2.0 * t); }
    private static double clamp(double d, double min, double max) { return Math.max(min, Math.min(max, d)); }
    private static double square(double x) { return x * x; }
}
