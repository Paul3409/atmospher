# WeatherRadar 0.4.0-alpha – Voxel Clouds

Minecraft **1.21.1**, **Fabric**, **Java 21**. Gradle über Windows-CMD, **ohne Gradle Wrapper**.

## Ziel

Ein eigenständiges regionales Wettersystem mit deinem Wasser-/Temperatur-Ansatz und dem vorhandenen 2×2-Radarnetzwerk. Version 0.4 ersetzt die alten, sich überlagernden transparenten Wolkenquader durch **eine originale dreidimensionale Voxel-Dichtefläche**. Es ist eine **stilistische Annäherung** an die eingereichten Simple-Clouds-Referenzbilder, **keine Portierung und keine Kopie** des Simple-Clouds-Quellcodes. Insbesondere gibt es noch kein hochauflösendes GPU-Compute-Rendering und noch keine volumetrischen Lichtstreueffekte.

## Was ist neu in dieser Überarbeitung?

- `CloudVoxelModel.java`: eigenständiges prozedurales **3D-Noise-Dichtefeld** mit Makroform, mehreren organischen Aufwölbungen und zwei räumlichen Detailfrequenzen. Der Detailnoise erodiert nur die Oberfläche; er kann weder Löcher durch das Volumen noch überlappende transparente Quader erzeugen.
- Für jeden gefüllten Voxel werden nur die sichtbaren Außenflächen ausgegeben. Ein **Greedy-Mesher** vereinigt benachbarte koplanare Flächen, wodurch weniger Grafikelemente erforderlich sind.
- **Undurchsichtige** weiß-graue Oberflächen statt transparenter, überlappender Quader. Lichthelle Oberseiten und dunklere Unterseiten. Das Stufenmuster bleibt als beabsichtigter Minecraft-Stil erkennbar.
- **Luv/Lee und Terrain-Clearance:** Der Client tastet für jede horizontale Voxelspalte das gesamte Wolkenfeld ab. Diese unveränderliche Clearance-Karte hebt oder entfernt nur die betroffenen unteren Voxel über Bergrücken – keine pauschale Teleportation des ganzen Körpers. Der Windvergleich vor/hinter der Zelle steuert weiterhin Stau und Lee-Ausdünnung.
- **Zwei Detailstufen**, **Wolkenmesh-Caching** und ein einzelner Hintergrund-Worker. Die Welt wird ausschließlich im Render-Thread abgetastet; das Dichtefeld und das Greedy-Meshing laufen danach asynchron. Maximal zwölf Wolkenzellen und zwei neue Aufträge je Renderbild begrenzen die Last.
- Der Farbübergabeweg im Radarmonitor wurde auf explizite RGBA-Kanäle umgestellt, damit die Karte nicht durch Farbkanal-Fehlinterpretation rot wird.
- Der fehleranfällige `VanillaCloudMixin` aus Version 0.3.0 bleibt entfernt.

## Was bleibt erhalten?

- Der 2×2-Radarmonitor und die beiden Modi, das 1.000-Blöcke-Netzwerk, 200-Blöcke-Radarmessradius und 20-Sekunden-Intervall.
- Nur über zusammenhängenden **mittelgroßen oder großen Wasserflächen** können neue Wetterzellen entstehen. Kleiner 3×3-Wasserpool reicht nicht.
- Eigene vereinfachte Temperaturen Tw und T850, `DeltaT = Tw - T850` und die Schwellenwertlogik.
- Winddrift, Aufladung über Wasser, Lake-Effect-Boost an der Küste und Abbau über Land.
- Radar, Regen-/Schneepartikel und Wolken werden von **denselben serverseitigen Wetterzellen** angetrieben.

## Installation / Build

1. Sicherheitskopie deiner Minecraft-Welt anfertigen.
2. ZIP entpacken. CMD **im Verzeichnis mit `build.gradle`** öffnen.
3. Diesen Befehl benutzen (keine `gradlew`-Datei):

   ```bat
   "C:\Gradle\gradle-8.14.6\bin\gradle.bat" clean build --no-daemon --stacktrace
   ```

4. **Nur bei `BUILD SUCCESSFUL`** die Datei `build\libs\weatheradar-0.4.0-alpha.jar` nach `%appdata%\.minecraft\mods` kopieren. **Nicht** `*-sources.jar`.
5. Die alte `weatheradar-0.3.2-alpha.jar` und andere frühere `weatheradar*.jar` aus `mods` entfernen. Die passende Fabric API muss installiert sein.
6. In Minecraft unter **Grafikeinstellungen → Wolken: AUS** wählen, denn die Vanilla-Wolken werden noch nicht automatisch deaktiviert. Dieser Verzicht auf ein Mixin verhindert den früheren bekannten Crashpfad.

## Test

- Für gezielte Tests an einen mindestens ungefähr 50×50 Blöcke großen See/Ozean gehen, dessen Chunks geladen sind.
- `/weatheradar water` zeigt Wasserquelle, Tw/T850 und DeltaT.
- `/weatheradar coldair` senkt die fiktive obere Lufttemperatur nur für Tests.
- `/weatheradar rain` erzeugt **nur dann** eine neue Zelle, wenn qualifiziertes Wasser mit ausreichendem DeltaT vorhanden ist.
- `/weatheradar status` zeigt Zellanzahl und örtliche Wetterwerte.
- `/weatheradar normalair` stellt die Testtemperatur zurück.
- `/weatheradar clear` löscht umliegende Zellen und pausiert deren automatische Neubildung kurz.
- Eine Radarstation neben dem See und einen Monitor im Netzwerk platzieren. Neue Niederschlagswerte erscheinen beim nächsten Scan.
- Wolken mit Blick auf einen hohen Berg prüfen: Vor der Luv-Seite, über dem Grat, und auf der Leeseite.

## Bekannte Grenzen / ehrlicher Teststatus

- **Der vollständige Gradle-Build konnte in dieser Umgebung nicht bis zur Kompilierung gelangen:** Loom und seine Abhängigkeiten wurden aufgelöst, der Download der Minecraft-Dateien scheitert jedoch nach drei Versuchen an der eingeschränkten Netzumgebung. Ein Minecraft-Clientstart war deshalb ebenfalls nicht möglich. Die Geo­metrie-Testklasse ist enthalten, konnte hier aber nicht separat gestartet werden, weil im Container nur eine Java-Laufzeit ohne `javac` verfügbar ist. Es werden keine nicht durchgeführten Tests als bestanden behauptet.
- Die Form ähnelt eher blockigem, zusammenhängendem Cumulus als detailliertem GPU-volumetrischem Simple Clouds; ein pixelgenauer Gleichstand mit deinen Bildern ist noch nicht erreicht.
- Die Terrain-Clearance folgt der Meshauflösung (nah 26×22, fern 16×14) und wird nur bei Mesh-Neuberechnung aktualisiert. Extrem schmale, nicht geladene oder unmittelbar nach einer Aktualisierung gebaute Hindernisse können in Ausnahmen weiterhin berührt werden. Der Luv-/Lee-Effekt ist bewusst eine Näherung, keine Flüssigkeitssimulation.
- Der Server erzeugt in dieser Version noch keine komplett eigenständigen unabhängigen Schönwetter-Cumuluswolken ohne Wetterzellen. Sie entstehen über die vorhandenen Wasser-Wetterzellen.
- Das globale Minecraft-Vanilla-Wetter ist noch nicht vollständig ersetzt; der regionale Regen ist ein eigener Partikeleffekt.
- Das bisherige Persistenzformat `weatheradar_weather_v3` wird weiter verwendet.

## Quellverweis / Urheberrecht

Technische Inspiration (nur Prinzip, **kein Code übernommen**): https://github.com/nonamecrackers2/simple-clouds – dessen README erklärt voxelbasierte Noise-Volumen und GPU-Compute-Meshing. Simple Clouds steht unter PolyForm Perimeter 1.0.1 und hat gesonderte Rechtebedingungen. Unsere Cloud-Implementierung ist eigenständig geschrieben und benutzt stattdessen CPU-Noise + Greedy-Meshing für Minecraft 1.21.1/Fabric.
