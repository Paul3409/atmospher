import dev.atmosphere.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import javax.imageio.ImageIO;
/** Orthographic alpha projection of the actual cloud volume; no game renderer. */
public class CondensationPreview {
 public static void main(String[] args)throws Exception{
  var im=new BufferedImage(1100,600,BufferedImage.TYPE_INT_RGB);var g=im.createGraphics();
  g.setColor(new Color(136,177,220));g.fillRect(0,0,1100,600);
  var mask=ImageIO.read(new File("src/main/resources/assets/atmosphere/textures/environment/condensation.png"));
  for(int panel=0;panel<2;panel++){
   var mesh=new CloudGeometry.Point[73][113];
   for(int j=0;j<=72;j++)for(int i=0;i<=112;i++){
    if(panel==0)mesh[j][i]=CloudGeometry.point(19,j*Math.PI/72,i*Math.PI*2/112,160,120,140,125,1,0,0);
    else{var p=SupercellGeometry.point(42,j/72.0,i*Math.PI*2/112,270,260,355,1,0,.8,.6);
     mesh[j][i]=new CloudGeometry.Point(p.x(),p.y(),p.z(),p.nx(),p.ny(),p.nz());}
   }
   var puffs=new ArrayList<>(CloudCondensation.volume(mesh,2));
   puffs.sort(Comparator.comparingDouble(p->-(-p.x()*.6+p.z()*.8)));
   double scale=panel==0?1:.60,cx=panel==0?230:760,cy=panel==0?400:510;
   for(var p:puffs){
    var sprite=new BufferedImage(128,128,BufferedImage.TYPE_INT_ARGB);
    int c=(int)(195*p.shade());
    for(int y=0;y<128;y++)for(int x=0;x<128;x++)sprite.setRGB(x,y,((int)((mask.getRGB(x,y)>>>24)*.88)<<24)|(c<<16)|(c<<8)|Math.min(255,c+8));
    int x=(int)(cx+(p.x()*.8+p.z()*.6)*scale),y=(int)(cy-p.y()*scale);
    int w=Math.max(2,(int)(p.width()*2*scale)),h=Math.max(2,(int)(p.height()*2*scale));
    g.drawImage(sprite,x-w/2,y-h/2,w,h,null);
   }
  }
  g.setColor(Color.BLACK);g.drawString("1.2.11 mathematische Kondensationsprojektion - KEIN Ingame-Bild; ohne Perspektive / Wetternebel",15,22);
  g.drawString("Trockene Wolke: gefuelltes Volumen",50,560);g.drawString("Superzelle: dicht ueberlappende Kondensation",580,560);
  g.dispose();ImageIO.write(im,"png",new File(args[0]));
 }
}
